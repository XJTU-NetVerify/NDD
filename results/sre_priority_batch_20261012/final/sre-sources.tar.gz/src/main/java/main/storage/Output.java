package main.storage;

import main.Controller;

import java.nio.file.Path;
import java.util.Objects;

public class Output {
    public Path _outputBase;
    public Path _log;
    public Path _fib;
    public Path _rib;
    public Path _spec;
    public Path _prob;

    public Output(Path outputBase,
                  Path log,
                  Path fib,
                  Path rib,
                  Path spec,
                  Path prob) {
        _outputBase = outputBase;
        _log = log;
        _fib = fib;
        _rib = rib;
        _spec = spec;
        _prob = prob;
    }

    public static class Builder {
        public Path _outputBase;
        public Path _log;
        public Path _fib;
        public Path _rib;
        public Path _spec;
        public Path _prob;

        public Builder setOutputBase(Path outputBase) {
            _outputBase = outputBase;
            return this;
        }

        public Builder setLog(Path log) {
            _log = log;
            return this;
        }

        public Builder setFib(Path fib) {
            _fib = fib;
            return this;
        }

        public Builder setRib(Path rib) {
            _rib = rib;
            return this;
        }

        public Builder setSpec(Path spec) {
            _spec = spec;
            return this;
        }

        public Builder setProb(Path prob) {
            _prob = prob;
            return this;
        }

        public Output build() {
            return new Output(Objects.requireNonNull(_outputBase),
                    _log == null ? _outputBase.resolve("log" + Controller.ID + ".txt") : _log,
                    _fib == null ? _outputBase.resolve("fib") : _fib,
                    _rib == null ? _outputBase.resolve("rib") : _rib,
                    _spec == null ? _outputBase.resolve("spec") : _spec,
                    _prob == null ? _outputBase.resolve("prob") : _prob);
        }
    }
}
