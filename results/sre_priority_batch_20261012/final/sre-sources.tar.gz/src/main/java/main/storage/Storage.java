package main.storage;

import main.SRELogger;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.PatternLayout;
import util.TimeUtil;

import java.nio.file.Path;
import java.util.HashSet;

public class Storage {
    public static String TODAY = TimeUtil.getDate();

    public Input input;
    public Output output;

    public Storage(Path inputBase, Path outputBase) {
        input = new Input.Builder().setInputBase(inputBase).build();
        output = new Output.Builder().setOutputBase(outputBase != null ? outputBase: inputBase.resolve("out").resolve(TODAY)).build();
    }

    public Storage(Input input, Output output) {
        this.input = input;
        this.output = output;
    }

    public static HashSet<Path> initializedLog = new HashSet<>();

    public void init() {
        if (!initializedLog.contains(output._log)) {
            PatternLayout layout = new PatternLayout();
            layout.setConversionPattern("%p %d{yyyy/MM/dd HH:mm:ss,SSS}  %m%n");

            FileAppender appender = new FileAppender();
            appender.setEncoding("UTF-8");
            appender.setThreshold(Level.INFO);
            appender.setAppend(true);
            appender.setImmediateFlush(true);
            appender.setLayout(layout);
            appender.setFile(output._log.toString());
            appender.activateOptions();

            SRELogger.addAppender(appender);

            initializedLog.add(output._log);
        }
    }
}
