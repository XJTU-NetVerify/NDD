package controlplane.process.ospf;

import multimap.HashBasedTable;
import multimap.Table;
import controlplane.network.NDDPort;
import controlplane.network.Port;
import sre.ndd.NDD;

public class NDDOspfTopology {
    public Table<NDDOspfProcess, NDDOspfProcess, NDDOspfEdge> edges;
    Table<NDDOspfProcess, NDDPort, NDDOspfNeighborConfig> configs;

    public NDDOspfTopology() {
        this.edges = HashBasedTable.create();
        this.configs = HashBasedTable.create();
    }

    public void addEdge(NDDOspfNeighborConfig n1, NDDOspfNeighborConfig n2, int tc) {
        NDDOspfEdge e1 = new NDDOspfEdge(n1, n2, tc);
        NDDOspfEdge e2 = new NDDOspfEdge(n2, n1, tc);
        edges.put(n1.process, n2.process, e1);
        edges.put(n2.process, n1.process, e2);
    }

    public void addNeighborConfig(NDDOspfNeighborConfig config) {
        configs.put(config.process, config.port, config);
    }

    public NDDOspfNeighborConfig getNeighborConfig(NDDOspfProcess process, NDDPort port) {
        return configs.get(process, port);
    }

    public Table<NDDOspfProcess, NDDOspfProcess, NDDOspfEdge> getEdges() {
        return edges;
    }

    public Table<NDDOspfProcess, NDDPort, NDDOspfNeighborConfig> getConfigs() {
        return configs;
    }
}
