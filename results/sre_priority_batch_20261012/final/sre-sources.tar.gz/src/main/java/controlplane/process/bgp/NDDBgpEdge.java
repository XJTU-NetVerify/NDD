package controlplane.process.bgp;

import sre.ndd.NDD;

public class NDDBgpEdge {
    NDDBgpNeighborConfig src;
    NDDBgpNeighborConfig dst;
    int tc;

    public NDDBgpEdge(NDDBgpNeighborConfig src, NDDBgpNeighborConfig dst, int tc) {
        this.src = src;
        this.dst = dst;
        this.tc = tc;
    }

    public void setTC(int tc) {
        this.tc = tc;
    }

    public NDDBgpNeighborConfig getSrc() {
        return src;
    }

    public NDDBgpNeighborConfig getDst() {
        return dst;
    }

    public int getTC() {
        return tc;
    }
}
