package controlplane.process.ospf;

public class OspfIntfSetting {
    int area;
    int cost;
    boolean passive;
    int process;

    public OspfIntfSetting(int area, int cost, boolean passive, int process) {
        this.area = area;
        this.cost = cost;
        this.passive = passive;
        this.process = process;
    }

    public int getArea() {
        return area;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        if (cost <= 0) throw new IllegalArgumentException("OSPF cost must be positive");
        this.cost = cost;
    }

    public boolean isPassive() {
        return passive;
    }

    public int getProcess() {
        return process;
    }
}
