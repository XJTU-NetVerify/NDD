package controlplane.route;

import controlplane.network.Port;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import main.Controller;

import java.util.Objects;

public abstract class DynamicRoute extends Route{
    // propagation path
    Path<String> _path;

    boolean _dirty;

    public DynamicRoute(
            Prefix prefix,
            Ip nextHop,
            Port outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            SortedMultiList list,
            Path<String> path,
            boolean dirty
    ) {
        super(prefix, nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list);
        _path = path;
        _dirty = dirty;
    }

    public Path<String> getPath() {
        return _path;
    }

    int _listTCOld;
    /**
     * the only caller of
     * @see DynamicRoute#setListTC(int)
     * is
     * @see bdd.BDDTCWrapper#calTC(SortedMultiList, boolean)
     * set _dirty = true if _listTC changes
     */
    @Override
    public void setListTC(int tc) {
        Controller.bddManager.deref(_listTCOld);
        _listTCOld = _listTC;
        _listTC = tc;
        _dirty = _listTCOld != _listTC;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        DynamicRoute that = (DynamicRoute) o;
        return Objects.equals(_path, that._path);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), _path);
    }

    public boolean dirty() {
        return _dirty;
    }

    public void setDirty(boolean dirty) {
        _dirty = dirty;
    }
}
