package controlplane.process.ospf;

import controlplane.network.Port;

public class OspfNeighborConfig {
    OspfProcess process;
    OspfIntfSetting intfSetting;
    Port port;

    public OspfNeighborConfig(OspfProcess process, OspfIntfSetting intfSetting, Port port) {
        this.process = process;
        this.intfSetting = intfSetting;
        this.port = port;
    }
}
