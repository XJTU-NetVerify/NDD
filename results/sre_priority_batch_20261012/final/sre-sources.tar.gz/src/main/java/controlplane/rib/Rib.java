package controlplane.rib;

import controlplane.network.Port;
import controlplane.process.Process;
import controlplane.route.Route;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import datamodel.list.SortedMultiListOwner;
import dataplane.fib.Fib;
import dataplane.fib.ForwardingRule;
import main.Controller;
import multimap.HashBasedTable;
import multimap.HashMultimap;
import multimap.ImmutableList;
import multimap.Multimap;
import multimap.Table;

import org.jetbrains.annotations.NotNull;

import multimap.javax.annotation.Nonnull;
import multimap.javax.annotation.Nullable;
import java.util.*;

public class Rib implements SortedMultiListOwner {
    /** From batfish FibImpl: Helps perform recursive route resolution and maintain the route chain */
    private static final class ResolutionTreeNode {
        private final @Nonnull Route _route;
        private final @Nullable Ip _finalNextHopIp;

        private final @Nonnull List<ResolutionTreeNode> _children;

        /** Use static factories for sanity */
        private ResolutionTreeNode(@NotNull Route route, @Nullable Ip finalNextHopIp, @NotNull List<ResolutionTreeNode> children) {
            _route = route;
            _finalNextHopIp = finalNextHopIp;
            _children = children;
        }

        static ResolutionTreeNode withParent(Route route, @Nullable ResolutionTreeNode parent, @Nullable Ip finalNextHopIp) {
            ResolutionTreeNode child = new ResolutionTreeNode(route, finalNextHopIp, new LinkedList<>());
            if (parent != null) {
                parent.addChild(child);
            }
            return child;
        }

        static ResolutionTreeNode root(@Nonnull Route route) {
            return new ResolutionTreeNode(route, null, new LinkedList<>());
        }

        @Nonnull
        public Route getRoute() {
            return _route;
        }

        @Nullable
        public Ip getFinalNextHopIp() {
            return _finalNextHopIp;
        }

        @Nonnull
        public List<ResolutionTreeNode> getChildren() {
            return _children;
        }

        private void addChild(ResolutionTreeNode child) {
            _children.add(child);
        }
    }

    private static final int MAX_DEPTH = 10;

    Process process;
    Map<Prefix, SortedMultiList> rib;
    Multimap<Integer, Prefix> networks;

    public Rib() {
        rib = new TreeMap<>();
        networks = HashMultimap.create();
    }

    public Rib(Process process) {
        this();
        this.process = process;
    }

    public void insert(Route route) {
        Prefix prefix = route.getPrefix();
        SortedMultiList list;
        if (rib.containsKey(prefix)) {
            list = rib.get(prefix);
        }
        else {
            list = new SortedMultiList(this);
            networks.put(prefix.getPreLength(), prefix);
        }
        list.insert(route);
        rib.put(prefix, list);
    }

    public void insert(Prefix prefix, SortedMultiList routes) {
        rib.put(prefix, routes);
        networks.put(prefix.getPreLength(), prefix);
    }

    public void install(Rib globalRib, boolean ecmp) {
        HashSet<Prefix> prefixes = new HashSet<>();
        rib.forEach((prefix, routes) -> {
            if (!globalRib.getRib().containsKey(prefix)) {
                globalRib.insert(prefix, routes);
            }
            else {
                prefixes.add(prefix);
                routes.flat().forEach(route -> globalRib.insert((Route) route));
            }
        });
        prefixes.forEach(prefix -> {
            SortedMultiList list = globalRib.getRib().get(prefix);
            Controller.bddManager.getBDDTCWrapper().calTC(list, ecmp);
        });
    }

    public void install(Fib fib) {
        for (Prefix prefix : rib.keySet()) {
            SortedMultiList routes = rib.get(prefix);
            SortedMultiList fwdRules;
            if (routes.flat().stream().allMatch(item -> ((Route) item).getOutPort() != null)) {
                fwdRules = routes.stream()
                        .map(list ->
                                list
                                        .stream()
                                        .map(item -> (Route) item)
                                        .map(ForwardingRule::new)
                                        .collect(ArrayList<SortedMultiListItem>::new, ArrayList<SortedMultiListItem>::add, ArrayList<SortedMultiListItem>::addAll))
                        .collect(SortedMultiList::new, SortedMultiList::add, SortedMultiList::addAll);
            }
            else {
                fwdRules = new SortedMultiList();
                for (SortedMultiListItem item : routes.flat()) {
                    Route route = (Route) item;
                    if (route.getOutPort() == null) {
                        resolveRoute(route).forEach(fwdRules::insert);
                    }
                    else {
                        fwdRules.insert(new ForwardingRule(route));
                    }
                }
                Controller.bddManager.getBDDTCWrapper().calTC(fwdRules, fib.getRouter().ecmp());
                fwdRules.cleanDead();
            }
            fib.insert(prefix, fwdRules);
        }
    }

    public int[] cleanDeadRoute() {
        int total = 0;
        int remain = 0;
        Iterator<Map.Entry<Prefix, SortedMultiList>> itr = rib.entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry<Prefix, SortedMultiList> entry = itr.next();
            int[] statistic = entry.getValue().cleanDead();
            total += statistic[0];
            remain += statistic[1];
            if (entry.getValue().isEmpty()) itr.remove();
        }
        return new int[] {total, remain};
    }

    public int[] getStats() {
        int total = 0;
        int valid = 0;
        for (SortedMultiList list : rib.values()) {
            int[] tmp = list.getStats();
            total += tmp[0];
            valid += tmp[1];
        }
        return new int[] {total, valid};
    }

    /**
     * Helper function for computing "igp cost to next hop" for ebgp routes.
     * Longest prefix match. For a specific prefix length, a next hop ip can match at most one prefix.
     */
    public Table<Long, Port, Integer> query(Ip ip) {
        // (metric, out port) -> tc
        Table<Long, Port, Integer> tbl = HashBasedTable.create();
        int prefixLength = 32;
        int alMatched = 0;
        int nAlMatched = 0;
        for (Map.Entry<Prefix, SortedMultiList> entry : rib.entrySet()) {
            if (entry.getKey().getPreLength() != prefixLength) {
                prefixLength = entry.getKey().getPreLength();
                nAlMatched = Controller.bddManager.not(alMatched);
            }
            if (entry.getKey().ipMatch(ip)) {
                for (SortedMultiListItem item : entry.getValue().flat()) {
                    Route route = (Route) item;
                    int delta = Controller.bddManager.and(route.getListTC(), nAlMatched);
                    int tc = 0;
                    if (tbl.contains(route.getMetric(), route.getOutPort())) {
                        tc = tbl.get(route.getMetric(), route.getOutPort());
                    }
                    tc = Controller.bddManager.orTo(tc, delta);
                    tbl.put(route.getMetric(), route.getOutPort(), tc);
                    alMatched = Controller.bddManager.orTo(alMatched, route.getListTC());
                }
            }
        }
        return tbl;
    }

    /**
     * Attempt to resolve a RIB route down to an interface route.
     *
     * @param route {@link Route} with a next hop IP to be resolved.
     * @return A map (interface name -&gt; last hop IP -&gt; last taken route) for
     */
    public Set<ForwardingRule> resolveRoute(Route route) {
        ResolutionTreeNode resolutionRoot = ResolutionTreeNode.root(route);
        buildResolutionTree(
                route,
                Ip.AUTO,
                new HashSet<>(),
                0,
                resolutionRoot);
        Set<ForwardingRule> collector = new HashSet<>();
        collect(resolutionRoot, new Stack<>(), collector);
        return collector;
    }

    public void collect(ResolutionTreeNode node, Stack<Route> stack, Set<ForwardingRule> collector) {
        if (node.getChildren().isEmpty() && node.getFinalNextHopIp() != null) {
            collector.add(new ForwardingRule(node._finalNextHopIp, ImmutableList.copyOf(stack)));
            return;
        }
        stack.push(node._route);
        for (ResolutionTreeNode child : node.getChildren()) {
            collect(child, stack, collector);
        }
        stack.pop();
    }

    public void buildResolutionTree(Route route,
                                    Ip mostRecentNextHopIp,
                                    Set<Prefix> seenNetworks,
                                    int depth,
                                    ResolutionTreeNode treeNode) {
        Prefix network = route.getPrefix();
        if (seenNetworks.contains(network) || depth > MAX_DEPTH) {
            // Don't enter a resolution loop
            return;
        }
        Set<Prefix> newSeenNetworks = new HashSet<>(seenNetworks);
        newSeenNetworks.add(network);

        Port outPort = route.getOutPort();
        Ip nextHop = route.getNextHop();
        // Finally we have reached an interface route.
        if (outPort != null) {
            // Discard
            if (outPort.isBlackhole()) {
                ResolutionTreeNode.withParent(route, treeNode, Ip.AUTO);
            }
            else {
                // nextHop equals Ip.AUTO means this is a connected route.
                // otherwise, ospf route.
                ResolutionTreeNode.withParent(route, treeNode, nextHop.equals(Ip.AUTO) ? mostRecentNextHopIp : nextHop);
            }
        }
        else {
            // todo
            SortedMultiList matched = null;
            for (int preLen = 32; preLen >= 0 && matched == null; preLen--) {
                matched = query(nextHop, preLen);
            }
            if (matched != null) {
                // We have at least one valid longest-prefix match
                for (SortedMultiListItem matchedRoute : matched.flat()) {
                    buildResolutionTree(
                            (Route) matchedRoute,
                            nextHop,
                            newSeenNetworks,
                            depth + 1,
                            ResolutionTreeNode.withParent((Route) matchedRoute, treeNode, null));
                }
            }
        }
    }

    public SortedMultiList query(Ip ip, int prefixLength) {
        for (Prefix prefix : networks.get(prefixLength)) {
            if (prefix.ipMatch(ip)) return rib.get(prefix);
        }
        return null;
    }

    public Map<Prefix, SortedMultiList> getRib() {
        return rib;
    }

    public Process getProcess() {
        return process;
    }

    public void clear() {
        rib = null;
    }

    public void reset() {
        rib = new TreeMap<>();
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        rib.values().forEach(list -> builder.append(list.toString()).append("\n\n"));
        return builder.toString();
    }
}
