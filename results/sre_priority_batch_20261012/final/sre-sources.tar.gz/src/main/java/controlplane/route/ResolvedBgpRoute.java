package controlplane.route;

import controlplane.network.Port;
import controlplane.route.builder.BgpRouteBuilder;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.Objects;

public class ResolvedBgpRoute extends BgpRoute {
    long _igpCostToNextHop;

    public ResolvedBgpRoute(
            BgpRoute bgpRoute,
            Port outPort,
            long igpCostToNextHop,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            SortedMultiList list
    ) {
        super(bgpRoute._prefix, bgpRoute._nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list, bgpRoute._path, false, bgpRoute._origin, bgpRoute._localPreference, bgpRoute._ASPath, bgpRoute._med, bgpRoute._iAD, bgpRoute._eAD, bgpRoute._bgpRouteType);
        _igpCostToNextHop = igpCostToNextHop;
    }

    public long getIgpCostToNextHop() {
        return _igpCostToNextHop;
    }

    public BgpRoute prepareOut() {
        _dirty = false;
        return new BgpRouteBuilder()
                .setPrefix(_prefix)
                .setNextHop(_nextHop)
                .setPath(new Path<>(_path))
                .setOrigin(_origin)
                .setLocalPreference(_localPreference)
                .setASPath(new Path<>(_ASPath))
                .setMetric(_med)
                .setIAD(_iAD)
                .setEAD(_eAD)
                .setType(_bgpRouteType)
                .setListTC(_listTC)
                .build();
    }

    @Override
    public int compareTo(@NotNull SortedMultiListItem o) {
        int tmp = super.compareTo(o);
        if (o instanceof ResolvedBgpRoute && tmp == 0) {
            return Comparator
                    .comparing(ResolvedBgpRoute::getIgpCostToNextHop, Comparator.reverseOrder())
                    .compare(this, (ResolvedBgpRoute) o);
        }
        else {
            return tmp;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        ResolvedBgpRoute that = (ResolvedBgpRoute) o;
        return _igpCostToNextHop == that._igpCostToNextHop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), _igpCostToNextHop);
    }
}
