package controlplane.process.bgp;

import controlplane.route.BgpRoute;
import controlplane.route.Path;
import controlplane.route.ResolvedBgpRoute;
import controlplane.route.builder.BgpRouteBuilder;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.SortedMultiList;
import jdd.bdd.NodeTableStats;
import main.Configuration;
import main.Controller;
import main.SRELogger;
import util.MemorizeUtil;
import util.TimeUtil;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import application.config2spec.Config2spec;

/**
 * Bgp-Routers can be divided into three categories:
 * Internal-Router (IR), Border-Router (BR) and Route-Reflector (RR)
 * Since Internal-Routers only receive announcements from internal peers and
 * have no route reflector clients.
 * They are passive in the sense that they never send any announcement.
 * To determine the converged state of BGP, it suffices to simulate interactions
 * between BR and RR
 * Once converged, we can run one BGP round to let IRs get routes.
 *
 * Samuel Steffen, Timon Gehr, Petar Tsankov, Laurent Vanbever, and Martin
 * Vechev. 2020. Probabilistic Verification of Network Configurations.
 */
public class BgpExecutor {
    public static int iteration = 0;
    public static int total = 0;
    public static int remain = 0;

    public static void execute(BgpTopology topology, BgpProcess announcer) {
        announcer.begin();
        iteration = Integer.max(iterate(topology), iteration);
        finalRound(topology);
        int[] stats = cleanDeadRoutes(topology);
        total = stats[0];
        remain = stats[1];
    }

    public static void execute(BgpTopology topology) {
        TimeUtil bgpTimer = new TimeUtil();
        bgpTimer.begin();

        // first round
        topology.edges.rowKeySet().forEach(BgpProcess::begin);
        // CountRoutes(topology);

        // iterate
        int iteration = iterate(topology);

        // final round: reflector to client
        finalRound(topology);
        // printBgpRib(topology);
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ITERATION] " + iteration);

        int[] stats = cleanDeadRoutes(topology);
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ROUTE] total: " + stats[0] + " remain: " + stats[1]);
        // System.out.print(stats[1] + "\t");

        // if (Configuration.checkCorrectness)
        OutputRoutes(topology, 10000, "execute");
        // CountRoutes(topology);

        bgpTimer.end(SRELogger.LEVEL.INFO, "");
    }

    public static void printBgpRib(BgpTopology topology) {
        int sum1 = 0;
        int sum2 = 0;
        for (BgpProcess process : topology.edges.rowKeySet()) {
            for (SortedMultiList lists : process.getRib().getRib().values()) {
                for (ArrayList list : lists) {
                    sum1 += list.size();
                }
            }
            sum2 += process.outQueue.size();
        }
        // System.out.println("NDDBgpExecutor Bgp Routes:" + sum1);
        // System.out.println("NDDBgpExecutor Out Queue:" + sum2);
    }

    public static void CountRoutes(BgpTopology topology) {
        int count = 0;
        for (BgpProcess process : topology.edges.rowKeySet()) {
            for (SortedMultiList lists : process.getRib().getRib().values()) {
                for (ArrayList list : lists) {
                    for (Object route : list) {
                        count++;
                    }
                }
            }
        }
        System.out.println("count " + count);
    }

    public static void OutputRoutes(BgpTopology topology, int i, String s) {
        try {
            String path = "/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/exp/fattree/bgp/" + Config2spec.dataset + "/OutBDD/test/routes_"
                    + i + "_" + s;
            FileWriter fw = new FileWriter(path, false);
            PrintWriter pw = new PrintWriter(fw);
            for (BgpProcess process : topology.edges.rowKeySet()) {
                if (!process.router.getRouterName().equals("edge-46")) {
                    continue;
                }
                for (SortedMultiList lists : process.getRib().getRib().values()) {
                    for (ArrayList list : lists) {
                        for (Object route : list) {
                            pw.println(((ResolvedBgpRoute) route).toString());
                            pw.flush();
                        }
                    }
                }
            }
            pw.close();
        } catch (IOException e) {
            // TODO: handle exception
        }
    }

    // public static int r = 3;

    public static int iterate(BgpTopology topology) {
        boolean converged = false;
        int iteration = 0;
        long start = System.nanoTime();

        List<String> tmp = new LinkedList<>();

        while (!converged
                && iteration < Configuration.MAX_SRC_ROUNDS
                && (System.nanoTime() - start) / 1e9 < Configuration.SRC_TIMEOUT_SECONDS) {
            // converged = true;
            // // exchange routes between bgp neighbors
            // topology.edges.rowMap().forEach((p, map) -> p.routeOut(map, x -> x !=
            // BgpNeighborConfig.NeighborType.REFLECTOR));
            // // bgp local step
            // for (BgpProcess process : topology.edges.rowKeySet()) {
            // converged = process.updateRIB() & converged;
            // }

            // System.out.println();
            // bgp local step
            // System.out.println("Round " + (iteration + 1));
            // if (iteration + 1 == r)
            // OutputRoutes(topology, iteration + 1, "before_execute");
            // int t = 0;
            for (BgpProcess process : topology.edges.rowKeySet()) {
                process.updateRIB();
                // if (iteration + 1 == r)
                // OutputRoutes(topology, iteration + 1, t + process.router.getRouterName() +
                // "before");
                process.routeOut(topology.edges.row(process), x -> x != BgpNeighborConfig.NeighborType.REFLECTOR);
                // if (iteration + 1 == r)
                // OutputRoutes(topology, iteration + 1, t + process.router.getRouterName() +
                // "after");
                // int[] stats = getStats(topology);
                // NodeTableStats usage = Controller.bddManager.getBDD().getStats();
                // tmp.add(stats[0] + "\t" +
                // stats[1] + "\t" +
                //// String.format("%.2f", (usage.get_table_size() -
                // usage.get_free_nodes_count()) * 100.0 / Integer.MAX_VALUE) + "\t" +
                // (usage.get_table_size() - usage.get_free_nodes_count()) + "\t" +
                // (System.nanoTime() - start) / 1e9);
                // t++;
            }
            converged = topology.edges.rowKeySet().stream()
                    .allMatch(process -> process.inQueue.isEmpty() && process.outQueue.isEmpty());
            iteration++;
            // if (iteration == r)
            // OutputRoutes(topology, iteration, "after_execute");
            // CountRoutes(topology);
            // int sumBgpRoute=0;
            // for(BgpProcess process : topology.edges.rowKeySet())
            // {
            // for(SortedMultiList lists : process.getRib().getRib().values())
            // {
            // for(ArrayList list : lists)
            // {
            // sumBgpRoute+=list.size();
            // }
            // }
            // }
            // System.out.println(sumBgpRoute+" bgp route");
        }

        int[] stats = getStats(topology);
        NodeTableStats usage = Controller.bddManager.getBDD().getStats();

        tmp.add(stats[0] + "\t" +
                stats[1] + "\t" +
                // String.format("%.2f", (usage.get_table_size() - usage.get_free_nodes_count())
                // * 100.0 / Integer.MAX_VALUE) + "\t" +
                (usage.get_table_size() - usage.get_free_nodes_count()) + "\t" +
                (System.nanoTime() - start) / 1e9);
        try {
            File file = Controller.storage.output._outputBase
                    .resolve("stats")
                    .resolve(Controller.MF + ".csv")
                    .toFile();
            MemorizeUtil.creatFileIfAbsent(file);
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            for (String str : tmp) {
                writer.write(str + "\n");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return iteration;
    }

    public static void finalRound(BgpTopology topology) {
        topology.edges.rowKeySet().stream().filter(BgpProcess::isRR).forEach(p -> {
            p.rrFinalRound();
            p.routeOut(topology.edges.row(p), x -> x == BgpNeighborConfig.NeighborType.REFLECTOR);
        });
        topology.edges.rowKeySet().stream().filter(BgpProcess::isIR).forEach(BgpProcess::updateRIB);
    }

    public static int[] cleanDeadRoutes(BgpTopology topology) {
        int total = 0;
        int remain = 0;
        for (BgpProcess process : topology.edges.rowKeySet()) {
            int[] statistic = process.rib.cleanDeadRoute();
            total += statistic[0];
            remain += statistic[1];
        }
        // topology.edges.rowKeySet().forEach(process -> process.rib.cleanDeadRoute());
        return new int[] { total, remain };
    }

    public static int[] getStats(BgpTopology topology) {
        int total = 0;
        int valid = 0;
        for (BgpProcess process : topology.edges.rowKeySet()) {
            int[] statistic = process.rib.getStats();
            total += statistic[0];
            valid += statistic[1];
        }
        return new int[] { total, valid };
    }

    public static void propagate(BgpRoute route, BgpEdge edge) {
        if (route.getType() == BgpRoute.BgpRouteType.FROM_IBGP_NEIGHBOR
                && edge.src.neighborType != BgpNeighborConfig.NeighborType.EBGP) {
            return;
        }
        if (route.getType() == BgpRoute.BgpRouteType.FROM_ROUTE_REFLECTOR) {
            return;
        }

        int newTC = Controller.bddManager.and(route.getListTC(), edge.getTC());

        if (newTC != 0) {
            Path<String> path = new Path<>(route.getPath());
            path.add(edge.src.process.router.getRouterName());

            BgpRoute newRoute = new BgpRouteBuilder()
                    .setPrefix(route.getPrefix())
                    .setNextHop(route.getNextHop())
                    .setArriveTC(newTC)
                    .setPath(path)
                    .setOrigin(route.getOrigin())
                    .setASPath(new Path<>(route.getASPath()))
                    .setType(edge.src.neighborType.bgpRouteType)
                    .build();

            /*
             * EBGP:
             * 1. Change "next hop"
             * 2. Extend "AS path"
             * IBGP:
             * set "local preference"
             */
            if (edge.src.neighborType == BgpNeighborConfig.NeighborType.EBGP) {
                newRoute.setNextHop(edge.src.localIp);
                newRoute.getASPath().add(edge.src.process.asNumber);
            } else {
                newRoute.setLocalPreference(route.getLocalPreference());
            }

            edge.dst.process.routeIn(edge.src.process.router, newRoute);
        }
    }

}
