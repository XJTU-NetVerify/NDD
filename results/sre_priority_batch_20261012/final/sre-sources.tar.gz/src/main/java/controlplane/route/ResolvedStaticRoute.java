package controlplane.route;

import controlplane.network.Port;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import main.Controller;
import util.BDDUtil;

import java.util.List;
import java.util.stream.Collectors;

public class ResolvedStaticRoute extends StaticRoute {
    List<Route> _resolutionSteps;

    public ResolvedStaticRoute(
            Prefix prefix,
            Ip nextHop,
            Port outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            SortedMultiList list,
            int AD,
            List<Route> resolutionSteps
    ) {
        super(
                prefix,
                nextHop,
                outPort,
                arriveTC,
                listTC,
                innerIdx,
                outerIdx,
                list,
                AD
        );
        _resolutionSteps = resolutionSteps;
    }

    public ResolvedStaticRoute(List<Route> resolutionSteps) {
        this(
                resolutionSteps.get(0)._prefix,
                resolutionSteps.get(resolutionSteps.size() - 1)._nextHop,
                resolutionSteps.get(resolutionSteps.size() - 1)._outPort,
                BDDUtil.andInBatch(Controller.bddManager.getBDD(), resolutionSteps.stream().map(Route::getListTC).collect(Collectors.toSet())),
                0,
                -1,
                -1,
                null,
                // todo
                resolutionSteps.get(0).getAD(),
                resolutionSteps
        );
    }
}
