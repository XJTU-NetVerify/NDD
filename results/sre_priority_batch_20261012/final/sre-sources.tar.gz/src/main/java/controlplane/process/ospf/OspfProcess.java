package controlplane.process.ospf;

import multimap.Streams;
import controlplane.network.Router;
import controlplane.process.Process;
import controlplane.rib.Rib;
import controlplane.route.*;
import controlplane.route.builder.OspfRouteBuilder;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import main.Controller;

import java.util.*;
import java.util.stream.Collectors;

public class OspfProcess implements Process {
    Router router;
    int processId;

    Deque<OspfRoute> inQueue = new LinkedList<>();
    Deque<OspfRoute> outQueue = new LinkedList<>();

    Rib rib;

    HashSet<RoutingProtocol> redistributions = new HashSet<>();
    HashSet<Prefix> networks = new HashSet<>();

    boolean valid = false;

    public OspfProcess(Router router, int processId) {
        this.router = router;
        this.rib = new Rib(this);
        this.processId = processId;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public boolean valid() {
        return valid;
    }

    public void begin() {
        if (valid) {
            networks.stream().filter(Prefix::isInterested).forEach(prefix -> {
                OspfRoute ospfRoute = new OspfRouteBuilder().setPrefix(prefix).setListTC(1).build();
                outQueue.add(ospfRoute);
            });
            redistribute();
        }
    }

    void redistribute() {
        HashSet<OspfRoute> generatedRoutes = new HashSet<>();
        if (redistributions.contains(RoutingProtocol.CONNECTED)) {
            router.getConnectedRib().getRib().values().forEach(list -> {
                ConnectedRoute cr = (ConnectedRoute) list.flat().iterator().next();
                generatedRoutes.add(redistribute(cr));
            });
        }
        if (redistributions.contains(RoutingProtocol.STATIC)) {
            Streams.concat(
                    router.getConditionalStaticRib().getRib().entrySet().stream(),
                    router.getUnconditionalStaticRib().getRib().entrySet().stream()
            )
                    // do not redistribute static routes with prefix 0.0.0.0/0
                    .filter(entry -> !entry.getKey().equals(Prefix.ZERO))
                    .forEach(entry -> entry.getValue().flat().forEach(item -> {
                        StaticRoute sr = (StaticRoute) item;
                        generatedRoutes.add(redistribute(sr));
                    }));
        }
        generatedRoutes.forEach(generatedRoute -> {
            rib.insert(generatedRoute);
            outQueue.add(generatedRoute);
        });
    }

    OspfRoute redistribute(Route route) {
        return new OspfRouteBuilder()
                .setPrefix(route.getPrefix())
                .setNextHop(route.getNextHop())
                .setOutPort(route.getOutPort())
                .setMetric(20)
                .setArriveTC(1)
                .setListTC(1)
                .build();
    }

    public void routeIn(OspfRoute route) {
        inQueue.add(route);
    }

//    public boolean updateRIB() {
//        HashSet<Prefix> prefixes = new HashSet<>();
//        HashSet<OspfRoute> routes = new HashSet<>();
//
//        while (!inQueue.isEmpty()) {
//            OspfRoute route = inQueue.pollFirst();
//            if (rib.insert(route)) {
//                Controller.bddManager.getBDDTCWrapper().calTC(route, router.ecmp());
//                routes.add(route);
//            }
//            else {
//                prefixes.add(route.getPrefix());
//            }
//        }
//
//        prefixes.forEach(prefix -> {
//            SortedMultiList list = rib.getRib().get(prefix);
//            Controller.bddManager.getBDDTCWrapper().calTC(list, router.ecmp());
//            list.flat().stream().map(item -> (OspfRoute) item).filter(OspfRoute::dirty).forEach(routes::add);
//        });
//
//        routes.forEach(this::insertOutQueue);
//
//        return outQueue.isEmpty();
//    }

    public boolean updateRIB() {
        HashSet<Prefix> prefixes = new HashSet<>();

        List<OspfRoute> ors = new ArrayList<>();
        while (!inQueue.isEmpty()) {
            OspfRoute route = inQueue.pollFirst();
            ors.add(route);
            prefixes.add(route.getPrefix());
        }
        ors.sort(OspfRoute::compareTo);
        ors.forEach(or -> rib.insert(or));

        prefixes.forEach(prefix -> {
            SortedMultiList list = rib.getRib().get(prefix);
            Controller.bddManager.getBDDTCWrapper().calTC(list, router.ecmp());
            list.flat().stream().map(item -> (OspfRoute) item).filter(OspfRoute::dirty).forEach(this::insertOutQueue);
        });

        rib.getRib().values().forEach(SortedMultiList::resetIdx);

        return outQueue.isEmpty();
    }

    public void routeOut(Map<OspfProcess, OspfEdge> edges) {
        Iterator<OspfRoute> itr = outQueue.iterator();
        while (itr.hasNext()) {
            OspfRoute route = itr.next();

            edges.forEach((p, e) -> {
                // avoid propagation path loop
                if (!route.getPath().contains(p.router.getRouterName())) {
                    OspfExecutor.propagate(route, e);
                }
            });

            itr.remove();
        }
    }

    @Override
    public void insertOutQueue(Route route) {
        if (route instanceof OspfRoute) {
            ((OspfRoute) route).setDirty(false);
            outQueue.add((OspfRoute) route);
        }
    }

    public void addRedistribution(RoutingProtocol rp) {
        redistributions.add(rp);
    }

    public void addNetwork(Prefix prefix) {
        networks.add(prefix);
    }

    /** Helper function, checking whether this ospf process will announce any prefix */
    public HashSet<Prefix> getPrefixes() {
        HashSet<Prefix> prefixes = new HashSet<>(networks);
        // route redistribution
        if (redistributions.contains(RoutingProtocol.CONNECTED)) {
            prefixes.addAll(router.getConnectedRib().getRib().keySet());
        }
        if (redistributions.contains(RoutingProtocol.STATIC)) {
            prefixes.addAll(
                    Streams.concat(
                            router.getConditionalStaticRib().getRib().entrySet().stream(),
                            router.getUnconditionalStaticRib().getRib().entrySet().stream()
                    )
                            // do not redistribute static routes with prefix 0.0.0.0/0
                            .filter(entry -> !entry.getKey().equals(Prefix.ZERO))
                            .map(Map.Entry::getKey)
                            .collect(Collectors.toSet())
            );
        }
        if (redistributions.contains(RoutingProtocol.LOOPBACK)) {
            prefixes.add(router.getLoopback().getPrimaryIpAddress().toPrefix());
        }
        return prefixes;
    }

    @Override
    public Router getRouter() {
        return router;
    }

    @Override
    public Rib getRib() {
        return rib;
    }

    public int getProcessId() {
        return processId;
    }

    public void clear() {
        inQueue = null;
        outQueue = null;
        redistributions = null;
        networks = null;
        rib.clear();
    }

    public void reset() {
        inQueue = new LinkedList<>();
        outQueue = new LinkedList<>();
        redistributions = new HashSet<>();
        networks = new HashSet<>();
        rib.reset();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OspfProcess that = (OspfProcess) o;
        return processId == that.processId &&
               Objects.equals(router, that.router);
    }

    @Override
    public int hashCode() {
        return Objects.hash(router, processId);
    }
}
