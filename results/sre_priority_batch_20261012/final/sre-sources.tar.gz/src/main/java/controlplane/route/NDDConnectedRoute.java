package controlplane.route;

import sre.ndd.NDD;

import controlplane.network.NDDPort;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;

public class NDDConnectedRoute extends NDDRoute {
    int _AD;

    public NDDConnectedRoute(
            Prefix prefix,
            Ip nextHop,
            NDDPort outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            NDDSortedMultiList list,
            int AD
    ) {
        super(prefix, nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list);
        _AD = AD;
    }

    @Override
    public RoutingProtocol getProtocol() {
        return RoutingProtocol.CONNECTED;
    }

    @Override
    public int getAD() {
        return _AD;
    }

    @Override
    public Long getMetric() {
        return 0L;
    }

    @Override
    public void setListTC(int tc) {
    }

    @Override
    public String toString() {
        return _prefix.toString()
                + "\t" + _outPort
                + "\tConnected";
    }
}
