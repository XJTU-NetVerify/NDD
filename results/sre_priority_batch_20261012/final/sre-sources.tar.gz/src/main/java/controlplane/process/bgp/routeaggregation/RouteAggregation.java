package controlplane.process.bgp.routeaggregation;

import multimap.HashMultimap;
import multimap.Multimap;
import controlplane.process.bgp.BgpProcess;
import controlplane.route.BgpRoute;
import controlplane.route.ResolvedBgpRoute;
import controlplane.route.builder.BgpRouteBuilder;
import controlplane.route.builder.ResolvedBgpRouteBuilder;
import datamodel.ipv4.Prefix;
import main.Controller;
import util.BDDUtil;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class RouteAggregation {
    BgpProcess process;

    Prefix prefix;
    boolean suppressOnly;

    Multimap<BgpRoute, BgpRoute> aggrRoutes = HashMultimap.create();

    public RouteAggregation(BgpProcess process, Prefix prefix, boolean suppressOnly) {
        this.process = process;
        this.prefix = prefix;
        this.suppressOnly = suppressOnly;
    }

    public boolean aggregate(BgpRoute specRoute) {
        if (specRoute.getPrefix().getPreLength() > prefix.getPreLength() &&
                prefix.prefixMatchLoose(specRoute.getPrefix())) {
            BgpRoute aggrRoute = new BgpRouteBuilder()
                    .setPrefix(prefix)
                    .build();
            aggrRoutes.put(aggrRoute, specRoute);
            return suppressOnly;
        }
        else {
            return false;
        }
    }

    public void insertInQueue() {
        for (Map.Entry<BgpRoute, Collection<BgpRoute>> entry : aggrRoutes.asMap().entrySet()) {
            BgpRoute aggrRoute = entry.getKey();
            Set<Integer> tcs = entry.getValue().stream().map(BgpRoute::getArriveTC).collect(Collectors.toSet());
            int tc = BDDUtil.orInBatch(Controller.bddManager.getBDD(), tcs);
            if (tc != aggrRoute.getArriveTC()) {
                aggrRoute.setArriveTC(tc);
                aggrRoute.setOutPort(process.getRouter().getBlackhole());
                process.routeIn(process.getRouter(), aggrRoute);
            }
        }
    }
}
