package controlplane.process.bgp.routemap;

import datamodel.ipv4.Prefix;
import controlplane.route.BgpRoute;

import java.util.Vector;

public class RouteMapMatch {
    public enum MatchType {
        PrefixList
    }
    MatchType type;
    Object match;

    public RouteMapMatch(MatchType type, Object match) {
        this.type = type;
        this.match = match;
    }

    public boolean match(BgpRoute route) {
        if (type == MatchType.PrefixList) {
            return matchPrefixList(route);
        }
        return false;
    }

    public boolean matchPrefixList(BgpRoute route) {
        for (Prefix prefix : (Vector<Prefix>) match) {
            if (prefix.prefixMatchStrict(route.getPrefix())) return true;
        }
        return false;
    }
}
