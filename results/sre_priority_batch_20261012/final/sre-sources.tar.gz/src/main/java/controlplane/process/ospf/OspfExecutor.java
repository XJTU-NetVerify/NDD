package controlplane.process.ospf;

import controlplane.route.OspfRoute;
import controlplane.route.Path;
import controlplane.route.builder.OspfRouteBuilder;
import main.Configuration;
import main.Controller;
import main.SRELogger;
import util.TimeUtil;


public class OspfExecutor {
    public static int iteration = 0;
    public static int total = 0;
    public static int remain = 0;
    public static void execute(OspfTopology topology, OspfProcess announcer) {
        announcer.begin();
        iteration = Integer.max(iterate(topology), iteration);
        int[] stats = cleanDeadRoutes(topology);
        total = stats[0];
        remain = stats[1];
    }

    public static void execute(OspfTopology topology) {
        TimeUtil igpTimer = new TimeUtil();
        igpTimer.begin();

        // first round
        topology.edges.rowKeySet().forEach(OspfProcess::begin);

        // iterate
        int iteration = iterate(topology);
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ITERATION] " + iteration);

        int[] stats = cleanDeadRoutes(topology);
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ROUTE] total: " + stats[0] + " remain: " + stats[1]);
//        System.out.print(stats[1] + "\t");

        igpTimer.end(SRELogger.LEVEL.INFO, "");
    }

    public static int iterate(OspfTopology topology) {
        boolean converged = false;
        int iteration = 0;
        long start = System.nanoTime();
        while (
                !converged
                && iteration < Configuration.MAX_SRC_ROUNDS
                && (System.nanoTime() - start) / 1e9 < Configuration.SRC_TIMEOUT_SECONDS
        ) {
            converged = true;

            // route exchange between ospf neighbors
            topology.edges.rowMap().forEach(OspfProcess::routeOut);

            // ospf local step
            for (OspfProcess process : topology.edges.rowKeySet()) {
                converged = process.updateRIB() & converged;
            }

            iteration++;
        }
        return iteration;
    }

    public static int[] cleanDeadRoutes(OspfTopology topology) {
        int total = 0;
        int remain = 0;
        for (OspfProcess process : topology.edges.rowKeySet()) {
            int[] statistic = process.getRib().cleanDeadRoute();
            total += statistic[0];
            remain += statistic[1];
        }
//        topology.edges.rowKeySet().forEach(process -> process.getRib().cleanDeadRoute());
        return new int[] {total, remain};
    }

    public static void propagate(OspfRoute route, OspfEdge edge) {

        int newTC = Controller.bddManager.and(route.getListTC(), edge.getTC());

        if (newTC != 0) {
            Path<String> path = new Path<>(route.getPath());
            path.add(edge.src.process.router.getRouterName());

            OspfRoute newRoute = new OspfRouteBuilder()
                    .setPrefix(route.getPrefix())
                    .setNextHop(edge.src.port.getIp())
                    .setOutPort(edge.dst.port)
                    .setArriveTC(newTC)
                    .setPath(path)
                    .setMetric(route.getMetric() + edge.dst.intfSetting.cost)
                    .build();

            edge.dst.process.routeIn(newRoute);
        }

    }
}
