package controlplane.network;

public enum State {
    UP,
    DOWN,
    SYMBOLIC
}
