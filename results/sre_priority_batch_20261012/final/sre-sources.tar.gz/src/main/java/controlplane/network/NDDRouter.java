package controlplane.network;

import sre.ndd.NDD;
import controlplane.process.bgp.BgpProcess;
import controlplane.process.bgp.NDDBgpProcess;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.process.ospf.OspfProcess;
import controlplane.rib.NDDRib;
import controlplane.rib.Rib;
import controlplane.route.*;
import controlplane.route.builder.*;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.ipv4.IpAddress;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.SortedMultiList;
import dataplane.fib.Fib;
import dataplane.fib.NDDFib;
import main.Controller;
import main.NDDController;
import util.BDDUtil;
import util.NDDUtil;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;

public class NDDRouter {
    String routerName;
    int asNumber;
    long routerId;

    Map<PortName, NDDPort> ports;
    NDDPort loopback;
    NDDPort blackhole;
    NDDPort sink;

    HashMap<Integer, NDDOspfProcess> ospfProcesses;
    NDDBgpProcess bgpProcess;

    NDDRib connectedRib;
    NDDRib localRib;
    NDDRib conditionalStaticRib;
    NDDRib unconditionalStaticRib;
    NDDRib globalRib;
    NDDFib fib;

    int prefixBDD = NDD.getFalse();

    boolean ecmp = true;

    State _state = State.SYMBOLIC;

    public NDDRouter(String name, int number) {
        routerName = name;
        asNumber = number;
        ports = new HashMap<>();
        ospfProcesses = new HashMap<>();
        connectedRib = new NDDRib();
        localRib = new NDDRib();
        conditionalStaticRib = new NDDRib();
        unconditionalStaticRib = new NDDRib();
        globalRib = new NDDRib();
        fib = new NDDFib(this);

        // virtual port, for packets being dropped
        PortName bh = new PortName(routerName, "blackhole");
        blackhole = new NDDPort(bh, this, null, false);
        blackhole.blackhole = true;
        ports.put(bh, blackhole);

        // virtual port, for packets being accepted
        PortName s = new PortName(routerName, "sink");
        sink = new NDDPort(s, this, null, false);
        sink.sink = true;
        ports.put(s, sink);
    }

    public NDDRouter(String name, int number, long id) {
        this(name, number);
        routerId = id;
    }

    public void genConnectedRoute() {
        for (NDDPort port : ports.values()) {
            if (!port.blackhole && !port.sink) {
                HashSet<IpAddress> ipAddresses = new HashSet<>();
                ipAddresses.add(port.getPrimaryIpAddress());
                if (port.getSecondaryIpAddresses() != null) {
                    ipAddresses.addAll(port.getSecondaryIpAddresses());
                }
                for (IpAddress ipAddress : ipAddresses) {
                    NDDConnectedRoute connectedRoute = new NDDConnectedRouteBuilder()
                            .setPrefix(ipAddress.toPrefix())
                            .setNextHop(Ip.AUTO)
                            .setOutPort(port)
                            .setArriveTC(port.l3Edge == null ? NDD.getTrue() : port.l3Edge.getTC())
                            .setListTC(port.l3Edge == null ? NDD.getTrue() : port.l3Edge.getTC())
                            // .setArriveTC(NDD.NDDTrue)
                            // .setListTC(NDD.NDDTrue)
                            .build();
                    connectedRib.insert(connectedRoute);
                    if (ipAddress.getNetworkBits() < 32) {
                        NDDLocalRoute localRoute = new NDDLocalRouteBuilder()
                                .setPrefix(ipAddress.getIp().toPrefix())
                                .setNextHop(Ip.AUTO)
                                .setOutPort(port)
                                .setArriveTC(NDD.getTrue())
                                .setListTC(NDD.getTrue())
                                .build();
                        localRib.insert(localRoute);
                    }
                }
            }
        }
    }

    public void insertStaticRoute(NDDStaticRoute route) {
        if (route.getOutPort() != null) {
            // static routes with next-hop-interface, unconditional
            route.setNextHop(Ip.AUTO);
            unconditionalStaticRib.insert(route);
        } else if (route.getNextHop().equals(Ip.ZERO)) {
            // static routes with next-hop-ip 0.0.0.0, discard matching packets,
            // unconditional
            route.setNextHop(Ip.AUTO);
            route.setOutPort(blackhole);
            unconditionalStaticRib.insert(route);
        } else {
            // static routes with next-hop-ip, needs resolution
            conditionalStaticRib.insert(route);
        }
    }

    public void installOriginalRoutesToGlobalRib() {
        connectedRib.install(globalRib, ecmp);
        localRib.install(globalRib, ecmp);
        unconditionalStaticRib.install(globalRib, ecmp);
        conditionalStaticRib.install(globalRib, ecmp);
        globalRib.cleanDeadRoute();
    }

    public void installIgpRoutesToGlobalRib() {
        ospfProcesses.values().forEach(process -> process.getRib().install(globalRib, ecmp));
        globalRib.cleanDeadRoute();
    }

    public void installBgpRoutesToGlobalRib() {
        bgpProcess.getRib().install(globalRib, ecmp);
        globalRib.cleanDeadRoute();
    }

    public void installGlobalRibToFib() {
        globalRib.install(fib);
    }

    public int getPrefixBDD() {
        return NDD.isFalse(prefixBDD) ? prepare() : prefixBDD;
    }

    public String getRouterName() {
        return routerName;
    }

    public Map<PortName, NDDPort> getPorts() {
        return ports;
    }

    public NDDPort getLoopback() {
        return loopback;
    }

    public void setLoopback(NDDPort loopback) {
        this.loopback = loopback;
    }

    public NDDPort getBlackhole() {
        return blackhole;
    }

    public NDDPort getSink() {
        return sink;
    }

    public NDDRib getConnectedRib() {
        return connectedRib;
    }

    public NDDRib getConditionalStaticRib() {
        return conditionalStaticRib;
    }

    public NDDRib getUnconditionalStaticRib() {
        return unconditionalStaticRib;
    }

    public NDDRib getGlobalRib() {
        return globalRib;
    }

    public NDDFib getFib() {
        return fib;
    }

    public int getAsNumber() {
        return asNumber;
    }

    public long getRouterId() {
        return routerId;
    }

    public HashSet<Prefix> getPrefixes() {
        HashSet<Prefix> prefixes = new HashSet<>();
        ospfProcesses.values().forEach(process -> prefixes.addAll(process.getPrefixes()));
        if (bgpProcess != null) {
            prefixes.addAll(bgpProcess.getNetworks());
        }
        return prefixes;
    }

    int prepare() {
        prefixBDD = NDD.getFalse();
        for (Prefix prefix : getPrefixes()) {
            int cached = NDDController.bddManager.getBDDACLWrapper().encodeDstIPPrefix(prefix.getIp().asLong(),
                    prefix.getPreLength());
            int tmp1 = NDD.ref(cached);
            prefixBDD = NDDController.bddManager.orDerefBoth(tmp1, prefixBDD);
        }
        return prefixBDD;
    }

    public Ip getLoopBackIp() {
        return loopback.primaryIpAddress.getIp();
    }

    public void addPort(NDDPort port) {
        ports.put(port.getPortName(), port);
    }

    public void addOspfProcess(NDDOspfProcess ospfProcess) {
        ospfProcesses.put(ospfProcess.getProcessId(), ospfProcess);
    }

    public void setOspfProcesses(HashMap<Integer, NDDOspfProcess> ospfProcesses) {
        this.ospfProcesses = ospfProcesses;
    }

    public NDDOspfProcess getOspfProcess(int id) {
        return ospfProcesses.get(id);
    }

    public HashMap<Integer, NDDOspfProcess> getOspfProcesses() {
        return ospfProcesses;
    }

    public void setBgpProcess(NDDBgpProcess bgpProcess) {
        this.bgpProcess = bgpProcess;
    }

    public NDDBgpProcess getBgpProcess() {
        return bgpProcess;
    }

    public State getState() {
        return _state;
    }

    public void setState(State state) {
        _state = state;
    }

    public boolean ecmp() {
        return ecmp;
    }

    public void setValid(boolean valid) {
        ospfProcesses.values().forEach(process -> process.setValid(valid));
        if (bgpProcess != null)
            bgpProcess.setValid(valid);
    }

    public boolean valid() {
        boolean valid = false;
        if (bgpProcess != null)
            valid = bgpProcess.valid();
        valid = valid | ospfProcesses.values().stream().anyMatch(NDDOspfProcess::valid);
        return valid;
    }

    public void clear() {
        ospfProcesses.values().forEach(NDDOspfProcess::clear);
        if (bgpProcess != null)
            bgpProcess.clear();
        globalRib.clear();
        fib.clear();
        prefixBDD = NDD.getFalse();
    }

    public void reset() {
        ospfProcesses.values().forEach(NDDOspfProcess::reset);
        if (bgpProcess != null)
            bgpProcess.reset();
        globalRib.reset();
        fib.reset();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NDDRouter that = (NDDRouter) o;
        return java.util.Objects.equals(routerName, that.routerName);
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(routerName);
    }

    @Override
    public String toString() {
        return routerName + "\t" + asNumber + "\t" + routerId;
    }
}
