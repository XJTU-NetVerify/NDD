package controlplane.route;

import controlplane.network.Port;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;

public class StaticRoute extends Route {
    int _AD;

    public StaticRoute(
            Prefix prefix,
            Ip nextHop,
            Port outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            SortedMultiList list,
            int AD
    ) {
        super(prefix, nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list);
        _AD = AD;
    }

    @Override
    public RoutingProtocol getProtocol() {
        return RoutingProtocol.STATIC;
    }

    @Override
    public int getAD() {
        return _AD;
    }

    @Override
    public Long getMetric() {
        return 0L;
    }

    @Override
    public String toString() {
        return _prefix.toString()
               + "\t" + _outPort
               + "\t" + _nextHop
               + "\tStatic";
    }
}
