package controlplane.route;

import sre.ndd.NDD;

import controlplane.network.NDDPort;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;

public class NDDLocalRoute extends NDDConnectedRoute {
    public NDDLocalRoute(
            Prefix prefix,
            Ip nextHop,
            NDDPort outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            NDDSortedMultiList list,
            int AD
    ) {
        super(prefix, nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list, AD);
    }

    @Override
    public RoutingProtocol getProtocol() {
        return RoutingProtocol.LOCAL;
    }

    @Override
    public String toString() {
        return _prefix.toString()
                + "\t" + _outPort
                + "\tLocal";
    }
}
