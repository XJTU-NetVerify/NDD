package controlplane.process.bgp.routemap;

import controlplane.route.BgpRoute;
import controlplane.route.NDDBgpRoute;

public class NDDRouteMapAction {
    RouteMapAction.ActionType type;
    Object action;

    public NDDRouteMapAction(RouteMapAction.ActionType type, Object action) {
        this.type = type;
        this.action = action;
    }

    public void act(NDDBgpRoute route) {
        switch (type) {
            case Metric:
                break;
            case MetricType:
                break;
            case DefaultInterface:
                break;
            case Interface:
                break;
            case IpDefaultNextHop:
                break;
            case IpNextHop:
                break;
            case NextHop:
                break;
            case AsPath:
                break;
            case Community:
                break;
            case LocalPreference:
                route.setLocalPreference((int) action);
                break;
            case Weight:
                break;
            case Origin:
                break;
            case Tag:
                break;
        }
    }
}
