package controlplane.process.bgp.routemap;

import controlplane.route.BgpRoute;

import java.util.HashMap;
import java.util.Map;

public class RouteMap {
    Map<String, RouteMapRule> rules;

    public RouteMap() {
        rules = new HashMap<>();
    }

    public void addRule(RouteMapRule rule) {
        rules.put(rule.neighbor, rule);
    }

    /**
     * @param route - route coming in / out
     */
    public BgpRoute map(String neighbor, BgpRoute route) {
        RouteMapRule rule = rules.get(neighbor);
        if (rule != null) {
            route = rule.match(route);
        }
        return route;
    }
}
