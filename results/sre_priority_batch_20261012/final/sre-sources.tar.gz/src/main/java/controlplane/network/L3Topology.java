package controlplane.network;

import algorithm.graph.KEdgeComponentAlgorithm;
import controlplane.Owner;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import main.Controller;
import org.jgrapht.Graph;
import org.jgrapht.graph.Multigraph;

import java.util.Collection;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * Since jgrapht's min cut algorithm is not tested on multigraph,
 * we cannot guarantee the simulation of "links always up" will get the correct answer.
 * Fortunately, it is correct for our test cases.
 */
public class L3Topology {

    public Graph<Router, L3Edge> buildGraph(int k) {
        Graph<Router, L3Edge> graph = new Multigraph<>(L3Edge.class);
        _nodes.values().stream().filter(node -> node.getState() != State.DOWN).forEach(graph::addVertex);
        _l3Edges.forEach(link -> {
            if (link.getState() != State.DOWN) {
                Router v1 = _nodes.get(link.getSrc().getRouterName());
                Router v2 = _nodes.get(link.getDst().getRouterName());
                // encode link-always-up
                if (link.getState() == State.UP) {
                    for (int i = 0; i < k; i++) {
                        graph.addEdge(v1, v2, link);
                    }
                }
                else {
                    graph.addEdge(v1, v2, link);
                }
            }
        });
        return graph;
    }

    private Graph<Router, L3Edge> graph = null;
    private KEdgeComponentAlgorithm<Router, L3Edge> alg = null;
    /** k = MF + 1 */
    public Collection<Graph<Router, L3Edge>> getKEdgeComponent(int k) {
        if (graph == null) graph = buildGraph(Controller.MF + 1);
        if (alg == null) alg = new KEdgeComponentAlgorithm<>(graph);
        return alg.getKEdgeComponent(k);
    }

    TreeMap<String, Router> _nodes;
    TreeMap<PortName, Port> _ports;
    HashSet<L3Edge> _l3Edges;
    HashSet<Port> _edgePorts;
    HashSet<Router> _edgeRouters;
    int down = 0;

    Owner<Prefix, Router> _prefixOwners;
    Owner<Ip, Router> _ipOwners;

    public L3Topology(TreeMap<String, Router> nodes,
                      TreeMap<PortName, Port> ports,
                      HashSet<L3Edge> l3Edges,
                      HashSet<Port> edgePorts,
                      Owner<Prefix, Router> prefixOwners,
                      Owner<Ip, Router> ipOwners) {
        _nodes = nodes;
        _ports = ports;
        _l3Edges = l3Edges;
        _edgePorts = edgePorts == null ? new HashSet<>(_ports.values()) : edgePorts;
        _edgeRouters = edgePorts == null ? new HashSet<>(_nodes.values()) : edgePorts.stream().map(Port::getRouter).collect(Collectors.toCollection(HashSet::new));
        for (L3Edge e : _l3Edges) {
            if (e.getState() == State.DOWN) {
                down++;
            }
        }
        _prefixOwners = prefixOwners;
        _ipOwners = ipOwners;
    }

    public TreeMap<String, Router> getNodes() {
        return _nodes;
    }

    public HashSet<L3Edge> getL3Edges() {
        return _l3Edges;
    }
}
