package controlplane.process.bgp.routemap;

import controlplane.route.BgpRoute;
import controlplane.route.NDDBgpRoute;

import java.util.Vector;

public class NDDRouteMapPolicy {
    boolean permit;
    Vector<NDDRouteMapMatch> matches;
    Vector<NDDRouteMapAction> actions;

    public NDDRouteMapPolicy(boolean permit, Vector<NDDRouteMapMatch> matches, Vector<NDDRouteMapAction> actions) {
        this.permit = permit;
        this.matches = matches;
        this.actions = actions;
    }

    public boolean match(NDDBgpRoute route) {
        // match all packets
        if (matches == null || matches.isEmpty()) {
            return true;
        }
        else {
            for (NDDRouteMapMatch match : matches) {
                if (match.match(route)) {
                    return true;
                }
            }
            return false;
        }
    }

    public NDDBgpRoute act(NDDBgpRoute route) {
        if (permit) {
            if (actions != null) {
                for (NDDRouteMapAction action : actions) action.act(route);
            }
            return route;
        }
        else {
            return null;
        }
    }
}
