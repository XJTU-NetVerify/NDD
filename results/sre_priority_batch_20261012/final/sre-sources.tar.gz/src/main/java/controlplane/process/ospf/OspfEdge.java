package controlplane.process.ospf;

public class OspfEdge {
    OspfNeighborConfig src;
    OspfNeighborConfig dst;
    int tc;

    public OspfEdge(OspfNeighborConfig src, OspfNeighborConfig dst, int tc) {
        this.src = src;
        this.dst = dst;
        this.tc = tc;
    }

    public OspfNeighborConfig getSrc() {
        return src;
    }

    public OspfNeighborConfig getDst() {
        return dst;
    }

    public int getTC() {
        return tc;
    }
}
