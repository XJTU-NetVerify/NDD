package controlplane.route;

import sre.ndd.NDD;
import controlplane.network.NDDPort;
import controlplane.network.Port;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import jdd.bdd.BDD;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;

public class NDDBgpRoute extends NDDDynamicRoute {

    BgpRoute.OriginType _origin;
    int _localPreference;
    Path<Integer> _ASPath;
    long _med;
    int _iAD;
    int _eAD;

    public NDDBgpRoute(
            Prefix prefix,
            Ip nextHop,
            NDDPort outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            NDDSortedMultiList list,
            Path<String> path,
            boolean dirty,
            BgpRoute.OriginType origin,
            int localPreference,
            Path<Integer> ASPath,
            long med,
            int iAD,
            int eAD,
            BgpRoute.BgpRouteType bgpRouteType) {
        super(prefix, nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list, path, dirty);
        _origin = origin;
        _localPreference = localPreference;
        _ASPath = ASPath;
        _med = med;
        _iAD = iAD;
        _eAD = eAD;
        _bgpRouteType = bgpRouteType;
    }

    public NDDBgpRoute(NDDBgpRoute one) {
        this(
                one._prefix,
                one._nextHop,
                one._outPort,
                one._arriveTC,
                one._listTC,
                one._innerIdx,
                one._outerIdx,
                one._list,
                new Path<>(one._path),
                one._dirty,
                one._origin,
                one._localPreference,
                new Path<>(one._ASPath),
                one._med,
                one._iAD,
                one._eAD,
                one._bgpRouteType);
    }

    public void setLocalPreference(int lp) {
        _localPreference = lp;
    }

    public int getLocalPreference() {
        return _localPreference;
    }

    public void setMetric(long med) {
        _med = med;
    }

    @Override
    public Long getMetric() {
        return _med;
    }

    public Path<Integer> getASPath() {
        return _ASPath;
    }

    @Override
    public RoutingProtocol getProtocol() {
        return RoutingProtocol.BGP;
    }

    @Override
    public int getAD() {
        return _bgpRouteType == BgpRoute.BgpRouteType.FROM_EBGP_NEIGHBOR ? _eAD : _iAD;
    }

    public BgpRoute.OriginType getOrigin() {
        return _origin;
    }

    @Override
    public int compareTo(@NotNull NDDSortedMultiListItem o) {
        if (o instanceof NDDBgpRoute) {
            return Comparator
                    .comparing(NDDBgpRoute::getLocalPreference)
                    .thenComparing(r -> r._ASPath.size(), Comparator.reverseOrder())
                    .thenComparing(r -> r._origin._preference)
                    .thenComparing(NDDBgpRoute::getMetric, Comparator.reverseOrder())
                    .compare(this, (NDDBgpRoute) o);
        } else {
            return super.compareTo(o);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        if (!super.equals(o))
            return false;
        NDDBgpRoute bgpRoute = (NDDBgpRoute) o;
        return _localPreference == bgpRoute._localPreference &&
                _med == bgpRoute._med &&
                _iAD == bgpRoute._iAD &&
                _eAD == bgpRoute._eAD &&
                _origin == bgpRoute._origin &&
                Objects.equals(_ASPath, bgpRoute._ASPath) &&
                _bgpRouteType == bgpRoute._bgpRouteType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), _origin, _localPreference, _ASPath, _med, _iAD, _eAD, _bgpRouteType);
    }

    BgpRoute.BgpRouteType _bgpRouteType;

    public void setType(BgpRoute.BgpRouteType bgpRouteType) {
        _bgpRouteType = bgpRouteType;
    }

    public BgpRoute.BgpRouteType getType() {
        return _bgpRouteType;
    }

    @Override
    public String toString() {
        return _prefix.toString()
                + "\t" + _outPort
                + "\t" + _nextHop
                + "\t" + _localPreference
                + "\t" + _path
                + "\t" + _ASPath
                + "\t" + NDD.satCount(_arriveTC)
                + "\t" + NDD.satCount(_listTC)
                + "\tBGP";
    }
}