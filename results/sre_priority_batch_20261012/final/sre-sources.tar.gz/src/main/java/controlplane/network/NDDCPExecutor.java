package controlplane.network;

import main.Configuration;
import controlplane.Owner;
import controlplane.process.bgp.NDDBgpExecutor;
import controlplane.process.bgp.NDDBgpNeighborConfig;
import controlplane.process.bgp.NDDBgpProcess;
import controlplane.process.bgp.NDDBgpTopology;
import controlplane.process.ospf.NDDOspfExecutor;
import controlplane.process.ospf.NDDOspfNeighborConfig;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.process.ospf.NDDOspfTopology;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import main.NDDController;
import main.SRELogger;
import sre.ndd.NDD;
import multimap.Table;
import util.NDDUtil;
import util.TimeUtil;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;

public class NDDCPExecutor {
    NDDL3Topology _l3Topology;
    NDDOspfTopology _ospfTopology;
    NDDBgpTopology _bgpTopology;

    public NDDCPExecutor() {
    }

    public void init() {
        NDDCPUtil util = new NDDCPUtil(this);
        util.parseConfigs(NDDController.storage.input._config, NDDController.storage.input._acl);
        util.parseL3Topology(NDDController.storage.input._l3Edges, NDDController.storage.input._edgePorts);
        util.parseEnvironment(NDDController.storage.input._environment);
    }

    public void init(Path cfg, Path acl, Path topo, Path edgePorts, Path env) {
        NDDCPUtil util = new NDDCPUtil(this);
        util.parseConfigs(cfg, acl);
        util.parseL3Topology(topo, edgePorts);
        util.parseEnvironment(env);
    }

    public NDDCPExecutor(NDDL3Topology l3Topology, NDDOspfTopology ospfTopology, NDDBgpTopology bgpTopology) {
        _l3Topology = l3Topology;
        _ospfTopology = ospfTopology;
        _bgpTopology = bgpTopology;
    }

    public void genConnectedRoute() {
        // generate connected route
        _l3Topology._nodes.values().forEach(NDDRouter::genConnectedRoute);
    }

    public void buildOspfTopology() {
        TimeUtil timer = new TimeUtil();
        timer.begin();
        _l3Topology._l3Edges.forEach(l3edge -> {
            if (!NDD.isFalse(l3edge._nddVar)) {
                NDDRouter r1 = _l3Topology._nodes.get(l3edge._port1.getRouterName());
                NDDRouter r2 = _l3Topology._nodes.get(l3edge._port2.getRouterName());
                NDDPort p1 = _l3Topology._ports.get(l3edge._port1);
                NDDPort p2 = _l3Topology._ports.get(l3edge._port2);
                if (r1.ospfProcesses != null && r2.ospfProcesses != null) {
                    for (NDDOspfProcess process1 : r1.getOspfProcesses().values()) {
                        for (NDDOspfProcess process2 : r2.getOspfProcesses().values()) {
                            NDDOspfNeighborConfig c1 = _ospfTopology.getNeighborConfig(process1, p1);
                            NDDOspfNeighborConfig c2 = _ospfTopology.getNeighborConfig(process2, p2);
                            if (c1 != null && c2 != null) {
                                _ospfTopology.addEdge(c1, c2, l3edge._nddVar);
                            }
                        }
                    }
                }
            }
        });
        timer.end(SRELogger.LEVEL.INFO, "[TOPO]");
    }

    public void computeOspfRoutes() {
        NDDOspfExecutor.execute(_ospfTopology);
    }

    public void computeOspfRoutes(NDDOspfProcess announcer) {
        NDDOspfExecutor.execute(_ospfTopology, announcer);
    }

    public void buildBgpTopology() {
        TimeUtil timer = new TimeUtil();
        timer.begin();

        /*
         * consider single direction route reachability to build bgp neighbor
         * relationship
         */
        _bgpTopology.getIpEdges().cellSet().forEach(cell -> {
            Ip srcIp = cell.getRowKey();
            Ip dstIp = cell.getColumnKey();
            NDDRouter src = _l3Topology._ipOwners.getOne(srcIp);
            NDDRouter dst = _l3Topology._ipOwners.getOne(dstIp);
            if (src != null && dst != null) {
                if (!_bgpTopology.containsEdge(src.bgpProcess, dst.bgpProcess)) {
                    int tc = NDDUtil.orInBatch(src.globalRib.query(dstIp).values());
                    if (NDD.isFalse(tc))
                        tc = NDDUtil.orInBatch(dst.globalRib.query(srcIp).values());

                    NDDBgpNeighborConfig c1 = _bgpTopology.getNeighborConfig(src.bgpProcess, cell.getColumnKey());
                    NDDBgpNeighborConfig c2 = _bgpTopology.getNeighborConfig(dst.bgpProcess, cell.getRowKey());
                    _bgpTopology.addEdge(c1, c2, tc);
                }
            }
        });

        timer.end(SRELogger.LEVEL.INFO, "[TOPO]");
    }

    public void computeBgpRoutes() {
        NDDBgpExecutor.execute(_bgpTopology);
    }

    public void computeBgpRoutes(NDDBgpProcess announcer) {
        NDDBgpExecutor.execute(_bgpTopology, announcer);
    }

    public void installOriginalRoutes() {
        _l3Topology._nodes.values().forEach(NDDRouter::installOriginalRoutesToGlobalRib);
    }

    public void installIgpRoutes() {
        _l3Topology._nodes.values().forEach(NDDRouter::installIgpRoutesToGlobalRib);
    }

    public void installBgpRoutes() {
        _l3Topology._nodes.values().forEach(NDDRouter::installBgpRoutesToGlobalRib);
    }

    public void rib2fib() {
        _l3Topology._nodes.values().forEach(NDDRouter::installGlobalRibToFib);
    }

    public void generateDataPlane() {
        if (Configuration.ALL_IN_ONE)
            generateDataPlaneAllInOne();
        else
            generateDataPlaneOneByOne();
    }

    public void generateDataPlaneOneByOne() {
        SRELogger.pushContext("CPE OBO");
        TimeUtil timer = new TimeUtil();
        timer.begin();

        genConnectedRoute();
        installOriginalRoutes();

        // igp
        SRELogger.pushContext("OSPF");
        buildOspfTopology();
        for (NDDRouter r : NDDController.ospfValidRouters) {
            r.ospfProcesses.values().forEach(process -> {
                process.setValid(true);
                computeOspfRoutes(process);
                process.setValid(false);
            });
        }
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ITERATION] " + NDDOspfExecutor.iteration);
        SRELogger.logCPExe(SRELogger.LEVEL.INFO,
                "[ROUTE] total: " + NDDOspfExecutor.total + " remain: " + NDDOspfExecutor.remain);
        SRELogger.popContext();

        // install igp routes
        installIgpRoutes();

        // bgp
        SRELogger.pushContext("BGP");
        buildBgpTopology();
        for (NDDRouter r : NDDController.bgpValidRouters) {
            r.bgpProcess.setValid(true);
            computeBgpRoutes(r.bgpProcess);
            r.bgpProcess.setValid(false);
        }
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ITERATION] " + NDDBgpExecutor.iteration);
        SRELogger.logCPExe(SRELogger.LEVEL.INFO,
                "[ROUTE] total: " + NDDBgpExecutor.total + " remain: " + NDDBgpExecutor.remain);
        SRELogger.popContext();

        // install bgp routes
        installBgpRoutes();

        // install all routes into FIB
        rib2fib();

        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public void generateDataPlaneAllInOne() {
        NDDController.ospfValidRouters.forEach(r -> r.getOspfProcesses().values().forEach(p -> p.setValid(true)));
        NDDController.bgpValidRouters.forEach(r -> r.getBgpProcess().setValid(true));

        SRELogger.pushContext("CPE AIO");
        TimeUtil timer = new TimeUtil();
        timer.begin();

        // generate connected route
        // double t0 = System.nanoTime();
        genConnectedRoute();
        installOriginalRoutes();
        // double t1 = System.nanoTime();
        // System.out.println("src stage1:"+(t1-t0)/1000000000.0);

        // igp
        SRELogger.pushContext("OSPF");
        buildOspfTopology();
        computeOspfRoutes();
        SRELogger.popContext();
        // double t2 = System.nanoTime();
        // System.out.println("src stage2:"+(t2-t1)/1000000000.0);

        // install igp routes
        installIgpRoutes();
        // double t3 = System.nanoTime();
        // System.out.println("src stage3:"+(t3-t2)/1000000000.0);

        // install IGP routes into FIB
        // when resolving BGP topology, if we only care about route reachability, this
        // is unnecessary
        // _l3Topology._nodes.values().forEach(Router::installGlobalRibToFib);

        // bgp
        SRELogger.pushContext("BGP");
        buildBgpTopology();
        computeBgpRoutes();
        SRELogger.popContext();
        // double t4 = System.nanoTime();
        // System.out.println("src stage4:"+(t4-t3)/1000000000.0);
        int sumBgpRoute = 0;
        for (NDDBgpProcess process : _bgpTopology.edges.rowKeySet()) {
            for (NDDSortedMultiList lists : process.getRib().getRib().values()) {
                for (ArrayList list : lists) {
                    sumBgpRoute += list.size();
                }
            }
        }
        System.out.println(sumBgpRoute + " bgp route");

        // install bgp routes
        installBgpRoutes();
        // double t5 = System.nanoTime();
        // System.out.println("src stage5:"+(t5-t4)/1000000000.0);

        // install all routes into FIB
        rib2fib();
        // double t6 = System.nanoTime();
        // System.out.println("src stage6:"+(t6-t5)/1000000000.0);

        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public TreeMap<String, NDDRouter> getRouters() {
        return _l3Topology._nodes;
    }

    public TreeMap<PortName, NDDPort> getPorts() {
        return _l3Topology._ports;
    }

    public HashSet<NDDL3Edge> getL3Edges() {
        return _l3Topology._l3Edges;
    }

    public HashSet<NDDPort> getEdgePorts() {
        return _l3Topology._edgePorts;
    }

    public HashSet<NDDRouter> getEdgeRouters() {
        return _l3Topology._edgeRouters;
    }

    public NDDL3Topology getL3Topology() {
        return _l3Topology;
    }

    public NDDOspfTopology getOspfTopology() {
        return _ospfTopology;
    }

    public NDDBgpTopology getBgpTopology() {
        return _bgpTopology;
    }

    public Owner<Prefix, NDDRouter> getPrefixOwners() {
        return _l3Topology._prefixOwners;
    }

    public Owner<Ip, NDDRouter> getIpOwners() {
        return _l3Topology._ipOwners;
    }

    public void clear() {
        _l3Topology._nodes.values().forEach(NDDRouter::clear);
    }

    public void reset() {
        _l3Topology._nodes.values().forEach(NDDRouter::reset);
    }
}
