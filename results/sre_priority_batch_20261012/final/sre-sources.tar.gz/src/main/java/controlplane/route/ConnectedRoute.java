package controlplane.route;

import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import controlplane.network.Port;

public class ConnectedRoute extends Route {
    int _AD;

    public ConnectedRoute(
            Prefix prefix,
            Ip nextHop,
            Port outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            SortedMultiList list,
            int AD
    ) {
        super(prefix, nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list);
        _AD = AD;
    }

    @Override
    public RoutingProtocol getProtocol() {
        return RoutingProtocol.CONNECTED;
    }

    @Override
    public int getAD() {
        return _AD;
    }

    @Override
    public Long getMetric() {
        return 0L;
    }

    @Override
    public void setListTC(int tc) {
    }

    @Override
    public String toString() {
        return _prefix.toString()
               + "\t" + _outPort
               + "\tConnected";
    }
}
