package controlplane.process.bgp;

import controlplane.route.BgpRoute;
import datamodel.ipv4.Ip;

public class NDDBgpNeighborConfig {
    public Ip localIp;
    public Ip neighborIp;
    public NDDBgpProcess process;

    BgpNeighborConfig.NeighborType neighborType;

    public NDDBgpNeighborConfig(Ip localIp, Ip neighborIp, NDDBgpProcess process, BgpNeighborConfig.NeighborType neighborType) {
        this.localIp = localIp;
        this.neighborIp = neighborIp;
        this.process = process;
        this.neighborType = neighborType;
    }

    public void setProcess(NDDBgpProcess process) {
        this.process = process;
    }

    public NDDBgpProcess getProcess() {
        return process;
    }

    public Ip getLocalIp() {
        return localIp;
    }
}
