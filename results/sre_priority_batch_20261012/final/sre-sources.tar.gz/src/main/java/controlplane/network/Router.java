package controlplane.network;

import controlplane.process.bgp.BgpProcess;
import controlplane.process.ospf.OspfProcess;
import controlplane.rib.Rib;
import controlplane.route.ConnectedRoute;
import controlplane.route.LocalRoute;
import controlplane.route.StaticRoute;
import controlplane.route.builder.ConnectedRouteBuilder;
import controlplane.route.builder.LocalRouteBuilder;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import datamodel.ipv4.Prefix;
import dataplane.fib.Fib;
import main.Controller;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class Router {
    String routerName;
    int asNumber;
    long routerId;

    Map<PortName, Port> ports;
    Port loopback;
    Port blackhole;
    Port sink;

    HashMap<Integer, OspfProcess> ospfProcesses;
    BgpProcess bgpProcess;

    Rib connectedRib;
    Rib localRib;
    Rib conditionalStaticRib;
    Rib unconditionalStaticRib;
    Rib globalRib;
    Fib fib;

    int prefixBDD = -1;

    boolean ecmp = true;

    State _state = State.SYMBOLIC;

    public Router(String name, int number) {
        routerName = name;
        asNumber = number;
        ports = new HashMap<>();
        ospfProcesses = new HashMap<>();
        connectedRib = new Rib();
        localRib = new Rib();
        conditionalStaticRib = new Rib();
        unconditionalStaticRib = new Rib();
        globalRib = new Rib();
        fib = new Fib(this);

        // virtual port, for packets being dropped
        PortName bh = new PortName(routerName, "blackhole");
        blackhole = new Port(bh, this, null, false);
        blackhole.blackhole = true;
        ports.put(bh, blackhole);

        // virtual port, for packets being accepted
        PortName s = new PortName(routerName, "sink");
        sink = new Port(s, this, null, false);
        sink.sink = true;
        ports.put(s, sink);
    }

    public Router(String name, int number, long id) {
        this(name, number);
        routerId = id;
    }

    public void genConnectedRoute() {
        for (Port port : ports.values()) {
            if (!port.blackhole && !port.sink) {
                HashSet<IpAddress> ipAddresses = new HashSet<>();
                ipAddresses.add(port.getPrimaryIpAddress());
                if (port.getSecondaryIpAddresses() != null) {
                    ipAddresses.addAll(port.getSecondaryIpAddresses());
                }
                for (IpAddress ipAddress : ipAddresses) {
                    ConnectedRoute connectedRoute = new ConnectedRouteBuilder()
                            .setPrefix(ipAddress.toPrefix())
                            .setNextHop(Ip.AUTO)
                            .setOutPort(port)
                            .setArriveTC(port.l3Edge == null ? 1 : port.l3Edge.getTC())
                            .setListTC(port.l3Edge == null ? 1 : port.l3Edge.getTC())
                            // .setArriveTC(1)
                            // .setListTC(1)
                            .build();
                    connectedRib.insert(connectedRoute);
                    if (ipAddress.getNetworkBits() < 32) {
                        LocalRoute localRoute = new LocalRouteBuilder()
                                .setPrefix(ipAddress.getIp().toPrefix())
                                .setNextHop(Ip.AUTO)
                                .setOutPort(port)
                                .setArriveTC(1)
                                .setListTC(1)
                                .build();
                        localRib.insert(localRoute);
                    }
                }
            }
        }
    }

    public void insertStaticRoute(StaticRoute route) {
        if (route.getOutPort() != null) {
            // static routes with next-hop-interface, unconditional
            route.setNextHop(Ip.AUTO);
            unconditionalStaticRib.insert(route);
        }
        else if (route.getNextHop().equals(Ip.ZERO)) {
            // static routes with next-hop-ip 0.0.0.0, discard matching packets, unconditional
            route.setNextHop(Ip.AUTO);
            route.setOutPort(blackhole);
            unconditionalStaticRib.insert(route);
        }
        else {
            // static routes with next-hop-ip, needs resolution
            conditionalStaticRib.insert(route);
        }
    }

    public void installOriginalRoutesToGlobalRib() {
        connectedRib.install(globalRib, ecmp);
        localRib.install(globalRib, ecmp);
        unconditionalStaticRib.install(globalRib, ecmp);
        conditionalStaticRib.install(globalRib, ecmp);
        globalRib.cleanDeadRoute();
    }

    public void installIgpRoutesToGlobalRib() {
        ospfProcesses.values().forEach(process -> process.getRib().install(globalRib, ecmp));
        globalRib.cleanDeadRoute();
    }

    public void installBgpRoutesToGlobalRib() {
        bgpProcess.getRib().install(globalRib, ecmp);
        globalRib.cleanDeadRoute();
    }

    public void installGlobalRibToFib() {
        globalRib.install(fib);
    }

    public int getPrefixBDD() {
        return prefixBDD == -1 ? prepare() : prefixBDD;
    }

    public String getRouterName() {
        return routerName;
    }

    public Map<PortName, Port> getPorts() {
        return ports;
    }

    public Port getLoopback() {
        return loopback;
    }

    public void setLoopback(Port loopback) {
        this.loopback = loopback;
    }

    public Port getBlackhole() {
        return blackhole;
    }

    public Port getSink() {
        return sink;
    }

    public Rib getConnectedRib() {
        return connectedRib;
    }

    public Rib getConditionalStaticRib() {
        return conditionalStaticRib;
    }

    public Rib getUnconditionalStaticRib() {
        return unconditionalStaticRib;
    }

    public Rib getGlobalRib() {
        return globalRib;
    }

    public Fib getFib() {
        return fib;
    }

    public int getAsNumber() {
        return asNumber;
    }

    public long getRouterId() {
        return routerId;
    }

    public HashSet<Prefix> getPrefixes() {
        HashSet<Prefix> prefixes = new HashSet<>();
        ospfProcesses.values().forEach(process -> prefixes.addAll(process.getPrefixes()));
        if (bgpProcess != null) {
            prefixes.addAll(bgpProcess.getNetworks());
        }
        return prefixes;
    }

    int prepare() {
        prefixBDD = 0;
        for (Prefix prefix : getPrefixes()) {
            int cached = Controller.bddManager.getBDDACLWrapper().encodeDstIPPrefix(prefix.getIp().asLong(), prefix.getPreLength());
            int tmp1 = Controller.bddManager.getBDD().ref(cached);
            prefixBDD = Controller.bddManager.orDerefBoth(tmp1, prefixBDD);
        }
        return prefixBDD;
    }

    public Ip getLoopBackIp() {
        return loopback.primaryIpAddress.getIp();
    }

    public void addPort(Port port) {
        ports.put(port.getPortName(), port);
    }

    public void addOspfProcess(OspfProcess ospfProcess) {
        ospfProcesses.put(ospfProcess.getProcessId(), ospfProcess);
    }

    public void setOspfProcesses(HashMap<Integer, OspfProcess> ospfProcesses) {
        this.ospfProcesses = ospfProcesses;
    }

    public OspfProcess getOspfProcess(int id) {
        return ospfProcesses.get(id);
    }

    public HashMap<Integer, OspfProcess> getOspfProcesses() {
        return ospfProcesses;
    }

    public void setBgpProcess(BgpProcess bgpProcess) {
        this.bgpProcess = bgpProcess;
    }

    public BgpProcess getBgpProcess() {
        return bgpProcess;
    }

    public State getState() {
        return _state;
    }

    public void setState(State state) {
        _state = state;
    }

    public boolean ecmp() {
        return ecmp;
    }

    public void setValid(boolean valid) {
        ospfProcesses.values().forEach(process -> process.setValid(valid));
        if (bgpProcess != null) bgpProcess.setValid(valid);
    }

    public boolean valid() {
        boolean valid = false;
        if (bgpProcess != null) valid = bgpProcess.valid();
        valid = valid | ospfProcesses.values().stream().anyMatch(OspfProcess::valid);
        return valid;
    }

    public void clear() {
        ospfProcesses.values().forEach(OspfProcess::clear);
        if (bgpProcess != null) bgpProcess.clear();
        globalRib.clear();
        fib.clear();
        prefixBDD = -1;
    }

    public void reset() {
        ospfProcesses.values().forEach(OspfProcess::reset);
        if (bgpProcess != null) bgpProcess.reset();
        globalRib.reset();
        fib.reset();
    }

//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        Router router = (Router) o;
//        return asNumber == router.asNumber &&
//               routerId == router.routerId &&
//               Objects.equals(routerName, router.routerName);
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(routerName, asNumber, routerId);
//    }

    @Override
    public String toString() {
        return routerName + "\t" + asNumber + "\t" + routerId;
    }
}
