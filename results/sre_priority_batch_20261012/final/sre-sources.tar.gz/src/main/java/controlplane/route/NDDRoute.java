package controlplane.route;

import sre.ndd.NDD;
import controlplane.network.NDDPort;
import controlplane.network.Port;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import main.Controller;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public abstract class NDDRoute implements NDDSortedMultiListItem {
    Prefix _prefix;

    Ip _nextHop;
    NDDPort _outPort;

    int _arriveTC;
    int _listTC;
    protected int boundedBudget = -1;
    @Override public void markBudgetBounded(int budget) { boundedBudget = budget; }
    @Override public int getBoundedBudget() { return boundedBudget; }

    int _innerIdx;
    int _outerIdx;
    NDDSortedMultiList _list;
    private boolean _nddOwnershipReleased;

    public NDDRoute(
            Prefix prefix,
            Ip nextHop,
            NDDPort outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            NDDSortedMultiList list) {
        _prefix = prefix;
        _nextHop = nextHop;
        _outPort = outPort;
        _arriveTC = arriveTC;
        _listTC = listTC;
        _innerIdx = innerIdx;
        _outerIdx = outerIdx;
        _list = list;
    }

    public abstract RoutingProtocol getProtocol();

    public Prefix getPrefix() {
        return _prefix;
    }

    public int getArriveTC() {
        return _arriveTC;
    }

    public void setArriveTC(int tc) {
        NDD.deref(_arriveTC);
        _arriveTC = tc;
    }

    public int getListTC() {
        return _listTC;
    }

    public void setListTC(int tc) {
        boundedBudget = -1;
        NDD.deref(_listTC);
        _listTC = tc;
    }

    public abstract int getAD();

    public abstract Long getMetric();

    /** Release the two symbolic roots owned by this detached route. */
    public void releaseNddOwnership() {
        if (_nddOwnershipReleased) return;
        NDD.deref(_arriveTC);
        NDD.deref(_listTC);
        _nddOwnershipReleased = true;
    }

    public Ip getNextHop() {
        return _nextHop;
    }

    public void setNextHop(Ip nextHop) {
        _nextHop = nextHop;
    }

    public NDDPort getOutPort() {
        return _outPort;
    }

    public void setOutPort(NDDPort port) {
        _outPort = port;
    }

    @Override
    public void setList(NDDSortedMultiList list) {
        _list = list;
    }

    @Override
    public NDDSortedMultiList getList() {
        return _list;
    }

    @Override
    public void setOuterIdx(int idx) {
        _outerIdx = idx;
    }

    @Override
    public int getOuterIdx() {
        return _outerIdx;
    }

    @Override
    public void setInnerIdx(int idx) {
        _innerIdx = idx;
    }

    @Override
    public int getInnerIdx() {
        return _innerIdx;
    }

    @Override
    public boolean isDead() {
        return NDD.isFalse(_arriveTC) || NDD.isFalse(_listTC);
    }

    @Override
    public int compareTo(@NotNull NDDSortedMultiListItem o) {
        if (!(o instanceof NDDRoute)) {
            throw new IllegalArgumentException();
        }
        return Integer.compare(((NDDRoute) o).getAD(), getAD());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        NDDRoute route = (NDDRoute) o;
        return Objects.equals(_prefix, route._prefix) &&
                Objects.equals(_nextHop, route._nextHop) &&
                Objects.equals(_outPort, route._outPort);
    }

    @Override
    public int hashCode() {
        return Objects.hash(_prefix, _nextHop, _outPort);
    }
}
