package controlplane.process.bgp;

import multimap.HashBasedTable;
import multimap.Table;
import datamodel.ipv4.Ip;

import java.util.Collection;
import java.util.HashMap;

public class BgpTopology {
    Table<BgpProcess, Ip, BgpNeighborConfig> configs;
    public Table<BgpProcess, BgpProcess, BgpEdge> edges;
    HashMap<BgpEdge, BgpEdge> inverseEdges;
    Table<Ip, Ip, Integer> ipEdges;

    public BgpTopology() {
        configs = HashBasedTable.create();
        edges = HashBasedTable.create();
        inverseEdges = new HashMap<>();
        ipEdges = HashBasedTable.create();
    }

    public void addEdge(BgpNeighborConfig n1, BgpNeighborConfig n2, int tc) {
        if (n1 != null && n2 != null && tc != 0) {
            BgpEdge e1 = new BgpEdge(n1, n2, tc);
            BgpEdge e2 = new BgpEdge(n2, n1, tc);
            edges.put(n1.process, n2.process, e1);
            edges.put(n2.process, n1.process, e2);
            inverseEdges.put(e1, e2);
            inverseEdges.put(e2, e1);
        }
    }

    public void addNeighborConfig(BgpNeighborConfig config) {
        configs.put(config.process, config.neighborIp, config);
        ipEdges.put(config.localIp, config.neighborIp, 0);
    }

    public BgpNeighborConfig getNeighborConfig(BgpProcess process, Ip neighborIp) {
        return configs.get(process, neighborIp);
    }

    public Collection<BgpEdge> getEdges() {
        return edges.values();
    }

    public BgpEdge getInverseEdge(BgpEdge edge) {
        return inverseEdges.get(edge);
    }

    public Table<Ip, Ip, Integer> getIpEdges() {
        return ipEdges;
    }

    public boolean containsEdge(BgpProcess p1, BgpProcess p2) {
        return edges.get(p1, p2) != null;
    }
}
