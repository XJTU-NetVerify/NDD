package controlplane.route;

import controlplane.network.Port;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import main.Controller;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public abstract class Route implements SortedMultiListItem {
    Prefix _prefix;

    Ip _nextHop;
    Port _outPort;

    int _arriveTC;
    int _listTC;

    int _innerIdx;
    int _outerIdx;
    SortedMultiList _list;

    public Route(
            Prefix prefix,
            Ip nextHop,
            Port outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            SortedMultiList list
    ) {
        _prefix = prefix;
        _nextHop = nextHop;
        _outPort = outPort;
        _arriveTC = arriveTC;
        _listTC = listTC;
        _innerIdx = innerIdx;
        _outerIdx = outerIdx;
        _list = list;
    }

    public abstract RoutingProtocol getProtocol();

    public Prefix getPrefix() {
        return _prefix;
    }

    public int getArriveTC() {
        return _arriveTC;
    }

    public void setArriveTC(int tc) {
        Controller.bddManager.deref(_arriveTC);
        _arriveTC = tc;
    }

    public int getListTC() {
        return _listTC;
    }

    public void setListTC(int tc) {
        Controller.bddManager.deref(_listTC);
        _listTC = tc;
    }

    public abstract int getAD();

    public abstract Long getMetric();

    public Ip getNextHop() {
        return _nextHop;
    }

    public void setNextHop(Ip nextHop) {
        _nextHop = nextHop;
    }

    public Port getOutPort() {
        return _outPort;
    }

    public void setOutPort(Port port) {
        _outPort = port;
    }

    @Override
    public void setList(SortedMultiList list) {
        _list = list;
    }

    @Override
    public SortedMultiList getList() {
        return _list;
    }

    @Override
    public void setOuterIdx(int idx) {
        _outerIdx = idx;
    }

    @Override
    public int getOuterIdx() {
        return _outerIdx;
    }

    @Override
    public void setInnerIdx(int idx) {
        _innerIdx = idx;
    }

    @Override
    public int getInnerIdx() {
        return _innerIdx;
    }

    @Override
    public boolean isDead() {
        return _arriveTC == 0 || _listTC == 0;
    }

    @Override
    public int compareTo(@NotNull SortedMultiListItem o) {
        if (!(o instanceof Route)) {
            throw new IllegalArgumentException();
        }
        return Integer.compare(((Route) o).getAD(), getAD());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Route route = (Route) o;
        return Objects.equals(_prefix, route._prefix) &&
               Objects.equals(_nextHop, route._nextHop) &&
               Objects.equals(_outPort, route._outPort);
    }

    @Override
    public int hashCode() {
        return Objects.hash(_prefix, _nextHop, _outPort);
    }
}
