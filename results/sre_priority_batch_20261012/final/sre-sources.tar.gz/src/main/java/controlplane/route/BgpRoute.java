package controlplane.route;

import controlplane.network.Port;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import main.Controller;

import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.Objects;

public class BgpRoute extends DynamicRoute {
    public enum OriginType {
        IGP("IGP", 2),
        EGP("EGP", 1),
        INCOMPLETE("incomplete", 0);

        String _name;
        int _preference;

        OriginType(String name, int preference) {
            _name = name;
            _preference = preference;
        }
    }

    OriginType _origin;
    int _localPreference;
    Path<Integer> _ASPath;
    long _med;
    int _iAD;
    int _eAD;

    public BgpRoute(
            Prefix prefix,
            Ip nextHop,
            Port outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            SortedMultiList list,
            Path<String> path,
            boolean dirty,
            OriginType origin,
            int localPreference,
            Path<Integer> ASPath,
            long med,
            int iAD,
            int eAD,
            BgpRouteType bgpRouteType) {
        super(prefix, nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list, path, dirty);
        _origin = origin;
        _localPreference = localPreference;
        _ASPath = ASPath;
        _med = med;
        _iAD = iAD;
        _eAD = eAD;
        _bgpRouteType = bgpRouteType;
    }

    public BgpRoute(BgpRoute one) {
        this(
                one._prefix,
                one._nextHop,
                one._outPort,
                one._arriveTC,
                one._listTC,
                one._innerIdx,
                one._outerIdx,
                one._list,
                new Path<>(one._path),
                one._dirty,
                one._origin,
                one._localPreference,
                new Path<>(one._ASPath),
                one._med,
                one._iAD,
                one._eAD,
                one._bgpRouteType);
    }

    public void setLocalPreference(int lp) {
        _localPreference = lp;
    }

    public int getLocalPreference() {
        return _localPreference;
    }

    public void setMetric(long med) {
        _med = med;
    }

    @Override
    public Long getMetric() {
        return _med;
    }

    public Path<Integer> getASPath() {
        return _ASPath;
    }

    @Override
    public RoutingProtocol getProtocol() {
        return RoutingProtocol.BGP;
    }

    @Override
    public int getAD() {
        return _bgpRouteType == BgpRouteType.FROM_EBGP_NEIGHBOR ? _eAD : _iAD;
    }

    public OriginType getOrigin() {
        return _origin;
    }

    @Override
    public int compareTo(@NotNull SortedMultiListItem o) {
        if (o instanceof BgpRoute) {
            return Comparator
                    .comparing(BgpRoute::getLocalPreference)
                    .thenComparing(r -> r._ASPath.size(), Comparator.reverseOrder())
                    .thenComparing(r -> r._origin._preference)
                    .thenComparing(BgpRoute::getMetric, Comparator.reverseOrder())
                    .compare(this, (BgpRoute) o);
        } else {
            return super.compareTo(o);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        if (!super.equals(o))
            return false;
        BgpRoute bgpRoute = (BgpRoute) o;
        return _localPreference == bgpRoute._localPreference &&
                _med == bgpRoute._med &&
                _iAD == bgpRoute._iAD &&
                _eAD == bgpRoute._eAD &&
                _origin == bgpRoute._origin &&
                Objects.equals(_ASPath, bgpRoute._ASPath) &&
                _bgpRouteType == bgpRoute._bgpRouteType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), _origin, _localPreference, _ASPath, _med, _iAD, _eAD, _bgpRouteType);
    }

    public enum BgpRouteType {
        NETWORK("route from network command"),
        FROM_EBGP_NEIGHBOR("route from eBGP neighbor"),
        FROM_IBGP_NEIGHBOR("route from iBGP neighbor"),
        FROM_ROUTE_REFLECTOR("route from route reflector"),
        FROM_CLIENT("route from client");

        String description;

        BgpRouteType(String description) {
            this.description = description;
        }
    }

    BgpRouteType _bgpRouteType;

    public void setType(BgpRouteType bgpRouteType) {
        _bgpRouteType = bgpRouteType;
    }

    public BgpRouteType getType() {
        return _bgpRouteType;
    }

    @Override
    public String toString() {
        return _prefix.toString()
                + "\t" + _outPort
                + "\t" + _nextHop
                + "\t" + _localPreference
                + "\t" + _path
                + "\t" + _ASPath
                + "\t" + Controller.bddManager.getBDD().satCount(_arriveTC)
                + "\t" + Controller.bddManager.getBDD().satCount(_listTC)
                + "\tBGP";
    }
}
