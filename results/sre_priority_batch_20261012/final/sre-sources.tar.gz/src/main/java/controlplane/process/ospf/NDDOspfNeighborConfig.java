package controlplane.process.ospf;

import controlplane.network.NDDPort;

public class NDDOspfNeighborConfig {
    NDDOspfProcess process;
    OspfIntfSetting intfSetting;
    NDDPort port;

    public NDDOspfNeighborConfig(NDDOspfProcess process, OspfIntfSetting intfSetting, NDDPort port) {
        this.process = process;
        this.intfSetting = intfSetting;
        this.port = port;
    }

    public NDDOspfProcess getProcess() {
        return process;
    }

    public OspfIntfSetting getIntfSetting() {
        return intfSetting;
    }

    public NDDPort getPort() {
        return port;
    }
}
