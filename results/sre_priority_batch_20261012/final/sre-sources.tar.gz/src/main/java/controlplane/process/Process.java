package controlplane.process;

import controlplane.network.Router;
import controlplane.rib.Rib;
import controlplane.route.Route;

public interface Process {
    void insertOutQueue(Route route);

    Router getRouter();

    Rib getRib();

    void clear();

    void reset();
}
