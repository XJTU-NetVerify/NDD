package controlplane.network;

import controlplane.Owner;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import inputparser.ConfigurationParser;
import inputparser.EnvironmentParser;
import inputparser.TopologyParser;
import main.SRELogger;

import java.nio.file.Path;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class CPUtil {

    CPExecutor _cpExecutor;

    TreeMap<String, Router> _nodes;
    TreeMap<PortName, Port> _ports;
    HashSet<L3Edge> _l3Edges;
    HashSet<Port> _edgePorts;

    Owner<Prefix, Router> _prefixOwners;
    Owner<Ip, Router> _ipOwners;

    public CPUtil(CPExecutor cpExecutor) {
        _cpExecutor = cpExecutor;
    }

    public void parseConfigs(Path cfgPath, Path aclPath) {
        ConfigurationParser parser = new ConfigurationParser();
        parser.parse(cfgPath, aclPath);

        _nodes = parser.getRouters();
        _ports = parser.getPorts();
        _prefixOwners = parser.getPrefixOwners();
        _ipOwners = parser.getIpOwners();
        _cpExecutor._bgpTopology = parser.getBgpTopology();
        _cpExecutor._ospfTopology = parser.getOspfTopology();

        SRELogger.logWorkFlow(SRELogger.LEVEL.DEBUG, "[SETUP] devices");
    }

    public void parseL3Topology(Path l3EdgesPath, Path edgePortPath) {
        TopologyParser parser = new TopologyParser();
        _l3Edges = parser.parseL3Edges(l3EdgesPath);
        if (edgePortPath != null && edgePortPath.toFile().exists()) {
            _edgePorts = parser.parseEdgePorts(edgePortPath)
                    .stream()
                    .map(pn -> _ports.get(pn))
                    .filter(Objects::nonNull)
                    .collect(Collectors.toCollection(HashSet::new));
            _edgePorts.forEach(Port::setEdge);
        }
        _cpExecutor._l3Topology = new L3Topology(_nodes, _ports, _l3Edges, _edgePorts, _prefixOwners, _ipOwners);

        Iterator<L3Edge> itr = _l3Edges.iterator();
        while (itr.hasNext()) {
            L3Edge l3Edge = itr.next();
            Port port1 = _ports.get(l3Edge.getSrc());
            Port port2 = _ports.get(l3Edge.getDst());
            // TODO check why port can be null ??? We only have active interfaces in cfg
            if (port1 != null && port2 != null) {
                port1.setLinkedPort(port2);
                port2.setLinkedPort(port1);
                port1.setLink(l3Edge);
                port2.setLink(l3Edge);
            }
//            else {
//                itr.remove();
//            }
        }

        SRELogger.logWorkFlow(SRELogger.LEVEL.DEBUG, "[SETUP] l3topology");
    }

    public void parseEnvironment(Path environmentPath) {
        if (environmentPath != null && environmentPath.toFile().exists()) {
            EnvironmentParser parser = new EnvironmentParser();
            parser.parseEnvironment(environmentPath);

            parser.getLinksUp().forEach(e -> e.setState(State.UP));
            parser.getLinksDown().forEach(e -> e.setState(State.DOWN));

            HashSet<String> nodesUp = parser.getNodesUp();
            HashSet<String> nodesDown = parser.getNodesDown();
            for (String node : nodesUp) {
                _nodes.get(node).setState(State.UP);
            }
            for (String node : nodesDown) {
                _nodes.get(node).setState(State.DOWN);
                _nodes.get(node).ports.values().forEach(p -> p.setState(State.DOWN));
            }

            SRELogger.logWorkFlow(SRELogger.LEVEL.DEBUG, "[SETUP] environment");
        }
    }

}
