package controlplane.network;

import algorithm.graph.KEdgeComponentAlgorithm;
import multimap.HashBasedTable;
import multimap.Table;
import controlplane.Owner;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import main.Controller;
import org.jgrapht.Graph;
import org.jgrapht.graph.Multigraph;

import java.util.Collection;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class NDDL3Topology {


    public Graph<NDDRouter, NDDL3Edge> buildGraph(int k) {
        Graph<NDDRouter, NDDL3Edge> graph = new Multigraph<>(NDDL3Edge.class);
        _nodes.values().stream().filter(node -> node.getState() != State.DOWN).forEach(graph::addVertex);
        _l3Edges.forEach(link -> {
            if (link.getState() != State.DOWN) {
                NDDRouter v1 = _nodes.get(link.getSrc().getRouterName());
                NDDRouter v2 = _nodes.get(link.getDst().getRouterName());
                // encode link-always-up
                if (link.getState() == State.UP) {
                    for (int i = 0; i < k; i++) {
                        graph.addEdge(v1, v2, link);
                    }
                }
                else {
                    graph.addEdge(v1, v2, link);
                }
            }
        });
        return graph;
    }

    private Graph<NDDRouter, NDDL3Edge> graph = null;
    private KEdgeComponentAlgorithm<NDDRouter, NDDL3Edge> alg = null;
    /** k = MF + 1 */
    public Collection<Graph<NDDRouter, NDDL3Edge>> getKEdgeComponent(int k) {
        if (graph == null) graph = buildGraph(Controller.MF + 1);
        if (alg == null) alg = new KEdgeComponentAlgorithm<>(graph);
        return alg.getKEdgeComponent(k);
    }

    TreeMap<String, NDDRouter> _nodes;
    TreeMap<PortName, NDDPort> _ports;
    HashSet<NDDL3Edge> _l3Edges;
    HashSet<NDDPort> _edgePorts;
    HashSet<NDDRouter> _edgeRouters;
    int down = 0;

    Owner<Prefix, NDDRouter> _prefixOwners;
    Owner<Ip, NDDRouter> _ipOwners;

    public NDDL3Topology(TreeMap<String, NDDRouter> nodes,
                      TreeMap<PortName, NDDPort> ports,
                      HashSet<NDDL3Edge> l3Edges,
                      HashSet<NDDPort> edgePorts,
                      Owner<Prefix, NDDRouter> prefixOwners,
                      Owner<Ip, NDDRouter> ipOwners) {
        _nodes = nodes;
        _ports = ports;
        _l3Edges = l3Edges;
        _edgePorts = edgePorts == null ? new HashSet<>(_ports.values()) : edgePorts;
        _edgeRouters = edgePorts == null ? new HashSet<>(_nodes.values()) : edgePorts.stream().map(NDDPort::getRouter).collect(Collectors.toCollection(HashSet::new));
        for (NDDL3Edge e : _l3Edges) {
            if (e.getState() == State.DOWN) {
                down++;
            }
        }
        _prefixOwners = prefixOwners;
        _ipOwners = ipOwners;
    }

    public TreeMap<String, NDDRouter> getNodes() {
        return _nodes;
    }

    public HashSet<NDDL3Edge> getL3Edges() {
        return _l3Edges;
    }
}
