package controlplane.process.bgp.routemap;

import controlplane.route.BgpRoute;

import java.util.Vector;

public class RouteMapPolicy {
    boolean permit;
    Vector<RouteMapMatch> matches;
    Vector<RouteMapAction> actions;

    public RouteMapPolicy(boolean permit, Vector<RouteMapMatch> matches, Vector<RouteMapAction> actions) {
        this.permit = permit;
        this.matches = matches;
        this.actions = actions;
    }

    public boolean match(BgpRoute route) {
        // match all packets
        if (matches == null || matches.isEmpty()) {
            return true;
        }
        else {
            for (RouteMapMatch match : matches) {
                if (match.match(route)) {
                    return true;
                }
            }
            return false;
        }
    }

    public BgpRoute act(BgpRoute route) {
        if (permit) {
            if (actions != null) {
                for (RouteMapAction action : actions) action.act(route);
            }
            return route;
        }
        else {
            return null;
        }
    }
}
