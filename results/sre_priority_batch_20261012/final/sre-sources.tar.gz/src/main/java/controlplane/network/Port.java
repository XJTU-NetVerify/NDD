package controlplane.network;

import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import dataplane.acl.ACLRule;

import java.util.LinkedList;
import java.util.Objects;
import java.util.Vector;

public class Port {
    final PortName portName;
    Router router;
    IpAddress primaryIpAddress;
    Vector<IpAddress> secondaryIpAddresses;
    Port linkedPort;
    L3Edge l3Edge;

    LinkedList<ACLRule> aclIn;
    LinkedList<ACLRule> aclOut;

    int portFwdBDD = 0;
    int portAclInBDD = 1;
    int portAclOutBDD = 1;

    boolean loopback;
    boolean blackhole;
    boolean sink;
    boolean edge;

    State _state = State.SYMBOLIC;

    public Port(PortName portName, Router router, IpAddress primaryIpAddress, boolean loopback) {
        this.portName = portName;
        this.router = router;
        this.primaryIpAddress = primaryIpAddress;
        this.loopback = loopback;
    }

    public boolean isLoopback() {
        return loopback;
    }

    public boolean isBlackhole() {
        return blackhole;
    }

    public boolean isSink() {
        return sink;
    }

    public void setEdge() {
        edge = true;
    }

    public boolean isEdge() {
        return edge;
    }

    public Ip getIp() {
        return primaryIpAddress.getIp();
    }

    public IpAddress getPrimaryIpAddress() {
        return primaryIpAddress;
    }

    public void addSecondaryIpAddress(IpAddress ipAddress) {
        if (secondaryIpAddresses == null) secondaryIpAddresses = new Vector<>();
        secondaryIpAddresses.add(ipAddress);
    }

    public Vector<IpAddress> getSecondaryIpAddresses() {
        return secondaryIpAddresses;
    }

    public Vector<IpAddress> getIpAddresses() {
        Vector<IpAddress> ipAddresses = new Vector<>();
        ipAddresses.add(primaryIpAddress);
        if (secondaryIpAddresses != null) ipAddresses.addAll(secondaryIpAddresses);
        return ipAddresses;
    }

    public PortName getPortName() {
        return portName;
    }

    public Router getRouter() {
        return router;
    }

    public Port getLinkedPort() {
        return linkedPort;
    }

    public void setLinkedPort(Port linkedPort) {
        this.linkedPort = linkedPort;
    }

    public L3Edge getLink() {
        return l3Edge;
    }

    public void setLink(L3Edge l3Edge) {
        this.l3Edge = l3Edge;
    }

    public LinkedList<ACLRule> getAclIn() {
        return aclIn;
    }

    public void setAclIn(LinkedList<ACLRule> aclIn) {
        this.aclIn = aclIn;
    }

    public LinkedList<ACLRule> getAclOut() {
        return aclOut;
    }

    public void setAclOut(LinkedList<ACLRule> aclOut) {
        this.aclOut = aclOut;
    }

    public int getPortFwdBDD() {
        return portFwdBDD;
    }

    public void setPortFwdBDD(int portFwdBDD) {
        this.portFwdBDD = portFwdBDD;
    }

    public int getPortAclInBDD() {
        return portAclInBDD;
    }

    public void setPortAclInBDD(int portAclInBDD) {
        this.portAclInBDD = portAclInBDD;
    }

    public int getPortAclOutBDD() {
        return portAclOutBDD;
    }

    public void setPortAclOutBDD(int portAclOutBDD) {
        this.portAclOutBDD = portAclOutBDD;
    }

    public State getState() {
        return _state;
    }

    public void setState(State state) {
        _state = state;
    }

    @Override
    public String toString() {
        return portName.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Port port = (Port) o;
        return Objects.equals(portName, port.portName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(portName);
    }
}
