package controlplane.process.bgp;

import controlplane.route.BgpRoute;
import datamodel.ipv4.Ip;

public class BgpNeighborConfig {
    Ip localIp;
    Ip neighborIp;
    BgpProcess process;

    NeighborType neighborType;

    public enum NeighborType {
        EBGP(BgpRoute.BgpRouteType.FROM_EBGP_NEIGHBOR),
        IBGP(BgpRoute.BgpRouteType.FROM_IBGP_NEIGHBOR),
        REFLECTOR(BgpRoute.BgpRouteType.FROM_ROUTE_REFLECTOR),
        CLIENT(BgpRoute.BgpRouteType.FROM_CLIENT);

        BgpRoute.BgpRouteType bgpRouteType;

        NeighborType(BgpRoute.BgpRouteType bgpRouteType) {
            this.bgpRouteType = bgpRouteType;
        }
    }

    public BgpNeighborConfig(Ip localIp, Ip neighborIp, BgpProcess process, NeighborType neighborType) {
        this.localIp = localIp;
        this.neighborIp = neighborIp;
        this.process = process;
        this.neighborType = neighborType;
    }

    public void setProcess(BgpProcess process) {
        this.process = process;
    }

    public BgpProcess getProcess() {
        return process;
    }

    public Ip getLocalIp() {
        return localIp;
    }
}
