package controlplane.process.bgp.routemap;

import controlplane.route.BgpRoute;
import controlplane.route.NDDBgpRoute;
import datamodel.ipv4.Prefix;

import java.util.Vector;

public class NDDRouteMapMatch {
    RouteMapMatch.MatchType type;
    Object match;

    public NDDRouteMapMatch(RouteMapMatch.MatchType type, Object match) {
        this.type = type;
        this.match = match;
    }

    public boolean match(NDDBgpRoute route) {
        if (type == RouteMapMatch.MatchType.PrefixList) {
            return matchPrefixList(route);
        }
        return false;
    }

    public boolean matchPrefixList(NDDBgpRoute route) {
        for (Prefix prefix : (Vector<Prefix>) match) {
            if (prefix.prefixMatchStrict(route.getPrefix())) return true;
        }
        return false;
    }
}
