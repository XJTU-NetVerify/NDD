package controlplane.process.bgp.routeaggregation;

import multimap.HashMultimap;
import multimap.Multimap;
import controlplane.process.bgp.NDDBgpProcess;
import controlplane.route.NDDBgpRoute;
import controlplane.route.NDDResolvedBgpRoute;
import controlplane.route.builder.NDDBgpRouteBuilder;
import controlplane.route.builder.NDDResolvedBgpRouteBuilder;
import datamodel.ipv4.Prefix;
import main.NDDController;
import util.NDDUtil;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class NDDRouteAggregation {
    NDDBgpProcess process;

    Prefix prefix;
    boolean suppressOnly;

    Multimap<NDDBgpRoute, NDDBgpRoute> aggrRoutes = HashMultimap.create();

    public NDDRouteAggregation(NDDBgpProcess process, Prefix prefix, boolean suppressOnly) {
        this.process = process;
        this.prefix = prefix;
        this.suppressOnly = suppressOnly;
    }

    public boolean aggregate(NDDBgpRoute specRoute) {
        if (specRoute.getPrefix().getPreLength() > prefix.getPreLength() &&
                prefix.prefixMatchLoose(specRoute.getPrefix())) {
            NDDBgpRoute aggrRoute = new NDDBgpRouteBuilder()
                    .setPrefix(prefix)
                    .build();
            aggrRoutes.put(aggrRoute, specRoute);
            return suppressOnly;
        }
        else {
            return false;
        }
    }

    public void insertInQueue() {
        for (Map.Entry<NDDBgpRoute, Collection<NDDBgpRoute>> entry : aggrRoutes.asMap().entrySet()) {
            NDDBgpRoute aggrRoute = entry.getKey();
            Set<Integer> tcs = entry.getValue().stream().map(NDDBgpRoute::getArriveTC).collect(Collectors.toSet());
            int tc = NDDUtil.orInBatch(tcs);
            if (tc != aggrRoute.getArriveTC()) {
                aggrRoute.setArriveTC(tc);
                aggrRoute.setOutPort(process.getRouter().getBlackhole());
                process.routeIn(process.getRouter(), aggrRoute);
            }
        }
    }
}
