package controlplane.network;

import application.config2spec.Config2spec;
import controlplane.Owner;
import controlplane.process.bgp.BgpExecutor;
import controlplane.process.bgp.BgpNeighborConfig;
import controlplane.process.bgp.BgpProcess;
import controlplane.process.bgp.BgpTopology;
import controlplane.process.ospf.OspfExecutor;
import controlplane.process.ospf.OspfNeighborConfig;
import controlplane.process.ospf.OspfProcess;
import controlplane.process.ospf.OspfTopology;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.TreeMap;
import main.Configuration;
import main.Controller;
import main.SRELogger;
import util.BDDUtil;
import util.TimeUtil;

public class CPExecutor {
    L3Topology _l3Topology;
    OspfTopology _ospfTopology;
    BgpTopology _bgpTopology;

    public CPExecutor() { }

    public void init() {
        CPUtil util = new CPUtil(this);
        util.parseConfigs(Controller.storage.input._config, Controller.storage.input._acl);
        util.parseL3Topology(Controller.storage.input._l3Edges, Controller.storage.input._edgePorts);
        util.parseEnvironment(Controller.storage.input._environment);
    }

    public void init(Path cfg, Path acl, Path topo, Path edgePorts, Path env) {
        CPUtil util = new CPUtil(this);
        util.parseConfigs(cfg, acl);
        util.parseL3Topology(topo, edgePorts);
        util.parseEnvironment(env);
    }

    public CPExecutor(L3Topology l3Topology, OspfTopology ospfTopology, BgpTopology bgpTopology) {
        _l3Topology = l3Topology;
        _ospfTopology = ospfTopology;
        _bgpTopology = bgpTopology;
    }

    public void genConnectedRoute() {
        // generate connected route
        _l3Topology._nodes.values().forEach(Router::genConnectedRoute);
    }

    public void buildOspfTopology() {
        TimeUtil timer = new TimeUtil();
        timer.begin();
        _l3Topology._l3Edges.forEach(l3edge -> {
            if (l3edge._bddVar != 0) {
                Router r1 = _l3Topology._nodes.get(l3edge._port1.getRouterName());
                Router r2 = _l3Topology._nodes.get(l3edge._port2.getRouterName());
                Port p1 = _l3Topology._ports.get(l3edge._port1);
                Port p2 = _l3Topology._ports.get(l3edge._port2);
                if (r1.ospfProcesses != null && r2.ospfProcesses != null) {
                    for (OspfProcess process1 : r1.getOspfProcesses().values()) {
                        for (OspfProcess process2 : r2.getOspfProcesses().values()) {
                            OspfNeighborConfig c1 = _ospfTopology.getNeighborConfig(process1, p1);
                            OspfNeighborConfig c2 = _ospfTopology.getNeighborConfig(process2, p2);
                            if (c1 != null && c2 != null) {
                                _ospfTopology.addEdge(c1, c2, l3edge._bddVar);
                            }
                        }
                    }
                }
            }
        });
        timer.end(SRELogger.LEVEL.INFO, "[TOPO]");
    }

    public void computeOspfRoutes() {
        OspfExecutor.execute(_ospfTopology);
    }

    public void computeOspfRoutes(OspfProcess announcer) {
        OspfExecutor.execute(_ospfTopology, announcer);
    }

    public void buildBgpTopology() {
        TimeUtil timer = new TimeUtil();
        timer.begin();

        /* considering dual direction packet reachability to build bgp neighbor relationship */
//        DPAnalyzer dpAnalyzer = new DPAnalyzer(this);
//        HashMap<Router, BDDTuple> hm = new HashMap<>();
//
//        _bgpTopology.getIpEdges().cellSet().forEach(cell -> {
//            Router src = _l3Topology._ipOwners.get(cell.getRowKey()).iterator().next();
//            int ip = Controller.bddManager.getBDDACLWrapper().encodeDstIPPrefix(cell.getColumnKey().asLong(), 32);
//            hm.put(src, hm.getOrDefault(src, BDDTuple.EMPTY).union(ip, 1));
//        });
//
//        dpAnalyzer.analyzeDataPlane(hm);
//
//        _bgpTopology.getIpEdges().cellSet().forEach(cell -> {
//            Router src = _l3Topology._ipOwners.get(cell.getRowKey()).iterator().next();
//            Router dst = _l3Topology._ipOwners.get(cell.getColumnKey()).iterator().next();
//            if (!_bgpTopology.containsEdge(src.bgpProcess, dst.bgpProcess)) {
//                int src2dst = dpAnalyzer._reachabilityDB.allRouterPairReachability.getOrDefault(new Pair<>(src, dst), BDDTuple.EMPTY).getBDD();
//                int dst2src = dpAnalyzer._reachabilityDB.allRouterPairReachability.getOrDefault(new Pair<>(src, dst), BDDTuple.EMPTY).getBDD();
//                int tc = Controller.bddManager.and(src2dst, dst2src);
//                tc = Controller.bddManager.getBDDPredicateWrapper().getTC(tc);
//                BgpNeighborConfig c1 = _bgpTopology.getNeighborConfig(src.bgpProcess, cell.getColumnKey());
//                BgpNeighborConfig c2 = _bgpTopology.getNeighborConfig(dst.bgpProcess, cell.getRowKey());
//                _bgpTopology.addEdge(c1, c2, tc);
//            }
//        });

        /* considering dual direction route reachability to build bgp neighbor relationship */
//        _bgpTopology.getIpEdges().cellSet().forEach(cell -> {
//            Ip srcIp = cell.getRowKey();
//            Ip dstIp = cell.getColumnKey();
//            Router src = _l3Topology._ipOwners.get(srcIp).iterator().next();
//            Router dst = _l3Topology._ipOwners.get(dstIp).iterator().next();
//            if (!_bgpTopology.containsEdge(src.bgpProcess, dst.bgpProcess)) {
//                int tc1 = 0;
//                for (Map.Entry<Prefix, SortedMultiList> entry : src.globalRib.getRib().entrySet()) {
//                    if (entry.getKey().ipMatch(dstIp)) {
//                        for (SortedMultiListItem item : entry.getValue().flat()) {
//                            tc1 = Controller.bddManager.orTo(tc1, item.getListTC());
//                        }
//                    }
//                }
//                int tc2 = 0;
//                for (Map.Entry<Prefix, SortedMultiList> entry : dst.globalRib.getRib().entrySet()) {
//                    if (entry.getKey().ipMatch(srcIp)) {
//                        for (SortedMultiListItem item : entry.getValue().flat()) {
//                            tc2 = Controller.bddManager.orTo(tc2, item.getListTC());
//                        }
//                    }
//                }
//                int tc = Controller.bddManager.andDerefBoth(tc1, tc2);
//                BgpNeighborConfig c1 = _bgpTopology.getNeighborConfig(src.bgpProcess, cell.getColumnKey());
//                BgpNeighborConfig c2 = _bgpTopology.getNeighborConfig(dst.bgpProcess, cell.getRowKey());
//                _bgpTopology.addEdge(c1, c2, tc);
//            }
//        });

        /* consider single direction route reachability to build bgp neighbor relationship */
        _bgpTopology.getIpEdges().cellSet().forEach(cell -> {
            Ip srcIp = cell.getRowKey();
            Ip dstIp = cell.getColumnKey();
            Router src = _l3Topology._ipOwners.getOne(srcIp);
            Router dst = _l3Topology._ipOwners.getOne(dstIp);
            if (src != null && dst != null) {
                if (!_bgpTopology.containsEdge(src.bgpProcess, dst.bgpProcess)) {
                    int tc = BDDUtil.orInBatch(Controller.bddManager.getBDD(), src.globalRib.query(dstIp).values());
                    if (tc == 0) tc = BDDUtil.orInBatch(Controller.bddManager.getBDD(), dst.globalRib.query(srcIp).values());

                    BgpNeighborConfig c1 = _bgpTopology.getNeighborConfig(src.bgpProcess, cell.getColumnKey());
                    BgpNeighborConfig c2 = _bgpTopology.getNeighborConfig(dst.bgpProcess, cell.getRowKey());
                    _bgpTopology.addEdge(c1, c2, tc);
                }
            }
        });

        timer.end(SRELogger.LEVEL.INFO, "[TOPO]");
    }

    public void computeBgpRoutes() {
        BgpExecutor.execute(_bgpTopology);
    }

    public void computeBgpRoutes(BgpProcess announcer) {
        BgpExecutor.execute(_bgpTopology, announcer);
    }

    public void installOriginalRoutes() {
        _l3Topology._nodes.values().forEach(Router::installOriginalRoutesToGlobalRib);
    }

    public void installIgpRoutes() {
        _l3Topology._nodes.values().forEach(Router::installIgpRoutesToGlobalRib);
    }

    public void installBgpRoutes() {
        _l3Topology._nodes.values().forEach(Router::installBgpRoutesToGlobalRib);
    }

    public void rib2fib() {
        _l3Topology._nodes.values().forEach(Router::installGlobalRibToFib);
    }

    public void generateDataPlane() {
        if (Configuration.ALL_IN_ONE) generateDataPlaneAllInOne();
        else generateDataPlaneOneByOne();
    }

    private void generateDataPlaneOneByOne() {
        SRELogger.pushContext("CPE OBO");
        TimeUtil timer = new TimeUtil();
        timer.begin();

        genConnectedRoute();
        installOriginalRoutes();

        // igp
        SRELogger.pushContext("OSPF");
        buildOspfTopology();
        for (Router r : Controller.ospfValidRouters) {
            r.ospfProcesses.values().forEach(process -> {
                process.setValid(true);
                computeOspfRoutes(process);
                process.setValid(false);
            });
        }
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ITERATION] " + OspfExecutor.iteration);
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ROUTE] total: " + OspfExecutor.total + " remain: " + OspfExecutor.remain);
        SRELogger.popContext();

        // install igp routes
        installIgpRoutes();

        // bgp
        SRELogger.pushContext("BGP");
        buildBgpTopology();
        for (Router r : Controller.bgpValidRouters) {
            r.bgpProcess.setValid(true);
            computeBgpRoutes(r.bgpProcess);
            r.bgpProcess.setValid(false);
        }
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ITERATION] " + BgpExecutor.iteration);
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ROUTE] total: " + BgpExecutor.total + " remain: " + BgpExecutor.remain);
        SRELogger.popContext();

        // install bgp routes
        installBgpRoutes();

        // install all routes into FIB
        rib2fib();

        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    private void generateDataPlaneAllInOne() {
        Controller.ospfValidRouters.forEach(r -> r.getOspfProcesses().values().forEach(p -> p.setValid(true)));
        Controller.bgpValidRouters.forEach(r -> r.getBgpProcess().setValid(true));

        SRELogger.pushContext("CPE AIO");
        TimeUtil timer = new TimeUtil();
        timer.begin();

        // generate connected route
        genConnectedRoute();
        installOriginalRoutes();
        // igp
        SRELogger.pushContext("OSPF");
        buildOspfTopology();
        computeOspfRoutes();
        SRELogger.popContext();
        // install igp routes
        installIgpRoutes();

        // install IGP routes into FIB
        // when resolving BGP topology, if we only care about route reachability, this is unnecessary
        // _l3Topology._nodes.values().forEach(Router::installGlobalRibToFib);

        // bgp
        SRELogger.pushContext("BGP");
        buildBgpTopology();
        computeBgpRoutes();
        SRELogger.popContext();

        int sumBgpRoute=0;
        for(BgpProcess process : _bgpTopology.edges.rowKeySet())
        {
            for(SortedMultiList lists : process.getRib().getRib().values())
            {
                for(ArrayList list : lists)
                {
                    sumBgpRoute+=list.size();
                }
            }
        }

        if (Configuration.RUN_BATCH_TIMES) {
            Config2spec.logWriter.println(sumBgpRoute+" bgp route");
            Config2spec.logWriter.flush();
        } else {
            System.out.println(sumBgpRoute+" bgp route");
        }

        // install bgp routes
        installBgpRoutes();
        // install all routes into FIB
        rib2fib();

        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public TreeMap<String, Router> getRouters() {
        return _l3Topology._nodes;
    }

    public TreeMap<PortName, Port> getPorts() {
        return _l3Topology._ports;
    }

    public HashSet<L3Edge> getL3Edges() {
        return _l3Topology._l3Edges;
    }

    public HashSet<Port> getEdgePorts() {
        return _l3Topology._edgePorts;
    }

    public HashSet<Router> getEdgeRouters() {
        return _l3Topology._edgeRouters;
    }

    public L3Topology getL3Topology() {
        return _l3Topology;
    }

    public Owner<Prefix, Router> getPrefixOwners() {
        return _l3Topology._prefixOwners;
    }

    public Owner<Ip, Router> getIpOwners() {
        return _l3Topology._ipOwners;
    }

    public void clear() {
        _l3Topology._nodes.values().forEach(Router::clear);
    }

    public void reset() {
        _l3Topology._nodes.values().forEach(Router::reset);
    }
}
