package controlplane.process.bgp;

public class BgpEdge {
    BgpNeighborConfig src;
    BgpNeighborConfig dst;
    int tc;

    public BgpEdge(BgpNeighborConfig src, BgpNeighborConfig dst, int tc) {
        this.src = src;
        this.dst = dst;
        this.tc = tc;
    }

    public void setTC(int tc) {
        this.tc = tc;
    }

    public BgpNeighborConfig getSrc() {
        return src;
    }

    public BgpNeighborConfig getDst() {
        return dst;
    }

    public int getTC() {
        return tc;
    }
}
