package controlplane.process.bgp.routemap;

import controlplane.route.BgpRoute;
import controlplane.route.NDDBgpRoute;

import java.util.HashMap;
import java.util.Map;

public class NDDRouteMap {
    Map<String, NDDRouteMapRule> rules;

    public NDDRouteMap() {
        rules = new HashMap<>();
    }

    public void addRule(NDDRouteMapRule rule) {
        rules.put(rule.neighbor, rule);
    }

    /**
     * @param route - route coming in / out
     */
    public NDDBgpRoute map(String neighbor, NDDBgpRoute route) {
        NDDRouteMapRule rule = rules.get(neighbor);
        if (rule != null) {
            route = rule.match(route);
        }
        return route;
    }
}
