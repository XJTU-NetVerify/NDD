package controlplane.process;

import controlplane.network.NDDRouter;
import controlplane.network.Router;
import controlplane.rib.NDDRib;
import controlplane.rib.Rib;
import controlplane.route.NDDRoute;
import controlplane.route.Route;

public interface NDDProcess {
    void insertOutQueue(NDDRoute route);

    NDDRouter getRouter();

    NDDRib getRib();

    void clear();

    void reset();
}

