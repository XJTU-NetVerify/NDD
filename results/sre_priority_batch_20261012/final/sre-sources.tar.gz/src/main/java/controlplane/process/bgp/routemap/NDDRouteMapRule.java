package controlplane.process.bgp.routemap;

import controlplane.route.BgpRoute;
import controlplane.route.NDDBgpRoute;

import java.util.Vector;

public class NDDRouteMapRule {
    String neighbor;

    Vector<NDDRouteMapPolicy> policies;

    public NDDRouteMapRule(String neighbor, Vector<NDDRouteMapPolicy> policies) {
        this.neighbor = neighbor;
        this.policies = policies;
    }

    public NDDBgpRoute match(NDDBgpRoute route) {
        for (NDDRouteMapPolicy policy : policies) {
            if (policy.match(route)) {
                return policy.act(route);
            }
        }
        // cisco's implicit deny policy
        return null;
    }
}
