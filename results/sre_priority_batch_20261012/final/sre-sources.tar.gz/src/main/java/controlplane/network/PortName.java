package controlplane.network;

import main.Configuration;
import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Objects;

public class PortName implements Comparable<PortName>, Serializable {
    private static final long serialVersionUID = -5651932486266221300L;

    final String _routerName;
    final String _interfaceName;

    public PortName(String routerName, String interfaceName) {
        _routerName = routerName;
        _interfaceName = interfaceName;
    }

    public String getRouterName() {
        return _routerName;
    }

    public String getInterfaceName() {
        return _interfaceName;
    }

    public String getFullName() {
        return _routerName + Configuration.ROUTER_INTF_CONNECTOR + _interfaceName;
    }

//    @Override
//    public String toString() {
//        return _interfaceName;
//    }

    @Override
    public String toString() {
        return getFullName();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PortName portName = (PortName) o;
        return _routerName.equals(portName._routerName) &&
               _interfaceName.equals(portName._interfaceName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(_routerName, _interfaceName);
    }

    @Override
    public int compareTo(@NotNull PortName o) {
        return Comparator.comparing(PortName::getRouterName).thenComparing(PortName::getInterfaceName).compare(this, o);
    }
}
