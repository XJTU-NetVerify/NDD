package controlplane.process.ospf;

import sre.ndd.NDD;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.network.Port;
import controlplane.network.Router;
import controlplane.process.NDDProcess;
import controlplane.process.Process;
import controlplane.rib.NDDRib;
import controlplane.rib.Rib;
import controlplane.route.*;
import controlplane.route.builder.NDDOspfRouteBuilder;
import controlplane.route.builder.OspfRouteBuilder;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.SortedMultiList;
import main.Controller;
import main.NDDController;
import multimap.Streams;

import java.util.*;
import java.util.stream.Collectors;

public class NDDOspfProcess implements NDDProcess {
    NDDRouter router;
    int processId;

    Deque<NDDOspfRoute> inQueue = new LinkedList<>();
    Deque<NDDOspfRoute> outQueue = new LinkedList<>();

    NDDRib rib;

    HashSet<RoutingProtocol> redistributions = new HashSet<>();
    HashSet<Prefix> networks = new HashSet<>();

    boolean valid = false;

    public NDDOspfProcess(NDDRouter router, int processId) {
        this.router = router;
        this.rib = new NDDRib(this);
        this.processId = processId;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public boolean valid() {
        return valid;
    }

    public void begin() {
        if (valid) {
                networks.stream().filter(Prefix::isInterested).forEach(prefix -> {
                NDDOspfRoute ospfRoute = new NDDOspfRouteBuilder().setPrefix(prefix).setListTC(NDD.getTrue()).build();
                outQueue.add(ospfRoute);
            });
            redistribute();
        }
    }

    void redistribute() {
        HashSet<NDDOspfRoute> generatedRoutes = new HashSet<>();
        if (redistributions.contains(RoutingProtocol.CONNECTED)) {
            router.getConnectedRib().getRib().values().forEach(list -> {
                NDDConnectedRoute cr = (NDDConnectedRoute) list.flat().iterator().next();
                generatedRoutes.add(redistribute(cr));
            });
        }
        if (redistributions.contains(RoutingProtocol.STATIC)) {
            multimap.Streams.concat(
                    router.getConditionalStaticRib().getRib().entrySet().stream(),
                    router.getUnconditionalStaticRib().getRib().entrySet().stream()
            )
                    // do not redistribute static routes with prefix 0.0.0.0/0
                    .filter(entry -> !entry.getKey().equals(Prefix.ZERO))
                    .forEach(entry -> entry.getValue().flat().forEach(item -> {
                        NDDStaticRoute sr = (NDDStaticRoute) item;
                        generatedRoutes.add(redistribute(sr));
                    }));
        }
        generatedRoutes.forEach(generatedRoute -> {
            rib.insert(generatedRoute);
            outQueue.add(generatedRoute);
        });
    }

    NDDOspfRoute redistribute(NDDRoute route) {
        return new NDDOspfRouteBuilder()
                .setPrefix(route.getPrefix())
                .setNextHop(route.getNextHop())
                .setOutPort(route.getOutPort())
                .setMetric(20)
                .setArriveTC(NDD.getTrue())
                .setListTC(NDD.getTrue())
                .build();
    }

    public void routeIn(NDDOspfRoute route) {
        inQueue.add(route);
    }

    public boolean updateRIB() {
        HashSet<Prefix> prefixes = new HashSet<>();

        List<NDDOspfRoute> ors = new ArrayList<>();
        while (!inQueue.isEmpty()) {
            NDDOspfRoute route = inQueue.pollFirst();
            ors.add(route);
            prefixes.add(route.getPrefix());
        }
        ors.sort(NDDOspfRoute::compareTo);
        ors.forEach(or -> rib.insert(or));

        prefixes.forEach(prefix -> {
            NDDSortedMultiList list = rib.getRib().get(prefix);
            NDDController.bddManager.getBDDTCWrapper().calTC(list, router.ecmp());
            list.flat().stream().map(item -> (NDDOspfRoute) item).filter(NDDOspfRoute::dirty).forEach(this::insertOutQueue);
        });

        rib.getRib().values().forEach(NDDSortedMultiList::resetIdx);

        return outQueue.isEmpty();
    }

    public void routeOut(Map<NDDOspfProcess, NDDOspfEdge> edges) {
        Iterator<NDDOspfRoute> itr = outQueue.iterator();
        while (itr.hasNext()) {
            NDDOspfRoute route = itr.next();

            edges.forEach((p, e) -> {
                // avoid propagation path loop
                if (!route.getPath().contains(p.router.getRouterName())) {
                    NDDOspfExecutor.propagate(route, e);
                }
            });

            itr.remove();
        }
    }

    @Override
    public void insertOutQueue(NDDRoute route) {
        if (route instanceof NDDOspfRoute) {
            ((NDDOspfRoute) route).setDirty(false);
            outQueue.add((NDDOspfRoute) route);
        }
    }

    public void addRedistribution(RoutingProtocol rp) {
        redistributions.add(rp);
    }

    public void addNetwork(Prefix prefix) {
        networks.add(prefix);
    }

    /** Helper function, checking whether this ospf process will announce any prefix */
    public HashSet<Prefix> getPrefixes() {
        HashSet<Prefix> prefixes = new HashSet<>(networks);
        // route redistribution
        if (redistributions.contains(RoutingProtocol.CONNECTED)) {
            prefixes.addAll(router.getConnectedRib().getRib().keySet());
        }
        if (redistributions.contains(RoutingProtocol.STATIC)) {
            prefixes.addAll(
                Streams.concat(
                    router.getConditionalStaticRib().getRib().entrySet().stream(),
                    router.getUnconditionalStaticRib().getRib().entrySet().stream()
                )
                // do not redistribute static routes with prefix 0.0.0.0/0
                .filter(entry -> !entry.getKey().equals(Prefix.ZERO))
                .map(Map.Entry::getKey)
                .collect(Collectors.toSet())
            );
        }
        if (redistributions.contains(RoutingProtocol.LOOPBACK)) {
            prefixes.add(router.getLoopback().getPrimaryIpAddress().toPrefix());
        }
        return prefixes;
    }

    @Override
    public NDDRouter getRouter() {
        return router;
    }

    @Override
    public NDDRib getRib() {
        return rib;
    }

    public int getProcessId() {
        return processId;
    }

    public void clear() {
        inQueue = null;
        outQueue = null;
        redistributions = null;
        networks = null;
        rib.clear();
    }

    public void reset() {
        inQueue = new LinkedList<>();
        outQueue = new LinkedList<>();
        redistributions = new HashSet<>();
        networks = new HashSet<>();
        rib.reset();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NDDOspfProcess that = (NDDOspfProcess) o;
        return processId == that.processId &&
                Objects.equals(router, that.router);
    }

    @Override
    public int hashCode() {
        return Objects.hash(router, processId);
    }
}
