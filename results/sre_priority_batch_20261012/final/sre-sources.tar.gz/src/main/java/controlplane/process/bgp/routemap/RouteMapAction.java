package controlplane.process.bgp.routemap;

import controlplane.route.BgpRoute;

public class RouteMapAction {
    public enum ActionType {
        Metric,
        MetricType,
        DefaultInterface,
        Interface,
        IpDefaultNextHop,
        IpNextHop,
        NextHop,
        AsPath,
        Community,
        LocalPreference,
        Weight,
        Origin,
        Tag
    }
    ActionType type;
    Object action;

    public RouteMapAction(ActionType type, Object action) {
        this.type = type;
        this.action = action;
    }

    public void act(BgpRoute route) {
        switch (type) {
            case Metric:
                break;
            case MetricType:
                break;
            case DefaultInterface:
                break;
            case Interface:
                break;
            case IpDefaultNextHop:
                break;
            case IpNextHop:
                break;
            case NextHop:
                break;
            case AsPath:
                break;
            case Community:
                break;
            case LocalPreference:
                route.setLocalPreference((int) action);
                break;
            case Weight:
                break;
            case Origin:
                break;
            case Tag:
                break;
        }
    }
}
