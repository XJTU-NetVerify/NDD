package controlplane.network;

import sre.ndd.NDD;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import multimap.HashBasedTable;
import multimap.Table;


public class NDDL3Edge implements Serializable {
    private static final long serialVersionUID = -5376464008825444024L;

    private static final Table<PortName, PortName, NDDL3Edge> CACHE = HashBasedTable.create();

    public static NDDL3Edge of(PortName port1, PortName port2) {
        if (!CACHE.contains(port1, port2)) {
            if (port1.compareTo(port2) > 0) {
                PortName tmp = port1;
                port1 = port2;
                port2 = tmp;
            }
            NDDL3Edge l3Edge = new NDDL3Edge(port1, port2);
            CACHE.put(port1, port2, l3Edge);
            CACHE.put(port2, port1, l3Edge);
        }
        return CACHE.get(port1, port2);
    }

    public static HashSet<NDDL3Edge> getAllL3Edge() {
        return new HashSet<>(CACHE.values());
    }

    /** Reset process-global canonical links between isolated S0/unit-test universes. */
    public static void clearCache() {
        CACHE.clear();
    }

    PortName _port1;
    PortName _port2;
    int _nddVar = NDD.getFalse(); //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    int _cnt = 0;
    State _state = State.SYMBOLIC;

    private NDDL3Edge(PortName port1, PortName port2) {
        _port1 = port1;
        _port2 = port2;
    }

    public PortName getSrc() {
        return _port1;
    }

    public PortName getDst() {
        return _port2;
    }

    public int getTC() {
        return _nddVar;
    }

    public void setTC(int nddVar) {
        _nddVar = nddVar;
    }

    public int getCnt() {
        return _cnt;
    }

    public void setCnt(int cnt) {
        _cnt = cnt;
    }

    public State getState() {
        return _state;
    }

    public void setState(State state) {
        _state = state;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NDDL3Edge l3Edge = (NDDL3Edge) o;
        return _port1.equals(l3Edge._port1) &&
                _port2.equals(l3Edge._port2);
    }

    @Override
    public int hashCode() {
        return Objects.hash(_port1, _port2);
    }

    @Override
    public String toString() {
        return "link{" + _port1.getFullName() + "," + _port2.getFullName() + "}";
    }
}
