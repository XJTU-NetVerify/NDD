package controlplane.route;

public enum RoutingProtocol {
    CONNECTED,
    STATIC,
    BGP,
    OSPF,
    LOCAL,
    // This is for comparing experiment with plankton,
    // since plankton runs ospf with each edge router announcing one prefix
    LOOPBACK
}
