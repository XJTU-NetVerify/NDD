package controlplane.process.ospf;

import multimap.HashBasedTable;
import multimap.Table;
import controlplane.network.Port;

public class OspfTopology {
    Table<OspfProcess, OspfProcess, OspfEdge> edges;
    Table<OspfProcess, Port, OspfNeighborConfig> configs;

    public OspfTopology() {
        this.edges = HashBasedTable.create();
        this.configs = HashBasedTable.create();
    }

    public void addEdge(OspfNeighborConfig n1, OspfNeighborConfig n2, int tc) {
        OspfEdge e1 = new OspfEdge(n1, n2, tc);
        OspfEdge e2 = new OspfEdge(n2, n1, tc);
        edges.put(n1.process, n2.process, e1);
        edges.put(n2.process, n1.process, e2);
    }

    public void addNeighborConfig(OspfNeighborConfig config) {
        configs.put(config.process, config.port, config);
    }

    public OspfNeighborConfig getNeighborConfig(OspfProcess process, Port port) {
        return configs.get(process, port);
    }
}
