package controlplane.route;

import org.jetbrains.annotations.NotNull;

import java.util.Vector;

/* class for OSPF-Route-PropagationPath and BGP-Route-ASPath */
public class Path<T extends Comparable<T>> extends Vector<T> implements Comparable<Path<T>> {

    private static final long serialVersionUID = 6859903401088825359L;

    public Path() {
        super();
    }

    public Path(Path<T> path) {
        super(path);
    }

    @Override
    public int compareTo(@NotNull Path<T> o) {
        int ds = size() - o.size();
        if (ds != 0) {
            // prefer shorter path
            return -ds;
        }
        else {
            for (int i = 0; i < size(); i++) {
                int tmp = elementAt(i).compareTo(o.elementAt(i));
                if (tmp != 0) {
                    return tmp;
                }
            }
            return 0;
        }
    }
}
