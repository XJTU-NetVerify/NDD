package controlplane.route;

import sre.ndd.NDD;
import controlplane.network.NDDPort;
import controlplane.network.Port;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.SortedMultiList;
import main.Controller;

import java.util.Objects;

public abstract class NDDDynamicRoute extends NDDRoute{
    // propagation path
    Path<String> _path;

    boolean _dirty;

    public NDDDynamicRoute(
            Prefix prefix,
            Ip nextHop,
            NDDPort outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            NDDSortedMultiList list,
            Path<String> path,
            boolean dirty
    ) {
        super(prefix, nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list);
        _path = path;
        _dirty = dirty;
    }

    public Path<String> getPath() {
        return _path;
    }

    int _listTCOld = NDD.getFalse();
    /**
     * the only caller of
     * @see DynamicRoute#setListTC(int)
     * is
     * @see bdd.BDDTCWrapper#calTC(SortedMultiList, boolean)
     * set _dirty = true if _listTC changes
     */
    @Override
    public void setListTC(int tc) {
        boundedBudget = -1;
        NDD.deref(_listTCOld);
        _listTCOld = _listTC;
        _listTC = tc;
        // Native retained roots have stable canonical identity across GC;
        // the Java path keeps the legacy semantic difference checks.
        _dirty = !NDD.equivalent(_listTCOld, _listTC);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        NDDDynamicRoute that = (NDDDynamicRoute) o;
        return Objects.equals(_path, that._path);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), _path);
    }

    public boolean dirty() {
        return _dirty;
    }

    public void setDirty(boolean dirty) {
        _dirty = dirty;
    }

    @Override
    public void releaseNddOwnership() {
        if (_listTCOld != NDD.getFalse()) {
            NDD.deref(_listTCOld);
            _listTCOld = NDD.getFalse();
        }
        super.releaseNddOwnership();
    }
}
