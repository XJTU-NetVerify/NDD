package controlplane.route;

import controlplane.network.Port;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.Objects;

public class OspfRoute extends DynamicRoute {
    int _AD;
    long _metric;

    public OspfRoute(
            Prefix prefix,
            Ip nextHop,
            Port outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            SortedMultiList list,
            Path<String> path,
            boolean dirty,
            int AD,
            long metric
    ) {
        super(prefix, nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list, path, dirty);
        _AD = AD;
        _metric = metric;
    }

    @Override
    public RoutingProtocol getProtocol() {
        return RoutingProtocol.OSPF;
    }

    @Override
    public int getAD() {
        return _AD;
    }

    @Override
    public Long getMetric() {
        return _metric;
    }

    @Override
    public int compareTo(@NotNull SortedMultiListItem o) {
        if (o instanceof OspfRoute) {
            return Comparator
                    .comparing(OspfRoute::getMetric, Comparator.reverseOrder())
                    .compare(this, (OspfRoute) o);
        }
        else {
            return super.compareTo(o);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        OspfRoute ospfRoute = (OspfRoute) o;
        return _AD == ospfRoute._AD &&
               _metric == ospfRoute._metric;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), _AD, _metric);
    }

    @Override
    public String toString() {
        return _prefix.toString()
               + "\t" + _outPort
               + "\t" + _nextHop
               + "\t" + _path
               + "\t" + _arriveTC
               + "\t" + _listTC
               + "\tOSPF";
    }
}
