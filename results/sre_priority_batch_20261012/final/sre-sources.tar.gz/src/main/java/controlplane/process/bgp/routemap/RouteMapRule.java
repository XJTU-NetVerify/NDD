package controlplane.process.bgp.routemap;

import controlplane.route.BgpRoute;

import java.util.Vector;

public class RouteMapRule {
    String neighbor;

    Vector<RouteMapPolicy> policies;

    public RouteMapRule(String neighbor, Vector<RouteMapPolicy> policies) {
        this.neighbor = neighbor;
        this.policies = policies;
    }

    public BgpRoute match(BgpRoute route) {
        for (RouteMapPolicy policy : policies) {
            if (policy.match(route)) {
                return policy.act(route);
            }
        }
        // cisco's implicit deny policy
        return null;
    }
}
