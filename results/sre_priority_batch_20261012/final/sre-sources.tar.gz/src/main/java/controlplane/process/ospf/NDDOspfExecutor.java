package controlplane.process.ospf;

import sre.ndd.NDD;
import main.Configuration;
import controlplane.route.NDDOspfRoute;
import controlplane.route.OspfRoute;
import controlplane.route.Path;
import controlplane.route.builder.NDDOspfRouteBuilder;
import controlplane.route.builder.OspfRouteBuilder;
import main.Controller;
import main.SRELogger;
import util.TimeUtil;

public class NDDOspfExecutor {
    public static int iteration = 0;
    public static int total = 0;
    public static int remain = 0;
    public static void execute(NDDOspfTopology topology, NDDOspfProcess announcer) {
        announcer.begin();
        iteration = Integer.max(iterate(topology), iteration);
        int[] stats = cleanDeadRoutes(topology);
        total = stats[0];
        remain = stats[1];
    }

    public static void execute(NDDOspfTopology topology) {
        TimeUtil igpTimer = new TimeUtil();
        igpTimer.begin();

        // first round
        topology.edges.rowKeySet().forEach(NDDOspfProcess::begin);

        // iterate
        int iteration = iterate(topology);
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ITERATION] " + iteration);

        int[] stats = cleanDeadRoutes(topology);
        SRELogger.logCPExe(SRELogger.LEVEL.INFO, "[ROUTE] total: " + stats[0] + " remain: " + stats[1]);
        // System.out.print(stats[1] + "\t");

        igpTimer.end(SRELogger.LEVEL.INFO, "");
    }

    /** Run the fixed point but retain dead contributions for an S1 dormant index. */
    public static void executeRetainingDeadRoutes(NDDOspfTopology topology) {
        topology.edges.rowKeySet().forEach(NDDOspfProcess::begin);
        iterate(topology);
    }

    public static int iterate(NDDOspfTopology topology) {
        boolean converged = false;
        int iteration = 0;
        long start = System.nanoTime();
        while (
                !converged
                && iteration < Configuration.MAX_SRC_ROUNDS
                && (System.nanoTime() - start) / 1e9 < Configuration.SRC_TIMEOUT_SECONDS
        ) {
            converged = true;

            // route exchange between ospf neighbors
            topology.edges.rowMap().forEach(NDDOspfProcess::routeOut);

            // ospf local step
            for (NDDOspfProcess process : topology.edges.rowKeySet()) {
                converged = process.updateRIB() & converged;
            }

            iteration++;
        }
        return iteration;
    }

    public static int[] cleanDeadRoutes(NDDOspfTopology topology) {
        int total = 0;
        int remain = 0;
        for (NDDOspfProcess process : topology.edges.rowKeySet()) {
            int[] statistic = process.getRib().cleanDeadRoute();
            total += statistic[0];
            remain += statistic[1];
        }
//        topology.edges.rowKeySet().forEach(process -> process.getRib().cleanDeadRoute());
        return new int[] {total, remain};
    }

    public static void propagate(NDDOspfRoute route, NDDOspfEdge edge) {

        int newTC = NDD.ref(NDD.and(route.getListTC(), edge.getTC()));

        if (!NDD.isFalse(newTC)) {
            Path<String> path = new Path<>(route.getPath());
            path.add(edge.src.process.router.getRouterName());

            NDDOspfRoute newRoute = new NDDOspfRouteBuilder()
                    .setPrefix(route.getPrefix())
                    .setNextHop(edge.src.port.getIp())
                    .setOutPort(edge.dst.port)
                    .setArriveTC(newTC)
                    .setPath(path)
                    .setMetric(route.getMetric() + edge.dst.intfSetting.cost)
                    .build();

            edge.dst.process.routeIn(newRoute);
        }

    }
}
