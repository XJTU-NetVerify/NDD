package controlplane.route;

import controlplane.network.Port;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;

public class LocalRoute extends ConnectedRoute {
    public LocalRoute(
            Prefix prefix,
            Ip nextHop,
            Port outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            SortedMultiList list,
            int AD
    ) {
        super(prefix, nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list, AD);
    }

    @Override
    public RoutingProtocol getProtocol() {
        return RoutingProtocol.LOCAL;
    }

    @Override
    public String toString() {
        return _prefix.toString()
                + "\t" + _outPort
                + "\tLocal";
    }
}
