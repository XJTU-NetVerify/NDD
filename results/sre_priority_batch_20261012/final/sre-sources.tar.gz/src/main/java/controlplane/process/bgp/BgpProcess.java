package controlplane.process.bgp;

import multimap.HashMultimap;
import multimap.Multimap;
import multimap.Table;
import controlplane.network.Port;
import controlplane.network.Router;
import controlplane.process.Process;
import controlplane.process.bgp.routeaggregation.RouteAggregation;
import controlplane.process.bgp.routemap.RouteMap;
import controlplane.rib.Rib;
import controlplane.route.BgpRoute;
import controlplane.route.DynamicRoute;
import controlplane.route.ResolvedBgpRoute;
import controlplane.route.Route;
import controlplane.route.builder.BgpRouteBuilder;
import controlplane.route.builder.ResolvedBgpRouteBuilder;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import main.Controller;

import java.util.*;
import java.util.function.Function;

public class BgpProcess implements Process {
    Router router;
    int asNumber;

    HashSet<Prefix> networks = new HashSet<>();

    Deque<BgpRoute> inQueue = new LinkedList<>();
    HashSet<Prefix> suppressedPrefixes = new HashSet<>();
    Multimap<Integer, BgpRoute> outQueue = HashMultimap.create();

    Rib rib;

    RouteMap routeMapIn;
    RouteMap routeMapOut;

    Vector<RouteAggregation> routeAggregations;

    boolean valid = false;
    boolean br = false;
    boolean rr = false;

    boolean multipath = true;

    public BgpProcess(Router router) {
        this.router = router;
        this.asNumber = router.getAsNumber();
        this.rib = new Rib(this);
    }

    public void setNetworks(HashSet<Prefix> networksToBeAdvertised) {
        this.networks = networksToBeAdvertised;
    }

    public void setRouteMapIn(RouteMap routeMapIn) {
        this.routeMapIn = routeMapIn;
    }

    public void setRouteMapOut(RouteMap routeMapOut) {
        this.routeMapOut = routeMapOut;
    }

    public void setRouteAggregations(Vector<RouteAggregation> routeAggregations) {
        this.routeAggregations = routeAggregations;
    }

    public void setMultipath(boolean multipath) {
        this.multipath = multipath;
    }

    public void addNetwork(Prefix prefix) {
        this.networks.add(prefix);
    }

    public Router getRouter() {
        return router;
    }

    public HashSet<Prefix> getNetworks() {
        return networks;
    }

    @Override
    public Rib getRib() {
        return rib;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public boolean valid() {
        return valid;
    }

    public void begin() {
        if (valid) {
            /*  According to Cisco documentation, when using network command in BGP,
                we have to check whether the prefix is already in the router's RIB.  */
            networks.stream()
                    .filter(prefix -> prefix.isInterested() && router.getGlobalRib().getRib().containsKey(prefix))
                    .forEach(prefix -> {
                        BgpRoute bgpRoute = new BgpRouteBuilder()
                                .setPrefix(prefix)
                                .setNextHop(Ip.of("0.0.0.0"))
                                .setType(BgpRoute.BgpRouteType.NETWORK)
                                .setArriveTC(1)
                                .setListTC(1)
                                .build();
                        ResolvedBgpRoute resolvedBgpRoute = new ResolvedBgpRouteBuilder()
                                .setBgpRoute(bgpRoute)
                                .setOutPort(router.getBlackhole())
                                .setIgpCostToNextHop(0)
                                .setArriveTC(1)
                                .setListTC(1)
                                .build();
                        rib.insert(resolvedBgpRoute);
                        insertOutQueue(bgpRoute);
                    });
//            networks.stream()
//                    .filter(prefix -> prefix.isInterested() && router.getGlobalRib().getRib().containsKey(prefix))
//                    .forEach(prefix -> {
//                        BgpRoute bgpRoute = new BgpRouteBuilder()
//                                .setPrefix(prefix)
//                                .setNextHop(prefix.getIp())
//                                .setType(BgpRoute.BgpRouteType.NETWORK)
//                                .setArriveTC(1)
//                                .setListTC(1)
//                                .build();
//                        routeIn(router, bgpRoute);
//                    });
//            updateRIB();
        }
    }

    /**
     * check if there exists loop
     * if so, drop
     * else, insert it into the inQueue
     */
    public void routeIn(Router from, BgpRoute route) {
        if (routeMapIn != null) {
            route = routeMapIn.map(from.getRouterName(), route);
        }
        if (route != null) {
            boolean suppressed = false;
            for (RouteAggregation ra : routeAggregations) {
                suppressed = ra.aggregate(route) | suppressed;
            }
            if (suppressed) {
                suppressedPrefixes.add(route.getPrefix());
            }
            inQueue.add(route);
        }
    }

//    public boolean updateRIB() {
//        HashSet<Prefix> prefixes = new HashSet<>();
//        HashSet<ResolvedBgpRoute> routes = new HashSet<>();
//
//        while (!inQueue.isEmpty()) {
//            BgpRoute route = inQueue.pollFirst();
//            combineIgp(route).forEach(r -> {
//                if (rib.insert(r)) {
//                    Controller.bddManager.getBDDTCWrapper().calTC(r, router.ecmp());
//                    routes.add(r);
//                }
//                else {
//                    prefixes.add(r.getPrefix());
//                }
//            });
//        }
//
//        prefixes.forEach(prefix -> {
//            SortedMultiList list = rib.getRib().get(prefix);
//            Controller.bddManager.getBDDTCWrapper().calTC(list, router.ecmp());
//            list.flat().stream().map(item -> (ResolvedBgpRoute) item).filter(DynamicRoute::dirty).forEach(routes::add);
//        });
//
//        routes.forEach(r -> insertOutQueue(r.prepareOut()));
//
//        return outQueue.isEmpty();
//    }

    public boolean updateRIB() {
        HashSet<Prefix> prefixes = new HashSet<>();

        routeAggregations.forEach(RouteAggregation::insertInQueue);
        List<ResolvedBgpRoute> rbrs = new ArrayList<>();
        while (!inQueue.isEmpty()) {
            BgpRoute route = inQueue.pollFirst();
            prefixes.add(route.getPrefix());
            rbrs.addAll(combineIgp(route));
        }
        rbrs.sort(ResolvedBgpRoute::compareTo);
        rbrs.forEach(rbr -> rib.insert(rbr));

        prefixes.forEach(prefix -> {
            SortedMultiList list = rib.getRib().get(prefix);
            if (list != null) {
                Controller.bddManager.getBDDTCWrapper().calTC(list, multipath);
                if (!suppressedPrefixes.contains(prefix)) {
                    list.flat().stream().map(item -> (ResolvedBgpRoute) item).filter(DynamicRoute::dirty).forEach(r -> insertOutQueue(r.prepareOut()));
                }
            }
        });

        rib.getRib().values().forEach(SortedMultiList::resetIdx);

        return outQueue.isEmpty();
    }

    public HashSet<ResolvedBgpRoute> combineIgp(BgpRoute bgpRoute) {
        HashSet<ResolvedBgpRoute> hs = new HashSet<>();
        if (bgpRoute.getOutPort() != null) {
            ResolvedBgpRoute newRoute = new ResolvedBgpRouteBuilder()
                    .setBgpRoute(bgpRoute)
                    .setOutPort(bgpRoute.getOutPort())
                    .setIgpCostToNextHop(0)
                    .setArriveTC(bgpRoute.getArriveTC())
                    .build();
            hs.add(newRoute);
        }
        else {
            // (igp cost, out port) -> tc
            Table<Long, Port, Integer> tbl = router.getGlobalRib().query(bgpRoute.getNextHop());
            tbl.cellSet().forEach(cell -> {
                ResolvedBgpRoute newRoute = new ResolvedBgpRouteBuilder()
                        .setBgpRoute(bgpRoute)
                        .setOutPort(cell.getColumnKey())
                        .setIgpCostToNextHop(Objects.requireNonNull(cell.getRowKey()))
                        .setArriveTC(Controller.bddManager.and(bgpRoute.getArriveTC(), Objects.requireNonNull(cell.getValue())))
                        .build();
                hs.add(newRoute);
            });
        }
        return hs;
    }

    public void routeOut(Map<BgpProcess, BgpEdge> edges, Function<BgpNeighborConfig.NeighborType, Boolean> func) {
        Iterator<BgpRoute> itr = outQueue.values().iterator();
        while (itr.hasNext()) {
            BgpRoute route = itr.next();

            for (Map.Entry<BgpProcess, BgpEdge> entry : edges.entrySet()) {
                BgpProcess p = entry.getKey();
                BgpEdge e = entry.getValue();
                if (e.tc != 0 && func.apply(e.src.neighborType)) {
                    BgpRoute tmp = new BgpRoute(route);
                    // apply RouteMapOut
                    if (routeMapOut != null) {
                        tmp = routeMapOut.map(p.router.getRouterName(), tmp);
                    }
                    // avoid propagation path loop and AS path loop
                    if (tmp != null && (!tmp.getPath().contains(p.router.getRouterName())) && (!tmp.getASPath().contains(p.asNumber))) {
                        BgpExecutor.propagate(tmp, e);
                    }
                }
            }

            itr.remove();
        }
    }

    public void rrFinalRound() {
        rib.getRib().values().forEach(list ->
                list.flat().forEach(item -> {
                    ResolvedBgpRoute rbr = (ResolvedBgpRoute) item;
                    insertOutQueue(rbr.prepareOut());
                }));
    }

    public void setBR(boolean br) {
        this.br = br;
    }

    public boolean isBR() {
        return br;
    }

    public void setRR(boolean rr) {
        this.rr = rr;
    }

    public boolean isRR() {
        return rr;
    }

    public boolean isIR() {
        return !br && !rr;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BgpProcess that = (BgpProcess) o;
        return asNumber == that.asNumber &&
               Objects.equals(router, that.router);
    }

    @Override
    public int hashCode() {
        return Objects.hash(router, asNumber);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("BgpProcess\n");
        networks.forEach(prefix -> builder.append(prefix.toString()));
        return builder.toString();
    }

    public void clear() {
        inQueue = null;
        outQueue = null;
        networks = null;
        rib.clear();
    }

    public void reset() {
        inQueue = new LinkedList<>();
        outQueue = HashMultimap.create();
        rib.reset();
    }

    public void insertOutQueue(Route route) {
        if (route instanceof BgpRoute) {
            BgpRoute tmp = (BgpRoute) route;
            int hash = tmp.hashCode();
            if (outQueue.containsKey(hash)) {
                for (BgpRoute bgpRoute : outQueue.get(hash)) {
                    if (bgpRoute.equals(tmp)) {
                        bgpRoute.setListTC(Controller.bddManager.or(bgpRoute.getListTC(), tmp.getListTC()));
                        return;
                    }
                }
            }
            outQueue.put(hash, tmp);
        }
    }
}
