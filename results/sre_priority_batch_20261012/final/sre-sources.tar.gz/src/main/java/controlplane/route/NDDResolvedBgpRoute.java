package controlplane.route;

import controlplane.network.NDDPort;
import controlplane.network.Port;
import controlplane.route.builder.BgpRouteBuilder;
import controlplane.route.builder.NDDBgpRouteBuilder;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import sre.ndd.NDD;
import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.Objects;

public class NDDResolvedBgpRoute extends NDDBgpRoute {
    long _igpCostToNextHop;

    public NDDResolvedBgpRoute(
            NDDBgpRoute bgpRoute,
            NDDPort outPort,
            long igpCostToNextHop,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            NDDSortedMultiList list
    ) {
        super(bgpRoute._prefix, bgpRoute._nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list, bgpRoute._path, false, bgpRoute._origin, bgpRoute._localPreference, bgpRoute._ASPath, bgpRoute._med, bgpRoute._iAD, bgpRoute._eAD, bgpRoute._bgpRouteType);
        _igpCostToNextHop = igpCostToNextHop;
    }

    public long getIgpCostToNextHop() {
        return _igpCostToNextHop;
    }

    public NDDBgpRoute prepareOut() {
        _dirty = false;
        return new NDDBgpRouteBuilder()
                .setPrefix(_prefix)
                .setNextHop(_nextHop)
                .setPath(new Path<>(_path))
                .setOrigin(_origin)
                .setLocalPreference(_localPreference)
                .setASPath(new Path<>(_ASPath))
                .setMetric(_med)
                .setIAD(_iAD)
                .setEAD(_eAD)
                .setType(_bgpRouteType)
                .setListTC(_listTC)
                .build();
    }

    @Override
    public int compareTo(@NotNull NDDSortedMultiListItem o) {
        int tmp = super.compareTo(o);
        if (o instanceof NDDResolvedBgpRoute && tmp == 0) {
            return Comparator
                    .comparing(NDDResolvedBgpRoute::getIgpCostToNextHop, Comparator.reverseOrder())
                    .compare(this, (NDDResolvedBgpRoute) o);
        }
        else {
            return tmp;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        NDDResolvedBgpRoute that = (NDDResolvedBgpRoute) o;
        return _igpCostToNextHop == that._igpCostToNextHop;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), _igpCostToNextHop);
    }
}