package controlplane.process.ospf;

import sre.ndd.NDD;

public class NDDOspfEdge {
    NDDOspfNeighborConfig src;
    NDDOspfNeighborConfig dst;
    int tc;

    public NDDOspfEdge(NDDOspfNeighborConfig src, NDDOspfNeighborConfig dst, int tc) {
        this.src = src;
        this.dst = dst;
        this.tc = tc;
    }

    public NDDOspfNeighborConfig getSrc() {
        return src;
    }

    public NDDOspfNeighborConfig getDst() {
        return dst;
    }

    public int getTC() {
        return tc;
    }
}
