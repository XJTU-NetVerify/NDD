package controlplane.process.bgp;

import sre.ndd.NDD;
import multimap.HashBasedTable;
import multimap.Table;
import controlplane.process.bgp.*;
import datamodel.ipv4.Ip;

import java.util.Collection;
import java.util.HashMap;

public class NDDBgpTopology {
    Table<NDDBgpProcess, Ip, NDDBgpNeighborConfig> configs;
    public Table<NDDBgpProcess, NDDBgpProcess, NDDBgpEdge> edges;
    HashMap<NDDBgpEdge, NDDBgpEdge> inverseEdges;
    Table<Ip, Ip, Integer> ipEdges;

    public NDDBgpTopology() {
        configs = HashBasedTable.create();
        edges = HashBasedTable.create();
        inverseEdges = new HashMap<>();
        ipEdges = HashBasedTable.create();
    }

    public void addEdge(NDDBgpNeighborConfig n1, NDDBgpNeighborConfig n2, int tc) {
        if (n1 != null && n2 != null && !NDD.isFalse(tc)) {
            NDDBgpEdge e1 = new NDDBgpEdge(n1, n2, tc);
            NDDBgpEdge e2 = new NDDBgpEdge(n2, n1, tc);
            edges.put(n1.process, n2.process, e1);
            edges.put(n2.process, n1.process, e2);
            inverseEdges.put(e1, e2);
            inverseEdges.put(e2, e1);
        }
    }

    public void addNeighborConfig(NDDBgpNeighborConfig config) {
        configs.put(config.process, config.neighborIp, config);
        ipEdges.put(config.localIp, config.neighborIp, NDD.getFalse());
    }

    public NDDBgpNeighborConfig getNeighborConfig(NDDBgpProcess process, Ip neighborIp) {
        return configs.get(process, neighborIp);
    }

    public Collection<NDDBgpEdge> getEdges() {
        return edges.values();
    }

    public NDDBgpEdge getInverseEdge(NDDBgpEdge edge) {
        return inverseEdges.get(edge);
    }

    public Table<Ip, Ip, Integer> getIpEdges() {
        return ipEdges;
    }

    public boolean containsEdge(NDDBgpProcess p1, NDDBgpProcess p2) {
        return edges.get(p1, p2) != null;
    }
}
