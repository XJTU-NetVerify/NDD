package controlplane.route;

import sre.ndd.NDD;
import java.util.List;
import java.util.stream.Collectors;


import controlplane.network.NDDPort;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import util.NDDUtil;

public class NDDResolvedStaticRoute extends NDDStaticRoute {
    List<NDDRoute> _resolutionSteps;

    public NDDResolvedStaticRoute(
            Prefix prefix,
            Ip nextHop,
            NDDPort outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            NDDSortedMultiList list,
            int AD,
            List<NDDRoute> resolutionSteps
    ) {
        super(
                prefix,
                nextHop,
                outPort,
                arriveTC,
                listTC,
                innerIdx,
                outerIdx,
                list,
                AD
        );
        _resolutionSteps = resolutionSteps;
    }

    public NDDResolvedStaticRoute(List<NDDRoute> resolutionSteps) {
        this(
                resolutionSteps.get(0)._prefix,
                resolutionSteps.get(resolutionSteps.size() - 1)._nextHop,
                resolutionSteps.get(resolutionSteps.size() - 1)._outPort,
                NDDUtil.andInBatch(resolutionSteps.stream().map(NDDRoute::getListTC).collect(Collectors.toSet())),
                NDD.getFalse(),
                -1,
                -1,
                null,
                // todo
                resolutionSteps.get(0).getAD(),
                resolutionSteps
        );
    }
}
