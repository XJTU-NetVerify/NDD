package controlplane.network;

import sre.ndd.NDD;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import dataplane.acl.NDDACLRule;

import java.util.LinkedList;
import java.util.Objects;
import java.util.Vector;

public class NDDPort {
    final PortName portName;
    NDDRouter router;
    IpAddress primaryIpAddress;
    Vector<IpAddress> secondaryIpAddresses;
    NDDPort linkedPort;
    NDDL3Edge l3Edge;

    LinkedList<NDDACLRule> aclIn;
    LinkedList<NDDACLRule> aclOut;

    int portFwdNDD = NDD.getFalse();
    int portAclInNDD = NDD.getTrue();
    int portAclOutNDD = NDD.getTrue();

    boolean loopback;
    boolean blackhole;
    boolean sink;
    boolean edge;

    State _state = State.SYMBOLIC;

    public NDDPort(PortName portName, NDDRouter router,  IpAddress primaryIpAddress, boolean loopback) {
        this.portName = portName;
        this.router = router;
        this.primaryIpAddress = primaryIpAddress;
        this.loopback = loopback;
    }

    public boolean isLoopback() {
        return loopback;
    }

    public boolean isBlackhole() {
        return blackhole;
    }

    public boolean isSink() {
        return sink;
    }

    public void setEdge() {
        edge = true;
    }

    public boolean isEdge() {
        return edge;
    }

    public Ip getIp() {
        return primaryIpAddress.getIp();
    }

    public IpAddress getPrimaryIpAddress() {
        return primaryIpAddress;
    }

    public void addSecondaryIpAddress(IpAddress ipAddress) {
        if (secondaryIpAddresses == null) secondaryIpAddresses = new Vector<>();
        secondaryIpAddresses.add(ipAddress);
    }

    public Vector<IpAddress> getSecondaryIpAddresses() {
        return secondaryIpAddresses;
    }

    public Vector<IpAddress> getIpAddresses() {
        Vector<IpAddress> ipAddresses = new Vector<>();
        ipAddresses.add(primaryIpAddress);
        if (secondaryIpAddresses != null) ipAddresses.addAll(secondaryIpAddresses);
        return ipAddresses;
    }

    public PortName getPortName() {
        return portName;
    }

    public NDDRouter getRouter() {
        return router;
    }

    public NDDPort getLinkedPort() {
        return linkedPort;
    }

    public void setLinkedPort(NDDPort linkedPort) {
        this.linkedPort = linkedPort;
    }

    public NDDL3Edge getLink() {
        return l3Edge;
    }

    public void setLink(NDDL3Edge l3Edge) {
        this.l3Edge = l3Edge;
    }

    public LinkedList<NDDACLRule> getAclIn() {
        return aclIn;
    }

    public void setAclIn(LinkedList<NDDACLRule> aclIn) {
        this.aclIn = aclIn;
    }

    public LinkedList<NDDACLRule> getAclOut() {
        return aclOut;
    }

    public void setAclOut(LinkedList<NDDACLRule> aclOut) {
        this.aclOut = aclOut;
    }

    public int getPortFwdNDD() {
        return portFwdNDD;
    }

    public void setPortFwdNDD(int portFwdNDD) {
        NDD.deref(this.portFwdNDD);
        this.portFwdNDD = portFwdNDD;
    }

    public int getPortAclInNDD() {
        return portAclInNDD;
    }

    public void setPortAclInNDD(int portAclInNDD) {
        NDD.deref(this.portAclInNDD);
        this.portAclInNDD = portAclInNDD;
    }

    public int getPortAclOutNDD() {
        return portAclOutNDD;
    }

    public void setPortAclOutNDD(int portAclOutNDD) {
        NDD.deref(this.portAclOutNDD);
        this.portAclOutNDD = portAclOutNDD;
    }

    public State getState() {
        return _state;
    }

    public void setState(State state) {
        _state = state;
    }

    @Override
    public String toString() {
        return portName.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NDDPort port = (NDDPort) o;
        return Objects.equals(portName, port.portName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(portName);
    }
}
