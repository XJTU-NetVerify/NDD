package datamodel.probability;

import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.Objects;

public class DoubleProbImpl extends Probability {
    public static DoubleProbImpl ONE = new DoubleProbImpl(1);
    public static DoubleProbImpl ZERO = new DoubleProbImpl(0);

    private final Double value;

    public DoubleProbImpl(double value) {
        this.value = value;
    }

    public DoubleProbImpl(String s) {
        this.value = Double.valueOf(s);
    }

    @Override
    public DoubleProbImpl add(Probability toAdd) {
        return new DoubleProbImpl(value + toAdd.doubleValue());
    }

    @Override
    public DoubleProbImpl subtract(Probability toSub) {
        return new DoubleProbImpl(value - toSub.doubleValue());
    }

    @Override
    public DoubleProbImpl multiply(Probability toMult) {
        return new DoubleProbImpl(value * toMult.doubleValue());
    }

    @Override
    public DoubleProbImpl divide(Probability toDiv) {
        return new DoubleProbImpl(value / toDiv.doubleValue());
    }

    @Override
    public DoubleProbImpl pow(int p) {
        return new DoubleProbImpl(Math.pow(value, p));
    }

    @Override
    public double doubleValue() {
        return value;
    }

    @Override
    public int compareTo(@NotNull Probability o) {
        return Comparator.comparing(Probability::doubleValue).compare(this, o);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DoubleProbImpl that = (DoubleProbImpl) o;
        return Objects.equals(value, that.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }
}

//public class DoubleProbImpl extends Probability {
//    public static DoubleProbImpl ONE = new DoubleProbImpl(false, 0);
//    public static DoubleProbImpl ZERO = new DoubleProbImpl(true, Double.MIN_VALUE);
//
//    private final boolean isZero;
//    private final double logValue;
//
//    public DoubleProbImpl(double value) {
//        this.isZero = value == 0;
//        if (!this.isZero) {
//            this.logValue = Math.log(value);
//        }
//        else {
//            this.logValue = Double.MIN_VALUE;
//        }
//    }
//
//    public DoubleProbImpl(String s) {
//        this(Double.parseDouble(s));
//    }
//
//    public DoubleProbImpl(boolean isZero, double logValue) {
//        this.isZero = isZero;
//        this.logValue = logValue;
//    }
//
//    @Override
//    public DoubleProbImpl add(Probability toAdd) {
//        return new DoubleProbImpl(doubleValue() + toAdd.doubleValue());
//    }
//
//    @Override
//    public DoubleProbImpl subtract(Probability toSub) {
//        return new DoubleProbImpl(doubleValue() - toSub.doubleValue());
//    }
//
//    @Override
//    public DoubleProbImpl multiply(Probability toMult) {
//        if (toMult instanceof DoubleProbImpl) {
//            if (isZero || ((DoubleProbImpl) toMult).isZero) {
//                return ZERO;
//            }
//            else {
//                return new DoubleProbImpl(false, logValue + ((DoubleProbImpl) toMult).logValue);
//            }
//        }
//        return new DoubleProbImpl(doubleValue() * toMult.doubleValue());
//    }
//
//    @Override
//    public DoubleProbImpl divide(Probability toDiv) {
//        if (toDiv instanceof DoubleProbImpl) {
//            if (((DoubleProbImpl) toDiv).isZero) {
//                throw new IllegalArgumentException("Divide by zero!");
//            }
//            else if (isZero) {
//                return ZERO;
//            }
//            else {
//                return new DoubleProbImpl(false, logValue - ((DoubleProbImpl) toDiv).logValue);
//            }
//        }
//        return new DoubleProbImpl(doubleValue() / toDiv.doubleValue());
//    }
//
//    @Override
//    public DoubleProbImpl pow(int p) {
//        return new DoubleProbImpl(Math.pow(doubleValue(), p));
//    }
//
//    @Override
//    public double doubleValue() {
//        if (isZero) {
//            return 0;
//        }
//        else {
//            return Math.exp(logValue);
//        }
//    }
//
//    @Override
//    public int compareTo(@NotNull Probability o) {
//        return Comparator.comparing(Probability::doubleValue).compare(this, o);
//    }
//
//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        DoubleProbImpl that = (DoubleProbImpl) o;
//        return (isZero && that.isZero) || Objects.equals(logValue, that.logValue);
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(isZero, logValue);
//    }
//}
