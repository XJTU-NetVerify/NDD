package datamodel.failure.node;

import datamodel.probability.BigDecimalProbImpl;
import datamodel.probability.Probability;
import controlplane.network.L3Topology;
import util.CombinationUtil;

public class NodeFailureModelBigDecimal extends NodeFailureModel {

    public NodeFailureModelBigDecimal(String linkDownProb, String nodeDownProb) {
        _linkDownProb = new BigDecimalProbImpl(linkDownProb);
        _linkUpProb = BigDecimalProbImpl.ONE.subtract(_linkDownProb);
        _nodeDownProb = new BigDecimalProbImpl(nodeDownProb);
        _nodeUpProb = BigDecimalProbImpl.ONE.subtract(_nodeDownProb);
    }

    @Override
    public void initForTopology(L3Topology l3Topology) {
        nCpt = new Probability[]{_nodeDownProb, _nodeUpProb};
        lCpt = new Probability[]{BigDecimalProbImpl.ONE, BigDecimalProbImpl.ONE,
                                 BigDecimalProbImpl.ONE, _linkDownProb,
                                 BigDecimalProbImpl.ZERO, BigDecimalProbImpl.ZERO,
                                 BigDecimalProbImpl.ZERO, _linkUpProb};
        super.initForTopology(l3Topology);
    }

    @Override
    Probability getZERO() {
        return BigDecimalProbImpl.ZERO;
    }

    /* This is not precise */
    @Override
    public int getK(int nLink, Probability precision) {
        imprecision = BigDecimalProbImpl.ONE;
        int k = -1;
        while (imprecision.compareTo(precision) > 0) {
            k++;
            imprecision = imprecision.subtract(calProbability(nLink, k));
        }
        return k;
    }

    private Probability calProbability(int nLink, int k) {
        long m = CombinationUtil.choose(nLink, k);
        Probability prob = BigDecimalProbImpl.ONE;
        prob = prob.multiply(_linkDownProb.pow(k));
        prob = prob.multiply(_linkUpProb.pow(nLink - k));
        return prob.multiply(new BigDecimalProbImpl(m));
    }
}
