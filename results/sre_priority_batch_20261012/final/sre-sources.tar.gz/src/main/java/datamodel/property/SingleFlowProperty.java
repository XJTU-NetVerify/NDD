package datamodel.property;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import datamodel.ipv4.Header;
import datamodel.ipv4.Prefix;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public abstract class SingleFlowProperty extends Property {
    Flow _flow;

    public SingleFlowProperty(Flow flow, Type type) {
        _flow = flow;
        _type = type;
    }

    @JsonIgnore
    public Flow getFlow() {
        return _flow;
    }

    @JsonGetter
    @JsonProperty("flow")
    public String flow() {
        return _flow.toString();
    }

    @Override
    public Set<Header> getPropertyDstHeaders() {
        HashSet<Header> hs = new HashSet<>();
        hs.add(_flow._header);
        return hs;
    }

    @Override
    public Set<String> getPropertySrcRouters() {
        HashSet<String> hs = new HashSet<>();
        hs.add(_flow._src);
        return hs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        SingleFlowProperty that = (SingleFlowProperty) o;
        return Objects.equals(_flow, that._flow);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), _flow);
    }
}
