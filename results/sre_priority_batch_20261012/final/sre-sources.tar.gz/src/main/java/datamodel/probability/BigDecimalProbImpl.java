package datamodel.probability;

import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Comparator;
import java.util.Objects;

public class BigDecimalProbImpl extends Probability {
    public static final BigDecimalProbImpl ONE = new BigDecimalProbImpl("1");
    public static final BigDecimalProbImpl ZERO = new BigDecimalProbImpl("0");

    private final BigDecimal value;

    public BigDecimalProbImpl(BigDecimal value) {
        this.value = value;
    }

    public BigDecimalProbImpl(String str) {
        value = new BigDecimal(str);
    }

    public BigDecimalProbImpl(long l) {
        value = BigDecimal.valueOf(l);
    }

    public BigDecimalProbImpl(double d) {
        value = BigDecimal.valueOf(d);
    }

    @Override
    public BigDecimalProbImpl add(Probability toAdd) {
        if (toAdd instanceof BigDecimalProbImpl) {
            return new BigDecimalProbImpl(value.add(((BigDecimalProbImpl) toAdd).getValue()));
        }
        else {
            return new BigDecimalProbImpl(doubleValue() + toAdd.doubleValue());
        }
    }

    @Override
    public BigDecimalProbImpl subtract(Probability toSub) {
        if (toSub instanceof BigDecimalProbImpl) {
            return new BigDecimalProbImpl(value.subtract(((BigDecimalProbImpl) toSub).getValue()));
        }
        else {
            return new BigDecimalProbImpl(doubleValue() - toSub.doubleValue());
        }
    }

    @Override
    public BigDecimalProbImpl multiply(Probability toMult) {
        if (toMult instanceof BigDecimalProbImpl) {
            return new BigDecimalProbImpl(value.multiply(((BigDecimalProbImpl) toMult).getValue()));
        }
        else {
            return new BigDecimalProbImpl(doubleValue() * toMult.doubleValue());
        }
    }

    @Override
    public BigDecimalProbImpl divide(Probability toDiv) {
        if (toDiv instanceof BigDecimalProbImpl) {
            return new BigDecimalProbImpl(value.divide(((BigDecimalProbImpl) toDiv).getValue(), RoundingMode.HALF_UP));
        }
        else {
            return new BigDecimalProbImpl(doubleValue() / toDiv.doubleValue());
        }
    }

    @Override
    public BigDecimalProbImpl pow(int p) {
        return new BigDecimalProbImpl(value.pow(p));
    }

    public BigDecimal getValue() {
        return value;
    }

    @Override
    public double doubleValue() {
        return value.doubleValue();
    }

    @Override
    public int compareTo(@NotNull Probability o) {
        return Comparator.comparing(Probability::doubleValue).compare(this, o);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BigDecimalProbImpl that = (BigDecimalProbImpl) o;
        return Objects.equals(value, that.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }
}
