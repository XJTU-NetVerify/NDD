package datamodel.property;

import sre.ndd.NDD;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import datamodel.ipv4.Header;
import datamodel.probability.Probability;

import java.util.Objects;
import java.util.Set;

public abstract class NDDProperty {

    Property.Type _type;
    int _tc = NDD.getFalse();

    int _mf;
    Probability _probability;
    Probability _imprecision;

    double _runtime;

    public Property.Type getType() {
        return _type;
    }

    public void setTC(int tc) {
        _tc = tc;
    }

    public int getTC() {
        return _tc;
    }

    public void setMF(int mf) {
        _mf = mf;
    }

    public int getMF() {
        return _mf;
    }

    public void setProbability(Probability probability) {
        _probability = probability;
    }

    public Probability getProbability() {
        return _probability;
    }

    public void setImprecision(Probability imprecision) {
        _imprecision = imprecision;
    }

    public Probability getImprecision() {
        return _imprecision;
    }

    public void setRuntime(double runtime) {
        _runtime = runtime;
    }

    @JsonGetter
    @JsonProperty("runtime")
    public double getRuntime() {
        return _runtime;
    }

    @JsonGetter
    @JsonProperty("probability")
    public double probability() {
        return _probability.doubleValue();
    }

    @JsonGetter
    @JsonProperty("imprecision")
    public double imprecision() {
        return _imprecision.doubleValue();
    }

    @JsonIgnore
    public abstract Set<Header> getPropertyDstHeaders();

    @JsonIgnore
    public abstract Set<String> getPropertySrcRouters();

    public String toSpecification() {
        return "";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NDDProperty property = (NDDProperty) o;
        return _type == property._type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(_type);
    }

    /* csv supports */
    public static final String[] CSV_HEADER = {"type", "protocol", "source", "source_port", "destination", "destination_port", "src_router", "attributes", "mf", "probability"};

    public abstract String[] toCsvString();
}
