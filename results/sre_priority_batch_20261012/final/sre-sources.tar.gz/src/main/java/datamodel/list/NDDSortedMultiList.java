package datamodel.list;

import sre.ndd.NDD;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.stream.Collectors;

/**
 * reversed sorted list: from high priority to low priority
 */
public class NDDSortedMultiList extends ArrayList<ArrayList<NDDSortedMultiListItem>> {
    private static final long serialVersionUID = 9072486635182407915L;

    SortedMultiListOwner owner;

    int outerPre = 0;
    int innerPre = 0;

    public NDDSortedMultiList() { }

    public NDDSortedMultiList(SortedMultiListOwner owner) {
        this.owner = owner;
    }

    int oIdx;
    int iIdx;
    /**
     * @param entry - item to be inserted into this list
     * @return item after insertion
     */
    public NDDSortedMultiListItem insert(NDDSortedMultiListItem entry) {
        entry.setList(this);
        int s = size(), cmp, idx = 0;
        if (s == 0 || (cmp = get(s - 1).get(0).compareTo(entry)) > 0) {
            idx = s;
        }
        else if (cmp == 0) {
            insertExist(s - 1, entry);
            return entry;
        }
        else{
            int low = 0, high = s - 1, mid;
            while (low <= high) {
                mid = (low + high) >> 1;
                cmp = get(mid).get(0).compareTo(entry);
                if (cmp == 0) {
                    insertExist(mid, entry);
                    return entry;
                }
                else if (cmp > 0) {
                    low = mid + 1;
                }
                else {
                    high = mid - 1;
                    idx = mid;
                }
            }
        }
        insertNew(idx, entry);
        return entry;
    }

    // insert the entry into an existing inner list
    private void insertExist(int o, NDDSortedMultiListItem entry) {
        ArrayList<NDDSortedMultiListItem> iList = get(o);
        for (int i = 0; i < iList.size(); i++) {
            if (iList.get(i).equals(entry)) {
                int oldTC = iList.get(i).getArriveTC();
                int newTC = entry.getArriveTC();
                // Native retained roots use canonical identity; Java preserves
                // the legacy semantic comparison across GC epochs.
                boolean tcChanged = !NDD.equivalent(oldTC, newTC);
                if (tcChanged) {
                    iList.set(i, entry);
                    updateIdx(o, i);
                } else {
                    // arriveTC is logically unchanged; release the new route's NDD ref to
                    // prevent a leak (the new route object will be discarded).
                    NDD.deref(entry.getArriveTC());
                }
                return;
            }
        }
        iList.add(entry);
        updateIdx(o, iList.size() - 1);
    }

    // create a new inner list and insert the entry into
    private void insertNew(int o, NDDSortedMultiListItem entry) {
        ArrayList<NDDSortedMultiListItem> iList = new ArrayList<>();
        iList.add(entry);
        add(o, iList);
        updateIdx(o, 0);
    }

    public void resetIdx() {
        if (!isEmpty()) {
            oIdx = size() - 1;
            iIdx = get(oIdx).size();
        }
    }

    private void updateIdx(int o, int i) {
        if (o < oIdx) {
            oIdx = o;
            iIdx = i;
        }
        else if (o == oIdx) {
            iIdx = Math.min(i, iIdx);
        }
    }

    private void validateInvariants() {
        for (int outer = 0; outer < size(); outer++) {
            ArrayList<NDDSortedMultiListItem> inner = get(outer);
            if (inner.isEmpty()) {
                throw new IllegalStateException("NDDSortedMultiList invariant failed: empty inner list at " + outer);
            }

            NDDSortedMultiListItem head = inner.get(0);
            for (int j = 1; j < inner.size(); j++) {
                NDDSortedMultiListItem item = inner.get(j);
                if (head.compareTo(item) != 0) {
                    throw new IllegalStateException(
                            "NDDSortedMultiList invariant failed: mixed priority in same inner list at " + outer);
                }
                for (int k = 0; k < j; k++) {
                    if (inner.get(k).equals(item)) {
                        throw new IllegalStateException(
                                "NDDSortedMultiList invariant failed: duplicate item in inner list at " + outer);
                    }
                }
            }

            if (outer + 1 < size()) {
                NDDSortedMultiListItem nextHead = get(outer + 1).get(0);
                if (head.compareTo(nextHead) <= 0) {
                    throw new IllegalStateException(
                            "NDDSortedMultiList invariant failed: outer list not strictly descending at " + outer);
                }
            }
        }

        if (!isEmpty()) {
            if (oIdx < 0 || oIdx >= size()) {
                throw new IllegalStateException("NDDSortedMultiList invariant failed: oIdx out of range: " + oIdx);
            }
            int innerSize = get(oIdx).size();
            if (iIdx < 0 || iIdx > innerSize) {
                throw new IllegalStateException("NDDSortedMultiList invariant failed: iIdx out of range: " + iIdx);
            }
        }
    }

    public ArrayList<NDDSortedMultiListItem> flat() {
        return (ArrayList<NDDSortedMultiListItem>) stream().flatMap(ArrayList::stream).collect(Collectors.toList());
    }

    public int[] cleanDead() {
        int total = 0;
        int remain = 0;
        Iterator<ArrayList<NDDSortedMultiListItem>> outerItr = iterator();
        while (outerItr.hasNext()) {
            ArrayList<NDDSortedMultiListItem> al = outerItr.next();
            total += al.size();
            al.removeIf(NDDSortedMultiListItem::isDead);
            remain += al.size();
            if (al.isEmpty()) outerItr.remove();
        }
        return new int[] {total, remain};
    }

    public int[] getStats() {
        int total = 0;
        int valid = 0;
        for (ArrayList<NDDSortedMultiListItem> al : this) {
            total += al.size();
            valid += al.stream().filter(item -> !item.isDead()).count();
        }
        return new int[] {total, valid};
    }

    public SortedMultiListOwner getOwner() {
        return owner;
    }

    public int getOuterPre() {
        return outerPre;
    }

    public void setOuterPre(int outerPre) {
        this.outerPre = outerPre;
    }

    public int getInnerPre() {
        return innerPre;
    }

    public void setInnerPre(int innerPre) {
        this.innerPre = innerPre;
    }

    public int getOIdx() {
        return oIdx;
    }

    public int getIIdx() {
        return iIdx;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        forEach(iList -> {
            iList.forEach(item -> builder.append(item.toString()).append("\n"));
            builder.append("\n");
        });
        return builder.toString();
    }
}
