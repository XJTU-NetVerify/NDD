package datamodel.property;

public class Reachability extends SingleFlowProperty {
    String _dst;

    public Reachability(Flow flow) {
        super(flow, Type.REACHABILITY);
    }

    public Reachability(Flow flow, String dst) {
        super(flow, Type.REACHABILITY);
        _dst = dst;
    }

    public String getDst() {
        return _dst;
    }

    public String toSpecification() {
        return _flow._header.toString() + ',' + _flow._src + ',' + _dst + '\n';
    }

    public String toString()
    {
        return _type.toString()+" "+
        _flow._header.getProtocol().toString()+" "+
        _flow._header.getSource().toString()+" "+
        _flow._header.getSourcePort().toString()+" "+
        _flow._header.getDestination().toString()+" "+
        _flow._header.getDestinationPort().toString()+" "+
        _flow._src+" "+
        _mf+" "+
        _probability;
    }

    @Override
    public String[] toCsvString() {
        return new String[] {_type.toString(),
                _flow._header.getProtocol().toString(),
                _flow._header.getSource().toString(),
                _flow._header.getSourcePort().toString(),
                _flow._header.getDestination().toString(),
                _flow._header.getDestinationPort().toString(),
                _flow._src,
//                "",
                _dst,
                _mf + "",
                _probability + ""};
    }
}
