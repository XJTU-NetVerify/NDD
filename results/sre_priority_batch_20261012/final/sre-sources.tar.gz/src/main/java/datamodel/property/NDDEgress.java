package datamodel.property;

public class NDDEgress extends NDDSingleFlowProperty {
    String _egress;

    public NDDEgress(Flow flow, String egress) {
        super(flow, Property.Type.EGRESS);
        _egress = egress;
    }

    public String getEgress() {
        return _egress;
    }

    @Override
    public String[] toCsvString() {
        return new String[] {_type.toString(),
                _flow._header.getProtocol().toString(),
                _flow._header.getSource().toString(),
                _flow._header.getSourcePort().toString(),
                _flow._header.getDestination().toString(),
                _flow._header.getDestinationPort().toString(),
                _flow._src,
                _egress,
                _mf + "",
                _probability + ""};
    }
}
