package datamodel.failure.node;

import datamodel.probability.DoubleProbImpl;
import datamodel.probability.Probability;
import controlplane.network.L3Topology;
import util.CombinationUtil;

public class NodeFailureModelDouble extends NodeFailureModel {

    public NodeFailureModelDouble(String linkDownProb, String nodeDownProb) {
        _linkDownProb = new DoubleProbImpl(linkDownProb);
        _linkUpProb = DoubleProbImpl.ONE.subtract(_linkDownProb);
        _nodeDownProb = new DoubleProbImpl(nodeDownProb);
        _nodeUpProb = DoubleProbImpl.ONE.subtract(_nodeDownProb);
    }

    @Override
    public void initForTopology(L3Topology l3Topology) {
        nCpt = new Probability[]{_nodeDownProb, _nodeUpProb};
        lCpt = new Probability[]{DoubleProbImpl.ONE, DoubleProbImpl.ONE,
                                 DoubleProbImpl.ONE, _linkDownProb,
                                 DoubleProbImpl.ZERO, DoubleProbImpl.ZERO,
                                 DoubleProbImpl.ZERO, _linkUpProb};
        super.initForTopology(l3Topology);
    }

    @Override
    Probability getZERO() {
        return DoubleProbImpl.ZERO;
    }

    /* This is not precise */
    @Override
    public int getK(int nLink, Probability precision) {
        imprecision = DoubleProbImpl.ONE;
        int k = -1;
        while (imprecision.compareTo(precision) > 0) {
            k++;
            imprecision = imprecision.subtract(calProbability(nLink, k));
        }
        return k;
    }

    private Probability calProbability(int nLink, int k) {
        long m = CombinationUtil.choose(nLink, k);
        Probability prob = DoubleProbImpl.ONE;
        prob = prob.multiply(_linkDownProb.pow(k));
        prob = prob.multiply(_linkUpProb.pow(nLink - k));
        return prob.multiply(new DoubleProbImpl(m));
    }
}
