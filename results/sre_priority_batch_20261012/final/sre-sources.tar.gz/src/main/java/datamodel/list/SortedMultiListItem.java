package datamodel.list;

public interface SortedMultiListItem extends Comparable<SortedMultiListItem> {
    void setList(SortedMultiList list);
    SortedMultiList getList();
    void setOuterIdx(int idx);
    int getOuterIdx();
    void setInnerIdx(int idx);
    int getInnerIdx();
    void setListTC(int tc);
    int getListTC();
    void setArriveTC(int tc);
    int getArriveTC();
    boolean isDead();
}
