package datamodel.failure.node;

import algorithm.bayes.BayesNet;
import algorithm.bayes.Condition;
import algorithm.bayes.Factor;
import algorithm.bayes.Variable;
import controlplane.network.L3Edge;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Vector;

public class NodeFailureUtil {
    String[] _routers;
    L3Edge[] _l3Edges;
    BigDecimal _linkDownProb;
    BigDecimal _routerDownProb;

    BayesNet _bn;

    Vector<Integer> _values;
    HashMap<String, Variable> _map;

    public NodeFailureUtil(String[] routers, L3Edge[] l3Edges, BigDecimal rDownProb, BigDecimal lDownProb) {
        _routers = routers;
        _l3Edges = l3Edges;
        _linkDownProb = lDownProb;
        _routerDownProb = rDownProb;
        _values = new Vector<>();
        _values.add(0);
        _values.add(1);
        _map = new HashMap<>();
        _bn = new BayesNet("alg/bayes");
        addVars();
        addFactors();
    }

    public void addFactors() {
        for (String r : _routers) {
            Variable var = _map.get(r);
            Vector<Variable> vars = new Vector<>(1);
            vars.add(var);
            Factor factor = new Factor(vars);
            Condition c1 = new Condition.Builder().addVarValPair(var, 0).build();
            Condition c2 = new Condition.Builder().addVarValPair(var, 1).build();
            factor.setValue(c1, _routerDownProb);
            factor.setValue(c2, BigDecimal.ONE.subtract(_routerDownProb));
            _bn.addFactor(factor);
        }
        for (L3Edge l : _l3Edges) {
            Variable lVar = _map.get(l.toString());
            Variable rVar1 = _map.get(l.getSrc().getRouterName());
            Variable rVar2 = _map.get(l.getDst().getRouterName());
            Vector<Variable> vars = new Vector<>(3);
            vars.add(lVar);
            vars.add(rVar1);
            vars.add(rVar2);
            Factor factor = new Factor(vars);
            Condition c1 = new Condition.Builder()
                    .addVarValPair(rVar1, 0)
                    .addVarValPair(rVar2, 0)
                    .addVarValPair(lVar, 0)
                    .build();
            Condition c2 = new Condition.Builder()
                    .addVarValPair(rVar1, 0)
                    .addVarValPair(rVar2, 0)
                    .addVarValPair(lVar, 1)
                    .build();
            Condition c3 = new Condition.Builder()
                    .addVarValPair(rVar1, 0)
                    .addVarValPair(rVar2, 1)
                    .addVarValPair(lVar, 0)
                    .build();
            Condition c4 = new Condition.Builder()
                    .addVarValPair(rVar1, 0)
                    .addVarValPair(rVar2, 1)
                    .addVarValPair(lVar, 1)
                    .build();
            Condition c5 = new Condition.Builder()
                    .addVarValPair(rVar1, 1)
                    .addVarValPair(rVar2, 0)
                    .addVarValPair(lVar, 0)
                    .build();
            Condition c6 = new Condition.Builder()
                    .addVarValPair(rVar1, 1)
                    .addVarValPair(rVar2, 0)
                    .addVarValPair(lVar, 1)
                    .build();
            Condition c7 = new Condition.Builder()
                    .addVarValPair(rVar1, 1)
                    .addVarValPair(rVar2, 1)
                    .addVarValPair(lVar, 0)
                    .build();
            Condition c8 = new Condition.Builder()
                    .addVarValPair(rVar1, 1)
                    .addVarValPair(rVar2, 1)
                    .addVarValPair(lVar, 1)
                    .build();
            factor.setValue(c1, BigDecimal.ONE);
            factor.setValue(c2, BigDecimal.ZERO);
            factor.setValue(c3, BigDecimal.ONE);
            factor.setValue(c4, BigDecimal.ZERO);
            factor.setValue(c5, BigDecimal.ONE);
            factor.setValue(c6, BigDecimal.ZERO);
            factor.setValue(c7, _linkDownProb);
            factor.setValue(c8, BigDecimal.ONE.subtract(_linkDownProb));
            _bn.addFactor(factor);
        }
    }

    public void addVars() {
        for (String r : _routers) {
            Variable var = new Variable(r, _values);
            _bn.addVariable(var);
            _map.put(r, var);
        }
        for (L3Edge l : _l3Edges) {
            Variable var = new Variable(l.toString(), _values);
            _bn.addVariable(var);
            _map.put(l.toString(), var);
        }
    }

    public BigDecimal inference(byte[] state) {
        Condition.Builder builder = new Condition.Builder();
        for (int i = 0; i < state.length; i++) {
            builder.addVarValPair(_map.get(_l3Edges[i].toString()), state[i]);
        }
        Condition toInference = builder.build();
        return _bn.inference(toInference);
    }

}
