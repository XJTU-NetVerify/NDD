package datamodel.property;

public class Waypoint extends SingleFlowProperty {
    String _point;

    public Waypoint(Flow flow, String point) {
        super(flow, Type.WAYPOINT);
        _point = point;
    }

    public String getPoint() {
        return _point;
    }

    @Override
    public String toString() {
        return "Waypoint{" +
               "flow=" + _flow +
               ", point=" + _point +
               ", probability=" + _probability.doubleValue() +
               '}';
    }

    @Override
    public String[] toCsvString() {
        return new String[] {_type.toString(),
                _flow._header.getProtocol().toString(),
                _flow._header.getSource().toString(),
                _flow._header.getSourcePort().toString(),
                _flow._header.getDestination().toString(),
                _flow._header.getDestinationPort().toString(),
                _flow._src,
                _point,
                _mf + "",
                _probability + ""};
    }
}
