package datamodel.property;

public class NDDPathLength extends NDDSingleFlowProperty {
    int _length;

    public NDDPathLength(Flow flow, int length) {
        super(flow, Property.Type.PATH_LENGTH);
        _length = length;
    }

    public int getLength() {
        return _length;
    }

    @Override
    public String[] toCsvString() {
        return new String[] {_type.toString(),
                _flow._header.getProtocol().toString(),
                _flow._header.getSource().toString(),
                _flow._header.getSourcePort().toString(),
                _flow._header.getDestination().toString(),
                _flow._header.getDestinationPort().toString(),
                _flow._src,
                _length + "",
                _mf + "",
                _probability + ""};
    }
}
