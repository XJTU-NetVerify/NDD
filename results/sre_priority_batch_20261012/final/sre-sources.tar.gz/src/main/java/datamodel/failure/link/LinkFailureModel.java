package datamodel.failure.link;

import main.Controller;
import datamodel.probability.Probability;
import controlplane.network.L3Topology;
import datamodel.failure.FailureModel;

import java.util.HashMap;

public abstract class LinkFailureModel extends FailureModel {
    Probability _linkDownProb;
    Probability _linkUpProb;

    @Override
    public void initForTopology(L3Topology l3Topology) {

    }

    HashMap<Integer, Probability> memo;

    @Override
    public Probability calProbability(int bdd) {
        if (!memo.containsKey(bdd)) {
            Probability low = calProbability(Controller.bddManager.getBDD().getLow(bdd)).multiply(_linkDownProb);
            Probability high = calProbability(Controller.bddManager.getBDD().getHigh(bdd)).multiply(_linkUpProb);
            Probability sum = low.add(high);
            memo.put(bdd, sum);
        }
        return memo.get(bdd);
    }
}
