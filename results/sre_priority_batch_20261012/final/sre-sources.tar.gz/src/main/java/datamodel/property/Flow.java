package datamodel.property;

import datamodel.ipv4.Header;

import java.util.Objects;

public class Flow {
    Header _header;
    String _src;

    public Flow(Header header, String src) {
        _header = header;
        _src = src;
    }

    public Header getHeader() {
        return _header;
    }

    public String getSrc() {
        return _src;
    }

    @Override
    public String toString() {
        return "Flow{" +
               "src='" + _src +'\'' +
               ", header=" + _header.toString() +
               '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Flow flow = (Flow) o;
        return Objects.equals(_header, flow._header) &&
               Objects.equals(_src, flow._src);
    }

    @Override
    public int hashCode() {
        return Objects.hash(_header, _src);
    }
}
