package datamodel.ipv4;

public class Subnet {

	long ipAddr;
	int prefixLen;
	String name;
	String iName;
	
	public Subnet(long ip, int maskLen, String name)
	{
		this.ipAddr = ip;
		this.prefixLen = 32 - maskLen;
		this.name = name;
		this.iName = null;
	}
	
	public Subnet(long ip, int maskLen, String name, String iName)
	{
		this(ip, maskLen, name);
		this.iName = iName;
	}
	
	public long getIpAddr()
	{
		return ipAddr;
	}
	
	public int getPrefixLen()
	{
		return prefixLen;
	}
	
	public String getName()
	{
		return name;
	}

	public String toString()
	{
		if(iName == null)
			return name + ":" + ipAddr + " " + prefixLen;
		else
			return name + ":" + ipAddr + " " + prefixLen + " " + iName;
	}
}
