package datamodel.ipv4;

import dataplane.acl.Range;

import java.util.Objects;

public class Header {
    Range protocol;
    Prefix source;
    Range sourcePort;
    Prefix destination;
    Range destinationPort;

    public Header(Range protocol, Prefix source, Range sourcePort, Prefix destination, Range destinationPort) {
        this.protocol = protocol;
        this.source = source;
        this.sourcePort = sourcePort;
        this.destination = destination;
        this.destinationPort = destinationPort;
    }

    public Range getProtocol() {
        return protocol;
    }

    public Prefix getSource() {
        return source;
    }

    public Range getSourcePort() {
        return sourcePort;
    }

    public Prefix getDestination() {
        return destination;
    }

    public Range getDestinationPort() {
        return destinationPort;
    }

    public boolean matchLoose(Header another) {
        return protocol.matchLoose(another.protocol) &&
               source.prefixMatchLoose(another.source) &&
               sourcePort.matchLoose(another.sourcePort) &&
               destination.prefixMatchLoose(another.destination) &&
               destinationPort.matchLoose(another.destinationPort);
    }

    public boolean matchStrict(Header another) {
        return equals(another);
    }

    @Override
    public String toString() {
        return "Header{" +
               "protocol=" + protocol +
               ", source=" + source +
               ", sourcePort=" + sourcePort +
               ", destination=" + destination +
               ", destinationPort=" + destinationPort +
               '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Header header = (Header) o;
        return Objects.equals(protocol, header.protocol) && Objects.equals(source, header.source) && Objects.equals(sourcePort, header.sourcePort) && Objects.equals(destination, header.destination) && Objects.equals(destinationPort, header.destinationPort);
    }

    @Override
    public int hashCode() {
        return Objects.hash(protocol, source, sourcePort, destination, destinationPort);
    }

    public static class HeaderBuilder {
        Range protocol = new Range(0, 255);
        Prefix source = Prefix.of(Ip.of("0.0.0.0"), Mask.of(0));
        Range sourcePort = new Range(0, 65535);
        Prefix destination = Prefix.of(Ip.of("0.0.0.0"), Mask.of(0));
        Range destinationPort = new Range(0, 65535);

        public HeaderBuilder setProtocol(Range protocol) {
            this.protocol = protocol;
            return this;
        }

        public HeaderBuilder setSource(Prefix source) {
            this.source = source;
            return this;
        }

        public HeaderBuilder setSourcePort(Range sourcePort) {
            this.sourcePort = sourcePort;
            return this;
        }

        public HeaderBuilder setDestination(Prefix destination) {
            this.destination = destination;
            return this;
        }

        public HeaderBuilder setDestinationPort(Range destinationPort) {
            this.destinationPort = destinationPort;
            return this;
        }

        public Header build() {
            return new Header(protocol, source, sourcePort, destination, destinationPort);
        }
    }
}
