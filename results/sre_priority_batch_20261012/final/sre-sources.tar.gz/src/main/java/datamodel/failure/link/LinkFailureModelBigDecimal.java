package datamodel.failure.link;

import datamodel.probability.BigDecimalProbImpl;
import datamodel.probability.Probability;
import util.CombinationUtil;

import java.util.HashMap;

public class LinkFailureModelBigDecimal extends LinkFailureModel {

    public LinkFailureModelBigDecimal(String linkDownProb) {
        _linkDownProb = new BigDecimalProbImpl(linkDownProb);
        _linkUpProb = BigDecimalProbImpl.ONE.subtract(_linkDownProb);
        initMemo();
    }

    public int getK(int nLink, Probability precision) {
        imprecision = BigDecimalProbImpl.ONE;
        int k = -1;
        while (imprecision.compareTo(precision) > 0) {
            k++;
            imprecision = imprecision.subtract(calProbability(nLink, k));
        }
        return k;
    }

    private Probability calProbability(int nLink, int k) {
        long m = CombinationUtil.choose(nLink, k);
        Probability prob = BigDecimalProbImpl.ONE;
        prob = prob.multiply(_linkDownProb.pow(k));
        prob = prob.multiply(_linkUpProb.pow(nLink - k));
        return prob.multiply(new BigDecimalProbImpl(m));
    }

    private void initMemo() {
        memo = new HashMap<>();
        memo.put(0, BigDecimalProbImpl.ZERO);
        memo.put(1, BigDecimalProbImpl.ONE);
    }
}
