package datamodel.ipv4;

import java.io.Serializable;
import java.util.Iterator;

public class IpBank implements Serializable, Iterator<Ip> {
    private static final long serialVersionUID = 6650741418915996335L;

    Ip[] bank;
    int pos = 0;

    public IpBank() {}

    public IpBank(int n) {
        bank = new Ip[n];
        for (int i = 0; i < n; i++) {
            bank[i] = Ip.randomIpGenerator();
        }
    }

    public void resetIterator() {
        // the first IP reserved for External Announcement
        pos = 0;
    }

    @Override
    public boolean hasNext() {
        return pos < bank.length;
    }

    @Override
    public Ip next() {
        return bank[pos++];
    }
}
