package datamodel.probability;

public abstract class Probability implements Comparable<Probability> {

    public abstract Probability add(Probability toAdd);

    public abstract Probability subtract(Probability toSub);

    public abstract Probability multiply(Probability toMult);

    public abstract Probability divide(Probability toDiv);

    public abstract Probability pow(int p);

    public abstract double doubleValue();

    @Override
    public String toString() {
        return String.valueOf(doubleValue());
    }
}
