package datamodel.failure.link;

import main.SRELogger;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import datamodel.error.UnsupportedFailureModelError;
import datamodel.failure.FailureModel;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.file.Path;

public class LinkFailureModelParser {
    public static FailureModel parseFailureModel(Path path) {
        JsonParser parser = new JsonParser();
        try {
            JsonObject root = (JsonObject) parser.parse(new FileReader(path.toFile()));
            JsonObject failureModel = root.getAsJsonObject("failures");
            if (failureModel.get("type").getAsString().equals("LinkFailureModel")) {
                return new LinkFailureModelDouble(failureModel.get("p_link_failure").getAsString());
            }
            else {
                SRELogger.logWorkFlow(SRELogger.LEVEL.ERROR, "Unsupported failure model!");
                throw new UnsupportedFailureModelError();
            }
        } catch (FileNotFoundException | UnsupportedFailureModelError e) {
            e.printStackTrace();
        }
        return null;
    }
}
