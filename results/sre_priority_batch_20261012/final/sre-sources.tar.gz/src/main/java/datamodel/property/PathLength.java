package datamodel.property;

public class PathLength extends SingleFlowProperty {
    int _length;

    public PathLength(Flow flow, int length) {
        super(flow, Type.PATH_LENGTH);
        _length = length;
    }

    public int getLength() {
        return _length;
    }

    @Override
    public String[] toCsvString() {
        return new String[] {_type.toString(),
                _flow._header.getProtocol().toString(),
                _flow._header.getSource().toString(),
                _flow._header.getSourcePort().toString(),
                _flow._header.getDestination().toString(),
                _flow._header.getDestinationPort().toString(),
                _flow._src,
                _length + "",
                _mf + "",
                _probability + ""};
    }
}
