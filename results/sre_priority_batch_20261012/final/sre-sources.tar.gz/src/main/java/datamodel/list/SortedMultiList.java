package datamodel.list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.stream.Collectors;

/**
 * reversed sorted list: from high priority to low priority
 */
public class SortedMultiList extends ArrayList<ArrayList<SortedMultiListItem>> {
    private static final long serialVersionUID = 9072486635182407915L;

    SortedMultiListOwner owner;

    int outerPre = 0;
    int innerPre = 0;

    public SortedMultiList() { }

    public SortedMultiList(SortedMultiListOwner owner) {
        this.owner = owner;
    }

    int oIdx;
    int iIdx;
    /**
     * @param entry - item to be inserted into this list
     * @return item after insertion
     */
    public SortedMultiListItem insert(SortedMultiListItem entry) {
        entry.setList(this);
        int s = size(), cmp, idx = 0;
        if (s == 0 || (cmp = get(s - 1).get(0).compareTo(entry)) > 0) {
            idx = s;
        }
        else if (cmp == 0) {
            insertExist(s - 1, entry);
            return entry;
        }
        else{
            int low = 0, high = s - 1, mid;
            while (low <= high) {
                mid = (low + high) >> 1;
                cmp = get(mid).get(0).compareTo(entry);
                if (cmp == 0) {
                    insertExist(mid, entry);
                    return entry;
                }
                else if (cmp > 0) {
                    low = mid + 1;
                }
                else {
                    high = mid - 1;
                    idx = mid;
                }
            }
        }
        insertNew(idx, entry);
        return entry;
    }

    // insert the entry into an existing inner list
    private void insertExist(int o, SortedMultiListItem entry) {
        ArrayList<SortedMultiListItem> iList = get(o);
        for (int i = 0; i < iList.size(); i++) {
            if (iList.get(i).equals(entry)) {
                if (iList.get(i).getArriveTC() != entry.getArriveTC()) {
                    iList.set(i, entry);
                    updateIdx(o, i);
                }
                return;
            }
        }
        iList.add(entry);
        updateIdx(o, iList.size() - 1);
    }

    // create a new inner list and insert the entry into
    private void insertNew(int o, SortedMultiListItem entry) {
        ArrayList<SortedMultiListItem> iList = new ArrayList<>();
        iList.add(entry);
        add(o, iList);
        updateIdx(o, 0);
    }

    public void resetIdx() {
        if (!isEmpty()) {
            oIdx = size() - 1;
            iIdx = get(oIdx).size();
        }
    }

    private void updateIdx(int o, int i) {
        if (o < oIdx) {
            oIdx = o;
            iIdx = i;
        }
        else if (o == oIdx) {
            iIdx = Math.min(i, iIdx);
        }
    }

//    /**
//     * @param entry - item to be inserted into this list
//     * @return item after insertion
//     */
//    public SortedMultiListItem insert(SortedMultiListItem entry) {
//        entry.setList(this);
//        int s = size(), idx = 0;
//        if (s > 0 && get(s - 1).get(0).compareTo(entry) > 0) {
//            idx = s;
//        }
//        else{
//            int low = 0, high = s - 1, mid, cmp;
//            while (low <= high) {
//                mid = (low + high) >> 1;
//                cmp = get(mid).get(0).compareTo(entry);
//                if (cmp == 0) {
//                    for (SortedMultiListItem item : get(mid)) {
//                        if (item.equals(entry)) {
//                            item.setArriveTC(entry.getArriveTC());
//                            return item;
//                        }
//                    }
//                    get(mid).add(entry);
//                    entry.setOuterIdx(mid);
//                    entry.setInnerIdx(get(mid).size() - 1);
//                    return entry;
//                }
//                else if (cmp > 0) {
//                    low = mid + 1;
//                }
//                else {
//                    high = mid - 1;
//                    idx = mid;
//                }
//            }
//        }
//        ArrayList<SortedMultiListItem> tmp = new ArrayList<>();
//        tmp.add(entry);
//        add(idx, tmp);
//        entry.setInnerIdx(0);
//        for (int i = idx; i < size(); i++) {
//            for (SortedMultiListItem item : get(i)) {
//                item.setOuterIdx(i);
//            }
//        }
//        return entry;
//    }

//    public boolean addLast(SortedMultiListItem entry) {
//        int s = size(), cmp;
//        if (s == 0 || (cmp = get(s - 1).get(0).compareTo(entry)) > 0) {
//            ArrayList<SortedMultiListItem> tmp = new ArrayList<>();
//            tmp.add(entry);
//            add(tmp);
//            entry.setOuterIdx(s);
//            entry.setInnerIdx(0);
//            entry.setList(this);
//            return true;
//        }
////        if (cmp == 0) {
////            get(s - 1).add(entry);
////            entry.setOuterIdx(s - 1);
////            entry.setInnerIdx(get(s - 1).size() - 1);
////            entry.setList(this);
////            return true;
////        }
//        return false;
//    }

    public ArrayList<SortedMultiListItem> flat() {
        return (ArrayList<SortedMultiListItem>) stream().flatMap(ArrayList::stream).collect(Collectors.toList());
    }

    public int[] cleanDead() {
        int total = 0;
        int remain = 0;
        Iterator<ArrayList<SortedMultiListItem>> outerItr = iterator();
        while (outerItr.hasNext()) {
            ArrayList<SortedMultiListItem> al = outerItr.next();
            total += al.size();
            al.removeIf(SortedMultiListItem::isDead);
            remain += al.size();
            if (al.isEmpty()) outerItr.remove();
        }
        return new int[] {total, remain};
    }

    public int[] getStats() {
        int total = 0;
        int valid = 0;
        for (ArrayList<SortedMultiListItem> al : this) {
            total += al.size();
            valid += al.stream().filter(item -> !item.isDead()).count();
        }
        return new int[] {total, valid};
    }

    public SortedMultiListOwner getOwner() {
        return owner;
    }

    public int getOuterPre() {
        return outerPre;
    }

    public void setOuterPre(int outerPre) {
        this.outerPre = outerPre;
    }

    public int getInnerPre() {
        return innerPre;
    }

    public void setInnerPre(int innerPre) {
        this.innerPre = innerPre;
    }

    public int getOIdx() {
        return oIdx;
    }

    public int getIIdx() {
        return iIdx;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        forEach(iList -> {
            iList.forEach(item -> builder.append(item.toString()).append("\n"));
            builder.append("\n");
        });
        return builder.toString();
    }
}
