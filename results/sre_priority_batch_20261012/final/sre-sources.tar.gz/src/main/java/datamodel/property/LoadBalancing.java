package datamodel.property;

public class LoadBalancing extends SingleFlowProperty {
    public LoadBalancing(Flow flow) {
        super(flow, Type.LOAD_BALANCING);
    }

    @Override
    public String[] toCsvString() {
        return new String[] {_type.toString(),
                _flow._header.getProtocol().toString(),
                _flow._header.getSource().toString(),
                _flow._header.getSourcePort().toString(),
                _flow._header.getDestination().toString(),
                _flow._header.getDestinationPort().toString(),
                _flow._src,
                "",
                _mf + "",
                _probability + ""};
    }
}
