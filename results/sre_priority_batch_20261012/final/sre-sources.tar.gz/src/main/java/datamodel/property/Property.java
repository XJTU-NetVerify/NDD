package datamodel.property;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import datamodel.ipv4.Header;
import datamodel.probability.Probability;

import java.util.Objects;
import java.util.Set;

public abstract class Property {
    public enum Type {
        // can src reach dst or not
        REACHABILITY("reach"),
        BLOCK("block"),
        // more than one path between src and dst
        LOAD_BALANCING("load_balancing"),
        WAYPOINT("waypoint"),
        EGRESS("egress"),
        PATH_LENGTH("path_length"),
        BALANCED("balanced"),
        ISOLATION("isolation"),
        CONGESTION("congestion");

        String type;

        Type(String t) {
            type = t;
        }

        public String toString() {
            return type;
        }
    }

    Type _type;
    int _tc = -1;

    int _mf;
    Probability _probability;
    Probability _imprecision;

    double _runtime;

    public Type getType() {
        return _type;
    }

    public void setTC(int tc) {
        _tc = tc;
    }

    public int getTC() {
        return _tc;
    }

    public void setMF(int mf) {
        _mf = mf;
    }

    public int getMF() {
        return _mf;
    }

    public void setProbability(Probability probability) {
        _probability = probability;
    }

    public Probability getProbability() {
        return _probability;
    }

    public void setImprecision(Probability imprecision) {
        _imprecision = imprecision;
    }

    public Probability getImprecision() {
        return _imprecision;
    }

    public void setRuntime(double runtime) {
        _runtime = runtime;
    }

    @JsonGetter
    @JsonProperty("runtime")
    public double getRuntime() {
        return _runtime;
    }

    @JsonGetter
    @JsonProperty("probability")
    public double probability() {
        return _probability.doubleValue();
    }

    @JsonGetter
    @JsonProperty("imprecision")
    public double imprecision() {
        return _imprecision.doubleValue();
    }

    @JsonIgnore
    public abstract Set<Header> getPropertyDstHeaders();

    @JsonIgnore
    public abstract Set<String> getPropertySrcRouters();

    public String toSpecification() {
        return "";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Property property = (Property) o;
        return _type == property._type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(_type);
    }

    /* csv supports */
    public static final String[] CSV_HEADER = {"type", "protocol", "source", "source_port", "destination", "destination_port", "src_router", "attributes", "mf", "probability"};

    public abstract String[] toCsvString();
}
