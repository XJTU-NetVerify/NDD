package datamodel.list;

public interface SortedMultiListOwner {
}
