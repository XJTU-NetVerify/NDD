package datamodel.property;

public class NDDBlock extends NDDSingleFlowProperty {
    public NDDBlock(Flow flow) {
        super(flow, Property.Type.BLOCK);
    }

    @Override
    public String[] toCsvString() {
        return new String[] {_type.toString(),
                _flow._header.getProtocol().toString(),
                _flow._header.getSource().toString(),
                _flow._header.getSourcePort().toString(),
                _flow._header.getDestination().toString(),
                _flow._header.getDestinationPort().toString(),
                _flow._src,
                "",
                _mf + "",
                _probability + ""};
    }
}
