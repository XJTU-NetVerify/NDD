package datamodel.failure.link;

import datamodel.probability.DoubleProbImpl;
import datamodel.probability.Probability;
import util.CombinationUtil;

import java.util.HashMap;

public class LinkFailureModelDouble extends LinkFailureModel {

    public LinkFailureModelDouble(String linkDownProb) {
        _linkDownProb = new DoubleProbImpl(linkDownProb);
        _linkUpProb = DoubleProbImpl.ONE.subtract(_linkDownProb);
        initMemo();
    }

    @Override
    public int getK(int nLink, Probability precision) {
        imprecision = DoubleProbImpl.ONE;
        int k = -1;
        while (imprecision.compareTo(precision) > 0) {
            k++;
            imprecision = imprecision.subtract(calProbability(nLink, k));
        }
        return k;
    }

    private Probability calProbability(int nLink, int k) {
        long m = CombinationUtil.choose(nLink, k);
        Probability prob = DoubleProbImpl.ONE;
        prob = prob.multiply(_linkDownProb.pow(k));
        prob = prob.multiply(_linkUpProb.pow(nLink - k));
        return prob.multiply(new DoubleProbImpl(m));
    }

    private void initMemo() {
        memo = new HashMap<>();
        memo.put(0, DoubleProbImpl.ZERO);
        memo.put(1, DoubleProbImpl.ONE);
    }
}
