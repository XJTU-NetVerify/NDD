package datamodel.list;

import sre.ndd.NDD;

public interface NDDSortedMultiListItem extends Comparable<NDDSortedMultiListItem> {
    default void markBudgetBounded(int budget) { }
    default int getBoundedBudget() { return -1; }
    void setList(NDDSortedMultiList list);
    NDDSortedMultiList getList();
    void setOuterIdx(int idx);
    int getOuterIdx();
    void setInnerIdx(int idx);
    int getInnerIdx();
    void setListTC(int tc);
    int getListTC();
    void setArriveTC(int tc);
    int getArriveTC();
    boolean isDead();
}
