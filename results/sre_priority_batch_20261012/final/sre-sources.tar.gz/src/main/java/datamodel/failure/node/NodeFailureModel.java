package datamodel.failure.node;

import algorithm.bayesian.BayesianNetwork;
import algorithm.bayesian.BnNode;
import algorithm.bayesian.Event;
import algorithm.bayesian.RandVar;
import controlplane.network.L3Edge;
import controlplane.network.L3Topology;
import controlplane.network.Router;
import controlplane.network.State;
import datamodel.failure.FailureModel;
import datamodel.probability.Probability;
import main.Controller;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Vector;

public abstract class NodeFailureModel extends FailureModel {
    Probability _linkDownProb;
    Probability _linkUpProb;
    Probability _nodeDownProb;
    Probability _nodeUpProb;

    HashMap<String, BnNode> bnNodes;

    Integer[] values = {0, 1};
    Probability[] nCpt;
    Probability[] lCpt;

    @Override
    public void initForTopology(L3Topology l3Topology) {
        bnNodes = new HashMap<>();
        for (Router r : l3Topology.getNodes().values()) {
            BnNode node = new BnNode(new RandVar(r.getRouterName(),
                    new Vector<>(Arrays.asList(values))),
                    new Vector<>(),
                    new Vector<>(Arrays.asList(nCpt)));
            bnNodes.put(r.getRouterName(), node);
        }
        for (L3Edge l : l3Topology.getL3Edges()) {
            if (l.getState() == State.SYMBOLIC) {
                Vector<BnNode> parents = new Vector<>();
                parents.add(bnNodes.get(l.getSrc().getRouterName()));
                parents.add(bnNodes.get(l.getDst().getRouterName()));
                BnNode node = new BnNode(new RandVar(l.toString(),
                        new Vector<>(Arrays.asList(values))),
                        parents,
                        new Vector<>(Arrays.asList(lCpt)));
                bnNodes.put(l.toString(), node);
            }
        }
    }

    private Probability calProbability(byte[] state) {
        for (BnNode node : bnNodes.values()) {
            node.clean();
        }

        BayesianNetwork bn = new BayesianNetwork();
        Event event = new Event();

        for (int i = 0; i < state.length; i++) {
            if (state[i] != -1) {
                L3Edge l = Controller.bddManager.getBDDTCWrapper().getLink(i);
                BnNode node = bnNodes.get(l.toString());
                event.setValue(node.getVar(), (int) state[i]);
                node.buildNetwork(bn);
            }
        }

        return bn.computeEventProb(event);
    }

    abstract Probability getZERO();

    public static Vector<byte[]> states = new Vector<>();
    public static Vector<Double> probs = new Vector<>();
    public static Vector<Long> times = new Vector<>();

    @Override
    public Probability calProbability(int bdd) {
        Probability prob = getZERO();
        Collection<byte[]> all = Controller.bddManager.getBDDTCWrapper().allSat(bdd);
        for (byte[] one : all) {
            prob = prob.add(calProbability(one));

//            long start = System.nanoTime();
//            Probability tmp = calProbability(one);
//            long end = System.nanoTime();
//
//            prob = prob.add(tmp);
//
//            states.add(one);
//            probs.add(tmp.doubleValue());
//            times.add((end - start));
        }
        return prob;
    }
}
