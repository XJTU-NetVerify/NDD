package datamodel.error;

public class UnsupportedFailureModelError extends Error {
    private static final long serialVersionUID = 6028709594058308840L;
}
