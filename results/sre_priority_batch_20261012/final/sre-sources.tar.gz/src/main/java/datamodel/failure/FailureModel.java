package datamodel.failure;

import controlplane.network.L3Topology;
import datamodel.probability.Probability;

public abstract class FailureModel {
    protected Probability imprecision;

    public Probability getImprecision() {
        return imprecision;
    }

    public abstract void initForTopology(L3Topology l3Topology);

    public abstract int getK(int nLink, Probability precision);

    public abstract Probability calProbability(int bdd);

    // public abstract Probability calProbability(int bdd);
}
