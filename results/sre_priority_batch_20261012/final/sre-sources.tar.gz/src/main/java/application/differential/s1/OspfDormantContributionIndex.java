package application.differential.s1;

import controlplane.network.NDDPort;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.route.NDDOspfRoute;
import controlplane.route.Path;
import controlplane.route.builder.NDDOspfRouteBuilder;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import sre.ndd.NDD;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeMap;

/** Owned pre-clean OSPF contribution templates for the first S1 update family. */
public final class OspfDormantContributionIndex implements AutoCloseable {
    private final List<Template> templates;
    private final Map<EdgeKey, BitSet> traversals;
    private final Map<BucketKey, IntMembers> buckets;
    private final int[] identityHeads;
    private int[] identityNext;
    private final int identityMask;
    private long traversalReferences;
    private int activeTemplates;
    private int reusedDuringAdvance;
    private int createdDuringAdvance;
    private boolean closed;

    private OspfDormantContributionIndex(List<Template> templates) {
        this(templates, 0, 0);
    }

    private OspfDormantContributionIndex(List<Template> templates,
            int reusedDuringAdvance, int createdDuringAdvance) {
        this.templates = new ArrayList<>(templates);
        this.traversals = buildTraversals(templates);
        this.buckets = buildBuckets(templates);
        int tableSize = 16;
        while (tableSize < templates.size() * 4L / 3L) tableSize <<= 1;
        this.identityHeads = new int[tableSize];
        this.identityNext = new int[templates.size()];
        this.identityMask = tableSize - 1;
        for (int index = 0; index < templates.size(); index++) {
            indexIdentity(templates.get(index), index);
        }
        this.traversalReferences = traversals.values().stream()
                .mapToLong(BitSet::cardinality).sum();
        this.activeTemplates = templates.size();
        this.reusedDuringAdvance = reusedDuringAdvance;
        this.createdDuringAdvance = createdDuringAdvance;
    }

    public static OspfDormantContributionIndex capture(
            Collection<NDDOspfProcess> processes) {
        List<NDDOspfProcess> ordered = new ArrayList<>(processes);
        ordered.sort(Comparator
                .comparing((NDDOspfProcess process) ->
                        process.getRouter().getRouterName())
                .thenComparingInt(NDDOspfProcess::getProcessId));
        List<Template> templates = new ArrayList<>();
        Map<MetadataKey, Metadata> metadata = new HashMap<>();
        for (NDDOspfProcess process : ordered) {
            for (Map.Entry<Prefix, NDDSortedMultiList> entry
                    : process.getRib().getRib().entrySet()) {
                for (NDDSortedMultiListItem item : entry.getValue().flat()) {
                    if (item instanceof NDDOspfRoute) {
                        templates.add(new Template(process,
                                (NDDOspfRoute) item, metadata));
                    }
                }
            }
        }
        return new OspfDormantContributionIndex(templates);
    }

    void advanceInPlace(List<NDDOspfRoute> replacements,
            List<NDDOspfProcess> owners) {
        int reused = 0;
        int created = 0;
        int oldSlots = templates.size();
        for (int index = 0; index < oldSlots; index++) {
            NDDOspfRoute route = replacements.get(index);
            if (route == null) continue;
            Template previous = templates.get(index);
            if (NDD.isFalse(route.getArriveTC())) {
                traversalReferences -= previous.traversalCount();
                previous.release();
                templates.set(index, null);
                activeTemplates--;
            } else if (previous.matchesDynamicState(route)) {
                reused++;
            } else {
                Template replacement = new Template(previous.getProcess(), route);
                previous.release();
                templates.set(index, replacement);
                created++;
            }
        }
        if (replacements.size() > identityNext.length) {
            identityNext = Arrays.copyOf(identityNext, replacements.size());
        }
        for (int index = oldSlots; index < replacements.size(); index++) {
            NDDOspfRoute route = replacements.get(index);
            NDDOspfProcess owner = owners.get(index - oldSlots);
            Template template = new Template(owner, route);
            templates.add(template);
            activeTemplates++;
            created++;
            template.indexTraversals(traversals, index);
            traversalReferences += template.traversalCount();
            buckets.computeIfAbsent(new BucketKey(owner, route.getPrefix()),
                    ignored -> new IntMembers()).add(index);
            indexIdentity(template, index);
        }
        reusedDuringAdvance = reused;
        createdDuringAdvance = created;
    }

    public List<Template> getTemplates() {
        if (closed) throw new IllegalStateException("dormant index is closed");
        return Collections.unmodifiableList(templates);
    }

    public Set<Integer> directIndices(String source, String destination) {
        BitSet bits = traversals.get(new EdgeKey(source, destination));
        if (bits == null) return Collections.emptySet();
        Set<Integer> indices = new HashSet<>();
        for (int index = bits.nextSetBit(0); index >= 0;
                index = bits.nextSetBit(index + 1)) {
            if (templates.get(index) != null) indices.add(index);
        }
        return indices;
    }

    public int directOwnerRouterCount(String source, String destination) {
        BitSet bits = traversals.get(new EdgeKey(source, destination));
        if (bits == null) return 0;
        Set<String> routers = new HashSet<>();
        for (int index = bits.nextSetBit(0); index >= 0;
                index = bits.nextSetBit(index + 1)) {
            Template template = templates.get(index);
            if (template != null) {
                routers.add(template.getProcess().getRouter().getRouterName());
            }
        }
        return routers.size();
    }

    public List<Integer> bucketIndices(NDDOspfProcess process, Prefix prefix) {
        IntMembers members = buckets.get(new BucketKey(process, prefix));
        if (members == null) return new ArrayList<>();
        List<Integer> result = new ArrayList<>(members.size);
        for (int offset = 0; offset < members.size; offset++) {
            int index = members.values[offset];
            if (templates.get(index) != null) result.add(index);
        }
        return result;
    }

    int identityHead(NDDOspfProcess process, Prefix prefix, List<String> path,
            Ip nextHop, NDDPort outPort) {
        return identityHeads[Template.identityHash(
                process, prefix, path, nextHop, outPort) & identityMask] - 1;
    }

    int nextIdentityCandidate(int index) {
        return identityNext[index] - 1;
    }

    Template templateAt(int index) { return templates.get(index); }

    public int size() { return activeTemplates; }
    public int slotCount() { return templates.size(); }
    public long traversalReferenceCount() { return traversalReferences; }
    public long ownedRootCount() { return 2L * activeTemplates; }
    public long estimatedBytes() {
        return 96L + 240L * activeTemplates
                + 4L * (identityHeads.length + identityNext.length)
                + 16L * templates.size();
    }
    public int reusedDuringAdvance() { return reusedDuringAdvance; }
    public int createdDuringAdvance() { return createdDuringAdvance; }

    public boolean needsCompaction() {
        return templates.size() > 2L * activeTemplates;
    }

    public OspfDormantContributionIndex compactedCopy() {
        List<Template> compacted = new ArrayList<>(activeTemplates);
        for (Template template : templates) {
            if (template != null) compacted.add(template.retain());
        }
        return new OspfDormantContributionIndex(compacted,
                reusedDuringAdvance, createdDuringAdvance);
    }

    /** Stable metadata multiset used to compare persistent and fresh indexes. */
    public Map<String, Integer> metadataHistogram() {
        Map<String, Integer> histogram = new TreeMap<>();
        for (Template template : templates) {
            if (template == null) continue;
            histogram.merge(metadataKey(template), 1, Integer::sum);
        }
        return histogram;
    }

    public Map<String, Integer> falseArriveMetadataHistogram() {
        Map<String, Integer> histogram = new TreeMap<>();
        for (Template template : templates) {
            if (template == null) continue;
            if (NDD.isFalse(template.arriveTc)) {
                histogram.merge(metadataKey(template), 1, Integer::sum);
            }
        }
        return histogram;
    }

    private static String metadataKey(Template template) {
        Metadata value = template.metadata;
        return value.process.getRouter().getRouterName() + "|ospf:"
                + value.process.getProcessId() + "|" + value.prefix + "|"
                + String.join(">", value.path) + "|" + value.nextHop + "|"
                + (value.outPort == null ? "NONE"
                        : value.outPort.getPortName().toString())
                + "|ad=" + value.administrativeDistance
                + "|metric=" + value.metric;
    }

    private static Map<EdgeKey, BitSet> buildTraversals(List<Template> templates) {
        Map<EdgeKey, BitSet> result = new HashMap<>();
        for (int index = 0; index < templates.size(); index++) {
            templates.get(index).indexTraversals(result, index);
        }
        return result;
    }

    private static Map<BucketKey, IntMembers> buildBuckets(
            List<Template> templates) {
        Map<BucketKey, IntMembers> result = new HashMap<>();
        for (int index = 0; index < templates.size(); index++) {
            Template template = templates.get(index);
            result.computeIfAbsent(new BucketKey(template.getProcess(),
                    template.getPrefix()), ignored -> new IntMembers()).add(index);
        }
        return result;
    }

    private void indexIdentity(Template template, int index) {
        int slot = template.identityHash() & identityMask;
        identityNext[index] = identityHeads[slot];
        identityHeads[slot] = index + 1;
    }

    @Override
    public void close() {
        if (closed) return;
        templates.stream().filter(Objects::nonNull).forEach(Template::release);
        closed = true;
    }

    public static final class Template {
        private final Metadata metadata;
        private final int arriveTc;
        private final int listTc;
        private int references = 1;

        private Template(NDDOspfProcess process, NDDOspfRoute route) {
            this(process, route, new HashMap<>());
        }

        private Template(NDDOspfProcess process, NDDOspfRoute route,
                Map<MetadataKey, Metadata> pool) {
            MetadataKey key = new MetadataKey(process, route);
            this.metadata = pool.computeIfAbsent(key,
                    ignored -> new Metadata(key));
            this.arriveTc = NDD.ref(route.getArriveTC());
            this.listTc = NDD.ref(route.getListTC());
        }

        private Template retain() {
            references++;
            return this;
        }

        public NDDOspfProcess getProcess() { return metadata.process; }
        public Prefix getPrefix() { return metadata.prefix; }
        public List<String> getPath() { return metadata.path; }
        public Ip getNextHop() { return metadata.nextHop; }
        public NDDPort getOutPort() { return metadata.outPort; }
        public long getMetric() { return metadata.metric; }

        private int identityHash() {
            return identityHash(metadata.process, metadata.prefix,
                    metadata.path, metadata.nextHop, metadata.outPort);
        }

        private static int identityHash(NDDOspfProcess process, Prefix prefix,
                List<String> path, Ip nextHop, NDDPort outPort) {
            int result = System.identityHashCode(process);
            result = 31 * result + prefix.hashCode();
            result = 31 * result + path.hashCode();
            result = 31 * result + Objects.hashCode(nextHop);
            result = 31 * result + System.identityHashCode(outPort);
            return result;
        }

        boolean matchesIdentity(NDDOspfProcess process, Prefix prefix,
                List<String> path, Ip nextHop, NDDPort outPort) {
            return metadata.process == process
                    && metadata.prefix.equals(prefix)
                    && metadata.path.equals(path)
                    && Objects.equals(metadata.nextHop, nextHop)
                    && metadata.outPort == outPort;
        }

        /** Existing aligned routes only mutate these three fields. */
        private boolean matchesDynamicState(NDDOspfRoute route) {
            return metadata.metric == route.getMetric()
                    && arriveTc == route.getArriveTC()
                    && listTc == route.getListTC();
        }

        public boolean traverses(String source, String destination) {
            String previous = null;
            for (String node : metadata.path) {
                if (source.equals(previous) && destination.equals(node)) return true;
                previous = node;
            }
            return source.equals(previous) && destination.equals(
                    metadata.process.getRouter().getRouterName());
        }

        private void indexTraversals(Map<EdgeKey, BitSet> result, int index) {
            String previous = null;
            for (String node : metadata.path) {
                if (previous != null) result.computeIfAbsent(
                        new EdgeKey(previous, node), ignored -> new BitSet())
                        .set(index);
                previous = node;
            }
            String owner = metadata.process.getRouter().getRouterName();
            if (previous != null) result.computeIfAbsent(
                    new EdgeKey(previous, owner), ignored -> new BitSet())
                    .set(index);
        }

        private int traversalCount() {
            return metadata.path.size();
        }

        public NDDOspfRoute newRoute() {
            Path<String> copiedPath = new Path<>();
            copiedPath.addAll(metadata.path);
            return new NDDOspfRouteBuilder()
                    .setPrefix(metadata.prefix)
                    .setNextHop(metadata.nextHop)
                    .setOutPort(metadata.outPort)
                    .setPath(copiedPath)
                    .setAD(metadata.administrativeDistance)
                    .setMetric(metadata.metric)
                    .setArriveTC(NDD.ref(arriveTc))
                    .setListTC(NDD.ref(listTc))
                    .build();
        }

        private void release() {
            references--;
            if (references > 0) return;
            if (references < 0) throw new IllegalStateException(
                    "dormant template released twice");
            NDD.deref(arriveTc);
            NDD.deref(listTc);
        }
    }

    /** Canonical immutable route data shared by templates that differ only in TC. */
    private static final class Metadata {
        private final NDDOspfProcess process;
        private final Prefix prefix;
        private final List<String> path;
        private final Ip nextHop;
        private final NDDPort outPort;
        private final int administrativeDistance;
        private final long metric;

        private Metadata(MetadataKey key) {
            process = key.process;
            prefix = key.prefix;
            path = Collections.unmodifiableList(new ArrayList<>(key.path));
            nextHop = key.nextHop;
            outPort = key.outPort;
            administrativeDistance = key.administrativeDistance;
            metric = key.metric;
        }
    }

    private static final class MetadataKey {
        private final NDDOspfProcess process;
        private final Prefix prefix;
        private final List<String> path;
        private final Ip nextHop;
        private final NDDPort outPort;
        private final int administrativeDistance;
        private final long metric;

        private MetadataKey(NDDOspfProcess process, NDDOspfRoute route) {
            this.process = process;
            this.prefix = route.getPrefix();
            this.path = route.getPath();
            this.nextHop = route.getNextHop();
            this.outPort = route.getOutPort();
            this.administrativeDistance = route.getAD();
            this.metric = route.getMetric();
        }

        @Override
        public boolean equals(Object object) {
            if (!(object instanceof MetadataKey)) return false;
            MetadataKey other = (MetadataKey) object;
            return process == other.process
                    && administrativeDistance == other.administrativeDistance
                    && metric == other.metric
                    && prefix.equals(other.prefix)
                    && path.equals(other.path)
                    && Objects.equals(nextHop, other.nextHop)
                    && outPort == other.outPort;
        }

        @Override
        public int hashCode() {
            int result = System.identityHashCode(process);
            result = 31 * result + prefix.hashCode();
            result = 31 * result + path.hashCode();
            result = 31 * result + Objects.hashCode(nextHop);
            result = 31 * result + System.identityHashCode(outPort);
            result = 31 * result + administrativeDistance;
            result = 31 * result + Long.hashCode(metric);
            return result;
        }
    }

    private static final class EdgeKey {
        private final String source;
        private final String destination;

        private EdgeKey(String source, String destination) {
            this.source = source;
            this.destination = destination;
        }

        @Override
        public boolean equals(Object object) {
            if (!(object instanceof EdgeKey)) return false;
            EdgeKey other = (EdgeKey) object;
            return source.equals(other.source)
                    && destination.equals(other.destination);
        }

        @Override
        public int hashCode() { return 31 * source.hashCode() + destination.hashCode(); }
    }

    private static final class BucketKey {
        private final NDDOspfProcess process;
        private final Prefix prefix;

        private BucketKey(NDDOspfProcess process, Prefix prefix) {
            this.process = process;
            this.prefix = prefix;
        }

        @Override
        public boolean equals(Object object) {
            if (!(object instanceof BucketKey)) return false;
            BucketKey other = (BucketKey) object;
            return process == other.process && prefix.equals(other.prefix);
        }

        @Override
        public int hashCode() {
            return 31 * System.identityHashCode(process) + prefix.hashCode();
        }
    }

    private static final class IntMembers {
        private int[] values = new int[8];
        private int size;

        private void add(int value) {
            if (size == values.length) values = Arrays.copyOf(values, size << 1);
            values[size++] = value;
        }
    }

}
