package application.differential.s3;

import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.network.PortName;
import sre.ndd.NDD;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** Owned snapshot of the forwarding predicate published on every router port. */
public final class FibPortSnapshot implements AutoCloseable {
    private final Map<NDDRouter, Map<PortName, Integer>> roots;
    private boolean closed;

    private FibPortSnapshot(Map<NDDRouter, Map<PortName, Integer>> roots) {
        this.roots = roots;
    }

    public static FibPortSnapshot capture(Collection<NDDRouter> routers) {
        Map<NDDRouter, Map<PortName, Integer>> roots = new LinkedHashMap<>();
        for (NDDRouter router : routers) {
            Map<PortName, Integer> ports = new LinkedHashMap<>();
            for (NDDPort port : router.getPorts().values()) {
                ports.put(port.getPortName(), NDD.ref(port.getPortFwdNDD()));
            }
            roots.put(router, ports);
        }
        return new FibPortSnapshot(roots);
    }

    public ChangedPortRegions diff(FibPortSnapshot newer) {
        Map<NDDRouter, Map<PortName, Integer>> changed = new LinkedHashMap<>();
        for (Map.Entry<NDDRouter, Map<PortName, Integer>> router : roots.entrySet()) {
            Map<PortName, Integer> newPorts = newer.roots.getOrDefault(
                    router.getKey(), Collections.emptyMap());
            for (Map.Entry<PortName, Integer> port : router.getValue().entrySet()) {
                int newerRoot = newPorts.getOrDefault(port.getKey(), NDD.getFalse());
                int region = symmetricDifference(port.getValue(), newerRoot);
                if (!NDD.isFalse(region)) {
                    changed.computeIfAbsent(router.getKey(), ignored ->
                            new LinkedHashMap<>()).put(port.getKey(), region);
                }
            }
        }
        return new ChangedPortRegions(changed);
    }

    private static int symmetricDifference(int left, int right) {
        int removed = NDD.ref(NDD.diff(left, right));
        int added = NDD.ref(NDD.diff(right, left));
        int result = NDD.ref(NDD.or(removed, added));
        NDD.deref(removed);
        NDD.deref(added);
        return result;
    }

    @Override
    public void close() {
        if (closed) return;
        roots.values().forEach(ports -> ports.values().forEach(NDD::deref));
        closed = true;
    }

    public static final class ChangedPortRegions implements AutoCloseable {
        private final Map<NDDRouter, Map<PortName, Integer>> roots;
        private boolean closed;

        private ChangedPortRegions(Map<NDDRouter, Map<PortName, Integer>> roots) {
            this.roots = roots;
        }

        public Set<NDDRouter> getRouters() {
            return Collections.unmodifiableSet(roots.keySet());
        }

        public Map<PortName, Integer> getPorts(NDDRouter router) {
            return Collections.unmodifiableMap(roots.getOrDefault(
                    router, Collections.emptyMap()));
        }

        public int getChangedPortCount() {
            return roots.values().stream().mapToInt(Map::size).sum();
        }

        @Override
        public void close() {
            if (closed) return;
            roots.values().forEach(ports -> ports.values().forEach(NDD::deref));
            closed = true;
        }
    }
}
