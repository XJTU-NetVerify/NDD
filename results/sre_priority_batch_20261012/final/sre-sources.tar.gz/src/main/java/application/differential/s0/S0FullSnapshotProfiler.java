package application.differential.s0;

import bdd.NDDManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import controlplane.network.NDDCPExecutor;
import controlplane.network.NDDL3Edge;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import datamodel.ipv4.Prefix;
import datamodel.property.NDDProperty;
import dataplane.analysis.NDDDPAnalyzer;
import main.Configuration;
import main.NDDController;
import main.storage.Storage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * One-event-per-JVM S0 full old/new/reverse locality profiler.
 *
 * Usage: S0FullSnapshotProfiler <input-dir> <output.json> [event-index] [mf]
 */
public final class S0FullSnapshotProfiler {
    private S0FullSnapshotProfiler() { }

    public static void main(String[] args) throws Exception {
        if (args.length < 2 || args.length > 4) {
            throw new IllegalArgumentException("usage: <input-dir> <output.json> [event-index] [mf]");
        }
        Path input = Paths.get(args[0]);
        Path output = Paths.get(args[1]);
        int eventIndex = args.length >= 3 ? Integer.parseInt(args[2]) : 0;
        int mf = args.length >= 4 ? Integer.parseInt(args[3]) : 1;
        S0LocalityObservation observation = run(input, output, eventIndex, mf);
        System.out.println("s0_event:" + observation.getEvent().getId());
        System.out.println("s0_reverse_exact:" + observation.isReverseExact());
        System.out.println("s0_changed_contributions:" + observation.getChangedContributions());
        System.out.println("s0_changed_rib_routes:" + observation.getChangedRibRoutes());
        System.out.println("s0_changed_fib_rules:" + observation.getChangedFibRules());
        System.out.println("s0_changed_pfecs:" + observation.getChangedPfecs());
        System.out.println("s0_changed_properties:" + observation.getChangedProperties());
    }

    public static S0LocalityObservation run(Path input, Path output,
            int eventIndex, int mf) throws Exception {
        if (!Files.isDirectory(input)) throw new IllegalArgumentException(
                "input directory not found: " + input);
        if (eventIndex < 0 || mf < 0) throw new IllegalArgumentException(
                "eventIndex and mf must be non-negative");
        resetGlobals(mf);

        List<RunContext> contexts = new ArrayList<>();
        for (String name : new String[] {"old", "new", "reverse"}) {
            Path runOutput = output.toAbsolutePath().getParent().resolve(
                    output.getFileName().toString() + "." + name);
            Storage storage = new Storage(input, runOutput);
            NDDController.storage = storage;
            NDDCPExecutor executor = new NDDCPExecutor();
            NDDController.cpExecutor = executor;
            executor.init();
            contexts.add(new RunContext(storage, executor));
            NDDController.cpExecutorStack.add(executor);
            markAllInterested(executor);
        }

        NDDController.cpExecutor = contexts.get(0).executor;
        NDDController.bddManager = new NDDManager(1_000_000, 100_000);
        for (RunContext context : contexts) {
            context.executor.buildOspfTopology();
        }
        OspfCostManifest manifest = OspfCostManifest.generate(
                input.getFileName().toString(), contexts.get(0).executor.getOspfTopology(), 1);
        if (eventIndex >= manifest.getUpdates().size()) {
            throw new IllegalArgumentException("eventIndex " + eventIndex
                    + " outside manifest size " + manifest.getUpdates().size());
        }
        OspfCostUpdate event = manifest.getUpdates().get(eventIndex);

        FullResult oldResult = executeFull(contexts.get(0), null, false);
        FullResult newResult = executeFull(contexts.get(1), event, false);
        FullResult reverseResult = executeFull(contexts.get(2), event, true);
        try (S0Snapshot oldState = oldResult.snapshot;
                S0Snapshot newState = newResult.snapshot;
                S0Snapshot restoredState = reverseResult.snapshot) {
            S0Oracle.Result oracle = S0Oracle.verify(oldState, newState, restoredState);
            RibOwnershipAudit.Report ownership = RibOwnershipAudit.inspect(
                    contexts.get(0).executor.getRouters().values());
            S0LocalityObservation observation = new S0LocalityObservation(event,
                    oldState, oracle, ownership, oldResult.nanos,
                    newResult.nanos, reverseResult.nanos, oldResult.resources,
                    newResult.resources, reverseResult.resources);
            write(output, observation);
            if (!oracle.isReverseExact()) printReverseDiagnostics(oracle);
            oracle.requireReverseExact();
            return observation;
        }
    }

    private static FullResult executeFull(RunContext context,
            OspfCostUpdate update, boolean rollbackBeforeExecution) {
        NDDController.storage = context.storage;
        NDDController.cpExecutor = context.executor;
        OspfCostUpdate.Bound bound = null;
        if (update != null) {
            bound = update.bind(context.executor.getRouters(),
                    context.executor.getOspfTopology());
            bound.apply();
            if (rollbackBeforeExecution) bound.rollback();
        }
        boolean completed = false;
        try {
            // Router equality is name-based, so the controller's cross-snapshot HashSet
            // retains only one snapshot's objects. Activate the current full snapshot
            // explicitly instead of relying on that global set.
            context.executor.getRouters().values().forEach(router -> {
                router.getOspfProcesses().values().forEach(process -> process.setValid(true));
                if (router.getBgpProcess() != null) router.getBgpProcess().setValid(true);
            });
            long start = System.nanoTime();
            context.executor.generateDataPlane();
            NDDDPAnalyzer analyzer = new NDDDPAnalyzer(context.executor);
            NDDController.dpAnalyzer = analyzer;
            analyzer.analyzeDataPlane(reachabilitySources(context));
            Set<NDDProperty> properties = analyzer._specificationBD.mineReachability();
            long nanos = System.nanoTime() - start;
            S0Snapshot snapshot = S0Snapshot.capture(
                    context.executor.getRouters().values(), analyzer._reachabilityDB, properties);
            S0ResourceSample resources = S0ResourceSample.capture();
            if (bound != null && !rollbackBeforeExecution) bound.commit();
            completed = true;
            return new FullResult(snapshot, nanos, resources);
        } finally {
            if (bound != null && (!completed || rollbackBeforeExecution)) bound.close();
        }
    }

    /**
     * Several generated fat-tree snapshots omit the optional edgePorts file.
     * The normal parser then exposes every router as a source but leaves every
     * terminal port unmarked, so SPF runs without ever recording a terminal
     * path.  For profiling only, infer the intended host-facing boundary from
     * unlinked interfaces.  Explicit edgePorts input always wins.
     */
    private static Collection<NDDRouter> reachabilitySources(RunContext context) {
        if (Files.isRegularFile(context.storage.input._edgePorts)) {
            return context.executor.getEdgeRouters();
        }
        Set<NDDRouter> sources = new LinkedHashSet<>();
        for (NDDPort port : context.executor.getPorts().values()) {
            if (port.getLinkedPort() == null) {
                port.setEdge();
                sources.add(port.getRouter());
            }
        }
        if (sources.isEmpty()) {
            throw new IllegalStateException(
                    "no explicit edgePorts file and no unlinked terminal ports");
        }
        return sources;
    }

    private static void markAllInterested(NDDCPExecutor executor) {
        for (NDDRouter router : executor.getRouters().values()) {
            for (Prefix prefix : router.getPrefixes()) prefix.setInterested(true);
            NDDController.ospfValidRouters.add(router);
            NDDController.bgpValidRouters.add(router);
        }
    }

    private static void resetGlobals(int mf) {
        NDDL3Edge.clearCache();
        NDDController.storageStack.clear();
        NDDController.cpExecutorStack.clear();
        NDDController.dpAnalyzerStack.clear();
        NDDController.bddManagerStack.clear();
        NDDController.mfStack.clear();
        NDDController.ospfValidRouters.clear();
        NDDController.bgpValidRouters.clear();
        NDDController.MF = mf;
        Configuration.ALL_IN_ONE = true;
        Configuration.LAZY = false;
        Configuration.FORWARD = true;
        Configuration.FILTER = false;
        Configuration.SORT = false;
    }

    private static void write(Path output, S0LocalityObservation observation)
            throws IOException {
        Path absolute = output.toAbsolutePath();
        if (absolute.getParent() != null) Files.createDirectories(absolute.getParent());
        new ObjectMapper().writerWithDefaultPrettyPrinter()
                .writeValue(absolute.toFile(), observation);
    }

    private static void printReverseDiagnostics(S0Oracle.Result oracle) {
        printLayer("contribution", oracle.getReverse().getContributions());
        printLayer("rib", oracle.getReverse().getRib());
        printLayer("fib", oracle.getReverse().getFib());
        printLayer("pfec", oracle.getReverse().getPfec());
        printLayer("property", oracle.getReverse().getProperties());
    }

    private static void printLayer(String name, S0Snapshot.LayerDiff diff) {
        System.err.println("s0_reverse_" + name + ":added=" + diff.getAdded()
                + ",removed=" + diff.getRemoved() + ",modified=" + diff.getModified());
        diff.getChangedKeys().stream().limit(5).forEach(key ->
                System.err.println("s0_reverse_" + name + "_key:" + key));
    }

    private static final class RunContext {
        private final Storage storage;
        private final NDDCPExecutor executor;
        private RunContext(Storage storage, NDDCPExecutor executor) {
            this.storage = storage;
            this.executor = executor;
        }
    }

    private static final class FullResult {
        private final S0Snapshot snapshot;
        private final long nanos;
        private final S0ResourceSample resources;
        private FullResult(S0Snapshot snapshot, long nanos, S0ResourceSample resources) {
            this.snapshot = snapshot;
            this.nanos = nanos;
            this.resources = resources;
        }
    }
}
