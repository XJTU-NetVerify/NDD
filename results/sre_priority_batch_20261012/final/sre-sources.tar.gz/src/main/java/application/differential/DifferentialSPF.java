package application.differential;

import main.Controller;

import java.nio.file.Path;
import java.nio.file.Paths;

public class DifferentialSPF extends Differential {
    public DifferentialSPF(Path inputBase, Path[] snapshots, int mf) {
        super(inputBase, snapshots, mf);
    }

    @Override
    public long spf() {
        long start = System.nanoTime();
        for (int i = 0; i < n; i++) {
            Controller.dpAnalyzer.computeFwdBDD();
            Controller.dpAnalyzer.computeAclBDD();
            Controller.popStorage();
            Controller.popCPExecutor();
            Controller.popDPAnalyzer();
        }
        return System.nanoTime() - start;
    }

    @Override
    public long diff() {
        return super.diff();
    }

    public static void main(String[] args) {
        Path inputBase = Paths.get(args[0]);
        int n = args.length - 1;
        Path[] snapshots = new Path[n - 1];
        for (int i = 1; i < n; i++) {
            snapshots[i - 1] = inputBase.resolve(args[i]);
            System.out.print(snapshots[i - 1].getFileName().toString() + "\t");
        }
        int mf = Integer.parseInt(args[n]);
        DifferentialSPF differential = new DifferentialSPF(inputBase, snapshots, mf);
        differential.run();
        System.out.print("\n");
    }
}
