package application.differential.s0;

/** Exact old/new/reverse composition check for S0 full snapshots. */
public final class S0Oracle {
    private S0Oracle() { }

    public static Result verify(S0Snapshot oldState, S0Snapshot newState,
            S0Snapshot restoredState) {
        if (oldState == null || newState == null || restoredState == null) {
            throw new IllegalArgumentException("old, new and restored snapshots are required");
        }
        S0Snapshot.SnapshotDiff forward = oldState.diff(newState);
        S0Snapshot.SnapshotDiff reverse = oldState.diff(restoredState);
        return new Result(forward, reverse);
    }

    public static final class Result {
        private final S0Snapshot.SnapshotDiff forward;
        private final S0Snapshot.SnapshotDiff reverse;

        private Result(S0Snapshot.SnapshotDiff forward,
                S0Snapshot.SnapshotDiff reverse) {
            this.forward = forward;
            this.reverse = reverse;
        }

        public S0Snapshot.SnapshotDiff getForward() { return forward; }
        public S0Snapshot.SnapshotDiff getReverse() { return reverse; }
        public boolean isReverseExact() { return reverse.isEmpty(); }

        public void requireReverseExact() {
            if (!isReverseExact()) {
                throw new IllegalStateException("old/new/reverse oracle failed: "
                        + "contributions=" + reverse.getContributions().getChangedCount()
                        + ", rib=" + reverse.getRib().getChangedCount()
                        + ", fib=" + reverse.getFib().getChangedCount()
                        + ", pfec=" + reverse.getPfec().getChangedCount()
                        + ", properties=" + reverse.getProperties().getChangedCount());
            }
        }
    }
}
