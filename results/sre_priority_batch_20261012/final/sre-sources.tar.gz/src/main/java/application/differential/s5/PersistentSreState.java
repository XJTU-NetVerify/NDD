package application.differential.s5;

import application.differential.s0.OspfCostUpdate;
import application.differential.s1.OspfCostContributionTransaction;
import application.differential.s1.OspfDormantContributionIndex;
import application.differential.s2.AffectedPrefixRibFibTransaction;
import application.differential.s3.AffectedSourceSpfTransaction;
import application.differential.s3.FibPortSnapshot;
import application.differential.s3.SpfAffectedSourceProbe;
import application.differential.s3.SpfReachabilityIndex;
import application.differential.s4.PfecPartitionSnapshot;
import application.differential.s4.ReachabilityPropertySet;
import application.differential.s4.ReachabilityCoverageSnapshot;
import controlplane.network.NDDCPExecutor;
import controlplane.network.NDDRouter;
import dataplane.analysis.NDDDPAnalyzer;
import dataplane.analysis.NDDReachabilityDB;
import sre.ndd.NDD;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/** Persistent accepted-domain state consumed by generation transactions. */
public final class PersistentSreState implements AutoCloseable {
    private NDDCPExecutor executor;
    private Collection<NDDRouter> sources;
    private OspfDormantContributionIndex dormantIndex;
    private NDDReachabilityDB reachability;
    private ReachabilityPropertySet properties;
    private ReachabilityPropertySet.Evaluation propertyResults;
    private ReachabilityCoverageSnapshot coverage;
    private FibPortSnapshot fibPorts;
    private SpfReachabilityIndex spfArrivals;
    private String lastFallbackReason = "none";
    private int lastDirectContributions;
    private int lastWorklistPops;
    private int lastClonedContributions;
    private int lastRecomputedBuckets;
    private int lastAffectedPrefixes;
    private int lastAffectedRouters;
    private int lastDirectOwnerRouters;
    private int lastChangedFibRules;
    private int lastAddedFibRules;
    private int lastAffectedSources;
    private int lastDependentProperties;
    private int lastSpfNodes;
    private double lastAffectedSourceFraction;
    private long lastContributionPrepareNanos;
    private long lastContributionApplyNanos;
    private long lastContributionStructuralBuildNanos;
    private long lastContributionPropagationNanos;
    private long lastContributionFinalizationNanos;
    private long lastRibFibNanos;
    private long lastFwdNanos;
    private long lastSelectionNanos;
    private long lastSpfNanos;
    private long lastPropertyNanos;
    private long lastIndexAdvanceNanos;
    private boolean lastIndexCompacted;
    private boolean closed;

    public PersistentSreState(NDDCPExecutor executor,
            OspfDormantContributionIndex dormantIndex,
            Collection<NDDRouter> sources) {
        this.executor = executor;
        this.dormantIndex = dormantIndex;
        this.sources = new ArrayList<>(sources);
        NDDDPAnalyzer analyzer = new NDDDPAnalyzer(executor);
        analyzer.analyzeDataPlane(this.sources);
        this.reachability = analyzer._reachabilityDB;
        this.properties = ReachabilityPropertySet.forRouters(
                this.sources, executor.getRouters().values());
        Set<String> sourceNames = sourceNames(this.sources);
        this.coverage = ReachabilityCoverageSnapshot.capture(
                reachability, sourceNames);
        this.fibPorts = FibPortSnapshot.capture(executor.getRouters().values());
        this.spfArrivals = SpfReachabilityIndex.capture(
                this.sources, reachability);
        try (PfecPartitionSnapshot partition = PfecPartitionSnapshot.capture(
                reachability, sourceNames)) {
            this.propertyResults = properties.evaluate(
                    partition, properties.getPropertyIds());
        }
    }

    public PersistentGenerationCoordinator.Transaction prepare(
            OspfCostUpdate update) {
        if (closed) throw new IllegalStateException("persistent state is closed");
        lastFallbackReason = "none";
        lastDirectContributions = 0;
        lastWorklistPops = 0;
        lastClonedContributions = 0;
        lastRecomputedBuckets = 0;
        lastAffectedPrefixes = 0;
        lastAffectedRouters = 0;
        lastDirectOwnerRouters = 0;
        lastChangedFibRules = 0;
        lastAddedFibRules = 0;
        lastAffectedSources = 0;
        lastDependentProperties = 0;
        lastSpfNodes = 0;
        lastAffectedSourceFraction = 0;
        lastContributionPrepareNanos = 0;
        lastContributionApplyNanos = 0;
        lastContributionStructuralBuildNanos = 0;
        lastContributionPropagationNanos = 0;
        lastContributionFinalizationNanos = 0;
        lastRibFibNanos = 0;
        lastFwdNanos = 0;
        lastSelectionNanos = 0;
        lastSpfNanos = 0;
        lastPropertyNanos = 0;
        lastIndexAdvanceNanos = 0;
        lastIndexCompacted = false;
        return new UpdateTransaction(update);
    }

    public NDDCPExecutor getExecutor() { return executor; }
    public NDDReachabilityDB getReachability() { return reachability; }
    public Collection<NDDRouter> getSources() { return sources; }
    public ReachabilityPropertySet getProperties() { return properties; }
    public ReachabilityPropertySet.Evaluation getPropertyResults() {
        return propertyResults;
    }
    public ReachabilityCoverageSnapshot getCoverage() { return coverage; }
    public String getLastFallbackReason() { return lastFallbackReason; }
    public int getLastDirectContributions() { return lastDirectContributions; }
    public int getLastWorklistPops() { return lastWorklistPops; }
    public int getLastClonedContributions() { return lastClonedContributions; }
    public int getLastRecomputedBuckets() { return lastRecomputedBuckets; }
    public int getLastAffectedPrefixes() { return lastAffectedPrefixes; }
    public int getLastAffectedRouters() { return lastAffectedRouters; }
    public int getLastDirectOwnerRouters() { return lastDirectOwnerRouters; }
    public int getLastChangedFibRules() { return lastChangedFibRules; }
    public int getLastAddedFibRules() { return lastAddedFibRules; }
    public int getLastAffectedSources() { return lastAffectedSources; }
    public int getLastDependentProperties() { return lastDependentProperties; }
    public int getLastSpfNodes() { return lastSpfNodes; }
    public double getLastAffectedSourceFraction() {
        return lastAffectedSourceFraction;
    }
    public long getLastContributionPrepareNanos() {
        return lastContributionPrepareNanos;
    }
    public long getLastContributionApplyNanos() {
        return lastContributionApplyNanos;
    }
    public long getLastContributionStructuralBuildNanos() {
        return lastContributionStructuralBuildNanos;
    }
    public long getLastContributionPropagationNanos() {
        return lastContributionPropagationNanos;
    }
    public long getLastContributionFinalizationNanos() {
        return lastContributionFinalizationNanos;
    }
    public long getLastRibFibNanos() { return lastRibFibNanos; }
    public long getLastFwdNanos() { return lastFwdNanos; }
    public long getLastSelectionNanos() { return lastSelectionNanos; }
    public long getLastSpfNanos() { return lastSpfNanos; }
    public long getLastPropertyNanos() { return lastPropertyNanos; }
    public long getLastIndexAdvanceNanos() { return lastIndexAdvanceNanos; }
    public boolean wasLastIndexCompacted() { return lastIndexCompacted; }
    public int getDormantIndexSize() { return dormantIndex.size(); }
    public int getDormantIndexSlots() { return dormantIndex.slotCount(); }
    public long getDormantIndexBytes() { return dormantIndex.estimatedBytes(); }
    public long getDormantIndexRoots() { return dormantIndex.ownedRootCount(); }
    public long getDormantTraversalReferences() {
        return dormantIndex.traversalReferenceCount();
    }
    public int getDormantReusedDuringAdvance() {
        return dormantIndex.reusedDuringAdvance();
    }
    public int getDormantCreatedDuringAdvance() {
        return dormantIndex.createdDuringAdvance();
    }
    public java.util.Map<String, Integer> getDormantMetadataHistogram() {
        return dormantIndex.metadataHistogram();
    }
    public java.util.Map<String, Integer> getDormantFalseArriveHistogram() {
        return dormantIndex.falseArriveMetadataHistogram();
    }

    public PersistentGenerationCoordinator.Transaction replaceWithFull(
            PersistentSreState candidate) {
        return new FullReplacementTransaction(candidate);
    }

    @Override
    public void close() {
        if (closed) return;
        releaseCurrent();
        closed = true;
    }

    private void releaseCurrent() {
        propertyResults.close();
        properties.close();
        coverage.close();
        fibPorts.close();
        spfArrivals.close();
        reachability.close();
        dormantIndex.close();
    }

    private final class FullReplacementTransaction
            implements PersistentGenerationCoordinator.Transaction {
        private PersistentSreState candidate;
        private boolean committed;

        private FullReplacementTransaction(PersistentSreState candidate) {
            this.candidate = candidate;
        }

        public void apply() { }
        public void verify() {
            if (candidate == null || candidate.closed) {
                throw new IllegalStateException("full candidate unavailable");
            }
        }
        public void commit() {
            releaseCurrent();
            executor = candidate.executor;
            sources = candidate.sources;
            dormantIndex = candidate.dormantIndex;
            reachability = candidate.reachability;
            properties = candidate.properties;
            propertyResults = candidate.propertyResults;
            coverage = candidate.coverage;
            fibPorts = candidate.fibPorts;
            spfArrivals = candidate.spfArrivals;
            candidate.closed = true;
            candidate = null;
            committed = true;
        }
        public void rollback() { }
        public void close() {
            if (!committed && candidate != null) candidate.close();
            candidate = null;
        }
    }

    private final class UpdateTransaction
            implements PersistentGenerationCoordinator.Transaction {
        private final OspfCostUpdate update;
        private OspfCostUpdate.Bound bound;
        private OspfCostContributionTransaction contribution;
        private AffectedPrefixRibFibTransaction ribFib;
        private AffectedSourceSpfTransaction spf;
        private FibPortSnapshot nextFibPorts;
        private ReachabilityPropertySet.Evaluation nextPropertyResults;
        private ReachabilityCoverageSnapshot nextCoverage;
        private String fallbackReason = "none";
        private boolean applied;
        private boolean committed;
        private boolean verified;
        private boolean closed;
        private int affectedSources;
        private int dependentProperties;

        private UpdateTransaction(OspfCostUpdate update) {
            this.update = update;
        }

        @Override
        public boolean isFallback() {
            return !"none".equals(fallbackReason);
        }

        @Override
        public String fallbackReason() { return fallbackReason; }

        @Override
        public void apply() {
            if (applied || isFallback()) return;
            lastDirectOwnerRouters = dormantIndex.directOwnerRouterCount(
                    update.getPeerRouter(), update.getRouter());
            if (!IncrementalAdmissionPolicy.acceptsDirectOwners(
                    lastDirectOwnerRouters, executor.getRouters().size())) {
                fallback("predicted_full_cheaper");
                return;
            }
            bound = update.bind(executor.getRouters(), executor.getOspfTopology());
            bound.apply();
            long stageStart = System.nanoTime();
            contribution = OspfCostContributionTransaction.prepare(update,
                    executor.getRouters(), executor.getOspfTopology(), dormantIndex);
            lastContributionPrepareNanos = System.nanoTime() - stageStart;
            lastContributionStructuralBuildNanos =
                    contribution.getStructuralBuildNanos();
            lastContributionPropagationNanos = contribution.getPropagationNanos();
            lastContributionFinalizationNanos =
                    contribution.getFinalizationNanos();
            lastDirectContributions = contribution.getDirectContributions();
            lastWorklistPops = contribution.getWorklistPops();
            lastClonedContributions = contribution.getClonedContributions();
            lastRecomputedBuckets = contribution.getRecomputedBuckets();
            lastAffectedRouters = contribution.getAffectedRouters().size();
            if (contribution.isFullFallback()) {
                fallback(contribution.getReason());
                return;
            }
            if (!IncrementalAdmissionPolicy.acceptsAffectedRouters(
                    lastAffectedRouters, executor.getRouters().size())) {
                fallback("predicted_full_cheaper");
                return;
            }
            stageStart = System.nanoTime();
            contribution.apply();
            lastContributionApplyNanos = System.nanoTime() - stageStart;
            if (!AffectedPrefixRibFibTransaction.isWithinBudget(
                    contribution.getAffectedPrefixesByRouter())) {
                fallback("affected_prefix_budget");
                return;
            }
            stageStart = System.nanoTime();
            ribFib = new AffectedPrefixRibFibTransaction(executor.getRouters(),
                    contribution.getAffectedPrefixesByRouter());
            ribFib.apply();
            lastRibFibNanos = System.nanoTime() - stageStart;
            lastAffectedPrefixes = ribFib.getAffectedPrefixCount();
            lastChangedFibRules = ribFib.getChangedFibRules();
            lastAddedFibRules = ribFib.getAddedFibRules();
            stageStart = System.nanoTime();
            ribFib.getChangedFibRouters().forEach(router ->
                    NDDDPAnalyzer.computeFwdBDD(
                            executor.getRouters().get(router), NDD.getTrue()));
            lastFwdNanos = System.nanoTime() - stageStart;
            long selectionStart = System.nanoTime();
            nextFibPorts = FibPortSnapshot.capture(executor.getRouters().values());
            try (FibPortSnapshot.ChangedPortRegions changed =
                            fibPorts.diff(nextFibPorts);
                    SpfAffectedSourceProbe.Result selected =
                            SpfAffectedSourceProbe.select(spfArrivals, changed,
                                    ribFib.getAddedFibRules() > 0
                                            ? sources
                                            : java.util.Collections.emptyList())) {
                lastSelectionNanos = System.nanoTime() - selectionStart;
                affectedSources = selected.getSources().size();
                lastAffectedSources = affectedSources;
                lastAffectedSourceFraction = sources.isEmpty() ? 0
                        : (double) affectedSources / sources.size();
                if (!IncrementalAdmissionPolicy.accepts(
                        affectedSources, sources.size())) {
                    fallback("predicted_full_cheaper");
                    return;
                }
                stageStart = System.nanoTime();
                spf = new AffectedSourceSpfTransaction(selected.getSources());
                spf.apply();
                lastSpfNanos = System.nanoTime() - stageStart;
                if (spf.isFallback()) {
                    fallback(spf.getFallbackReason());
                    return;
                }
                lastSpfNodes = spf.getStoredNodeCount();
                Set<String> selectedNames = sourceNames(selected.getSources());
                stageStart = System.nanoTime();
                try (ReachabilityCoverageSnapshot oldAffected =
                                coverage.subset(selectedNames);
                        ReachabilityCoverageSnapshot candidateAffected =
                                ReachabilityCoverageSnapshot.capture(
                                        spf.getCandidate(), selectedNames);
                        PfecPartitionSnapshot.CoverageDelta coverageDelta =
                                oldAffected.coverageDelta(candidateAffected)) {
                    Set<PfecPartitionSnapshot.PairKey> dependencies =
                            properties.dependencies(coverageDelta);
                    dependentProperties = dependencies.size();
                    lastDependentProperties = dependentProperties;
                    try (ReachabilityPropertySet.Evaluation changedResults =
                            properties.evaluate(candidateAffected, dependencies)) {
                        nextPropertyResults = propertyResults.updatedWith(changedResults);
                    }
                    nextCoverage = coverage.updatedSources(
                            candidateAffected, selectedNames);
                }
                lastPropertyNanos = System.nanoTime() - stageStart;
            }
            applied = true;
        }

        @Override
        public void verify() {
            if (!applied || isFallback()) {
                throw new IllegalStateException("incremental candidate unavailable");
            }
            verified = true;
        }

        @Override
        public void commit() {
            if (!verified) throw new IllegalStateException("commit before oracle");
            spf.commitInto(reachability);
            spfArrivals.replaceSources(spf.getSources(), spf.getCandidate());
            ribFib.commit();
            long stageStart = System.nanoTime();
            contribution.advanceIndex();
            if (dormantIndex.needsCompaction()) {
                OspfDormantContributionIndex compacted =
                        dormantIndex.compactedCopy();
                dormantIndex.close();
                dormantIndex = compacted;
                lastIndexCompacted = true;
            }
            lastIndexAdvanceNanos = System.nanoTime() - stageStart;
            contribution.commit();
            bound.commit();
            propertyResults.close();
            coverage.close();
            fibPorts.close();
            propertyResults = nextPropertyResults;
            coverage = nextCoverage;
            fibPorts = nextFibPorts;
            nextPropertyResults = null;
            nextCoverage = null;
            nextFibPorts = null;
            committed = true;
            applied = false;
        }

        @Override
        public void rollback() {
            if (committed || closed) return;
            if (ribFib != null) ribFib.rollback();
            if (contribution != null) contribution.rollback();
            if (bound != null) bound.rollback();
            if (ribFib != null) {
                ribFib.getChangedFibRouters().forEach(router ->
                        NDDDPAnalyzer.computeFwdBDD(
                                executor.getRouters().get(router), NDD.getTrue()));
            }
            applied = false;
        }

        @Override
        public void close() {
            if (closed) return;
            if (!committed) rollback();
            if (nextPropertyResults != null) nextPropertyResults.close();
            if (nextCoverage != null) nextCoverage.close();
            if (spf != null) spf.close();
            if (ribFib != null) ribFib.close();
            if (contribution != null) contribution.close();
            if (bound != null) bound.close();
            if (nextFibPorts != null) nextFibPorts.close();
            closed = true;
        }

        public int getAffectedSources() { return affectedSources; }
        public int getDependentProperties() { return dependentProperties; }

        private void fallback(String reason) {
            fallbackReason = reason;
            lastFallbackReason = reason;
        }
    }

    private static Set<String> sourceNames(Collection<NDDRouter> routers) {
        Set<String> names = new HashSet<>();
        routers.forEach(router -> names.add(router.getRouterName()));
        return names;
    }
}
