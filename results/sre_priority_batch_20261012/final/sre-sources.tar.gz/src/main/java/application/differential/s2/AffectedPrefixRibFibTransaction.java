package application.differential.s2;

import controlplane.network.NDDRouter;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.rib.NDDRib;
import controlplane.route.NDDOspfRoute;
import controlplane.route.NDDRoute;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import dataplane.fib.NDDFib;
import dataplane.fib.NDDForwardingRule;
import main.NDDController;
import sre.ndd.NDD;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.IdentityHashMap;

/** Prefix-local global-RIB competition and Symbolic FIB replacement. */
public final class AffectedPrefixRibFibTransaction implements AutoCloseable {
    public static final int MAX_AFFECTED_PREFIXES = 128;
    private static final String PREFIX_PROPERTY =
            "delta.sre.maxAffectedPrefixes";
    private final Map<String, NDDRouter> routers;
    private final List<Key> affected;
    private final Map<Key, NDDSortedMultiList> oldRibs = new LinkedHashMap<>();
    private final Map<Key, NDDSortedMultiList> oldFibs = new LinkedHashMap<>();
    private final Set<Key> changedFibPrefixes = new HashSet<>();
    private final Set<NDDOspfRoute> ownedGlobalRoutes = Collections.newSetFromMap(
            new IdentityHashMap<>());
    private int addedFibRules;
    private int removedFibRules;
    private int modifiedFibRules;
    private int eliminatedFibPrefixes;
    private boolean applied;
    private boolean committed;

    public AffectedPrefixRibFibTransaction(Map<String, NDDRouter> routers,
            Map<String, Set<Prefix>> affectedPrefixes) {
        this.routers = routers;
        this.affected = new ArrayList<>();
        affectedPrefixes.forEach((router, prefixes) -> prefixes.forEach(
                prefix -> affected.add(new Key(router, prefix))));
        Collections.sort(affected);
    }

    public static boolean isWithinBudget(
            Map<String, Set<Prefix>> affectedPrefixes) {
        int count = 0;
        for (Set<Prefix> prefixes : affectedPrefixes.values()) {
            count += prefixes.size();
            if (count > maxAffectedPrefixes()) return false;
        }
        return true;
    }

    public static int maxAffectedPrefixes() {
        return Integer.getInteger(PREFIX_PROPERTY, MAX_AFFECTED_PREFIXES);
    }

    public void apply() {
        if (applied) return;
        for (Key key : affected) {
            NDDRouter router = routers.get(key.router);
            NDDSortedMultiList oldRib = router.getGlobalRib().removePrefix(key.prefix);
            NDDSortedMultiList oldFib = router.getFib().remove(key.prefix);
            oldRibs.put(key, oldRib);
            oldFibs.put(key, oldFib);

            NDDSortedMultiList newRib = rebuildGlobalPrefix(router, key.prefix, oldRib);
            if (newRib != null && !newRib.isEmpty()) {
                router.getGlobalRib().attachPrefix(key.prefix, newRib);
            }
            NDDSortedMultiList newFib = buildFib(router, key.prefix, newRib);
            RuleDiff diff = diffRules(oldFib, newFib);
            if (diff.changed() == 0) {
                releaseFib(router.getFib().remove(key.prefix));
                if (oldFib != null) router.getFib().insert(key.prefix, oldFib);
                eliminatedFibPrefixes++;
            } else {
                changedFibPrefixes.add(key);
                addedFibRules += diff.added;
                removedFibRules += diff.removed;
                modifiedFibRules += diff.modified;
            }
        }
        applied = true;
    }

    public void rollback() {
        if (!applied) return;
        for (Key key : affected) {
            NDDRouter router = routers.get(key.router);
            router.getGlobalRib().removePrefix(key.prefix);
            if (oldRibs.get(key) != null) {
                router.getGlobalRib().attachPrefix(key.prefix, oldRibs.get(key));
            }
            if (changedFibPrefixes.contains(key)) {
                releaseFib(router.getFib().remove(key.prefix));
                if (oldFibs.get(key) != null) {
                    router.getFib().insert(key.prefix, oldFibs.get(key));
                }
            }
        }
        releaseRoutes(ownedGlobalRoutes);
        ownedGlobalRoutes.clear();
        applied = false;
    }

    public void commit() {
        if (!applied) return;
        for (Key key : changedFibPrefixes) {
            releaseFib(oldFibs.get(key));
        }
        releaseOspfRoutes(oldRibs.values());
        oldRibs.clear();
        oldFibs.clear();
        committed = true;
        applied = false;
    }

    public int getAffectedPrefixCount() { return affected.size(); }
    public int getChangedFibPrefixCount() { return changedFibPrefixes.size(); }
    public Set<String> getChangedFibRouters() {
        Set<String> changed = new HashSet<>();
        for (Key key : changedFibPrefixes) changed.add(key.router);
        return Collections.unmodifiableSet(changed);
    }
    public int getChangedFibRules() {
        return addedFibRules + removedFibRules + modifiedFibRules;
    }
    public int getAddedFibRules() { return addedFibRules; }
    public int getRemovedFibRules() { return removedFibRules; }
    public int getModifiedFibRules() { return modifiedFibRules; }
    public int getEliminatedFibPrefixes() { return eliminatedFibPrefixes; }

    @Override
    public void close() {
        if (!committed) rollback();
    }

    private static void releaseFib(NDDSortedMultiList fib) {
        if (fib == null) return;
        Set<NDDForwardingRule> released = Collections.newSetFromMap(
                new IdentityHashMap<>());
        for (NDDSortedMultiListItem item : fib.flat()) {
            NDDForwardingRule rule = (NDDForwardingRule) item;
            if (released.add(rule)) rule.releaseNddOwnership();
        }
    }

    private NDDSortedMultiList rebuildGlobalPrefix(NDDRouter router,
            Prefix prefix, NDDSortedMultiList oldGlobal) {
        NDDSortedMultiList candidates = new NDDSortedMultiList();
        if (oldGlobal != null) {
            for (NDDSortedMultiListItem item : oldGlobal.flat()) {
                if (!(item instanceof NDDOspfRoute)) candidates.insert(item);
            }
        }
        for (NDDOspfProcess process : router.getOspfProcesses().values()) {
            NDDSortedMultiList routes = process.getRib().getRib().get(prefix);
            if (routes != null) {
                for (NDDSortedMultiListItem item : routes.flat()) {
                    NDDOspfRoute copy = ((NDDOspfRoute) item).detachedCopy();
                    ownedGlobalRoutes.add(copy);
                    candidates.insert(copy);
                }
            }
        }
        if (candidates.isEmpty()) return null;
        NDDController.bddManager.getBDDTCWrapper().calTC(candidates, router.ecmp());
        candidates.cleanDead();
        Set<NDDOspfRoute> retained = Collections.newSetFromMap(
                new IdentityHashMap<>());
        for (NDDSortedMultiListItem item : candidates.flat()) {
            if (item instanceof NDDOspfRoute) retained.add((NDDOspfRoute) item);
        }
        Set<NDDOspfRoute> discarded = Collections.newSetFromMap(
                new IdentityHashMap<>());
        for (NDDOspfRoute route : ownedGlobalRoutes) {
            if (!retained.contains(route) && route.getPrefix().equals(prefix)) {
                discarded.add(route);
            }
        }
        releaseRoutes(discarded);
        ownedGlobalRoutes.removeAll(discarded);
        return candidates;
    }

    private static void releaseRoutes(Iterable<NDDOspfRoute> routes) {
        for (NDDOspfRoute route : routes) route.releaseNddOwnership();
    }

    private static void releaseOspfRoutes(Iterable<NDDSortedMultiList> ribs) {
        Set<NDDOspfRoute> released = Collections.newSetFromMap(
                new IdentityHashMap<>());
        for (NDDSortedMultiList rib : ribs) {
            if (rib == null) continue;
            for (NDDSortedMultiListItem item : rib.flat()) {
                if (item instanceof NDDOspfRoute) {
                    NDDOspfRoute route = (NDDOspfRoute) item;
                    if (released.add(route)) route.releaseNddOwnership();
                }
            }
        }
    }

    private static NDDSortedMultiList buildFib(NDDRouter router, Prefix prefix,
            NDDSortedMultiList global) {
        if (global == null || global.isEmpty()) return null;
        NDDRib onePrefix = new NDDRib();
        onePrefix.insert(prefix, global);
        NDDFib target = router.getFib();
        onePrefix.install(target);
        return target.getFib().get(prefix);
    }

    private static RuleDiff diffRules(NDDSortedMultiList older,
            NDDSortedMultiList newer) {
        Map<String, List<RuleState>> oldStates = rules(older);
        Map<String, List<RuleState>> newStates = rules(newer);
        Set<String> keys = new HashSet<>(oldStates.keySet());
        keys.addAll(newStates.keySet());
        int added = 0;
        int removed = 0;
        int modified = 0;
        for (String key : keys) {
            List<RuleState> left = oldStates.getOrDefault(key,
                    Collections.emptyList());
            List<RuleState> right = newStates.getOrDefault(key,
                    Collections.emptyList());
            boolean[] matched = new boolean[right.size()];
            int exact = 0;
            for (RuleState oldState : left) {
                for (int index = 0; index < right.size(); index++) {
                    if (!matched[index] && oldState.equivalent(right.get(index))) {
                        matched[index] = true;
                        exact++;
                        break;
                    }
                }
            }
            int oldUnmatched = left.size() - exact;
            int newUnmatched = right.size() - exact;
            int changedPairs = Math.min(oldUnmatched, newUnmatched);
            modified += changedPairs;
            removed += oldUnmatched - changedPairs;
            added += newUnmatched - changedPairs;
        }
        return new RuleDiff(added, removed, modified);
    }

    private static Map<String, List<RuleState>> rules(NDDSortedMultiList list) {
        Map<String, List<RuleState>> states = new HashMap<>();
        if (list == null) return states;
        for (int group = 0; group < list.size(); group++) {
            for (NDDSortedMultiListItem item : list.get(group)) {
                NDDForwardingRule rule = (NDDForwardingRule) item;
                String key = rule.getPrefix() + "|" + rule.getNextHop()
                        + "|" + rule.getOutPort();
                states.computeIfAbsent(key, ignored -> new ArrayList<>())
                        .add(new RuleState(group, rule.getArriveTC(), rule.getListTC()));
            }
        }
        return states;
    }

    private static boolean equivalent(int left, int right) {
        return left == right || (NDD.isFalse(NDD.diff(left, right))
                && NDD.isFalse(NDD.diff(right, left)));
    }

    private static final class RuleState {
        private final int group;
        private final int arrive;
        private final int list;

        private RuleState(int group, int arrive, int list) {
            this.group = group;
            this.arrive = arrive;
            this.list = list;
        }

        private boolean equivalent(RuleState other) {
            return group == other.group
                    && AffectedPrefixRibFibTransaction.equivalent(
                            arrive, other.arrive)
                    && AffectedPrefixRibFibTransaction.equivalent(
                            list, other.list);
        }
    }

    private static final class RuleDiff {
        private final int added;
        private final int removed;
        private final int modified;

        private RuleDiff(int added, int removed, int modified) {
            this.added = added;
            this.removed = removed;
            this.modified = modified;
        }

        private int changed() { return added + removed + modified; }
    }

    private static final class Key implements Comparable<Key> {
        private final String router;
        private final Prefix prefix;

        private Key(String router, Prefix prefix) {
            this.router = router;
            this.prefix = prefix;
        }

        @Override
        public int compareTo(Key other) {
            int byRouter = router.compareTo(other.router);
            return byRouter != 0 ? byRouter : prefix.compareTo(other.prefix);
        }

        @Override
        public boolean equals(Object object) {
            if (!(object instanceof Key)) return false;
            Key other = (Key) object;
            return router.equals(other.router) && prefix.equals(other.prefix);
        }

        @Override
        public int hashCode() { return Objects.hash(router, prefix); }
    }
}
