package application.differential.s0;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.network.PortName;
import controlplane.process.ospf.NDDOspfEdge;
import controlplane.process.ospf.NDDOspfNeighborConfig;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.process.ospf.NDDOspfTopology;

import java.util.Map;
import java.util.Objects;

/** Immutable, reversible identity for one directed OSPF interface-cost update. */
public final class OspfCostUpdate {
    public enum Direction { LOCAL_INTERFACE }

    private final String id;
    private final int sequence;
    private final String snapshotId;
    private final String router;
    private final int processId;
    private final String interfaceName;
    private final String peerRouter;
    private final Direction direction;
    private final int oldCost;
    private final int newCost;

    @JsonCreator
    public OspfCostUpdate(
            @JsonProperty("id") String id,
            @JsonProperty("sequence") int sequence,
            @JsonProperty("snapshotId") String snapshotId,
            @JsonProperty("router") String router,
            @JsonProperty("processId") int processId,
            @JsonProperty("interfaceName") String interfaceName,
            @JsonProperty("peerRouter") String peerRouter,
            @JsonProperty("direction") Direction direction,
            @JsonProperty("oldCost") int oldCost,
            @JsonProperty("newCost") int newCost) {
        this.id = require("id", id);
        if (sequence < 0) throw new IllegalArgumentException("sequence must be non-negative");
        this.sequence = sequence;
        this.snapshotId = require("snapshotId", snapshotId);
        this.router = require("router", router);
        if (processId < 0) throw new IllegalArgumentException("processId must be non-negative");
        this.processId = processId;
        this.interfaceName = require("interfaceName", interfaceName);
        this.peerRouter = require("peerRouter", peerRouter);
        this.direction = Objects.requireNonNull(direction, "direction");
        if (oldCost <= 0 || newCost <= 0 || oldCost == newCost) {
            throw new IllegalArgumentException("OSPF costs must be positive and different");
        }
        this.oldCost = oldCost;
        this.newCost = newCost;
    }

    public OspfCostUpdate reverse() {
        return new OspfCostUpdate(id, sequence, snapshotId, router, processId,
                interfaceName, peerRouter, direction, newCost, oldCost);
    }

    @JsonIgnore
    public boolean isCostIncrease() { return newCost > oldCost; }

    public Bound bind(Map<String, NDDRouter> routers, NDDOspfTopology topology) {
        if (routers == null || topology == null) {
            throw new IllegalArgumentException("routers and topology are required");
        }
        NDDRouter boundRouter = routers.get(router);
        if (boundRouter == null) throw new IllegalArgumentException("unknown router: " + router);
        NDDOspfProcess process = boundRouter.getOspfProcess(processId);
        if (process == null) throw new IllegalArgumentException(
                "unknown OSPF process: " + router + ":" + processId);
        NDDPort port = boundRouter.getPorts().get(new PortName(router, interfaceName));
        if (port == null) throw new IllegalArgumentException(
                "unknown interface: " + router + ":" + interfaceName);
        NDDOspfNeighborConfig config = topology.getNeighborConfig(process, port);
        if (config == null) throw new IllegalArgumentException(
                "OSPF interface is not bound to process: " + canonicalTarget());

        NDDOspfEdge matched = null;
        for (Map.Entry<NDDOspfProcess, NDDOspfEdge> entry
                : topology.getEdges().row(process).entrySet()) {
            NDDOspfEdge edge = entry.getValue();
            if (edge.getSrc() != config) continue;
            if (!peerRouter.equals(entry.getKey().getRouter().getRouterName())) continue;
            if (matched != null) throw new IllegalArgumentException(
                    "ambiguous active OSPF adjacency: " + canonicalTarget());
            matched = edge;
        }
        if (matched == null) throw new IllegalArgumentException(
                "active OSPF peer not found: " + canonicalTarget());
        int modelCost = config.getIntfSetting().getCost();
        if (modelCost != oldCost) {
            throw new IllegalStateException("OSPF old-value mismatch for "
                    + canonicalTarget() + ": model=" + modelCost + ", event=" + oldCost);
        }
        return new Bound(this, config);
    }

    public String canonicalTarget() {
        return router + "|ospf:" + processId + "|" + interfaceName + "|"
                + peerRouter + "|" + direction;
    }

    public String getId() { return id; }
    public int getSequence() { return sequence; }
    public String getSnapshotId() { return snapshotId; }
    public String getRouter() { return router; }
    public int getProcessId() { return processId; }
    public String getInterfaceName() { return interfaceName; }
    public String getPeerRouter() { return peerRouter; }
    public Direction getDirection() { return direction; }
    public int getOldCost() { return oldCost; }
    public int getNewCost() { return newCost; }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (!(object instanceof OspfCostUpdate)) return false;
        OspfCostUpdate other = (OspfCostUpdate) object;
        return sequence == other.sequence && processId == other.processId
                && oldCost == other.oldCost && newCost == other.newCost
                && id.equals(other.id) && snapshotId.equals(other.snapshotId)
                && router.equals(other.router) && interfaceName.equals(other.interfaceName)
                && peerRouter.equals(other.peerRouter) && direction == other.direction;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, sequence, snapshotId, router, processId,
                interfaceName, peerRouter, direction, oldCost, newCost);
    }

    private static String require(String name, String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(name + " must not be empty");
        }
        return value;
    }

    /** Prepared binding. Applying and closing it is exactly reversible. */
    public static final class Bound implements AutoCloseable {
        private final OspfCostUpdate update;
        private final NDDOspfNeighborConfig config;
        private boolean applied;
        private boolean committed;

        private Bound(OspfCostUpdate update, NDDOspfNeighborConfig config) {
            this.update = update;
            this.config = config;
        }

        public OspfCostUpdate getUpdate() { return update; }
        public boolean isApplied() { return applied; }

        public void apply() {
            if (committed) throw new IllegalStateException("binding is committed");
            if (applied) return;
            if (config.getIntfSetting().getCost() != update.oldCost) {
                throw new IllegalStateException("OSPF old-value changed after bind");
            }
            config.getIntfSetting().setCost(update.newCost);
            applied = true;
        }

        public void rollback() {
            if (!applied || committed) return;
            config.getIntfSetting().setCost(update.oldCost);
            applied = false;
        }

        public void commit() {
            if (!applied) throw new IllegalStateException("cannot commit before apply");
            committed = true;
            applied = false;
        }

        @Override public void close() { rollback(); }
    }
}
