package application.netdice;

import bdd.BDDManager;
import bdd.BDDTuple;
import com.google.gson.stream.JsonWriter;
import controlplane.network.Router;
import controlplane.network.State;
import datamodel.failure.FailureModel;
import datamodel.failure.link.LinkFailureModelBigDecimal;
import datamodel.failure.link.LinkFailureModelDouble;
import datamodel.failure.node.NodeFailureModel;
import datamodel.failure.node.NodeFailureModelBigDecimal;
import datamodel.failure.node.NodeFailureModelDouble;
import datamodel.ipv4.Header;
import datamodel.probability.BigDecimalProbImpl;
import datamodel.probability.DoubleProbImpl;
import datamodel.probability.Probability;
import datamodel.property.Flow;
import datamodel.property.Property;
import datamodel.property.Reachability;
import datamodel.property.Waypoint;
import dataplane.analysis.DPAnalyzer;
import main.Configuration;
import main.Controller;
import main.SRELogger;
import main.storage.Storage;
import util.MemorizeUtil;
import util.TimeUtil;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

public class Netdice {
    public static String failure;

    FailureModel _failureModel;
    Probability _precision;
    public void setupFailureModel(boolean link, boolean doub) {
        if (link) {
            Configuration.FILTER = false;
            failure = "link";
            if (doub) {
                _failureModel = new LinkFailureModelDouble("0.001");
            }
            else {
                _failureModel = new LinkFailureModelBigDecimal("0.001");
            }
        }
        else {
            Configuration.FILTER = true;
            failure = "node";
            if (doub) {
                _failureModel = new NodeFailureModelDouble("0.001", "0.0001");
            }
            else {
                _failureModel = new NodeFailureModelBigDecimal("0.001", "0.0001");
            }
        }
        if (doub) {
            _precision = new DoubleProbImpl("0.0001");
        }
        else {
            _precision = new BigDecimalProbImpl("0.0001");
        }
    }

    NetdiceUtil _util;
    public long setupCPExecutor(Path inputBase) {
        long start = System.nanoTime();
        _util = new NetdiceUtil(inputBase);
        _util.init();
        Controller.pushCPExecutor(_util._cpExecutor);
        long end = System.nanoTime();
        return end - start;
    }

    public void getValidRouters() {
        Controller.ospfValidRouters = new HashSet<>();
        Controller.ospfValidRouters.addAll(_util._brs);
        Controller.ospfValidRouters.addAll(_util._rrs);
        Controller.bgpValidRouters = new HashSet<>();
        Controller.bgpValidRouters.addAll(_util._ers);
    }

    public long setupBDDManager() {
        long start = System.nanoTime();
        /* Init failure model */
        _failureModel.initForTopology(_util._l3Topology);

        /* Get MF according to 1) the number of symbolic links; and 2) target precision */
        int n = (int) Controller.cpExecutor.getL3Edges().stream().filter(e -> e.getState() == State.SYMBOLIC).count();
        int MF = _failureModel.getK(n, _precision);
        Controller.pushMF(MF);

        /* Get valid routers */
        getValidRouters();

        /* Set up BDDManager */
        BDDManager manager = new BDDManager();
        Controller.pushBDDManager(manager);
        long end = System.nanoTime();
        return end - start;
    }

    public long src() {
        long start = System.nanoTime();
        Controller.cpExecutor.generateDataPlane();
        long end = System.nanoTime();
        return end - start;
    }

    BDDTuple _tuple;
    public void prepareDPA() {
        /* Set up DPAnalyzer */
        Controller.pushDPAnalyzer(new DPAnalyzer());
        int dst = Controller.bddManager.getBDDACLWrapper().encodeDstIPPrefix(_util._extAnn.getIp().asLong(), _util._extAnn.getPreLength());
        _tuple = new BDDTuple(dst, dst);
    }

    /* Get and check properties (all pair reachability/waypoint) */
    Vector<Property> _properties;
    public void checkWaypoints() {
        HashSet<Router> hs = new HashSet<>(_util._irs);
        hs.addAll(_util._rrs);
        hs.remove(_util._pr);
        List<Router> routers = hs
                .stream()
                .sorted(Comparator.comparing(router -> Integer.valueOf(router.getRouterName())))
                .collect(Collectors.toList());
        _properties = new Vector<>();
        for (Router router : routers) {
            Header header = new Header.HeaderBuilder().setDestination(_util._extAnn).build();
            Waypoint waypoint = new Waypoint(new Flow(header, router.getRouterName()), _util._pr.getRouterName());
            _properties.add(waypoint);
            t3 += spf(router);
            t4 += fpa(waypoint);
            if ((System.nanoTime() - start) / 1e9 > Configuration.TIMEOUT_SECONDS) break;
        }
    }

    public void checkReachabilities() {
        HashSet<Router> hs = new HashSet<>(_util._irs);
        hs.addAll(_util._rrs);
        List<Router> routers = hs
                .stream()
                .sorted(Comparator.comparing(router -> Integer.valueOf(router.getRouterName())))
                .collect(Collectors.toList());
        _properties = new Vector<>();
        for (Router router : routers) {
            Header header = new Header.HeaderBuilder().setDestination(_util._extAnn).build();
            Reachability reachability = new Reachability(new Flow(header, router.getRouterName()));
            _properties.add(reachability);
            t3 += spf(router);
            t4 += fpa(reachability);
            if ((System.nanoTime() - start) / 1e9 > Configuration.TIMEOUT_SECONDS) break;
        }
    }

    public long spf(Router router) {
        long start = System.nanoTime();
        Controller.dpAnalyzer._reachabilityDB.buildReachabilityTreeLazy(router, _tuple);
        long end = System.nanoTime();
        return end - start;
    }

    public long fpa(Property property) {
        long start = System.nanoTime();
        Controller.dpAnalyzer._propertyChecker.checkProperty(property);
        property.setProbability(_failureModel.calProbability(property.getTC()));
        property.setImprecision(_failureModel.getImprecision());
        long end = System.nanoTime();
        return end - start;
    }

    long start;
    double t0, t1, t2, t3, t4, singleT, totalT;
    public void run(Path inputBase, String propertyType, String failureModel) {
        start = System.nanoTime();
        TimeUtil timer = new TimeUtil();
        timer.begin();

        setupFailureModel(failureModel.equalsIgnoreCase("link"), true);
        t0 = setupCPExecutor(inputBase) / 1e9;
        t1 = setupBDDManager() / 1e9;
        t2 = src() / 1e9;

        System.out.print(t0 + "\t" + t1 + "\t" + t2 + "\t");

        prepareDPA();
        if (propertyType.equals("waypoint")) checkWaypoints();
        else if (propertyType.equals("reachability")) checkReachabilities();
        t3 = t3 / 1e9;
        t4 = t4 / 1e9;
        singleT = t0 + t1 + t2 + (t3 + t4) / _properties.size();
        totalT = t0 + t1 + t2 + t3 + t4;

        timer.end(SRELogger.LEVEL.INFO, "mf: "+ Controller.MF + " finished");
        System.out.print(t3 + "\t" + t4 + "\t" + singleT + "\t" + totalT + "\t");
        System.out.print(Controller.bddManager.getBDDTCWrapper().getAllSatMemoHit());

        printResult(timer, propertyType, inputBase);
//        printBN(util, inputBase, propertyType, manager, n);
    }

    public void printResult(TimeUtil timer, String propertyType, Path inputBase) {
        /* Output results */
        NetdiceUtil.PVResult result = new NetdiceUtil.PVResult(timer.getTotal(), _properties);
//        result.toFile(Controller.storage._prob.resolve(type + ".json"));
        result.toFile(Paths.get("output")
                .resolve("probabilistic")
                .resolve(failure)
                .resolve(propertyType)
                .resolve(Storage.TODAY)
                .resolve(inputBase.getFileName().toString() + ".json"));
    }

    public void printBN(NetdiceUtil util, Path inputBase, String propertyType, BDDManager manager, int n) {
        try {
            File topo = Paths.get("output")
                    .resolve("probabilistic")
                    .resolve("bn")
                    .resolve(propertyType)
                    .resolve(inputBase.getFileName().toString() + "_topo.json")
                    .toFile();
            if (!topo.exists()) MemorizeUtil.creatFileIfAbsent(topo);
            JsonWriter topoWriter = new JsonWriter(new FileWriter(topo));
            topoWriter.setIndent("    ");
            topoWriter.beginObject();
            topoWriter.name("nof_nodes");
            topoWriter.value(util._brs.size() + util._rrs.size() + util._irs.size());
            topoWriter.name("links");
            topoWriter.beginArray();
            for (int i = 0; i < n; i++) {
                topoWriter.beginArray();
                topoWriter.value(manager.getBDDTCWrapper().getLink(i).getSrc().getRouterName());
                topoWriter.value(manager.getBDDTCWrapper().getLink(i).getDst().getRouterName());
                topoWriter.endArray();
            }
            topoWriter.endArray();
            topoWriter.endObject();
            topoWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            File bn = Paths.get("output")
                    .resolve("probabilistic")
                    .resolve("bn")
                    .resolve(propertyType)
                    .resolve(inputBase.getFileName().toString() + "_bn.json")
                    .toFile();
            if (!bn.exists()) MemorizeUtil.creatFileIfAbsent(bn);
            JsonWriter bnWriter = new JsonWriter(new FileWriter(bn));
            bnWriter.setIndent("    ");
            bnWriter.beginObject();
            bnWriter.name("bn");
            bnWriter.beginArray();
            for (int i = 0; i < NodeFailureModel.states.size(); i++) {
                bnWriter.beginObject();
                bnWriter.name("state");
                bnWriter.beginArray();
                for (byte b : NodeFailureModel.states.get(i)) bnWriter.value(b);
                bnWriter.endArray();
                bnWriter.name("probability");
                bnWriter.value(NodeFailureModel.probs.get(i));
                bnWriter.name("time");
                bnWriter.value(NodeFailureModel.times.get(i));
                bnWriter.endObject();
            }
            bnWriter.endArray();
            bnWriter.endObject();
            bnWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Path inputBase = Paths.get(args[0]);
        Controller.pushStorage(new Storage(inputBase, null));

        System.out.print(inputBase.getFileName().toString() + "\t");

        Netdice netdice = new Netdice();
        netdice.run(inputBase, args[1], args[2]);

        System.out.print("\n");
    }
}
