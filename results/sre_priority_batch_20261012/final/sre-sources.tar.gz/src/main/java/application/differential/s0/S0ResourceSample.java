package application.differential.s0;

import sre.ndd.NDD;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Best-effort per-stage live resource counters for the S0 profiler. */
public final class S0ResourceSample {
    private final long nddNodes;
    private final long labelNodes;
    private final long heapUsedBytes;
    private final long rssBytes;

    private S0ResourceSample(long nddNodes, long labelNodes,
            long heapUsedBytes, long rssBytes) {
        this.nddNodes = nddNodes;
        this.labelNodes = labelNodes;
        this.heapUsedBytes = heapUsedBytes;
        this.rssBytes = rssBytes;
    }

    public static S0ResourceSample capture() {
        Runtime runtime = Runtime.getRuntime();
        long heapUsed = runtime.totalMemory() - runtime.freeMemory();
        return new S0ResourceSample(NDD.getNodeCount(), NDD.getLabelNodeCount(),
                heapUsed, readLinuxRss());
    }

    private static long readLinuxRss() {
        Path status = Paths.get("/proc/self/status");
        if (!Files.isRegularFile(status)) return -1;
        try {
            for (String line : Files.readAllLines(status)) {
                if (!line.startsWith("VmRSS:")) continue;
                String[] fields = line.trim().split("\\s+");
                if (fields.length >= 2) return Long.parseLong(fields[1]) * 1024L;
            }
        } catch (IOException | NumberFormatException ignored) {
            // Resource telemetry must never change oracle execution semantics.
        }
        return -1;
    }

    public long getNddNodes() { return nddNodes; }
    public long getLabelNodes() { return labelNodes; }
    public long getHeapUsedBytes() { return heapUsedBytes; }
    public long getRssBytes() { return rssBytes; }
}
