package application.config2spec;

import bdd.NDDManager;
import controlplane.network.NDDCPExecutor;
import controlplane.network.NDDRouter;
import dataplane.analysis.NDDDPAnalyzer;
import main.Configuration;
import main.NDDController;
import main.SRELogger;
import main.storage.Storage;
import org.jgrapht.Graph;
import util.TimeUtil;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;

public class NDDOnePairReach {

    public static void run(Path inputBase, int mf, String source, String destination) {
        Configuration.FILTER = false;
        Configuration.SORT_METHOD = Configuration.LinkVarSortMethod.PROPAGATION;

        TimeUtil timer = new TimeUtil();
        timer.begin();

        /* Set up Storage */
        Path outputBase = inputBase.resolve("single_property_out").resolve(Storage.TODAY).resolve(source + "_" + destination);
        NDDController.pushStorage(new Storage(inputBase, outputBase));

        /* Set up CPExecutor */
        NDDCPExecutor cpExecutor = new NDDCPExecutor();
        NDDController.pushCPExecutor(cpExecutor);
        NDDController.cpExecutor.init();

        /* Set MF */
        NDDController.pushMF(mf);

        NDDRouter src = cpExecutor.getRouters().get(source);
        NDDRouter dst = cpExecutor.getRouters().get(destination);

        boolean valid = NDDController.cpExecutor.getL3Topology().getKEdgeComponent(mf + 1)
                .stream()
                .map(Graph::vertexSet)
                .filter(set -> set.size() > 1)
                .anyMatch(set -> set.contains(src));

        if (valid) {
            /* Set up BDDManager */
            NDDController.ospfValidRouters.add(dst);
            NDDController.bgpValidRouters.add(dst);
            NDDController.pushBDDManager(new NDDManager());

            /* SRC */
            NDDController.generateDataPlane();

            /* Set up DPAnalyzer */
            NDDController.pushDPAnalyzer(new NDDDPAnalyzer());

            /* SPF */
            HashSet<NDDRouter> hs = new HashSet<>();
            hs.add(src);
            NDDController.analyzeDataPlane(hs);

            /* Mine */
            NDDController.mineSpecification(null);
        }
        else {
            System.out.print(0 + "\t" + 0 + "\t");
        }

        timer.end(SRELogger.LEVEL.INFO, "mf: "+ mf + " finished");
    }

    public static void main(String[] args) {
        long start = System.nanoTime();

        Path inputBase = Paths.get(args[0]);
        int mf = Integer.parseInt(args[1]);
        String source = args[2];
        String destination = args[3];

        System.out.print(inputBase.getFileName().toString() + "\t" + mf + "\t" + source + "\t" + destination + "\t");
        NDDOnePairReach.run(inputBase, mf, source, destination);
        System.out.print((System.nanoTime() - start) / 1e9 + "\n");
    }
}
