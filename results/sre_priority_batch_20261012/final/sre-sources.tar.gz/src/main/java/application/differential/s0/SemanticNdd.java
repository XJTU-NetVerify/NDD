package application.differential.s0;

import sre.ndd.NDD;

/** Exact NDD helpers. Raw handle equality is only a fast path. */
final class SemanticNdd {
    private SemanticNdd() { }

    static int retain(int root) {
        return NDD.ref(root);
    }

    static void release(int root) {
        NDD.deref(root);
    }

    static boolean equivalent(int left, int right) {
        return left == right || (NDD.isFalse(NDD.diff(left, right))
                && NDD.isFalse(NDD.diff(right, left)));
    }
}
