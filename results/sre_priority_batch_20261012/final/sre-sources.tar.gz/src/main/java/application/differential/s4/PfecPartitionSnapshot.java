package application.differential.s4;

import controlplane.network.NDDRouter;
import dataplane.analysis.NDDReachabilityDB;
import dataplane.analysis.NDDReachabilityNode;
import multimap.Table;
import sre.ndd.NDD;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/** Owned canonical path/PFEC partition grouped by source and destination. */
public final class PfecPartitionSnapshot implements AutoCloseable {
    private final Map<PairKey, Map<String, Integer>> states = new LinkedHashMap<>();
    private boolean closed;

    public static PfecPartitionSnapshot capture(NDDReachabilityDB database,
            Collection<String> sourceNames) {
        Set<String> sources = new HashSet<>(sourceNames);
        PfecPartitionSnapshot snapshot = new PfecPartitionSnapshot();
        Map<PairKey, Map<String, Integer>> raw = new LinkedHashMap<>();
        for (Table.Cell<NDDRouter, NDDRouter,
                java.util.HashSet<NDDReachabilityNode>> cell
                : database.reachabilityForest.cellSet()) {
            NDDRouter source = cell.getRowKey();
            NDDRouter destination = cell.getColumnKey();
            if (!sources.contains(source.getRouterName())) continue;
            PairKey pair = new PairKey(source.getRouterName(),
                    destination.getRouterName());
            for (NDDReachabilityNode node : cell.getValue()) {
                String behavior = behavior(node);
                int region = NDD.ref(NDD.and(node.getTuple().getFirst(),
                        node.getTuple().getSecond()));
                merge(raw.computeIfAbsent(pair, ignored -> new LinkedHashMap<>()),
                        behavior, region);
            }
        }
        raw.forEach(snapshot::canonicalize);
        raw.values().forEach(map -> map.values().forEach(NDD::deref));
        return snapshot;
    }

    public boolean isDisjoint() {
        for (Map<String, Integer> pair : states.values()) {
            List<Integer> regions = new ArrayList<>(pair.values());
            for (int left = 0; left < regions.size(); left++) {
                for (int right = left + 1; right < regions.size(); right++) {
                    if (!NDD.isFalse(NDD.and(
                            regions.get(left), regions.get(right)))) return false;
                }
            }
        }
        return true;
    }

    public boolean semanticallyEquivalent(PfecPartitionSnapshot other) {
        Set<PairKey> pairs = new HashSet<>(states.keySet());
        pairs.addAll(other.states.keySet());
        for (PairKey pair : pairs) {
            Map<String, Integer> left = states.getOrDefault(pair,
                    Collections.emptyMap());
            Map<String, Integer> right = other.states.getOrDefault(pair,
                    Collections.emptyMap());
            if (!left.keySet().equals(right.keySet())) return false;
            for (String behavior : left.keySet()) {
                if (!equivalent(left.get(behavior), right.get(behavior))) return false;
            }
        }
        return true;
    }

    public boolean coverageEquivalent(PfecPartitionSnapshot other) {
        Set<PairKey> pairs = new HashSet<>(states.keySet());
        pairs.addAll(other.states.keySet());
        for (PairKey pair : pairs) {
            int left = coverage(pair);
            int right = other.coverage(pair);
            boolean exact = equivalent(left, right);
            NDD.deref(left);
            NDD.deref(right);
            if (!exact) return false;
        }
        return true;
    }

    public Delta diff(PfecPartitionSnapshot newer) {
        int added = 0;
        int removed = 0;
        int modified = 0;
        int splits = 0;
        int merges = 0;
        Set<PairKey> pairs = new HashSet<>(states.keySet());
        pairs.addAll(newer.states.keySet());
        for (PairKey pair : pairs) {
            Map<String, Integer> oldStates = states.getOrDefault(pair,
                    Collections.emptyMap());
            Map<String, Integer> newStates = newer.states.getOrDefault(pair,
                    Collections.emptyMap());
            Set<String> behaviors = new HashSet<>(oldStates.keySet());
            behaviors.addAll(newStates.keySet());
            for (String behavior : behaviors) {
                Integer oldRegion = oldStates.get(behavior);
                Integer newRegion = newStates.get(behavior);
                if (oldRegion == null) added++;
                else if (newRegion == null) removed++;
                else if (!equivalent(oldRegion, newRegion)) modified++;
            }
            for (int oldRegion : oldStates.values()) {
                if (overlapCount(oldRegion, newStates.values()) > 1) splits++;
            }
            for (int newRegion : newStates.values()) {
                if (overlapCount(newRegion, oldStates.values()) > 1) merges++;
            }
        }
        return new Delta(added, removed, modified, splits, merges);
    }

    public CoverageDelta coverageDelta(PfecPartitionSnapshot newer) {
        Map<PairKey, Integer> changed = new LinkedHashMap<>();
        Set<PairKey> pairs = new HashSet<>(states.keySet());
        pairs.addAll(newer.states.keySet());
        for (PairKey pair : pairs) {
            int oldCoverage = coverage(pair);
            int newCoverage = newer.coverage(pair);
            int region = symmetricDifference(oldCoverage, newCoverage);
            NDD.deref(oldCoverage);
            NDD.deref(newCoverage);
            if (NDD.isFalse(region)) NDD.deref(region);
            else changed.put(pair, region);
        }
        return new CoverageDelta(changed);
    }

    public int coverage(PairKey pair) {
        int result = NDD.getFalse();
        for (int region : states.getOrDefault(pair,
                Collections.emptyMap()).values()) {
            int merged = NDD.ref(NDD.or(result, region));
            NDD.deref(result);
            result = merged;
        }
        return result;
    }

    public Set<PairKey> getPairs() {
        return Collections.unmodifiableSet(states.keySet());
    }

    public int getStateCount() {
        return states.values().stream().mapToInt(Map::size).sum();
    }

    private void canonicalize(PairKey pair, Map<String, Integer> raw) {
        List<Atom> atoms = new ArrayList<>();
        for (Map.Entry<String, Integer> behavior : raw.entrySet()) {
            int remaining = NDD.ref(behavior.getValue());
            List<Atom> next = new ArrayList<>();
            for (Atom atom : atoms) {
                int overlap = NDD.ref(NDD.and(atom.region, behavior.getValue()));
                if (NDD.isFalse(overlap)) {
                    NDD.deref(overlap);
                    next.add(atom);
                    continue;
                }
                int oldOnly = NDD.ref(NDD.diff(atom.region, behavior.getValue()));
                if (!NDD.isFalse(oldOnly)) next.add(new Atom(atom.behaviors, oldOnly));
                else NDD.deref(oldOnly);
                Set<String> combined = new java.util.TreeSet<>(atom.behaviors);
                combined.add(behavior.getKey());
                next.add(new Atom(combined, overlap));
                int newRemaining = NDD.ref(NDD.diff(remaining, atom.region));
                NDD.deref(remaining);
                remaining = newRemaining;
                NDD.deref(atom.region);
            }
            if (!NDD.isFalse(remaining)) {
                next.add(new Atom(Collections.singleton(behavior.getKey()), remaining));
            } else {
                NDD.deref(remaining);
            }
            atoms = next;
        }
        Map<String, Integer> canonical = states.computeIfAbsent(pair,
                ignored -> new LinkedHashMap<>());
        for (Atom atom : atoms) {
            merge(canonical, String.join("&&", atom.behaviors), atom.region);
        }
    }

    private static void merge(Map<String, Integer> byBehavior,
            String behavior, int ownedRegion) {
        Integer previous = byBehavior.putIfAbsent(behavior, ownedRegion);
        if (previous == null) return;
        int merged = NDD.ref(NDD.or(previous, ownedRegion));
        NDD.deref(previous);
        NDD.deref(ownedRegion);
        byBehavior.put(behavior, merged);
    }

    private static final class Atom {
        private final Set<String> behaviors;
        private final int region;

        private Atom(Collection<String> behaviors, int region) {
            this.behaviors = new java.util.TreeSet<>(behaviors);
            this.region = region;
        }
    }

    private static String behavior(NDDReachabilityNode node) {
        String path = node.getPath().stream().map(NDDRouter::getRouterName)
                .collect(Collectors.joining(">"));
        return (node.getOutPort() == null ? "NONE"
                : node.getOutPort().getPortName().toString())
                + "|" + path + "|loop=" + node.isLoopDetected();
    }

    private static int overlapCount(int region, Collection<Integer> candidates) {
        int count = 0;
        for (int candidate : candidates) {
            if (!NDD.isFalse(NDD.and(region, candidate))) count++;
        }
        return count;
    }

    private static int symmetricDifference(int left, int right) {
        int removed = NDD.ref(NDD.diff(left, right));
        int added = NDD.ref(NDD.diff(right, left));
        int result = NDD.ref(NDD.or(removed, added));
        NDD.deref(removed);
        NDD.deref(added);
        return result;
    }

    private static boolean equivalent(int left, int right) {
        return left == right || (NDD.isFalse(NDD.diff(left, right))
                && NDD.isFalse(NDD.diff(right, left)));
    }

    @Override
    public void close() {
        if (closed) return;
        states.values().forEach(map -> map.values().forEach(NDD::deref));
        closed = true;
    }

    public static final class PairKey {
        private final String source;
        private final String destination;

        public PairKey(String source, String destination) {
            this.source = source;
            this.destination = destination;
        }

        public String getSource() { return source; }
        public String getDestination() { return destination; }

        @Override
        public boolean equals(Object object) {
            if (!(object instanceof PairKey)) return false;
            PairKey other = (PairKey) object;
            return source.equals(other.source)
                    && destination.equals(other.destination);
        }

        @Override
        public int hashCode() { return Objects.hash(source, destination); }

        @Override
        public String toString() { return source + "|" + destination; }
    }

    public static final class Delta {
        private final int added;
        private final int removed;
        private final int modified;
        private final int splits;
        private final int merges;

        private Delta(int added, int removed, int modified,
                int splits, int merges) {
            this.added = added;
            this.removed = removed;
            this.modified = modified;
            this.splits = splits;
            this.merges = merges;
        }

        public int getAdded() { return added; }
        public int getRemoved() { return removed; }
        public int getModified() { return modified; }
        public int getSplits() { return splits; }
        public int getMerges() { return merges; }
        public int getChangedCount() { return added + removed + modified; }
    }

    public static final class CoverageDelta implements AutoCloseable {
        private final Map<PairKey, Integer> regions;
        private boolean closed;

        CoverageDelta(Map<PairKey, Integer> regions) {
            this.regions = regions;
        }

        public Set<PairKey> getPairs() {
            return Collections.unmodifiableSet(regions.keySet());
        }

        public int getRegion(PairKey pair) {
            return regions.getOrDefault(pair, NDD.getFalse());
        }

        @Override
        public void close() {
            if (closed) return;
            regions.values().forEach(NDD::deref);
            closed = true;
        }
    }
}
