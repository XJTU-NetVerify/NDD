package application.differential.s1;

import controlplane.network.NDDRouter;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import controlplane.route.NDDOspfRoute;
import dataplane.fib.NDDForwardingRule;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Collections;
import java.util.IdentityHashMap;

/** Affected-router global-RIB/FIB rebuild boundary for S1. */
public final class AffectedRibFibTransaction implements AutoCloseable {
    private final List<NDDRouter> routers;
    private final Map<NDDRouter, Map<Prefix, NDDSortedMultiList>> oldRibs =
            new LinkedHashMap<>();
    private final Map<NDDRouter, Map<Prefix, NDDSortedMultiList>> oldFibs =
            new LinkedHashMap<>();
    private boolean applied;

    public AffectedRibFibTransaction(Map<String, NDDRouter> allRouters,
            Set<String> affectedRouters) {
        routers = new ArrayList<>();
        for (String name : affectedRouters) {
            NDDRouter router = allRouters.get(name);
            if (router != null) routers.add(router);
        }
    }

    public void apply() {
        if (applied) return;
        for (NDDRouter router : routers) {
            oldRibs.put(router, detachRib(router));
            oldFibs.put(router, router.getFib().detachRules());
            router.installOriginalRoutesToGlobalRib();
            router.installIgpRoutesToGlobalRib();
            if (router.getBgpProcess() != null) {
                router.installBgpRoutesToGlobalRib();
            }
            router.installGlobalRibToFib();
        }
        applied = true;
    }

    public void rollback() {
        if (!applied) return;
        for (NDDRouter router : routers) {
            releaseRibs(detachRib(router));
            releaseFibs(router.getFib().detachRules());
            for (Map.Entry<Prefix, NDDSortedMultiList> entry
                    : oldRibs.get(router).entrySet()) {
                router.getGlobalRib().attachPrefix(entry.getKey(), entry.getValue());
            }
            router.getFib().attachRules(oldFibs.get(router));
        }
        applied = false;
    }

    public int getAffectedRouterCount() { return routers.size(); }

    @Override
    public void close() { rollback(); }

    private static Map<Prefix, NDDSortedMultiList> detachRib(NDDRouter router) {
        Map<Prefix, NDDSortedMultiList> detached = new LinkedHashMap<>();
        Collection<Prefix> prefixes = new ArrayList<>(
                router.getGlobalRib().getRib().keySet());
        for (Prefix prefix : prefixes) {
            detached.put(prefix, router.getGlobalRib().removePrefix(prefix));
        }
        return detached;
    }

    private static void releaseRibs(Map<Prefix, NDDSortedMultiList> ribs) {
        Set<NDDOspfRoute> released = Collections.newSetFromMap(
                new IdentityHashMap<>());
        for (NDDSortedMultiList rib : ribs.values()) {
            for (NDDSortedMultiListItem item : rib.flat()) {
                if (item instanceof NDDOspfRoute) {
                    NDDOspfRoute route = (NDDOspfRoute) item;
                    if (released.add(route)) route.releaseNddOwnership();
                }
            }
        }
    }

    private static void releaseFibs(Map<Prefix, NDDSortedMultiList> fibs) {
        Set<NDDForwardingRule> released = Collections.newSetFromMap(
                new IdentityHashMap<>());
        for (NDDSortedMultiList fib : fibs.values()) {
            for (NDDSortedMultiListItem item : fib.flat()) {
                NDDForwardingRule rule = (NDDForwardingRule) item;
                if (released.add(rule)) rule.releaseNddOwnership();
            }
        }
    }
}
