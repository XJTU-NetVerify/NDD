package application.differential.s3;

import controlplane.network.NDDRouter;
import dataplane.analysis.NDDReachabilityDB;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/** Shadow recomputation for selected SPF sources with pre-publication budgets. */
public final class AffectedSourceSpfTransaction implements AutoCloseable {
    public static final int MAX_AFFECTED_SOURCES = 8;
    public static final int MAX_STORED_NODES = 1_024;
    public static final int MAX_LOOP_PRUNES = 1_024;
    private static final String SOURCE_PROPERTY =
            "delta.sre.maxAffectedSources";
    private static final String NODE_PROPERTY = "delta.sre.maxSpfNodes";
    private static final String LOOP_PROPERTY = "delta.sre.maxLoopPrunes";

    private final List<NDDRouter> sources;
    private NDDReachabilityDB candidate;
    private String fallbackReason = "none";

    public AffectedSourceSpfTransaction(Collection<NDDRouter> sources) {
        this.sources = new ArrayList<>(sources);
        this.sources.sort((left, right) -> left.getRouterName()
                .compareTo(right.getRouterName()));
        if (this.sources.size() > maxAffectedSources()) {
            fallbackReason = "affected_source_budget";
        }
    }

    public void apply() {
        if (isFallback() || candidate != null) return;
        NDDReachabilityDB shadow = new NDDReachabilityDB();
        for (NDDRouter source : sources) shadow.buildReachabilityTree(source);
        if (shadow.getStoredNodeCount() > maxStoredNodes()) {
            fallbackReason = "spf_node_budget";
            shadow.close();
            return;
        }
        if (shadow.getLoopPrunes() > maxLoopPrunes()) {
            fallbackReason = "spf_loop_budget";
            shadow.close();
            return;
        }
        candidate = shadow;
    }

    public boolean isFallback() {
        return !"none".equals(fallbackReason);
    }

    public static int maxAffectedSources() {
        return Integer.getInteger(SOURCE_PROPERTY, MAX_AFFECTED_SOURCES);
    }

    public static int maxStoredNodes() {
        return Integer.getInteger(NODE_PROPERTY, MAX_STORED_NODES);
    }

    public static int maxLoopPrunes() {
        return Integer.getInteger(LOOP_PROPERTY, MAX_LOOP_PRUNES);
    }

    public String getFallbackReason() {
        return fallbackReason;
    }

    public List<NDDRouter> getSources() {
        return Collections.unmodifiableList(sources);
    }

    public NDDReachabilityDB getCandidate() {
        return candidate;
    }

    public int getStoredNodeCount() {
        return candidate == null ? 0 : candidate.getStoredNodeCount();
    }

    public int getLoopPrunes() {
        return candidate == null ? 0 : candidate.getLoopPrunes();
    }

    public void commitInto(NDDReachabilityDB live) {
        if (candidate == null || isFallback()) {
            throw new IllegalStateException("no SPF candidate to commit");
        }
        live.replaceSourcesFrom(candidate, sources);
    }

    @Override
    public void close() {
        if (candidate != null) candidate.close();
        candidate = null;
    }
}
