package application.differential.s5;

import java.util.HashSet;
import java.util.Set;

/** Minimal generation/commit boundary shared by incremental and full transactions. */
public final class PersistentGenerationCoordinator {
    private final Set<String> committedEvents = new HashSet<>();
    private long generation;

    public Outcome execute(String eventId, Factory incremental, Factory full) {
        if (committedEvents.contains(eventId)) {
            return new Outcome(generation, Mode.REPLAY, "already_committed");
        }
        Transaction transaction = incremental.create();
        Mode mode = Mode.INCREMENTAL;
        String reason = "none";
        if (transaction.isFallback()) {
            reason = transaction.fallbackReason();
            transaction.close();
            transaction = full.create();
            mode = Mode.FULL;
        }
        try {
            transaction.apply();
            if (mode == Mode.INCREMENTAL && transaction.isFallback()) {
                reason = transaction.fallbackReason();
                transaction.rollback();
                transaction.close();
                transaction = null;
                transaction = full.create();
                mode = Mode.FULL;
                transaction.apply();
            }
            transaction.verify();
            transaction.commit();
            generation++;
            committedEvents.add(eventId);
            return new Outcome(generation, mode, reason);
        } catch (RuntimeException exception) {
            if (transaction != null) transaction.rollback();
            throw exception;
        } finally {
            if (transaction != null) transaction.close();
        }
    }

    public long getGeneration() { return generation; }

    public enum Mode { INCREMENTAL, FULL, REPLAY }

    public interface Factory {
        Transaction create();
    }

    public interface Transaction extends AutoCloseable {
        default boolean isFallback() { return false; }
        default String fallbackReason() { return "none"; }
        void apply();
        void verify();
        void commit();
        void rollback();
        @Override void close();
    }

    public static final class Outcome {
        private final long generation;
        private final Mode mode;
        private final String fallbackReason;

        private Outcome(long generation, Mode mode, String fallbackReason) {
            this.generation = generation;
            this.mode = mode;
            this.fallbackReason = fallbackReason;
        }

        public long getGeneration() { return generation; }
        public Mode getMode() { return mode; }
        public String getFallbackReason() { return fallbackReason; }
    }
}
