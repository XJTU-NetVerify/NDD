package application.differential.s1;

import application.differential.s0.OspfCostManifest;
import application.differential.s0.OspfCostUpdate;
import application.differential.s0.S0Snapshot;
import application.differential.s2.AffectedPrefixRibFibTransaction;
import application.differential.s3.FibPortSnapshot;
import application.differential.s3.AffectedSourceSpfTransaction;
import application.differential.s3.SpfAffectedSourceProbe;
import application.differential.s3.SpfReachabilityIndex;
import application.differential.s4.PfecPartitionSnapshot;
import application.differential.s4.ReachabilityPropertySet;
import bdd.NDDManager;
import controlplane.network.NDDCPExecutor;
import controlplane.network.NDDL3Edge;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.process.ospf.NDDOspfExecutor;
import dataplane.analysis.NDDDPAnalyzer;
import dataplane.analysis.NDDReachabilityDB;
import datamodel.ipv4.Prefix;
import main.Configuration;
import main.NDDController;
import main.storage.Storage;
import sre.ndd.NDD;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/** One-event S1 preflight; intentionally not a batch runner. */
public final class S1SingleEventSmoke {
    private S1SingleEventSmoke() { }

    public static void main(String[] args) throws Exception {
        if (args.length < 1 || args.length > 4) {
            throw new IllegalArgumentException(
                    "usage: <input-dir> [event-index] [mf] [s1|s2|s3|s4]");
        }
        Path input = Paths.get(args[0]);
        int eventIndex = args.length >= 2 ? Integer.parseInt(args[1]) : 0;
        int mf = args.length >= 3 ? Integer.parseInt(args[2]) : 1;
        String stage = args.length >= 4 ? args[3] : "s1";
        boolean s4 = "s4".equals(stage);
        boolean s3 = "s3".equals(stage) || s4;
        boolean s2 = "s2".equals(stage) || s3;
        reset(mf);

        Context live = context(input, "s1-live");
        Context full = context(input, "s1-full");
        NDDController.cpExecutor = live.executor;
        NDDController.bddManager = new NDDManager(1_000_000, 100_000);
        live.executor.buildOspfTopology();
        full.executor.buildOspfTopology();
        OspfCostManifest manifest = OspfCostManifest.generate(
                input.getFileName().toString(), live.executor.getOspfTopology(), 1);
        OspfCostUpdate update = manifest.getUpdates().get(eventIndex);

        OspfDormantContributionIndex index = runOld(live);
        S3OldState oldSpf = s3 ? S3OldState.capture(live) : null;
        try (S0Snapshot oldState = S0Snapshot.capture(
                        live.executor.getRouters().values(), null, null);
                OspfCostUpdate.Bound liveBound = update.bind(
                        live.executor.getRouters(), live.executor.getOspfTopology());
                OspfCostUpdate.Bound fullBound = update.bind(
                        full.executor.getRouters(), full.executor.getOspfTopology());
                OspfDormantContributionIndex ownedIndex = index;
                S3OldState ownedOldSpf = oldSpf) {
            liveBound.apply();
            long prepareStart = System.nanoTime();
            try (OspfCostContributionTransaction contribution =
                            OspfCostContributionTransaction.prepare(update,
                                    live.executor.getRouters(),
                                    live.executor.getOspfTopology(), ownedIndex)) {
                long prepareNanos = System.nanoTime() - prepareStart;
                if (contribution.isFullFallback()) {
                    liveBound.rollback();
                    try (S0Snapshot unchanged = S0Snapshot.capture(
                            live.executor.getRouters().values(), null, null)) {
                        if (!oldState.semanticallyEquivalent(unchanged)) {
                            throw new IllegalStateException(
                                    "fallback mutated live route state");
                        }
                    }
                    fullBound.apply();
                    activate(full.executor);
                    NDDController.storage = full.storage;
                    NDDController.cpExecutor = full.executor;
                    long fullStart = System.nanoTime();
                    full.executor.generateDataPlane();
                    long fullNanos = System.nanoTime() - fullStart;
                    System.out.println("s1_event:" + update.getId());
                    System.out.println("s1_fallback:true");
                    System.out.println("s1_fallback_reason:"
                            + contribution.getReason());
                    System.out.println("s1_direct_contributions:"
                            + contribution.getDirectContributions());
                    System.out.println("s1_prepare_nanos:" + prepareNanos);
                    System.out.println("s1_full_nanos:" + fullNanos);
                    return;
                }
                long applyStart = System.nanoTime();
                contribution.apply();
                try (RibFibStage ribFib = createRibFibStage(s2,
                                live.executor.getRouters(), contribution)) {
                    ribFib.apply();
                    long applyNanos = System.nanoTime() - applyStart;

                    fullBound.apply();
                    activate(full.executor);
                    NDDController.storage = full.storage;
                    NDDController.cpExecutor = full.executor;
                    long fullStart = System.nanoTime();
                    full.executor.generateDataPlane();
                    long fullNanos = System.nanoTime() - fullStart;
                    S3ProbeResult s3Result = null;
                    if (s3) {
                        s3Result = probeS3(ownedOldSpf, live, full, s4,
                                ribFib.getAddedFibRules() > 0);
                    }
                    try (S0Snapshot incremental = S0Snapshot.capture(
                                    live.executor.getRouters().values(), null, null);
                            S0Snapshot freshFull = S0Snapshot.capture(
                                    full.executor.getRouters().values(), null, null)) {
                        S0Snapshot.SnapshotDiff exact = incremental.diff(freshFull);
                        if (!exact.getContributions().isEmpty()
                                || !exact.getRib().isEmpty()
                                || !exact.getFib().isEmpty()) {
                            throw new IllegalStateException("incremental/full mismatch: "
                                    + "contribution=" + exact.getContributions().getChangedCount()
                                    + ",rib=" + exact.getRib().getChangedCount()
                                    + ",fib=" + exact.getFib().getChangedCount()
                                    + ",contributionKeys="
                                    + firstKeys(exact.getContributions()));
                        }
                    }

                    ribFib.rollback();
                    contribution.rollback();
                    liveBound.rollback();
                    try (S0Snapshot restored = S0Snapshot.capture(
                            live.executor.getRouters().values(), null, null)) {
                        S0Snapshot.SnapshotDiff reverse = oldState.diff(restored);
                        if (!reverse.getContributions().isEmpty()
                                || !reverse.getRib().isEmpty()
                                || !reverse.getFib().isEmpty()) {
                            throw new IllegalStateException("rollback mismatch");
                        }
                    }
                    System.out.println("s1_event:" + update.getId());
                    System.out.println("sre_stage:" + stage);
                    System.out.println("s1_exact:true");
                    System.out.println("s1_direct_contributions:"
                            + contribution.getDirectContributions());
                    System.out.println("s1_dormant_contributions:"
                            + ownedIndex.size());
                    System.out.println("s1_dormant_roots:"
                            + ownedIndex.ownedRootCount());
                    System.out.println("s1_dormant_estimated_bytes:"
                            + ownedIndex.estimatedBytes());
                    System.out.println("s1_cloned_contributions:"
                            + contribution.getClonedContributions());
                    System.out.println("s1_recomputed_buckets:"
                            + contribution.getRecomputedBuckets());
                    System.out.println("s1_affected_routers:"
                            + contribution.getAffectedRouters().size());
                    if (s2) {
                        System.out.println("s2_fallback_reason:"
                                + ribFib.getFallbackReason());
                        System.out.println("s2_affected_prefixes:"
                                + ribFib.getAffectedPrefixes());
                        System.out.println("s2_changed_fib_prefixes:"
                                + ribFib.getChangedFibPrefixes());
                        System.out.println("s2_changed_fib_rules:"
                                + ribFib.getChangedFibRules());
                        System.out.println("s2_added_fib_rules:"
                                + ribFib.getAddedFibRules());
                        System.out.println("s2_removed_fib_rules:"
                                + ribFib.getRemovedFibRules());
                        System.out.println("s2_modified_fib_rules:"
                                + ribFib.getModifiedFibRules());
                        System.out.println("s2_no_fib_change_prefixes:"
                                + ribFib.getEliminatedFibPrefixes());
                    }
                    if (s3Result != null) {
                        System.out.println("s3_changed_ports:"
                                + s3Result.changedPorts);
                        System.out.println("s3_selected_sources:"
                                + s3Result.selectedSources);
                        System.out.println("s3_full_changed_sources:"
                                + s3Result.fullChangedSources);
                        System.out.println("s3_source_selection_exact:"
                                + s3Result.exact);
                        System.out.println("s3_selected_only:"
                                + s3Result.selectedOnly);
                        System.out.println("s3_full_only:"
                                + s3Result.fullOnly);
                        System.out.println("s3_spf_fallback_reason:"
                                + s3Result.fallbackReason);
                        System.out.println("s3_recomputed_nodes:"
                                + s3Result.recomputedNodes);
                        System.out.println("s3_loop_prunes:"
                                + s3Result.loopPrunes);
                        System.out.println("s3_composed_spf_exact:"
                                + s3Result.composedExact);
                        if (s3Result.s4 != null) {
                            System.out.println("s4_partition_disjoint:"
                                    + s3Result.s4.disjoint);
                            System.out.println("s4_partition_coverage_exact:"
                                    + s3Result.s4.coverageExact);
                            System.out.println("s4_composed_partition_exact:"
                                    + s3Result.s4.partitionExact);
                            System.out.println("s4_pfecs_added:"
                                    + s3Result.s4.added);
                            System.out.println("s4_pfecs_removed:"
                                    + s3Result.s4.removed);
                            System.out.println("s4_pfecs_modified:"
                                    + s3Result.s4.modified);
                            System.out.println("s4_pfecs_split:"
                                    + s3Result.s4.splits);
                            System.out.println("s4_pfecs_merged:"
                                    + s3Result.s4.merges);
                            System.out.println("s4_dependent_properties:"
                                    + s3Result.s4.dependentProperties);
                            System.out.println("s4_full_changed_properties:"
                                    + s3Result.s4.fullChangedProperties);
                            System.out.println("s4_dependency_exact:"
                                    + s3Result.s4.dependencyExact);
                            System.out.println("s4_verdict_witness_exact:"
                                    + s3Result.s4.verdictWitnessExact);
                        }
                    }
                    System.out.println("s1_prepare_nanos:" + prepareNanos);
                    System.out.println("s1_apply_nanos:" + applyNanos);
                    System.out.println("s1_full_nanos:" + fullNanos);
                }
            }
        }
    }

    private static OspfDormantContributionIndex runOld(Context context) {
        NDDController.storage = context.storage;
        NDDController.cpExecutor = context.executor;
        activate(context.executor);
        context.executor.genConnectedRoute();
        context.executor.installOriginalRoutes();
        NDDOspfExecutor.executeRetainingDeadRoutes(
                context.executor.getOspfTopology());
        OspfDormantContributionIndex index = OspfDormantContributionIndex.capture(
                context.executor.getOspfTopology().getEdges().rowKeySet());
        NDDOspfExecutor.cleanDeadRoutes(context.executor.getOspfTopology());
        context.executor.installIgpRoutes();
        context.executor.buildBgpTopology();
        context.executor.computeBgpRoutes();
        context.executor.installBgpRoutes();
        context.executor.rib2fib();
        return index;
    }

    private static Context context(Path input, String name) {
        Storage storage = new Storage(input, input.resolve(name));
        NDDController.storage = storage;
        NDDCPExecutor executor = new NDDCPExecutor();
        NDDController.cpExecutor = executor;
        executor.init();
        NDDController.cpExecutorStack.add(executor);
        for (NDDRouter router : executor.getRouters().values()) {
            for (Prefix prefix : router.getPrefixes()) prefix.setInterested(true);
        }
        return new Context(storage, executor);
    }

    private static void activate(NDDCPExecutor executor) {
        executor.getRouters().values().forEach(router -> {
            router.getOspfProcesses().values().forEach(process -> process.setValid(true));
            if (router.getBgpProcess() != null) router.getBgpProcess().setValid(true);
        });
    }

    private static S3ProbeResult probeS3(S3OldState oldState,
            Context live, Context full, boolean runS4,
            boolean includeAllSources) {
        for (NDDRouter router : live.executor.getRouters().values()) {
            NDDDPAnalyzer.computeFwdBDD(router, NDD.getTrue());
        }
        try (FibPortSnapshot newPorts = FibPortSnapshot.capture(
                        live.executor.getRouters().values());
                FibPortSnapshot.ChangedPortRegions changedPorts =
                        oldState.ports.diff(newPorts);
                SpfAffectedSourceProbe.Result selected =
                        SpfAffectedSourceProbe.select(
                                oldState.reachability, changedPorts,
                                includeAllSources ? oldState.sources
                                        : java.util.Collections.emptyList())) {
            Collection<NDDRouter> fullSources = reachabilitySources(full);
            NDDDPAnalyzer fullAnalyzer = new NDDDPAnalyzer(full.executor);
            fullAnalyzer.analyzeDataPlane(fullSources);
            try (NDDReachabilityDB fullReachability = fullAnalyzer._reachabilityDB;
                    S0Snapshot fullSpf = S0Snapshot.capture(
                    full.executor.getRouters().values(),
                    fullReachability, null)) {
                Set<String> changedSources = new HashSet<>();
                for (String key : oldState.snapshot.diff(fullSpf)
                        .getPfec().getChangedKeys()) {
                    changedSources.add(key.substring(0, key.indexOf('|')));
                }
                Set<String> selectedSources = new HashSet<>();
                selected.getSources().forEach(source ->
                        selectedSources.add(source.getRouterName()));
                Set<String> selectedOnly = new java.util.TreeSet<>(selectedSources);
                selectedOnly.removeAll(changedSources);
                Set<String> fullOnly = new java.util.TreeSet<>(changedSources);
                fullOnly.removeAll(selectedSources);
                Set<String> unaffectedSources = new HashSet<>(oldState.sourceNames);
                unaffectedSources.removeAll(selectedSources);
                try (AffectedSourceSpfTransaction transaction =
                                new AffectedSourceSpfTransaction(
                                        selected.getSources())) {
                    transaction.apply();
                    boolean composedExact = false;
                    S4ProbeResult s4Result = null;
                    if (!transaction.isFallback()) {
                        try (S0Snapshot candidateAffected = S0Snapshot.capturePfec(
                                        transaction.getCandidate(), selectedSources);
                                S0Snapshot fullAffected = S0Snapshot.capturePfec(
                                        fullReachability, selectedSources);
                                S0Snapshot oldUnaffected = S0Snapshot.capturePfec(
                                        oldState.database, unaffectedSources);
                                S0Snapshot fullUnaffected = S0Snapshot.capturePfec(
                                        fullReachability, unaffectedSources)) {
                            composedExact = candidateAffected.semanticallyEquivalent(
                                    fullAffected)
                                    && oldUnaffected.semanticallyEquivalent(
                                            fullUnaffected);
                        }
                        if (runS4) {
                            s4Result = probeS4(oldState, live, fullReachability,
                                    transaction.getCandidate(), selectedSources,
                                    unaffectedSources);
                        }
                    }
                    return new S3ProbeResult(changedPorts.getChangedPortCount(),
                            selectedSources.size(), changedSources.size(),
                            selectedSources.equals(changedSources), selectedOnly,
                            fullOnly, transaction.getFallbackReason(),
                            transaction.getStoredNodeCount(),
                            transaction.getLoopPrunes(), composedExact, s4Result);
                }
            }
        }
    }

    private static S4ProbeResult probeS4(S3OldState oldState, Context live,
            NDDReachabilityDB fullReachability,
            NDDReachabilityDB candidateReachability,
            Set<String> affectedSources, Set<String> unaffectedSources) {
        try (PfecPartitionSnapshot oldAll = PfecPartitionSnapshot.capture(
                        oldState.database, oldState.sourceNames);
                PfecPartitionSnapshot fullAll = PfecPartitionSnapshot.capture(
                        fullReachability, oldState.sourceNames);
                PfecPartitionSnapshot oldAffected = PfecPartitionSnapshot.capture(
                        oldState.database, affectedSources);
                PfecPartitionSnapshot candidateAffected =
                        PfecPartitionSnapshot.capture(candidateReachability,
                                affectedSources);
                PfecPartitionSnapshot fullAffected = PfecPartitionSnapshot.capture(
                        fullReachability, affectedSources);
                PfecPartitionSnapshot oldUnaffected = PfecPartitionSnapshot.capture(
                        oldState.database, unaffectedSources);
                PfecPartitionSnapshot fullUnaffected = PfecPartitionSnapshot.capture(
                        fullReachability, unaffectedSources);
                ReachabilityPropertySet properties =
                        ReachabilityPropertySet.forRouters(oldState.sources,
                                live.executor.getRouters().values());
                PfecPartitionSnapshot.CoverageDelta coverageDelta =
                        oldAffected.coverageDelta(candidateAffected)) {
            boolean disjoint = oldAll.isDisjoint() && fullAll.isDisjoint()
                    && candidateAffected.isDisjoint();
            boolean coverageExact = candidateAffected.coverageEquivalent(fullAffected)
                    && oldUnaffected.coverageEquivalent(fullUnaffected);
            boolean partitionExact = candidateAffected.semanticallyEquivalent(fullAffected)
                    && oldUnaffected.semanticallyEquivalent(fullUnaffected);
            PfecPartitionSnapshot.Delta delta = oldAffected.diff(candidateAffected);
            Set<PfecPartitionSnapshot.PairKey> dependencies =
                    properties.dependencies(coverageDelta);
            try (ReachabilityPropertySet.Evaluation oldResults = properties.evaluate(
                            oldAll, properties.getPropertyIds());
                    ReachabilityPropertySet.Evaluation fullResults = properties.evaluate(
                            fullAll, properties.getPropertyIds());
                    ReachabilityPropertySet.Evaluation candidateChanged =
                            properties.evaluate(candidateAffected, dependencies);
                    ReachabilityPropertySet.Evaluation fullChanged =
                            properties.evaluate(fullAffected, dependencies)) {
                Set<PfecPartitionSnapshot.PairKey> fullChangedIds =
                        oldResults.changedIds(fullResults);
                return new S4ProbeResult(disjoint, coverageExact, partitionExact,
                        delta.getAdded(), delta.getRemoved(), delta.getModified(),
                        delta.getSplits(), delta.getMerges(), dependencies.size(),
                        fullChangedIds.size(), dependencies.equals(fullChangedIds),
                        candidateChanged.semanticallyEquivalent(fullChanged));
            }
        }
    }

    private static Collection<NDDRouter> reachabilitySources(Context context) {
        if (Files.isRegularFile(context.storage.input._edgePorts)) {
            return context.executor.getEdgeRouters();
        }
        Set<NDDRouter> sources = new LinkedHashSet<>();
        for (NDDPort port : context.executor.getPorts().values()) {
            if (port.getLinkedPort() == null) {
                port.setEdge();
                sources.add(port.getRouter());
            }
        }
        return sources;
    }

    private static void reset(int mf) {
        NDDL3Edge.clearCache();
        NDDController.storageStack.clear();
        NDDController.cpExecutorStack.clear();
        NDDController.dpAnalyzerStack.clear();
        NDDController.bddManagerStack.clear();
        NDDController.mfStack.clear();
        NDDController.ospfValidRouters.clear();
        NDDController.bgpValidRouters.clear();
        NDDController.MF = mf;
        Configuration.ALL_IN_ONE = true;
        Configuration.FILTER = false;
        Configuration.SORT = false;
    }

    private static java.util.List<String> firstKeys(S0Snapshot.LayerDiff diff) {
        return diff.getChangedKeys().stream().limit(8)
                .collect(java.util.stream.Collectors.toList());
    }

    private static RibFibStage createRibFibStage(boolean s2,
            Map<String, NDDRouter> routers,
            OspfCostContributionTransaction contribution) {
        if (s2) {
            Map<String, java.util.Set<Prefix>> affected =
                    contribution.getAffectedPrefixesByRouter();
            if (!AffectedPrefixRibFibTransaction.isWithinBudget(affected)) {
                AffectedRibFibTransaction fallback = new AffectedRibFibTransaction(
                        routers, contribution.getAffectedRouters());
                return new RibFibStage() {
                    public void apply() { fallback.apply(); }
                    public void rollback() { fallback.rollback(); }
                    public int getAffectedPrefixes() { return 0; }
                    public int getChangedFibPrefixes() { return 0; }
                    public int getChangedFibRules() { return 0; }
                    public int getAddedFibRules() { return 0; }
                    public int getRemovedFibRules() { return 0; }
                    public int getModifiedFibRules() { return 0; }
                    public int getEliminatedFibPrefixes() { return 0; }
                    public String getFallbackReason() {
                        return "affected_prefix_budget";
                    }
                    public void close() { fallback.close(); }
                };
            }
            AffectedPrefixRibFibTransaction transaction =
                    new AffectedPrefixRibFibTransaction(routers, affected);
            return new RibFibStage() {
                public void apply() { transaction.apply(); }
                public void rollback() { transaction.rollback(); }
                public int getAffectedPrefixes() {
                    return transaction.getAffectedPrefixCount();
                }
                public int getChangedFibPrefixes() {
                    return transaction.getChangedFibPrefixCount();
                }
                public int getChangedFibRules() {
                    return transaction.getChangedFibRules();
                }
                public int getAddedFibRules() {
                    return transaction.getAddedFibRules();
                }
                public int getRemovedFibRules() {
                    return transaction.getRemovedFibRules();
                }
                public int getModifiedFibRules() {
                    return transaction.getModifiedFibRules();
                }
                public int getEliminatedFibPrefixes() {
                    return transaction.getEliminatedFibPrefixes();
                }
                public void close() { transaction.close(); }
            };
        }
        AffectedRibFibTransaction transaction = new AffectedRibFibTransaction(
                routers, contribution.getAffectedRouters());
        return new RibFibStage() {
            public void apply() { transaction.apply(); }
            public void rollback() { transaction.rollback(); }
            public int getAffectedPrefixes() { return 0; }
            public int getChangedFibPrefixes() { return 0; }
            public int getChangedFibRules() { return 0; }
            public int getAddedFibRules() { return 0; }
            public int getRemovedFibRules() { return 0; }
            public int getModifiedFibRules() { return 0; }
            public int getEliminatedFibPrefixes() { return 0; }
            public void close() { transaction.close(); }
        };
    }

    private interface RibFibStage extends AutoCloseable {
        void apply();
        void rollback();
        int getAffectedPrefixes();
        int getChangedFibPrefixes();
        int getChangedFibRules();
        int getAddedFibRules();
        int getRemovedFibRules();
        int getModifiedFibRules();
        int getEliminatedFibPrefixes();
        default String getFallbackReason() { return "none"; }
        void close();
    }

    private static final class S3OldState implements AutoCloseable {
        private final S0Snapshot snapshot;
        private final FibPortSnapshot ports;
        private final SpfReachabilityIndex reachability;
        private final NDDReachabilityDB database;
        private final Set<String> sourceNames;
        private final Collection<NDDRouter> sources;

        private S3OldState(S0Snapshot snapshot, FibPortSnapshot ports,
                SpfReachabilityIndex reachability, NDDReachabilityDB database,
                Set<String> sourceNames, Collection<NDDRouter> sources) {
            this.snapshot = snapshot;
            this.ports = ports;
            this.reachability = reachability;
            this.database = database;
            this.sourceNames = sourceNames;
            this.sources = sources;
        }

        private static S3OldState capture(Context context) {
            Collection<NDDRouter> sources = reachabilitySources(context);
            NDDDPAnalyzer analyzer = new NDDDPAnalyzer(context.executor);
            analyzer.analyzeDataPlane(sources);
            S0Snapshot snapshot = S0Snapshot.capture(
                    context.executor.getRouters().values(),
                    analyzer._reachabilityDB, null);
            FibPortSnapshot ports = FibPortSnapshot.capture(
                    context.executor.getRouters().values());
            SpfReachabilityIndex reachability = SpfReachabilityIndex.capture(
                    sources, analyzer._reachabilityDB);
            Set<String> sourceNames = new HashSet<>();
            sources.forEach(source -> sourceNames.add(source.getRouterName()));
            return new S3OldState(snapshot, ports, reachability,
                    analyzer._reachabilityDB, sourceNames,
                    new java.util.ArrayList<>(sources));
        }

        @Override
        public void close() {
            reachability.close();
            ports.close();
            snapshot.close();
            database.close();
        }
    }

    private static final class S3ProbeResult {
        private final int changedPorts;
        private final int selectedSources;
        private final int fullChangedSources;
        private final boolean exact;
        private final Set<String> selectedOnly;
        private final Set<String> fullOnly;
        private final String fallbackReason;
        private final int recomputedNodes;
        private final int loopPrunes;
        private final boolean composedExact;
        private final S4ProbeResult s4;

        private S3ProbeResult(int changedPorts, int selectedSources,
                int fullChangedSources, boolean exact,
                Set<String> selectedOnly, Set<String> fullOnly,
                String fallbackReason, int recomputedNodes, int loopPrunes,
                boolean composedExact, S4ProbeResult s4) {
            this.changedPorts = changedPorts;
            this.selectedSources = selectedSources;
            this.fullChangedSources = fullChangedSources;
            this.exact = exact;
            this.selectedOnly = selectedOnly;
            this.fullOnly = fullOnly;
            this.fallbackReason = fallbackReason;
            this.recomputedNodes = recomputedNodes;
            this.loopPrunes = loopPrunes;
            this.composedExact = composedExact;
            this.s4 = s4;
        }

        private static S3ProbeResult fallback(String reason) {
            return new S3ProbeResult(0, 0, 0, false,
                    java.util.Collections.emptySet(),
                    java.util.Collections.emptySet(), reason, 0, 0, false, null);
        }
    }

    private static final class S4ProbeResult {
        private final boolean disjoint;
        private final boolean coverageExact;
        private final boolean partitionExact;
        private final int added;
        private final int removed;
        private final int modified;
        private final int splits;
        private final int merges;
        private final int dependentProperties;
        private final int fullChangedProperties;
        private final boolean dependencyExact;
        private final boolean verdictWitnessExact;

        private S4ProbeResult(boolean disjoint, boolean coverageExact,
                boolean partitionExact, int added, int removed, int modified,
                int splits, int merges, int dependentProperties,
                int fullChangedProperties, boolean dependencyExact,
                boolean verdictWitnessExact) {
            this.disjoint = disjoint;
            this.coverageExact = coverageExact;
            this.partitionExact = partitionExact;
            this.added = added;
            this.removed = removed;
            this.modified = modified;
            this.splits = splits;
            this.merges = merges;
            this.dependentProperties = dependentProperties;
            this.fullChangedProperties = fullChangedProperties;
            this.dependencyExact = dependencyExact;
            this.verdictWitnessExact = verdictWitnessExact;
        }
    }

    private static final class Context {
        private final Storage storage;
        private final NDDCPExecutor executor;

        private Context(Storage storage, NDDCPExecutor executor) {
            this.storage = storage;
            this.executor = executor;
        }
    }
}
