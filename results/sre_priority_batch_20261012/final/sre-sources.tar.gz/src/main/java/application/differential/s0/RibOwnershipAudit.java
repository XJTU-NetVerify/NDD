package application.differential.s0;

import controlplane.network.NDDRouter;
import controlplane.process.ospf.NDDOspfProcess;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/** Read-only audit of process/global RIB Java-object ownership. */
public final class RibOwnershipAudit {
    private RibOwnershipAudit() { }

    public static Report inspect(Collection<NDDRouter> routers) {
        if (routers == null) throw new IllegalArgumentException("routers are required");
        List<Alias> listAliases = new ArrayList<>();
        List<Alias> routeAliases = new ArrayList<>();
        for (NDDRouter router : routers) {
            Map<Prefix, NDDSortedMultiList> global = router.getGlobalRib().getRib();
            for (NDDOspfProcess process : router.getOspfProcesses().values()) {
                for (Map.Entry<Prefix, NDDSortedMultiList> entry
                        : process.getRib().getRib().entrySet()) {
                    NDDSortedMultiList globalList = global.get(entry.getKey());
                    if (globalList == null) continue;
                    String owner = router.getRouterName() + "|ospf:"
                            + process.getProcessId() + "|" + entry.getKey();
                    if (entry.getValue() == globalList) {
                        listAliases.add(new Alias(owner, "shared-list"));
                    }
                    IdentityHashMap<NDDSortedMultiListItem, Boolean> processItems =
                            new IdentityHashMap<>();
                    for (NDDSortedMultiListItem item : entry.getValue().flat()) {
                        processItems.put(item, Boolean.TRUE);
                    }
                    int sharedItems = 0;
                    for (NDDSortedMultiListItem item : globalList.flat()) {
                        if (processItems.containsKey(item)) sharedItems++;
                    }
                    if (sharedItems > 0) {
                        routeAliases.add(new Alias(owner,
                                "shared-route-objects=" + sharedItems));
                    }
                }
            }
        }
        return new Report(listAliases, routeAliases);
    }

    public static final class Alias {
        private final String owner;
        private final String detail;

        private Alias(String owner, String detail) {
            this.owner = owner;
            this.detail = detail;
        }

        public String getOwner() { return owner; }
        public String getDetail() { return detail; }
        @Override public String toString() { return owner + "|" + detail; }
    }

    public static final class Report {
        private final List<Alias> listAliases;
        private final List<Alias> routeAliases;

        private Report(List<Alias> listAliases, List<Alias> routeAliases) {
            this.listAliases = Collections.unmodifiableList(listAliases);
            this.routeAliases = Collections.unmodifiableList(routeAliases);
        }

        public List<Alias> getListAliases() { return listAliases; }
        public List<Alias> getRouteAliases() { return routeAliases; }
        public int getListAliasCount() { return listAliases.size(); }
        public int getRouteAliasCount() { return routeAliases.size(); }
        public boolean isDetached() {
            return listAliases.isEmpty() && routeAliases.isEmpty();
        }

        public void requireDetached() {
            if (!isDetached()) {
                throw new IllegalStateException("RIB ownership audit failed: listAliases="
                        + listAliases.size() + ", routeAliases=" + routeAliases.size());
            }
        }
    }
}
