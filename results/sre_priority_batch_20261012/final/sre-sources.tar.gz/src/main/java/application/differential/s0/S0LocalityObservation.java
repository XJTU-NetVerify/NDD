package application.differential.s0;

import java.util.HashSet;
import java.util.Set;

/** Serializable one-event S0 locality/oracle record. */
public final class S0LocalityObservation {
    private final OspfCostUpdate event;
    private final int oldContributions;
    private final int oldRibRoutes;
    private final int oldFibRules;
    private final int oldPfecs;
    private final int oldProperties;
    private final int changedContributions;
    private final int changedRibRoutes;
    private final int changedFibRules;
    private final int changedPfecs;
    private final int changedProperties;
    private final int changedContributionKeys;
    private final int changedRibKeys;
    private final int changedFibKeys;
    private final int changedPfecKeys;
    private final int changedContributionRouters;
    private final int changedRibRouters;
    private final int changedFibRouters;
    private final int changedPfecSources;
    private final int changedPfecPairs;
    private final boolean reverseExact;
    private final int reverseChangedContributions;
    private final int reverseChangedRibRoutes;
    private final int reverseChangedFibRules;
    private final int reverseChangedPfecs;
    private final int reverseChangedProperties;
    private final int processGlobalListAliases;
    private final int processGlobalRouteAliases;
    private final long oldFullNanos;
    private final long newFullNanos;
    private final long reverseFullNanos;
    private final S0ResourceSample oldResources;
    private final S0ResourceSample newResources;
    private final S0ResourceSample reverseResources;

    public S0LocalityObservation(OspfCostUpdate event, S0Snapshot oldState,
            S0Oracle.Result oracle, RibOwnershipAudit.Report ownership,
            long oldFullNanos, long newFullNanos, long reverseFullNanos,
            S0ResourceSample oldResources, S0ResourceSample newResources,
            S0ResourceSample reverseResources) {
        if (event == null || oldState == null || oracle == null || ownership == null
                || oldResources == null || newResources == null || reverseResources == null) {
            throw new IllegalArgumentException(
                    "event, snapshot, oracle, ownership and resources are required");
        }
        this.event = event;
        oldContributions = oldState.getContributionCount();
        oldRibRoutes = oldState.getRibRouteCount();
        oldFibRules = oldState.getFibRuleCount();
        oldPfecs = oldState.getPfecCount();
        oldProperties = oldState.getPropertyCount();
        changedContributions = oracle.getForward().getContributions().getChangedCount();
        changedRibRoutes = oracle.getForward().getRib().getChangedCount();
        changedFibRules = oracle.getForward().getFib().getChangedCount();
        changedPfecs = oracle.getForward().getPfec().getChangedCount();
        changedProperties = oracle.getForward().getProperties().getChangedCount();
        changedContributionKeys = oracle.getForward().getContributions().getChangedKeys().size();
        changedRibKeys = oracle.getForward().getRib().getChangedKeys().size();
        changedFibKeys = oracle.getForward().getFib().getChangedKeys().size();
        changedPfecKeys = oracle.getForward().getPfec().getChangedKeys().size();
        changedContributionRouters = distinctPrefixes(
                oracle.getForward().getContributions().getChangedKeys(), 1);
        changedRibRouters = distinctPrefixes(
                oracle.getForward().getRib().getChangedKeys(), 1);
        changedFibRouters = distinctPrefixes(
                oracle.getForward().getFib().getChangedKeys(), 1);
        changedPfecSources = distinctPrefixes(
                oracle.getForward().getPfec().getChangedKeys(), 1);
        changedPfecPairs = distinctPrefixes(
                oracle.getForward().getPfec().getChangedKeys(), 2);
        reverseExact = oracle.isReverseExact();
        reverseChangedContributions = oracle.getReverse().getContributions().getChangedCount();
        reverseChangedRibRoutes = oracle.getReverse().getRib().getChangedCount();
        reverseChangedFibRules = oracle.getReverse().getFib().getChangedCount();
        reverseChangedPfecs = oracle.getReverse().getPfec().getChangedCount();
        reverseChangedProperties = oracle.getReverse().getProperties().getChangedCount();
        processGlobalListAliases = ownership.getListAliasCount();
        processGlobalRouteAliases = ownership.getRouteAliasCount();
        this.oldFullNanos = oldFullNanos;
        this.newFullNanos = newFullNanos;
        this.reverseFullNanos = reverseFullNanos;
        this.oldResources = oldResources;
        this.newResources = newResources;
        this.reverseResources = reverseResources;
    }

    private static int distinctPrefixes(Set<String> keys, int segments) {
        Set<String> values = new HashSet<>();
        for (String key : keys) {
            String[] parts = key.split("\\|", -1);
            if (parts.length < segments) {
                throw new IllegalStateException("invalid stable key: " + key);
            }
            StringBuilder prefix = new StringBuilder(parts[0]);
            for (int index = 1; index < segments; index++) {
                prefix.append('|').append(parts[index]);
            }
            values.add(prefix.toString());
        }
        return values.size();
    }

    public OspfCostUpdate getEvent() { return event; }
    public int getOldContributions() { return oldContributions; }
    public int getOldRibRoutes() { return oldRibRoutes; }
    public int getOldFibRules() { return oldFibRules; }
    public int getOldPfecs() { return oldPfecs; }
    public int getOldProperties() { return oldProperties; }
    public int getChangedContributions() { return changedContributions; }
    public int getChangedRibRoutes() { return changedRibRoutes; }
    public int getChangedFibRules() { return changedFibRules; }
    public int getChangedPfecs() { return changedPfecs; }
    public int getChangedProperties() { return changedProperties; }
    public int getChangedContributionKeys() { return changedContributionKeys; }
    public int getChangedRibKeys() { return changedRibKeys; }
    public int getChangedFibKeys() { return changedFibKeys; }
    public int getChangedPfecKeys() { return changedPfecKeys; }
    public int getChangedContributionRouters() { return changedContributionRouters; }
    public int getChangedRibRouters() { return changedRibRouters; }
    public int getChangedFibRouters() { return changedFibRouters; }
    public int getChangedPfecSources() { return changedPfecSources; }
    public int getChangedPfecPairs() { return changedPfecPairs; }
    public boolean isReverseExact() { return reverseExact; }
    public int getReverseChangedContributions() { return reverseChangedContributions; }
    public int getReverseChangedRibRoutes() { return reverseChangedRibRoutes; }
    public int getReverseChangedFibRules() { return reverseChangedFibRules; }
    public int getReverseChangedPfecs() { return reverseChangedPfecs; }
    public int getReverseChangedProperties() { return reverseChangedProperties; }
    public int getProcessGlobalListAliases() { return processGlobalListAliases; }
    public int getProcessGlobalRouteAliases() { return processGlobalRouteAliases; }
    public long getOldFullNanos() { return oldFullNanos; }
    public long getNewFullNanos() { return newFullNanos; }
    public long getReverseFullNanos() { return reverseFullNanos; }
    public S0ResourceSample getOldResources() { return oldResources; }
    public S0ResourceSample getNewResources() { return newResources; }
    public S0ResourceSample getReverseResources() { return reverseResources; }
}
