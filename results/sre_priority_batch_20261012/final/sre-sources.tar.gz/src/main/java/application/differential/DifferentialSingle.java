package application.differential;

import multimap.HashBasedTable;
import controlplane.network.CPExecutor;
import controlplane.network.Router;
import main.Controller;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;

public class DifferentialSingle extends Differential {
    String source;
    String destination;

    public DifferentialSingle(Path inputBase, Path[] snapshots, String source, String destination, int mf) {
        super(inputBase, snapshots, mf);
        this.source = source;
        this.destination = destination;
    }

    @Override
    void initOutput() {
        super.initOutput();
        outputBase = outputBase.resolve(source).resolve(destination);
    }

    @Override
    public void getValidRouters() {
        for (CPExecutor cpe : Controller.cpExecutorStack) {
            Router router = cpe.getRouters().get(destination);
            Controller.ospfValidRouters.add(router);
            Controller.bgpValidRouters.add(router);
        }
    }

    @Override
    public long spf() {
        long start = System.nanoTime();
        for (int i = 0; i < n; i++) {
            HashSet<Router> hs = new HashSet<>();
            hs.add(Controller.cpExecutor.getRouters().get(source));
            Controller.dpAnalyzer.analyzeDataPlane(hs);
            Controller.popStorage();
            Controller.popCPExecutor();
            Controller.popDPAnalyzer();
        }
        return System.nanoTime() - start;
    }

    @Override
    public long diff() {
        long start = System.nanoTime();

        int[] stpList = new int[n];
        Diff[] diffList = new Diff[n - 1];

        for (int i = 0; i < n; i++) {
            Router src = Controller.cpExecutorStack.get(i).getRouters().get(source);
            Router dst = Controller.cpExecutorStack.get(i).getRouters().get(destination);
            int stp = 0;
            if (Controller.dpAnalyzerStack.get(i)._reachabilityDB.getAllPairReachability().contains(src, dst)) {
                stp = Controller.dpAnalyzerStack.get(i)._reachabilityDB.getAllPairReachability().get(src, dst);
                stp = Controller.bddManager.and(stp, dst.getPrefixBDD());
            }
            stpList[i] = stp;
            if (i > 0) diffList[i - 1] = new Diff(stpList[i - 1], stp);
        }

        stpTable = HashBasedTable.create();
        diffTable = HashBasedTable.create();
        stpTable.put(source, destination, stpList);
        diffTable.put(source, destination, diffList);

        return System.nanoTime() - start;
    }

    public static void main(String[] args) {
        Path inputBase = Paths.get(args[0]);
        int n = args.length - 3;
        Path[] snapshots = new Path[n - 1];
        for (int i = 1; i < n; i++) {
            snapshots[i - 1] = inputBase.resolve(args[i]);
            System.out.print(snapshots[i - 1].getFileName().toString() + "\t");
        }
        String src = args[n++];
        String dst = args[n++];
        int mf = Integer.parseInt(args[n]);
        DifferentialSingle ds = new DifferentialSingle(inputBase, snapshots, src, dst, mf);
        ds.run();
        System.out.print("\n");
    }
}
