package application.config2spec;

import bdd.BDDManager;
import controlplane.network.CPExecutor;
import controlplane.network.Router;
import controlplane.process.ospf.OspfProcess;
import datamodel.ipv4.Prefix;
import datamodel.property.Property;
import dataplane.analysis.DPAnalyzer;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import jdd.bdd.BDD;
import main.Configuration;
import main.Controller;
import main.SRELogger;
import main.storage.Storage;
import multimap.HashMultimap;
import multimap.Multimap;
import org.jgrapht.Graph;
import util.BDDUtil;
import util.MemorizeUtil;
import util.TimeUtil;


public class Config2spec {
    public static boolean trim = true;
    public static boolean reach = true;
    public static boolean block = false;
    public static boolean waypoint = false;
    public static boolean loadbalancing = false;

    public static boolean verbose = false;

    public String[] valid;
    int mf;

    protected Collection<Router> randomWaypoint() {
        if (waypoint) {
            HashSet<Router> routers = new HashSet<>();
            routers.addAll(Controller.ospfValidRouters);
            routers.addAll(Controller.bgpValidRouters);
            List<Router> list = new ArrayList<>(routers);
            Collections.shuffle(list);
            int nWaypoints = Integer.max(3, Controller.cpExecutor.getRouters().size() / 5);
            return list.subList(0, Integer.min(list.size(), nWaypoints));
        }
        return new HashSet<>();
    }

    protected void check(Router r) {
        if (r.getOspfProcesses().values().stream().anyMatch(p -> p.getPrefixes().size() > 0)) {
            for (OspfProcess p : r.getOspfProcesses().values()) {
                for (Prefix prefix : p.getPrefixes()) {
                    prefix.setInterested(true);
                    Controller.ospfValidRouters.addAll(Controller.cpExecutor.getPrefixOwners().get(prefix));
                }
            }
        }
        if (r.getBgpProcess().getNetworks().size() > 0) {
            r.getBgpProcess().getNetworks().forEach(prefix -> {
                prefix.setInterested(true);
                Controller.bgpValidRouters.addAll(Controller.cpExecutor.getPrefixOwners().get(prefix));
            });
        }
    }

    protected void getValidRoutersRoughly() {
        if (valid != null) {
            for (String v : valid) {
                Router r = Controller.cpExecutor.getRouters().get(v);
                check(r);
            }
        } else {
            if (trim) {
                if (block && mf > 0) {
                    // run mf=0 first if mining blocks
                    Config2spec helper = new Config2spec();
                    helper.setupCPExecutor();
                    helper.setupBDDManager(0);
                    helper.src();
                    helper.spf();
                    Set<Property> reaches = Controller.dpAnalyzer._specificationBD.mineReachability();
                    Multimap<Prefix, String> multimap = HashMultimap.create();
                    reaches.forEach(reach -> reach.getPropertyDstHeaders().forEach(
                            header -> multimap.putAll(header.getDestination(), reach.getPropertySrcRouters())));
                    HashSet<Prefix> noTrim = multimap.keySet()
                            .stream()
                            .filter(prefix -> multimap.get(prefix).size() < Controller.cpExecutor.getRouters().size()
                                    - 1)
                            .collect(Collectors.toCollection(HashSet::new));
                    helper.exit();
                    noTrim.forEach(prefix -> Controller.cpExecutor.getPrefixOwners().get(prefix).forEach(this::check));
                }
                SRELogger.pushContext("TRIM");
                Controller.cpExecutor.getL3Topology().getKEdgeComponent(mf + 1)
                        .stream()
                        .map(Graph::vertexSet)
                        .filter(set -> set.size() > 1)
                        .collect(Collectors.toSet())
                        .forEach(set -> set.forEach(this::check));
            } else {
                SRELogger.pushContext("NO TRIM");
                Controller.cpExecutor.getRouters().values().forEach(this::check);
            }
        }
    }

    protected void getValidRouterPrecisely() {
        List<Integer> list = Controller.cpExecutor.getPrefixOwners().keys()
                .stream()
                .filter(Prefix::isInterested)
                .map(prefix -> Controller.bddManager.getBDDACLWrapper().encodeDstIPPrefix(prefix))
                .collect(Collectors.toList());
        int rough = BDDUtil.orInBatch(Controller.bddManager.getBDD(), list);
        Controller.cpExecutor.getPrefixOwners().entries().forEach(entry -> {
            Prefix prefix = entry.getKey();
            if (!prefix.isInterested()) {
                int prefixBDD = Controller.bddManager.getBDDACLWrapper().encodeDstIPPrefix(prefix);
                int tmp = Controller.bddManager.and(rough, prefixBDD);
                if (tmp != 0) {
                    entry.getKey().setInterested(true);
                    Controller.ospfValidRouters.addAll(Controller.cpExecutor.getPrefixOwners().get(prefix));
                    Controller.bgpValidRouters.addAll(Controller.cpExecutor.getPrefixOwners().get(prefix));
                }
                Controller.bddManager.deref(tmp);
            }
        });
        Controller.bddManager.deref(rough);
    }

    /* Parse configurations and set up CPExecutor */
    public long setupCPExecutor() {
        long start = System.nanoTime();
        CPExecutor cpExecutor = new CPExecutor();
        Controller.pushCPExecutor(cpExecutor);
        Controller.cpExecutor.init();
        long end = System.nanoTime();
        return end - start;
    }

    /* Set MF and set up BDDManager */
    public long setupBDDManager(int mf) {
        long start = System.nanoTime();
        Controller.pushMF(this.mf = mf);
        getValidRoutersRoughly();
        Controller.pushBDDManager(new BDDManager());
        getValidRouterPrecisely();
        long end = System.nanoTime();
        return end - start;
    }

    /* Symbolic route computation */
    public long src() {
        long start = System.nanoTime();
        Controller.generateDataPlane();
        long end = System.nanoTime();
        // Controller.cpExecutor.getRouters().values().forEach(r -> {
        // System.out.println("======");
        // System.out.println(r.getRouterName());
        // System.out.println(r.getBgpProcess().getRib().toString());
        // });
        MemorizeUtil.printRIB();
        // MemorizeUtil.printFIB(false);
        return end - start;
    }

    /* Symbolic packet forwarding */
    public long spf() {
        long start = System.nanoTime();
        Controller.pushDPAnalyzer(new DPAnalyzer());
        // build reachability forest
        Controller.analyzeDataPlane(Controller.cpExecutor.getEdgeRouters());
        long end = System.nanoTime();
        // MemorizeUtil.printReachabilityForestStats();
        // MemorizeUtil.printFwdPathNums();
        // if (verbose)
        // System.out.print(Controller.dpAnalyzer._reachabilityDB.getNumOfPFEC() +
        // "\t");
        // if (verbose)
        // System.out.print(Controller.dpAnalyzer._reachabilityDB.getNumOfFwdPath() +
        // "\t");
        return end - start;
    }

    /* Mine specifications */
    public long mine() {
        long start = System.nanoTime();
        Controller.mineSpecification(randomWaypoint());
        long end = System.nanoTime();
        return end - start;
    }

    // public long computeAP() {
    // long start = System.nanoTime();
    // HashSet<Integer> fwdAPs = Controller.dpAnalyzer.computeFwdAP();
    // HashSet<Integer> aclAPs = Controller.dpAnalyzer.computeAclAP();
    // long end = System.nanoTime();
    // if (verbose) {
    // System.out.print(fwdAPs.size() + "\t");
    // System.out.print(aclAPs.size() + "\t");
    // }
    // return end - start;
    // }

    public void exit() {
        Controller.bddManager.logUsage();
        Controller.popBDDManager();
        Controller.popCPExecutor();
        Controller.popDPAnalyzer();
        Controller.popMF();
    }

    public void run(int mf) {
        // System.out.println("run init");
        TimeUtil timer = new TimeUtil();
        timer.begin();

        double t0 = System.nanoTime();
        setupCPExecutor();
        setupBDDManager(mf);
        double t1 = System.nanoTime();
        // System.out.println("init:" + (t1 - t0) / 1000000000.0);
        src();
        double t2 = System.nanoTime();
        // System.out.println("src:" + (t2 - t1) / 1000000000.0);
        spf();
        double t3 = System.nanoTime();
        // System.out.println("spf:" + (t3 - t2) / 1000000000.0);
        if (Configuration.testBDDFattree16) {
            System.out.println("until now");
            System.out.print("time:" + (System.nanoTime() - startTime) / 1e9 + "\n");
            Runtime r1 = Runtime.getRuntime();
            r1.gc();
            r1.gc();
            long m2 = r1.totalMemory() - r1.freeMemory();
            System.out.println("memory:" + (m2 - startMemory) / (1024 * 1024) + "MB");
            Controller.bddManager.showStats();
        }
        mine();
        double t4 = System.nanoTime();
        // System.out.println("mine:" + (t4 - t3) / 1000000000.0);
        exit();
        double t5 = System.nanoTime();
        // System.out.println("exit:" + (t5 - t4) / 1000000000.0);

        timer.end(SRELogger.LEVEL.INFO, "mf: " + mf + " finished");
    }

    public static String dataset;
    public static long startMemory = 0l;
    public static long startTime = 0l;
    public static PrintWriter logWriter = null;

    public static void main(String[] args) {
        long start = System.nanoTime();

        dataset = args[0];
        int mf = Integer.parseInt(args[1]);
        BDD.getMKCount = false;

        Path inputBase = Paths.get("/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/exp/fattree/bgp/" + args[0]);
        File file = new File("/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/exp/fattree/bgp/" + args[0] + "/OutBDD");
        if (!file.exists()) {
            file.mkdir();
        }
        Path outputBase = Paths.get("/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/exp/fattree/bgp/" + args[0] + "/OutBDD");

        // Path inputBase = Paths.get("/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/c2s/bgp/"+dataset);
        // File file = new
        // File("/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/c2s/bgp/"+dataset+"/outBDD");
        // if(!file.exists())
        // {
        // file.mkdir();
        // }
        // Path outputBase =
        // Paths.get("/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/c2s/bgp/"+dataset+"/OutBDD");

        if (Configuration.RUN_BATCH_TIMES) {
            try {
                FileWriter fileWriter = new FileWriter("/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/Results/BDD/" + inputBase.getFileName().toString() + "_" + mf, true);
                logWriter = new PrintWriter(fileWriter);
            } catch (IOException e) {
                // TODO: handle exception
            }
        } else {
            try {
                PrintStream print = new PrintStream(
                        "/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/Results/BDD/" + inputBase.getFileName().toString() + "_" + mf);
                System.setOut(print);
                System.setErr(print);
            } catch (FileNotFoundException e) {
                // TODO: handle exception
            }
        }

        Runtime r = Runtime.getRuntime();
        r.gc();
        r.gc();
        long m1 = r.totalMemory() - r.freeMemory();
        if (Configuration.testBDDFattree16) {
            startMemory = m1;
            startTime = start;
        }

        // Timer timer = new Timer();
        // timer.scheduleAtFixedRate(new TimerTask() {
        // public void run() {
        // System.out.println("New bdd nodes:" + BDD.MKCount);
        // }
        // }, 0, 60 * 60 * 1000);

        Configuration.FILTER = Arrays.stream(args).anyMatch(arg -> arg.equalsIgnoreCase("filter"));
        Config2spec.trim = Arrays.stream(args).noneMatch(arg -> arg.equalsIgnoreCase("notrim"));

        if (Configuration.RUN_BATCH_TIMES) {
            logWriter.println(inputBase.getFileName().toString() + "\t" + mf + "\t");
            logWriter.flush();
        } else {
            System.out.println(inputBase.getFileName().toString() + "\t" + mf + "\t");
        }

        Controller.pushStorage(new Storage(inputBase, outputBase));
        Config2spec c2s = new Config2spec();
        c2s.run(mf);

        if (Configuration.RUN_BATCH_TIMES) {
            logWriter.println("total:" + (System.nanoTime() - start) / 1e9);
            logWriter.flush();
        } else {
            System.out.print("total:" + (System.nanoTime() - start) / 1e9);
        }

        Runtime r1 = Runtime.getRuntime();
        r1.gc();
        r1.gc();
        long m2 = r1.totalMemory() - r1.freeMemory();

        if (Configuration.RUN_BATCH_TIMES) {
            logWriter.println("memory:" + (m2 - m1) / (1024 * 1024) + "MB");
            logWriter.flush();
        } else {
            System.out.println("memory:" + (m2 - m1) / (1024 * 1024) + "MB");
        }
        // Controller.bddManager.showStats();

        // System.out.println("New bdd nodes:" + BDD.MKCount);
    }
}
