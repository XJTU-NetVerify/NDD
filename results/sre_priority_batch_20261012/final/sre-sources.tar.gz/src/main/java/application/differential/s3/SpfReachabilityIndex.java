package application.differential.s3;

import controlplane.network.NDDRouter;
import dataplane.analysis.NDDReachabilityDB;
import dataplane.analysis.NDDReachabilityNode;
import sre.ndd.NDD;

import java.util.Collection;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import multimap.Table;

/** Owned old-state arrival region indexed by source and current router. */
public final class SpfReachabilityIndex implements AutoCloseable {
    private final Map<NDDRouter, Map<NDDRouter, Integer>> arrivals =
            new LinkedHashMap<>();
    private boolean closed;

    public static SpfReachabilityIndex capture(Collection<NDDRouter> sources,
            NDDReachabilityDB reachability) {
        SpfReachabilityIndex index = new SpfReachabilityIndex();
        for (NDDRouter source : sources) {
            index.merge(source, source, NDD.ref(NDD.getTrue()));
        }
        for (Table.Cell<NDDRouter, NDDRouter,
                java.util.HashSet<NDDReachabilityNode>> cell
                : reachability.reachabilityForest.cellSet()) {
            NDDRouter source = cell.getRowKey();
            for (NDDReachabilityNode node : cell.getValue()) {
                int region = NDD.ref(NDD.and(node.getTuple().getFirst(),
                        node.getTuple().getSecond()));
                for (NDDRouter router : node.getPath()) {
                    index.merge(source, router, NDD.ref(region));
                }
                NDD.deref(region);
            }
        }
        return index;
    }

    public Map<NDDRouter, Integer> getArrivals(NDDRouter router) {
        return Collections.unmodifiableMap(arrivals.getOrDefault(
                router, Collections.emptyMap()));
    }

    public int getSourceCount() {
        Set<NDDRouter> sources = Collections.newSetFromMap(new IdentityHashMap<>());
        arrivals.values().forEach(bySource -> sources.addAll(bySource.keySet()));
        return sources.size();
    }

    /** Replaces only committed source rows while retaining every other row. */
    public void replaceSources(Collection<NDDRouter> sources,
            NDDReachabilityDB replacement) {
        Set<NDDRouter> replaced = Collections.newSetFromMap(
                new IdentityHashMap<>());
        replaced.addAll(sources);
        for (Map<NDDRouter, Integer> bySource : arrivals.values()) {
            for (NDDRouter source : replaced) {
                Integer removed = bySource.remove(source);
                if (removed != null) NDD.deref(removed);
            }
        }
        for (NDDRouter source : replaced) {
            merge(source, source, NDD.ref(NDD.getTrue()));
        }
        for (Table.Cell<NDDRouter, NDDRouter,
                java.util.HashSet<NDDReachabilityNode>> cell
                : replacement.reachabilityForest.cellSet()) {
            NDDRouter source = cell.getRowKey();
            if (!replaced.contains(source)) continue;
            for (NDDReachabilityNode node : cell.getValue()) {
                int region = NDD.ref(NDD.and(node.getTuple().getFirst(),
                        node.getTuple().getSecond()));
                for (NDDRouter router : node.getPath()) {
                    merge(source, router, NDD.ref(region));
                }
                NDD.deref(region);
            }
        }
    }

    private void merge(NDDRouter source, NDDRouter router, int ownedRegion) {
        Map<NDDRouter, Integer> bySource = arrivals.computeIfAbsent(router,
                ignored -> new LinkedHashMap<>());
        Integer previous = bySource.putIfAbsent(source, ownedRegion);
        if (previous == null) return;
        int merged = NDD.ref(NDD.or(previous, ownedRegion));
        NDD.deref(previous);
        NDD.deref(ownedRegion);
        bySource.put(source, merged);
    }

    @Override
    public void close() {
        if (closed) return;
        arrivals.values().forEach(bySource -> bySource.values().forEach(NDD::deref));
        closed = true;
    }
}
