package application.config2spec;

import bdd.NDDManager;
import controlplane.network.NDDCPExecutor;
import dataplane.analysis.NDDDPAnalyzer;
import main.NDDController;
import main.SRELogger;
import main.storage.Storage;
import org.jgrapht.Graph;
import util.TimeUtil;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

public class NDDAllPairReach {
    public static Path inputBase, outputBase;
    public static boolean PREFIX_PRUNE = false;
    public static int ROUTE_PRUNE_MF;
    public static int PREFIX_PRUNE_MF;

    // only consider bgp
    public static void getValidRouter() {
        if (!PREFIX_PRUNE) {
            NDDController.bgpValidRouters.addAll(NDDController.cpExecutor.getRouters().values().stream().filter(r -> r.getBgpProcess().getNetworks().size() > 0).collect(Collectors.toSet()));
        }
         else {
            NDDController.cpExecutor.getL3Topology().getKEdgeComponent(PREFIX_PRUNE_MF + 1)
                    .stream()
                    .map(Graph::vertexSet)
                    .filter(set -> set.size() > 1)
                    .forEach(set -> NDDController.bgpValidRouters.addAll(set.stream().filter(r -> r.getBgpProcess().getNetworks().size() > 0).collect(Collectors.toSet())));
        }
    }

    public static void run() {
        TimeUtil timer = new TimeUtil();
        timer.begin();

        long start, end;

        /* Set up Storage */
        NDDController.pushStorage(new Storage(inputBase, outputBase));

        /* Set up CPExecutor */
        NDDCPExecutor cpExecutor = new NDDCPExecutor();
        NDDController.pushCPExecutor(cpExecutor);
        NDDController.cpExecutor.init();

        /* Set MF */
        NDDController.pushMF(ROUTE_PRUNE_MF);

        getValidRouter();

        /* Set up BDDManager */
        start = System.nanoTime();
        NDDController.pushBDDManager(new NDDManager());
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* SRC */
        start = System.nanoTime();
        NDDController.generateDataPlane();
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* SPF */
        start = System.nanoTime();
        NDDController.pushDPAnalyzer(new NDDDPAnalyzer());
        NDDController.analyzeDataPlane(NDDController.cpExecutor.getEdgeRouters());
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* FPA */
        start = System.nanoTime();
        NDDController.mineSpecification(null);
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");


        timer.end(SRELogger.LEVEL.INFO, "mf: "+ ROUTE_PRUNE_MF + " finished");
    }

    public static void main(String[] args) {
        long start = System.nanoTime();

        inputBase = Paths.get(args[0]);
        outputBase = Paths.get(args[1]);
        ROUTE_PRUNE_MF = Integer.parseInt(args[2]);
        PREFIX_PRUNE_MF = Integer.parseInt(args[3]);
        PREFIX_PRUNE = PREFIX_PRUNE_MF >= 0;

        String[] params = {
                inputBase.getFileName().toString(),
                args[2],
                args[3]
        };
        System.out.print(String.join("\t", params) + "\t");

        NDDAllPairReach.run();

        System.out.print((System.nanoTime() - start) / 1e9 + "\n");
    }
}
