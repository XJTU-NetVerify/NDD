package application.singleprefix;

import bdd.NDDManager;
import controlplane.network.NDDCPExecutor;
import controlplane.network.NDDRouter;
import dataplane.analysis.NDDDPAnalyzer;
import main.Configuration;
import main.NDDController;
import main.SRELogger;
import main.storage.Storage;
import org.jgrapht.Graph;
import util.TimeUtil;

import java.nio.file.Path;
import java.nio.file.Paths;

public class NDDSinglePrefix {
    public static Path inputBase, outputBase;
    public static boolean PREFIX_TRIM = false;
    public static int ROUTE_FILTER_MF;
    public static int PREFIX_FILTER_MF;
    public static String destination;

    public static void getValidRouter() {
        NDDRouter dst = NDDController.cpExecutor.getRouters().get(destination);
        if (
                !PREFIX_TRIM
                || NDDController.cpExecutor.getL3Topology().getKEdgeComponent(PREFIX_FILTER_MF + 1)
                        .stream()
                        .map(Graph::vertexSet)
                        .anyMatch(set -> set.contains(dst) && set.size() > 1)
        ) {
            NDDController.bgpValidRouters.add(dst);
        }
    }

    public static void run() {
        Configuration.FILTER = false;
        Configuration.SORT_METHOD = Configuration.LinkVarSortMethod.PROPAGATION;

        TimeUtil timer = new TimeUtil();
        timer.begin();

        long start, end;

        /* Set up Storage */
        NDDController.pushStorage(new Storage(inputBase, outputBase));

        /* Set up CPExecutor */
        NDDCPExecutor cpExecutor = new NDDCPExecutor();
        NDDController.pushCPExecutor(cpExecutor);
        NDDController.cpExecutor.init();

        /* Set MF */
        NDDController.pushMF(ROUTE_FILTER_MF);

        getValidRouter();

        /* Set up BDDManager */
        start = System.nanoTime();
        NDDController.pushBDDManager(new NDDManager());
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* SRC */
        start = System.nanoTime();
        NDDController.generateDataPlane();
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* SPF */
        start = System.nanoTime();
        NDDController.pushDPAnalyzer(new NDDDPAnalyzer());
        NDDController.analyzeDataPlane(NDDController.cpExecutor.getEdgeRouters());
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* FPA */
        start = System.nanoTime();
        NDDController.mineSpecification(null);
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");


        timer.end(SRELogger.LEVEL.INFO, "mf: "+ ROUTE_FILTER_MF + " finished");
    }

    public static void main(String[] args) {
        long start = System.nanoTime();

        inputBase = Paths.get(args[0]);
        outputBase = Paths.get(args[1]);
        ROUTE_FILTER_MF = Integer.parseInt(args[2]);
        PREFIX_FILTER_MF = Integer.parseInt(args[3]);
        PREFIX_TRIM = PREFIX_FILTER_MF >= 0;
        destination = args[4];

        String[] params = {
                inputBase.getFileName().toString(),
                args[2],
                args[3],
                args[4]
        };
        System.out.print(String.join("\t", params) + "\t");

        NDDSinglePrefix.run();

        System.out.print((System.nanoTime() - start) / 1e9 + "\n");
    }
}
