package application.config2spec;

import sre.ndd.NDD;
import org.ants.jndd.bdd.ComplementedBDD;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.jgrapht.Graph;

import bdd.NDDManager;
import controlplane.network.NDDCPExecutor;
import controlplane.network.NDDRouter;
import controlplane.process.ospf.NDDOspfProcess;
import datamodel.ipv4.Prefix;
import datamodel.property.NDDProperty;
import dataplane.analysis.NDDDPAnalyzer;
import jdd.bdd.BDD;
import main.Configuration;
import main.NDDController;
import main.SRELogger;
import main.storage.Storage;
import multimap.HashMultimap;
import multimap.Multimap;
import util.MemorizeUtil;
import util.NDDUtil;
import util.TimeUtil;
// import jdk.nashorn.internal.ir.debug.ObjectSizeCalculator;
// import ndd.NodeTable;

public class NDDConfig2spec {
    public static boolean trim = true;
    public static boolean reach = true;
    public static boolean block = false;
    public static boolean waypoint = false;
    public static boolean loadbalancing = false;

    public static boolean verbose = false;

    public String[] valid;
    int mf;

    protected Collection<NDDRouter> randomWaypoint() {
        if (waypoint) {
            HashSet<NDDRouter> routers = new HashSet<>();
            routers.addAll(NDDController.ospfValidRouters);
            routers.addAll(NDDController.bgpValidRouters);
            List<NDDRouter> list = new ArrayList<>(routers);
            Collections.shuffle(list);
            int nWaypoints = Integer.max(3, NDDController.cpExecutor.getRouters().size() / 5);
            return list.subList(0, Integer.min(list.size(), nWaypoints));
        }
        return new HashSet<>();
    }

    protected void check(NDDRouter r) {
        if (r.getOspfProcesses().values().stream().anyMatch(p -> p.getPrefixes().size() > 0)) {
            for (NDDOspfProcess p : r.getOspfProcesses().values()) {
                for (Prefix prefix : p.getPrefixes()) {
                    prefix.setInterested(true);
                    NDDController.ospfValidRouters.addAll(NDDController.cpExecutor.getPrefixOwners().get(prefix));
                }
            }
        }
        if (r.getBgpProcess().getNetworks().size() > 0) {
            r.getBgpProcess().getNetworks().forEach(prefix -> {
                prefix.setInterested(true);
                NDDController.bgpValidRouters.addAll(NDDController.cpExecutor.getPrefixOwners().get(prefix));
            });
        }
    }

    protected void getValidRoutersRoughly() {
        if (valid != null) {
            for (String v : valid) {
                NDDRouter r = NDDController.cpExecutor.getRouters().get(v);
                check(r);
            }
        } else {
            if (trim) {
                if (block && mf > 0) {
                    // run mf=0 first if mining blocks
                    NDDConfig2spec helper = new NDDConfig2spec();
                    helper.setupCPExecutor();
                    helper.setupBDDManager(0);
                    helper.src();
                    helper.spf();
                    Set<NDDProperty> reaches = NDDController.dpAnalyzer._specificationBD.mineReachability();
                    Multimap<Prefix, String> multimap = HashMultimap.create();
                    reaches.forEach(reach -> reach.getPropertyDstHeaders().forEach(
                            header -> multimap.putAll(header.getDestination(), reach.getPropertySrcRouters())));
                    HashSet<Prefix> noTrim = multimap.keySet()
                            .stream()
                            .filter(prefix -> multimap.get(prefix).size() < NDDController.cpExecutor.getRouters().size()
                                    - 1)
                            .collect(Collectors.toCollection(HashSet::new));
                    helper.exit();
                    noTrim.forEach(
                            prefix -> NDDController.cpExecutor.getPrefixOwners().get(prefix).forEach(this::check));
                }
                SRELogger.pushContext("TRIM");
                NDDController.cpExecutor.getL3Topology().getKEdgeComponent(mf + 1)
                        .stream()
                        .map(Graph::vertexSet)
                        .filter(set -> set.size() > 1)
                        .collect(Collectors.toSet())
                        .forEach(set -> set.forEach(this::check));
            } else {
                SRELogger.pushContext("NO TRIM");
                NDDController.cpExecutor.getRouters().values().forEach(this::check);
            }
        }
    }

    protected void getValidRouterPrecisely() {
        List<Integer> list = NDDController.cpExecutor.getPrefixOwners().keys()
                .stream()
                .filter(Prefix::isInterested)
                .map(prefix -> NDDController.bddManager.getBDDACLWrapper().encodeDstIPPrefix(prefix))
                .collect(Collectors.toList());
        int rough = NDDUtil.orInBatch(list);
        NDDController.cpExecutor.getPrefixOwners().entries().forEach(entry -> {
            Prefix prefix = entry.getKey();
            if (!prefix.isInterested()) {
                int prefixBDD = NDDController.bddManager.getBDDACLWrapper().encodeDstIPPrefix(prefix);
                // System.out.println("tag1");
                int tmp = NDD.ref(NDD.and(rough, prefixBDD));
                // System.out.println("tag2");
                if (!NDD.isFalse(tmp)) {
                    entry.getKey().setInterested(true);
                    NDDController.ospfValidRouters.addAll(NDDController.cpExecutor.getPrefixOwners().get(prefix));
                    NDDController.bgpValidRouters.addAll(NDDController.cpExecutor.getPrefixOwners().get(prefix));
                }
                NDD.deref(tmp);
            }
        });
        NDD.deref(rough);
    }

    /* Parse configurations and set up CPExecutor */
    public long setupCPExecutor() {
        long start = System.nanoTime();
        NDDCPExecutor cpExecutor = new NDDCPExecutor();
        NDDController.pushCPExecutor(cpExecutor);
        NDDController.cpExecutor.init();
        long end = System.nanoTime();
        return end - start;
    }

    /* Set MF and set up BDDManager */
    public long setupBDDManager(int mf) {
        long start = System.nanoTime();
        NDDController.pushMF(this.mf = mf);
        getValidRoutersRoughly();
        NDDController.pushBDDManager(new NDDManager());
        getValidRouterPrecisely();
        long end = System.nanoTime();
        return end - start;
    }

    /* Symbolic route computation */
    public long src() {
        long start = System.nanoTime();
        NDDController.generateDataPlane();
        long computeEnd = System.nanoTime();
        MemorizeUtil.printNDDRIB();
        long end = System.nanoTime();
        System.out.println("src_compute:" + (computeEnd - start) / 1000000000.0);
        System.out.println("src_rib_dump:" + (end - computeEnd) / 1000000000.0);
        // MemorizeUtil.printNDDFIB(false);
        return end - start;
    }

    /* Symbolic packet forwarding */
    public long spf() {
        long start = System.nanoTime();
        NDDController.pushDPAnalyzer(new NDDDPAnalyzer());
        // build reachability forest
        NDDController.analyzeDataPlane(NDDController.cpExecutor.getEdgeRouters());
        long end = System.nanoTime();
        // MemorizeUtil.printReachabilityForestStats();
        // MemorizeUtil.printFwdPathNums();
        // if (verbose)
        // System.out.print(Controller.dpAnalyzer._reachabilityDB.getNumOfPFEC() +
        // "\t");
        // if (verbose)
        // System.out.print(Controller.dpAnalyzer._reachabilityDB.getNumOfFwdPath() +
        // "\t");
        return end - start;
    }

    /* Mine specifications */
    public long mine() {
        long start = System.nanoTime();
        NDDController.mineSpecification(randomWaypoint());
        long end = System.nanoTime();
        return end - start;
    }

    // public long computeAP() {
    // long start = System.nanoTime();
    // HashSet<Integer> fwdAPs = Controller.dpAnalyzer.computeFwdAP();
    // HashSet<Integer> aclAPs = Controller.dpAnalyzer.computeAclAP();
    // long end = System.nanoTime();
    // if (verbose) {
    // System.out.print(fwdAPs.size() + "\t");
    // System.out.print(aclAPs.size() + "\t");
    // }
    // return end - start;
    // }

    public void exit() {
        NDDController.bddManager.logUsage();
        NDDController.popBDDManager();
        NDDController.popCPExecutor();
        NDDController.popDPAnalyzer();
        NDDController.popMF();
    }

    public void run(int mf) {
        TimeUtil timer = new TimeUtil();
        timer.begin();

        double t0 = System.nanoTime();
        setupCPExecutor();
        setupBDDManager(mf);
        double t1 = System.nanoTime();
        System.out.println("init:" + (t1 - t0) / 1000000000.0);
        src(); // generate dp
        double t2 = System.nanoTime();
        System.out.println("src:" + (t2 - t1) / 1000000000.0);
        spf(); // loop dp and check (pair num and packet num)
        double t3 = System.nanoTime();
        System.out.println("spf:" + (t3 - t2) / 1000000000.0);
        mine(); // regard as string and compare
        double t4 = System.nanoTime();
        System.out.println("mine:" + (t4 - t3) / 1000000000.0);
        if (dataset.equals("bgp_fattree20"))
            return;
        exit();
        double t5 = System.nanoTime();
        System.out.println("exit:" + (t5 - t4) / 1000000000.0);

        timer.end(SRELogger.LEVEL.INFO, "mf: " + mf + " finished");
    }

    public static String dataset;

    public static void main(String[] args) {
        System.setProperty("java.vm.name", "Java HotSpot(TM) ");

        long start = System.nanoTime();

        dataset = args[0];
        // dataset = inputBase.getFileName().toString();

        int mf = Integer.parseInt(args[1]);

        Configuration.configureNDD(args);
        System.out.println("ndd_backend_profile:" + Configuration.NDD_BACKEND_PROFILE);
        System.out.println("ndd_domain_order:" + Configuration.NDD_DOMAIN_ORDER);
        System.out.println("ndd_test_plan:" + Configuration.testPlan);

        BDD.getMKCount = true;
        Path inputBase = Paths.get("networks/exp/fattree/bgp/" + dataset);
        Path outputBase = Paths.get("networks/exp/fattree/bgp/" + dataset + "/OutNDD");

        NDDController.pushStorage(new Storage(inputBase, outputBase));

        // try {
        //     PrintStream print = new PrintStream(
        //             "/home/augists/Cheney/SRE-Benchmark/variants/ndd/output/parallel/" + inputBase.getFileName().toString() + "_" + mf);
        //     System.setOut(print);
        //     System.setErr(print);
        // } catch (FileNotFoundException e) {
        //     // TODO: handle exception
        // }

        // System.out.println(inputBase.getFileName().toString() + "\t" + mf + "\t");

        Runtime r = Runtime.getRuntime();
        r.gc();
        r.gc();
        long m1 = r.totalMemory() - r.freeMemory();

        Configuration.FILTER = Arrays.stream(args).anyMatch(arg -> arg.equalsIgnoreCase("filter"));
        NDDConfig2spec.trim = Arrays.stream(args).noneMatch(arg -> arg.equalsIgnoreCase("notrim"));
        NDDConfig2spec c2s = new NDDConfig2spec();

        c2s.run(mf);

        System.out.print("total:" + (System.nanoTime() - start) / 1e9 + "\n");

        Runtime r1 = Runtime.getRuntime();
        r1.gc();
        r1.gc();
        long m2 = r1.totalMemory() - r1.freeMemory();

        System.out.println("memory:" + (m2 - m1) / (1024 * 1024) + "MB");
        NDDController.bddManager.showStats();
        // NDD.showMemoryUsage();

        // System.out.println("New ndd nodes:"+NodeTable.mkCount);
        System.out.println("New bdd nodes:" + BDD.MKCount);
        System.out.println("ndd_nodes_created:" + NDD.getTotalCreated());
        System.out.println("ndd_nodes_alive:" + NDD.getNodeCount());
        System.out.println("label_nodes_alive_bdd:" + NDD.getLabelNodeCount(NDD.LabelMode.BDD));
        System.out.println("label_nodes_alive_bcdd:" + NDD.getLabelNodeCount(NDD.LabelMode.COMPLEMENTED_BDD));
        System.out.println("label_nodes_alive_zdd:" + NDD.getLabelNodeCount(NDD.LabelMode.ZDD));
        System.out.println("label_nodes_alive_total:" + NDD.getLabelNodeCount());
        System.out.println("label_nodes_created_bdd:" + NDD.getLabelTotalCreated(NDD.LabelMode.BDD));
        System.out.println("label_nodes_created_bcdd:" + NDD.getLabelTotalCreated(NDD.LabelMode.COMPLEMENTED_BDD));
        System.out.println("label_nodes_created_zdd:" + NDD.getLabelTotalCreated(NDD.LabelMode.ZDD));
        ComplementedBDD bcdd = NDD.getBCDDEngine();
        if (bcdd != null) {
            System.out.println("bcdd_table_capacity:" + bcdd.getTableCapacity());
            System.out.println("bcdd_gc_count:" + bcdd.getGcCount());
            System.out.println("bcdd_grow_count:" + bcdd.getGrowCount());
            System.out.println("bcdd_apply_cache_hits:" + bcdd.getCacheHits());
            System.out.println("bcdd_apply_cache_misses:" + bcdd.getCacheMisses());
        }

        NDD.printNativeStats();
        if (Boolean.getBoolean("sre.ndd.checksum")) sre.ndd.SemanticCheck.print();
        NDD.closeNative();
        // NDD.showStatestic();
    }
}
