package application.netdice;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import controlplane.Owner;
import controlplane.network.*;
import controlplane.process.bgp.BgpNeighborConfig;
import controlplane.process.bgp.BgpProcess;
import controlplane.process.bgp.BgpTopology;
import controlplane.process.ospf.OspfIntfSetting;
import controlplane.process.ospf.OspfNeighborConfig;
import controlplane.process.ospf.OspfProcess;
import controlplane.process.ospf.OspfTopology;
import controlplane.route.builder.StaticRouteBuilder;
import datamodel.ipv4.*;
import datamodel.property.Property;
import util.Pair;
import main.SRELogger;
import util.MemorizeUtil;
import util.ObjectUtil;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.Vector;

public class NetdiceUtil {
    static int DEFAULT_AS_NUMBER = 100;
    static int DEFAULT_EXTERNAL_AS = 400;
    static int DEFAULT_OSPF_AREA = 100;
    static int DEFAULT_OSPF_PROCESS = 100;
    static Mask MASK24 = Mask.of(24);
    static Mask MASK31 = Mask.of(31);
    static Mask MASK32 = Mask.of(32);

    Path inputBase;
    Path topologyFile;
    Path configFile;
    Path ipBankFile;
    public NetdiceUtil(Path inputBase) {
        this.inputBase = inputBase;
        this.configFile = inputBase.resolve("config.json");
        this.ipBankFile = inputBase.resolve("IpBank");
    }

    IpBank _ipBank;
    Prefix _extAnn;

    TreeMap<String, Router> _nodes = new TreeMap<>();
    TreeMap<PortName, Port> _ports = new TreeMap<>();
    HashSet<L3Edge> _l3Edges = new HashSet<>();

    HashSet<Router> _rrs = new HashSet<>(); // route reflectors
    HashSet<Router> _irs = new HashSet<>(); // internal routers
    HashSet<Router> _brs = new HashSet<>(); // border routers
    HashSet<Router> _ers = new HashSet<>(); // external routers
    Router _pr; // waypoint router

    Owner<Prefix, Router> _prefixOwners = new Owner<>();
    Owner<Ip, Router> _ipOwners = new Owner<>();

    L3Topology _l3Topology;
    BgpTopology _bgpTopology = new BgpTopology();
    OspfTopology _ospfTopology = new OspfTopology();
    CPExecutor _cpExecutor;

    Table<Router, Router, L3Edge> _rrl = HashBasedTable.create();

    public void init() {
        prepare();
        loadTopology();
        loadConfig();
        _l3Topology = new L3Topology(
                _nodes,
                _ports,
                _l3Edges,
                null,
                _prefixOwners,
                _ipOwners);
        _cpExecutor = new CPExecutor(_l3Topology, _ospfTopology, _bgpTopology);
    }

    private void prepare() {
        _ipBank = (IpBank) ObjectUtil.loadObject(ipBankFile);
        _extAnn = Prefix.of(_ipBank.next(), MASK24);
    }

    /* load topology, either .in or .json */
    private void loadTopology() {
        topologyFile = inputBase.resolve(inputBase.getFileName() + ".in");
        if (topologyFile.toFile().exists()) {
            loadTopologyIn();
        }
        else {
            topologyFile = inputBase.resolve(inputBase.getFileName() + ".json");
            if (topologyFile.toFile().exists()) {
                loadTopologyJson();
            }
            else {
                SRELogger.log(SRELogger.LEVEL.ERROR, "Must appoint topology file!");
                System.exit(0);
            }
        }
    }

    Vector<Router> routers = new Vector<>();
    /* helper function for loadTopologyIn() and loadTopologyJson() */
    private void addRouter(String name, int id) {
        Router r = new Router(name, DEFAULT_AS_NUMBER, id);
        addLoopback(r);
        OspfProcess ospfProcess = new OspfProcess(r, DEFAULT_OSPF_PROCESS);
        ospfProcess.addNetwork(Prefix.of(r.getLoopBackIp(), MASK32));
        r.addOspfProcess(ospfProcess);
        _nodes.put(name, r);
        routers.add(r);
    }

    /* helper function for loadTopologyIn() and loadTopologyJson() */
    private void addLink(String u, String v, int wuv, int wvu) {
        Router r1 = _nodes.get(u);
        Router r2 = _nodes.get(v);

        Pair<Port, Port> pair = addLinkBetweenTwoRouter(r1, r2, State.SYMBOLIC);

        _ospfTopology.addNeighborConfig(
                new OspfNeighborConfig(r1.getOspfProcess(DEFAULT_OSPF_PROCESS),
                        new OspfIntfSetting(DEFAULT_OSPF_AREA, wuv, false, DEFAULT_OSPF_PROCESS),
                        pair.getKey()));
        _ospfTopology.addNeighborConfig(
                new OspfNeighborConfig(r2.getOspfProcess(DEFAULT_OSPF_PROCESS),
                        new OspfIntfSetting(DEFAULT_OSPF_AREA, wvu, false, DEFAULT_OSPF_PROCESS),
                        pair.getValue()));
    }

    /* parse .in data */
    private void loadTopologyIn() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(topologyFile.toFile()));
            String line = reader.readLine();
            int numNodes = Integer.parseInt(line);
            for (int i = 0; i < numNodes; i++) {
                addRouter(i + "", i);
            }
            HashSet<String> hs = new HashSet<>();
            while ((line = reader.readLine()) != null) {
                if (hs.contains(line)) continue;
                else hs.add(line);
                String[] strs = line.split(" ");
                if (strs[0].equals(strs[1])) continue;
                addLink(strs[0], strs[1], Integer.parseInt(strs[2]), Integer.parseInt(strs[3]));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadTopologyJson() {
        JsonParser parser = new JsonParser();
        try {
            JsonObject root = (JsonObject) parser.parse(new FileReader(topologyFile.toFile()));
            JsonObject topology = root.getAsJsonObject("topology");
            JsonArray nodes = topology.getAsJsonArray("nodes");
            for (int i = 0; i < nodes.size(); i++) {
                addRouter(nodes.get(i).getAsString(), i);
            }
            JsonArray links = topology.getAsJsonArray("links");
            HashSet<JsonObject> hs = new HashSet<>();
            for (int i = 0; i < links.size(); i++) {
                JsonObject link = links.get(i).getAsJsonObject();
                if (hs.contains(link)) continue;
                else hs.add(link);
                if (link.get("u").equals(link.get("v"))) continue;
                addLink(link.get("u").getAsString(), link.get("v").getAsString(), link.get("w_uv").getAsInt(), link.get("w_vu").getAsInt());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadConfig() {
        try {
            JsonParser parser = new JsonParser();
            JsonObject root = (JsonObject) parser.parse(new FileReader(configFile.toFile()));
            JsonArray rrArray = root.getAsJsonArray("rrs");
            for (int j = 0; j < rrArray.size(); j++) {
//                _rrs.add(_nodes.get(rrArray.get(j).getAsString()));
                _rrs.add(routers.get(rrArray.get(j).getAsInt()));
            }
            JsonArray brArray = root.getAsJsonArray("brs");
            for (int j = 0; j < brArray.size(); j++) {
//                _brs.add(_nodes.get(brArray.get(j).getAsString()));
                _brs.add(routers.get(brArray.get(j).getAsInt()));
            }
            _pr = _nodes.get(root.get("point").getAsString());
            _irs.addAll(_nodes.values());
            _irs.removeAll(_rrs);
            _irs.removeAll(_brs);
            setupBgpNeighborBetweenTwoRouterSet(_rrs, _rrs, "ibgp");
            setupBgpNeighborBetweenTwoRouterSet(_rrs, _irs, "reflector");
            setupBgpNeighborBetweenTwoRouterSet(_rrs, _brs, "reflector");
            addExternalRouters();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void addLoopback(Router r) {
        // add loopback port to router
        PortName name = new PortName(r.getRouterName(), "loopback");
        Ip ip = _ipBank.next();
        IpAddress ipAddress = new IpAddress(ip, MASK31);
        Port port = new Port(name, r, ipAddress, true);
        r.setLoopback(port);
        r.addPort(port);
        _ports.put(name, port);
        _ipOwners.add(ip, r);
        _prefixOwners.add(ipAddress.toPrefix(), r);
    }

    private PortName getNextPortName(Router r) {
        PortName p;
        if (r.getPorts() == null) {
            p = new PortName(r.getRouterName(), "p0");
        }
        else {
            p = new PortName(r.getRouterName(), "p" + (r.getPorts().size()));
        }
        return p;
    }

    private Pair<Port, Port> addLinkBetweenTwoRouter(Router r1, Router r2, State state) {
        Ip ip1 = _ipBank.next();
        Ip ip2;
        if (ip1.asLong() % 2 == 0) {
            ip2 = Ip.of(ip1.asLong() + 1);
        }
        else {
            ip2 = Ip.of(ip1.asLong() - 1);
        }
        IpAddress ipAddress1 = new IpAddress(ip1, MASK31);
        IpAddress ipAddress2 = new IpAddress(ip2, MASK31);

        _ipOwners.add(ip1, r1);
        _ipOwners.add(ip2, r2);
        _prefixOwners.add(ipAddress1.toPrefix(), r1);
        _prefixOwners.add(ipAddress2.toPrefix(), r2);

        PortName p1 = getNextPortName(r1);
        Port port1 = new Port(p1, r1, ipAddress1, false);
        PortName p2 = getNextPortName(r2);
        Port port2 = new Port(p2, r2, ipAddress2, false);
        _ports.put(p1, port1);
        _ports.put(p2, port2);
        r1.addPort(port1);
        r2.addPort(port2);

        L3Edge l3Edge = L3Edge.of(p1, p2);
        _l3Edges.add(l3Edge);
        l3Edge.setState(state);

        port1.setLink(l3Edge);
        port1.setLinkedPort(port2);
        port2.setLink(l3Edge);
        port2.setLinkedPort(port1);

        _rrl.put(r1, r2, l3Edge);
        _rrl.put(r2, r1, l3Edge);

        return new Pair<>(port1, port2);
    }

    private void setupBgpNeighborBetweenTwoRouter(Router r1, Router r2, String relation) {
        if (r1.getBgpProcess() == null) {
            r1.setBgpProcess(new BgpProcess(r1));
        }
        if (r2.getBgpProcess() == null) {
            r2.setBgpProcess(new BgpProcess(r2));
        }
        /*
         * if relation is "ibgp", "client" or "reflector"
         * use loopback ip to set up bgp neighbor relationship
         * if relation is "ebgp"
         * use ports' ip of direct connected link
         */
        Ip ip1 = r1.getLoopBackIp();
        Ip ip2 = r2.getLoopBackIp();
        BgpNeighborConfig n1 = null, n2 = null;
        if (relation.equals("ebgp")) {
            L3Edge l3Edge = _rrl.get(r1, r2);
            if (l3Edge.getSrc().getRouterName().equals(r1.getRouterName())) {
                ip1 = _ports.get(l3Edge.getSrc()).getIp();
                ip2 = _ports.get(l3Edge.getDst()).getIp();
            }
            else {
                ip1 = _ports.get(l3Edge.getDst()).getIp();
                ip2 = _ports.get(l3Edge.getSrc()).getIp();
            }
            n1 = new BgpNeighborConfig(ip1, ip2, r1.getBgpProcess(), BgpNeighborConfig.NeighborType.EBGP);
            n2 = new BgpNeighborConfig(ip2, ip1, r2.getBgpProcess(), BgpNeighborConfig.NeighborType.EBGP);
        }
        if (relation.equals("ibgp")) {
            n1 = new BgpNeighborConfig(ip1, ip2, r1.getBgpProcess(), BgpNeighborConfig.NeighborType.IBGP);
            n2 = new BgpNeighborConfig(ip2, ip1, r2.getBgpProcess(), BgpNeighborConfig.NeighborType.IBGP);
        }
        if (relation.equals("reflector")) {
            n1 = new BgpNeighborConfig(ip1, ip2, r1.getBgpProcess(), BgpNeighborConfig.NeighborType.REFLECTOR);
            n2 = new BgpNeighborConfig(ip2, ip1, r2.getBgpProcess(), BgpNeighborConfig.NeighborType.CLIENT);
        }
        _bgpTopology.addNeighborConfig(n1);
        _bgpTopology.addNeighborConfig(n2);
    }

    private void setupBgpNeighborBetweenTwoRouterSet(HashSet<Router> s1, HashSet<Router> s2, String relation) {
        for (Router r1 : s1) {
            for (Router r2 : s2) {
                if (r1 != r2) {
                    setupBgpNeighborBetweenTwoRouter(r1, r2, relation);
                }
            }
            r1.getBgpProcess().setRR(true);
        }
    }

    private void addExternalRouters() {
        _brs.forEach(br -> {
            Router er1 = new Router("ext" + br.getRouterName() + "0", DEFAULT_EXTERNAL_AS);
            Router er2 = new Router("ext" + br.getRouterName() + "1", DEFAULT_EXTERNAL_AS);

            addLoopback(er1);
            addLoopback(er2);

            Pair<Port, Port> pair1 = addLinkBetweenTwoRouter(br, er1, State.UP);
            Pair<Port, Port> pair2 = addLinkBetweenTwoRouter(br, er2, State.UP);

            br.getOspfProcess(DEFAULT_OSPF_PROCESS).addNetwork(pair1.getKey().getPrimaryIpAddress().toPrefix());
            br.getOspfProcess(DEFAULT_OSPF_PROCESS).addNetwork(pair2.getKey().getPrimaryIpAddress().toPrefix());

            setupBgpNeighborBetweenTwoRouter(br, er1, "ebgp");
            setupBgpNeighborBetweenTwoRouter(br, er2, "ebgp");

            er1.getBgpProcess().addNetwork(_extAnn);
            er2.getBgpProcess().addNetwork(_extAnn);

            // insert _extAnn as static route, otherwise BGP won't announce it
            er1.insertStaticRoute(new StaticRouteBuilder().setPrefix(_extAnn).setOutPort(er1.getSink()).build());
            er2.insertStaticRoute(new StaticRouteBuilder().setPrefix(_extAnn).setOutPort(er2.getSink()).build());

            _ipOwners.add(_extAnn.getIp(), er1);
            _ipOwners.add(_extAnn.getIp(), er2);
            _prefixOwners.add(_extAnn, er1);
            _prefixOwners.add(_extAnn, er2);

            _nodes.put(er1.getRouterName(), er1);
            _nodes.put(er2.getRouterName(), er2);
            _ers.add(er1);
            _ers.add(er2);
            br.getBgpProcess().setBR(true);
            er1.getBgpProcess().getNetworks().forEach(p -> p.setInterested(true));
            er2.getBgpProcess().getNetworks().forEach(p -> p.setInterested(true));
        });
    }

    static class PVResult {
        double runtime;
        Vector<Property> properties;

        public PVResult(double runtime, Vector<Property> properties) {
            this.runtime = runtime;
            this.properties = properties;
        }

        public double getRuntime() {
            return runtime;
        }

        public Vector<Property> getProperties() {
            return properties;
        }

        public void toFile(Path path) {
            try {
                File file = path.toFile();
                MemorizeUtil.creatFileIfAbsent(file);
                BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                writer.write(ObjectUtil.JacksonWriter.writePrettyString(this));
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        Path dir = Paths.get("networks", "exp", "mrinfo");
        for (String cfg : dir.toFile().list()) {
            Path inputBase = dir.resolve(cfg);
            Path topologyFile = inputBase.resolve(cfg + ".json");
            int n = 0;
            JsonParser parser = new JsonParser();
            try {
                JsonObject root = (JsonObject) parser.parse(new FileReader(topologyFile.toFile()));
                JsonObject topology = root.getAsJsonObject("topology");
                JsonArray nodes = topology.getAsJsonArray("nodes");
                n += nodes.size();
                JsonArray links = topology.getAsJsonArray("links");
                n += links.size() * 2;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            IpBank bank = new IpBank(n * 2);
            ObjectUtil.writeObject(bank, inputBase.resolve("IpBank"));
        }
    }
}
