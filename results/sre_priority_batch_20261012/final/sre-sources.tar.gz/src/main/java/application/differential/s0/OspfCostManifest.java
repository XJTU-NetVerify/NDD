package application.differential.s0;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import controlplane.process.ospf.NDDOspfEdge;
import controlplane.process.ospf.NDDOspfNeighborConfig;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.process.ospf.NDDOspfTopology;
import multimap.Table;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Versioned deterministic manifest for S0 directed OSPF cost events. */
public final class OspfCostManifest {
    public static final int CURRENT_SCHEMA = 1;

    private final int schemaVersion;
    private final String snapshotId;
    private final List<OspfCostUpdate> updates;

    @JsonCreator
    public OspfCostManifest(
            @JsonProperty("schemaVersion") int schemaVersion,
            @JsonProperty("snapshotId") String snapshotId,
            @JsonProperty("updates") List<OspfCostUpdate> updates) {
        if (schemaVersion != CURRENT_SCHEMA) {
            throw new IllegalArgumentException("unsupported schemaVersion: " + schemaVersion);
        }
        if (snapshotId == null || snapshotId.trim().isEmpty()) {
            throw new IllegalArgumentException("snapshotId must not be empty");
        }
        if (updates == null) throw new IllegalArgumentException("updates are required");
        List<OspfCostUpdate> ordered = new ArrayList<>(updates);
        ordered.sort(Comparator.comparingInt(OspfCostUpdate::getSequence)
                .thenComparing(OspfCostUpdate::getId));
        Set<Integer> sequences = new HashSet<>();
        Set<String> ids = new HashSet<>();
        Set<String> targets = new HashSet<>();
        for (OspfCostUpdate update : ordered) {
            if (update == null) throw new IllegalArgumentException("null update");
            if (!snapshotId.equals(update.getSnapshotId())) {
                throw new IllegalArgumentException("event snapshotId mismatch");
            }
            if (!sequences.add(update.getSequence())) {
                throw new IllegalArgumentException("duplicate sequence: " + update.getSequence());
            }
            if (!ids.add(update.getId())) {
                throw new IllegalArgumentException("duplicate id: " + update.getId());
            }
            if (!targets.add(update.canonicalTarget())) {
                throw new IllegalArgumentException("duplicate target: " + update.canonicalTarget());
            }
        }
        this.schemaVersion = schemaVersion;
        this.snapshotId = snapshotId;
        this.updates = Collections.unmodifiableList(ordered);
    }

    public static OspfCostManifest generate(String snapshotId,
            NDDOspfTopology topology, int costIncrease) {
        if (topology == null) throw new IllegalArgumentException("topology is required");
        if (costIncrease <= 0) throw new IllegalArgumentException("costIncrease must be positive");
        List<Candidate> candidates = new ArrayList<>();
        Set<String> targets = new HashSet<>();
        for (Table.Cell<NDDOspfProcess, NDDOspfProcess, NDDOspfEdge> cell
                : topology.getEdges().cellSet()) {
            NDDOspfProcess source = cell.getRowKey();
            NDDOspfProcess peer = cell.getColumnKey();
            NDDOspfNeighborConfig config = cell.getValue().getSrc();
            String router = source.getRouter().getRouterName();
            String peerRouter = peer.getRouter().getRouterName();
            String intf = config.getPort().getPortName().getInterfaceName();
            String target = router + "|ospf:" + source.getProcessId() + "|"
                    + intf + "|" + peerRouter + "|" + OspfCostUpdate.Direction.LOCAL_INTERFACE;
            if (targets.add(target)) {
                candidates.add(new Candidate(router, source.getProcessId(), intf,
                        peerRouter, config.getIntfSetting().getCost()));
            }
        }
        candidates.sort(Comparator.comparing(Candidate::canonical));
        List<OspfCostUpdate> updates = new ArrayList<>();
        for (int index = 0; index < candidates.size(); index++) {
            Candidate candidate = candidates.get(index);
            long proposed = (long) candidate.cost + costIncrease;
            if (proposed > Integer.MAX_VALUE) {
                throw new IllegalArgumentException("OSPF cost overflow for "
                        + candidate.canonical());
            }
            updates.add(new OspfCostUpdate("ospf-cost-" + index, index,
                    snapshotId, candidate.router, candidate.processId,
                    candidate.interfaceName, candidate.peerRouter,
                    OspfCostUpdate.Direction.LOCAL_INTERFACE,
                    candidate.cost, (int) proposed));
        }
        return new OspfCostManifest(CURRENT_SCHEMA, snapshotId, updates);
    }

    public OspfCostManifest reverse() {
        List<OspfCostUpdate> reversed = new ArrayList<>();
        for (int index = updates.size() - 1; index >= 0; index--) {
            OspfCostUpdate source = updates.get(index).reverse();
            reversed.add(new OspfCostUpdate(source.getId(), reversed.size(),
                    source.getSnapshotId(), source.getRouter(), source.getProcessId(),
                    source.getInterfaceName(), source.getPeerRouter(),
                    source.getDirection(), source.getOldCost(), source.getNewCost()));
        }
        return new OspfCostManifest(CURRENT_SCHEMA, snapshotId, reversed);
    }

    public static OspfCostManifest read(Path path) throws IOException {
        return mapper().readValue(path.toFile(), OspfCostManifest.class);
    }

    public void write(Path path) throws IOException {
        Path absolute = path.toAbsolutePath();
        Path parent = absolute.getParent();
        if (parent != null) Files.createDirectories(parent);
        Path temporary = Files.createTempFile(parent, absolute.getFileName().toString(), ".tmp");
        boolean moved = false;
        try {
            mapper().writerWithDefaultPrettyPrinter().writeValue(temporary.toFile(), this);
            try {
                Files.move(temporary, absolute, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (java.nio.file.AtomicMoveNotSupportedException exception) {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING);
            }
            moved = true;
        } finally {
            if (!moved) Files.deleteIfExists(temporary);
        }
    }

    public int getSchemaVersion() { return schemaVersion; }
    public String getSnapshotId() { return snapshotId; }
    public List<OspfCostUpdate> getUpdates() { return updates; }

    private static ObjectMapper mapper() { return new ObjectMapper(); }

    private static final class Candidate {
        private final String router;
        private final int processId;
        private final String interfaceName;
        private final String peerRouter;
        private final int cost;

        private Candidate(String router, int processId, String interfaceName,
                String peerRouter, int cost) {
            this.router = router;
            this.processId = processId;
            this.interfaceName = interfaceName;
            this.peerRouter = peerRouter;
            this.cost = cost;
        }

        private String canonical() {
            return router + "|" + processId + "|" + interfaceName + "|" + peerRouter;
        }
    }
}
