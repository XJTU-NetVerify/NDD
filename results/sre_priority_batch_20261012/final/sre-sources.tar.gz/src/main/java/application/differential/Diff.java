package application.differential;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.gson.stream.JsonWriter;
import datamodel.failure.FailureModel;
import datamodel.failure.link.LinkFailureModelDouble;
import datamodel.ipv4.Header;
import datamodel.probability.Probability;
import main.Controller;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class Diff {
    int oldSTP;
    int newSTP;

    // packet level difference
    Map<Header, Integer> inc;
    Map<Header, Integer> dec;

    Map<Header, Integer> oldProperties;
    Map<Header, Integer> newProperties;

    // failure tolerance level difference
    Map<Header, int[]> ftDiff;

    // probability level difference
    Map<Header, Probability[]> probDiff;

    public Diff(int oldSTP, int newSTP) {
        this.oldSTP = oldSTP;
        this.newSTP = newSTP;
        this.inc = getDiff(newSTP, oldSTP);
        this.dec = getDiff(oldSTP, newSTP);
        getProperties();
        getFtDiff();
        getProbDiff();
    }

    private Map<Header, Integer> getDiff(int i, int j) {
        int diff = Controller.bddManager.filter(Controller.bddManager.minus(i, j));
        return Controller.bddManager.getBDDPredicateWrapper().splitHeaderTC(diff);
    }

    private void getProperties() {
        oldProperties = Controller.bddManager.getBDDPredicateWrapper().splitHeaderTC(oldSTP);
        newProperties = Controller.bddManager.getBDDPredicateWrapper().splitHeaderTC(newSTP);
    }

//    static LoadingCache<int[], int[]> ftDiffCache = CacheBuilder.newBuilder().softValues().maximumSize(1 << 10).build(CacheLoader.from(x -> x));

    private void getFtDiff() {
        ftDiff = new HashMap<>();
        HashSet<Header> headers = new HashSet<>(oldProperties.keySet());
        headers.addAll(newProperties.keySet());
        for (Header header : headers) {
            int mf1 = Controller.bddManager.getBDDTCWrapper().getTCFailureMax(oldProperties.getOrDefault(header, 0));
            int mf2 = Controller.bddManager.getBDDTCWrapper().getTCFailureMax(newProperties.getOrDefault(header, 0));
//            if (mf1 != mf2) ftDiff.put(header, ftDiffCache.getUnchecked(new int[] {mf1, mf2}));
            if (mf1 != mf2) ftDiff.put(header, new int[] {mf1, mf2});
        }
    }

//    static LoadingCache<Probability[], Probability[]> probDiffCache = CacheBuilder.newBuilder().softValues().maximumSize(1 << 10).build(CacheLoader.from(x -> x));

    private void getProbDiff() {
        probDiff = new HashMap<>();
        FailureModel failureModel = new LinkFailureModelDouble("0.001");
        HashSet<Header> headers = new HashSet<>(oldProperties.keySet());
        headers.addAll(newProperties.keySet());
        for (Header header : headers) {
            Probability prob1 = failureModel.calProbability(oldProperties.getOrDefault(header, 0));
            Probability prob2 = failureModel.calProbability(newProperties.getOrDefault(header, 0));
//            if (prob1 != prob2) probDiff.put(header, probDiffCache.getUnchecked(new Probability[] {prob1, prob2}));
            if (prob1 != prob2) probDiff.put(header, new Probability[] {prob1, prob2});
        }
    }

    public void visualizeDiff(JsonWriter writer) throws IOException {
        writer.beginObject();

        visualizePktDiff(writer);
        visualizeFtDiff(writer);
        visualizeProbDiff(writer);

        writer.endObject();
    }

    public void visualizePktDiff(JsonWriter writer) throws IOException {
//        visualizeHeaderTC(writer, "oldSTP", Controller.bddManager.getBDDPredicateWrapper().splitHeaderTC(oldSTP));
//        visualizeHeaderTC(writer, "newSTP", Controller.bddManager.getBDDPredicateWrapper().splitHeaderTC(newSTP));
//        visualizeHeaderTC(writer, "inc", inc);
//        visualizeHeaderTC(writer, "dec", dec);

        writer.name("NumberPacketDiff");
        writer.beginObject();
        writer.name("inc");
        writer.value(inc.size());
        writer.name("dec");
        writer.value(dec.size());
        writer.endObject();
    }

    public void visualizeFtDiff(JsonWriter writer) throws IOException {
        writer.name("NumberFailureToleranceDiff");
        writer.value(ftDiff.size());
    }

    public void visualizeProbDiff(JsonWriter writer) throws IOException {
        writer.name("NumberProbabilityDiff");
        writer.value(probDiff.size());
    }

    public static void visualizeHeaderTC(JsonWriter writer, String name, Map<Header, Integer> map) throws IOException {
        writer.name(name);
        writer.beginArray();
        for (Map.Entry<Header, Integer> entry : map.entrySet()) {
            writer.beginObject();
            writer.name("header");
            writer.value(entry.getKey().toString());
            writer.name("tc");
            writer.value(entry.getValue());
            visualizeTC(writer, entry.getValue());
            writer.endObject();
        }
        writer.endArray();
    }

    public static void visualizeTC(JsonWriter writer, int tc) throws IOException {
        Collection<byte[]> allSats = Controller.bddManager.getBDDTCWrapper().allSat(tc);
        writer.name("failure scenarios");
        writer.beginArray();
        for (byte[] one : allSats) {
            HashSet<Integer> up = new HashSet<>();
            HashSet<Integer> down = new HashSet<>();
            for (int i = 0; i < one.length; i++) {
                if (one[i] == 1) up.add(i);
                else if (one[i] == 0) down.add(i);
            }
            writer.beginObject();
            writer.name("up");
            writer.beginArray();
            for (int i : up) writer.value(Controller.bddManager.getBDDTCWrapper().getLink(i).toString());
            writer.endArray();
            writer.name("down");
            writer.beginArray();
            for (int i : down) writer.value(Controller.bddManager.getBDDTCWrapper().getLink(i).toString());
            writer.endArray();
            writer.endObject();
        }
        writer.endArray();
    }

}
