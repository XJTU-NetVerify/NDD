package application.config2spec;

import bdd.BDDManager;
import controlplane.network.CPExecutor;
import controlplane.network.Router;
import dataplane.analysis.DPAnalyzer;
import main.Configuration;
import main.Controller;
import main.SRELogger;
import main.storage.Storage;
import org.jgrapht.Graph;
import util.TimeUtil;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;

public class OnePairReach {

    public static void run(Path inputBase, int mf, String source, String destination) {
        Configuration.FILTER = false;
        Configuration.SORT_METHOD = Configuration.LinkVarSortMethod.PROPAGATION;

        TimeUtil timer = new TimeUtil();
        timer.begin();

        /* Set up Storage */
        Path outputBase = inputBase.resolve("single_property_out").resolve(Storage.TODAY).resolve(source + "_" + destination);
        Controller.pushStorage(new Storage(inputBase, outputBase));

        /* Set up CPExecutor */
        CPExecutor cpExecutor = new CPExecutor();
        Controller.pushCPExecutor(cpExecutor);
        Controller.cpExecutor.init();

        /* Set MF */
        Controller.pushMF(mf);

        Router src = cpExecutor.getRouters().get(source);
        Router dst = cpExecutor.getRouters().get(destination);

        boolean valid = Controller.cpExecutor.getL3Topology().getKEdgeComponent(mf + 1)
                .stream()
                .map(Graph::vertexSet)
                .filter(set -> set.size() > 1)
                .anyMatch(set -> set.contains(src));

        if (valid) {
            /* Set up BDDManager */
            Controller.ospfValidRouters.add(dst);
            Controller.bgpValidRouters.add(dst);
            Controller.pushBDDManager(new BDDManager());

            /* SRC */
            Controller.generateDataPlane();

            /* Set up DPAnalyzer */
            Controller.pushDPAnalyzer(new DPAnalyzer());

            /* SPF */
            HashSet<Router> hs = new HashSet<>();
            hs.add(src);
            Controller.analyzeDataPlane(hs);

            /* Mine */
            Controller.mineSpecification(null);
        }
        else {
            System.out.print(0 + "\t" + 0 + "\t");
        }

        timer.end(SRELogger.LEVEL.INFO, "mf: "+ mf + " finished");
    }

    public static void main(String[] args) {
        long start = System.nanoTime();

        Path inputBase = Paths.get(args[0]);
        int mf = Integer.parseInt(args[1]);
        String source = args[2];
        String destination = args[3];

        System.out.print(inputBase.getFileName().toString() + "\t" + mf + "\t" + source + "\t" + destination + "\t");
        OnePairReach.run(inputBase, mf, source, destination);
        System.out.print((System.nanoTime() - start) / 1e9 + "\n");
    }
}
