package application.differential.s0;

import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.route.NDDDynamicRoute;
import controlplane.route.NDDOspfRoute;
import controlplane.route.NDDRoute;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import datamodel.property.NDDProperty;
import dataplane.analysis.NDDReachabilityDB;
import dataplane.analysis.NDDReachabilityNode;
import dataplane.fib.NDDForwardingRule;
import multimap.Table;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 * Owned S0 oracle snapshot for the current NDD manager/generation.
 *
 * Keys are stable Java values; all semantic NDD roots are independently retained.
 * Equality never relies solely on object identity or raw integer handles.
 */
public final class S0Snapshot implements AutoCloseable {
    private final LayerSnapshot contributions;
    private final LayerSnapshot rib;
    private final LayerSnapshot fib;
    private final LayerSnapshot pfec;
    private final LayerSnapshot properties;
    private boolean closed;

    private S0Snapshot(LayerSnapshot contributions, LayerSnapshot rib, LayerSnapshot fib,
            LayerSnapshot pfec, LayerSnapshot properties) {
        this.contributions = contributions;
        this.rib = rib;
        this.fib = fib;
        this.pfec = pfec;
        this.properties = properties;
    }

    public static S0Snapshot capture(Collection<NDDRouter> routers,
            NDDReachabilityDB reachability, Collection<NDDProperty> properties) {
        if (routers == null) throw new IllegalArgumentException("routers are required");
        LayerSnapshot contributions = new LayerSnapshot();
        LayerSnapshot rib = new LayerSnapshot();
        LayerSnapshot fib = new LayerSnapshot();
        LayerSnapshot pfec = new LayerSnapshot();
        LayerSnapshot propertyLayer = new LayerSnapshot();
        try {
            captureContributions(routers, contributions);
            captureRib(routers, rib);
            captureFib(routers, fib);
            if (reachability != null) capturePfec(reachability, pfec);
            if (properties != null) captureProperties(properties, propertyLayer);
            return new S0Snapshot(contributions, rib, fib, pfec, propertyLayer);
        } catch (RuntimeException exception) {
            contributions.close();
            rib.close();
            fib.close();
            pfec.close();
            propertyLayer.close();
            throw exception;
        }
    }

    public static S0Snapshot capturePfec(NDDReachabilityDB reachability,
            Collection<String> sourceNames) {
        LayerSnapshot contributions = new LayerSnapshot();
        LayerSnapshot rib = new LayerSnapshot();
        LayerSnapshot fib = new LayerSnapshot();
        LayerSnapshot pfec = new LayerSnapshot();
        LayerSnapshot properties = new LayerSnapshot();
        capturePfec(reachability, pfec, new java.util.HashSet<>(sourceNames));
        return new S0Snapshot(contributions, rib, fib, pfec, properties);
    }

    public SnapshotDiff diff(S0Snapshot newer) {
        ensureOpen();
        newer.ensureOpen();
        return new SnapshotDiff(
                contributions.diff(newer.contributions),
                rib.diff(newer.rib),
                fib.diff(newer.fib),
                pfec.diff(newer.pfec),
                properties.diff(newer.properties));
    }

    public boolean semanticallyEquivalent(S0Snapshot other) {
        return diff(other).isEmpty();
    }

    public int getContributionCount() { ensureOpen(); return contributions.size(); }
    public int getRibRouteCount() { ensureOpen(); return rib.size(); }
    public int getFibRuleCount() { ensureOpen(); return fib.size(); }
    public int getPfecCount() { ensureOpen(); return pfec.size(); }
    public int getPropertyCount() { ensureOpen(); return properties.size(); }

    @Override
    public void close() {
        if (closed) return;
        contributions.close();
        rib.close();
        fib.close();
        pfec.close();
        properties.close();
        closed = true;
    }

    private void ensureOpen() {
        if (closed) throw new IllegalStateException("S0 snapshot is closed");
    }

    private static void captureContributions(Collection<NDDRouter> routers,
            LayerSnapshot target) {
        for (NDDRouter router : routers) {
            for (NDDOspfProcess process : router.getOspfProcesses().values()) {
                for (Map.Entry<datamodel.ipv4.Prefix, NDDSortedMultiList> entry
                        : process.getRib().getRib().entrySet()) {
                    NDDSortedMultiList routes = entry.getValue();
                    for (int group = 0; group < routes.size(); group++) {
                        for (NDDSortedMultiListItem item : routes.get(group)) {
                            if (!(item instanceof NDDOspfRoute)) continue;
                            NDDOspfRoute route = (NDDOspfRoute) item;
                            String key = router.getRouterName() + "|ospf:"
                                    + process.getProcessId() + "|" + route.getPrefix()
                                    + "|" + route.getPath().stream()
                                            .collect(Collectors.joining(">"))
                                    + "|" + value(route.getNextHop()) + "|"
                                    + port(route.getOutPort());
                            String metadata = "group=" + group + "|ad=" + route.getAD()
                                    + "|metric=" + route.getMetric();
                            target.add(key, new SemanticState(metadata,
                                    route.getArriveTC(), route.getListTC()));
                        }
                    }
                }
            }
        }
    }

    private static void captureFib(Collection<NDDRouter> routers,
            LayerSnapshot target) {
        for (NDDRouter router : routers) {
            for (Map.Entry<datamodel.ipv4.Prefix, NDDSortedMultiList> entry
                    : router.getFib().getFib().entrySet()) {
                NDDSortedMultiList rules = entry.getValue();
                for (int group = 0; group < rules.size(); group++) {
                    for (NDDSortedMultiListItem item : rules.get(group)) {
                        if (!(item instanceof NDDForwardingRule)) continue;
                        NDDForwardingRule rule = (NDDForwardingRule) item;
                        String key = router.getRouterName() + "|" + entry.getKey()
                                + "|" + value(rule.getNextHop()) + "|"
                                + value(rule.getOutPort());
                        target.add(key, new SemanticState("group=" + group,
                                rule.getArriveTC(), rule.getListTC()));
                    }
                }
            }
        }
    }

    private static void captureRib(Collection<NDDRouter> routers,
            LayerSnapshot target) {
        for (NDDRouter router : routers) {
            for (Map.Entry<datamodel.ipv4.Prefix, NDDSortedMultiList> entry
                    : router.getGlobalRib().getRib().entrySet()) {
                NDDSortedMultiList routes = entry.getValue();
                for (int group = 0; group < routes.size(); group++) {
                    for (NDDSortedMultiListItem item : routes.get(group)) {
                        if (!(item instanceof NDDRoute)) continue;
                        NDDRoute route = (NDDRoute) item;
                        String path = route instanceof NDDDynamicRoute
                                ? ((NDDDynamicRoute) route).getPath().stream()
                                        .collect(Collectors.joining(">"))
                                : "";
                        String key = router.getRouterName() + "|global|"
                                + entry.getKey() + "|" + route.getClass().getName()
                                + "|" + value(route.getNextHop()) + "|"
                                + port(route.getOutPort()) + "|" + path;
                        String metadata = "group=" + group + "|protocol="
                                + route.getProtocol() + "|ad=" + route.getAD()
                                + "|metric=" + route.getMetric();
                        target.add(key, new SemanticState(metadata,
                                route.getArriveTC(), route.getListTC()));
                    }
                }
            }
        }
    }

    private static void capturePfec(NDDReachabilityDB reachability,
            LayerSnapshot target) {
        capturePfec(reachability, target, null);
    }

    private static void capturePfec(NDDReachabilityDB reachability,
            LayerSnapshot target, Set<String> sourceNames) {
        if (reachability.reachabilityForest == null) return;
        for (Table.Cell<NDDRouter, NDDRouter, java.util.HashSet<NDDReachabilityNode>> cell
                : reachability.reachabilityForest.cellSet()) {
            NDDRouter source = Objects.requireNonNull(cell.getRowKey());
            if (sourceNames != null
                    && !sourceNames.contains(source.getRouterName())) continue;
            NDDRouter destination = Objects.requireNonNull(cell.getColumnKey());
            for (NDDReachabilityNode node : Objects.requireNonNull(cell.getValue())) {
                String path = node.getPath().stream().map(NDDRouter::getRouterName)
                        .collect(Collectors.joining(">"));
                String key = source.getRouterName() + "|" + destination.getRouterName()
                        + "|" + port(node.getOutPort()) + "|" + path
                        + "|loop=" + node.isLoopDetected();
                target.add(key, new SemanticState("tuple", node.getTuple().getFirst(),
                        node.getTuple().getSecond()));
            }
        }
    }

    private static void captureProperties(Collection<NDDProperty> properties,
            LayerSnapshot target) {
        for (NDDProperty property : properties) {
            if (property == null) throw new IllegalArgumentException("null property");
            String key = property.getClass().getName() + "|" + property.getType()
                    + "|" + property.toSpecification();
            target.add(key, new SemanticState("mf=" + property.getMF(), property.getTC()));
        }
    }

    private static String port(NDDPort port) {
        return port == null ? "NONE" : port.getPortName().toString();
    }

    private static String value(Object value) {
        return value == null ? "NONE" : value.toString();
    }

    private static final class LayerSnapshot implements AutoCloseable {
        private final Map<String, List<SemanticState>> states = new LinkedHashMap<>();
        private int size;
        private boolean closed;

        void add(String key, SemanticState state) {
            if (closed) throw new IllegalStateException("layer snapshot is closed");
            states.computeIfAbsent(key, ignored -> new ArrayList<>()).add(state);
            size++;
        }

        int size() { return size; }

        LayerDiff diff(LayerSnapshot newer) {
            Set<String> keys = new TreeSet<>(states.keySet());
            keys.addAll(newer.states.keySet());
            int added = 0;
            int removed = 0;
            int modified = 0;
            Set<String> changedKeys = new TreeSet<>();
            for (String key : keys) {
                List<SemanticState> oldStates = states.getOrDefault(key,
                        Collections.emptyList());
                List<SemanticState> newStates = newer.states.getOrDefault(key,
                        Collections.emptyList());
                boolean[] matched = new boolean[newStates.size()];
                int exact = 0;
                for (SemanticState oldState : oldStates) {
                    for (int index = 0; index < newStates.size(); index++) {
                        if (!matched[index]
                                && oldState.semanticallyEquals(newStates.get(index))) {
                            matched[index] = true;
                            exact++;
                            break;
                        }
                    }
                }
                int oldUnmatched = oldStates.size() - exact;
                int newUnmatched = newStates.size() - exact;
                int keyModified = Math.min(oldUnmatched, newUnmatched);
                int keyRemoved = oldUnmatched - keyModified;
                int keyAdded = newUnmatched - keyModified;
                if (keyModified + keyRemoved + keyAdded > 0) changedKeys.add(key);
                modified += keyModified;
                removed += keyRemoved;
                added += keyAdded;
            }
            return new LayerDiff(added, removed, modified, changedKeys);
        }

        @Override
        public void close() {
            if (closed) return;
            for (List<SemanticState> group : states.values()) {
                for (SemanticState state : group) state.close();
            }
            closed = true;
        }
    }

    private static final class SemanticState implements AutoCloseable {
        private final String metadata;
        private final int[] roots;
        private boolean closed;

        SemanticState(String metadata, int... borrowedRoots) {
            this.metadata = Objects.requireNonNull(metadata);
            roots = new int[borrowedRoots.length];
            int retained = 0;
            try {
                for (; retained < borrowedRoots.length; retained++) {
                    roots[retained] = SemanticNdd.retain(borrowedRoots[retained]);
                }
            } catch (RuntimeException exception) {
                for (int index = 0; index < retained; index++) {
                    SemanticNdd.release(roots[index]);
                }
                throw exception;
            }
        }

        boolean semanticallyEquals(SemanticState other) {
            if (!metadata.equals(other.metadata) || roots.length != other.roots.length) {
                return false;
            }
            for (int index = 0; index < roots.length; index++) {
                if (!SemanticNdd.equivalent(roots[index], other.roots[index])) return false;
            }
            return true;
        }

        @Override
        public void close() {
            if (closed) return;
            for (int root : roots) SemanticNdd.release(root);
            closed = true;
        }
    }

    public static final class LayerDiff {
        private final int added;
        private final int removed;
        private final int modified;
        private final Set<String> changedKeys;

        private LayerDiff(int added, int removed, int modified,
                Set<String> changedKeys) {
            this.added = added;
            this.removed = removed;
            this.modified = modified;
            this.changedKeys = Collections.unmodifiableSet(changedKeys);
        }

        public int getAdded() { return added; }
        public int getRemoved() { return removed; }
        public int getModified() { return modified; }
        public int getChangedCount() { return added + removed + modified; }
        public Set<String> getChangedKeys() { return changedKeys; }
        public boolean isEmpty() { return getChangedCount() == 0; }
    }

    public static final class SnapshotDiff {
        private final LayerDiff contributions;
        private final LayerDiff rib;
        private final LayerDiff fib;
        private final LayerDiff pfec;
        private final LayerDiff properties;

        private SnapshotDiff(LayerDiff contributions, LayerDiff rib, LayerDiff fib,
                LayerDiff pfec, LayerDiff properties) {
            this.contributions = contributions;
            this.rib = rib;
            this.fib = fib;
            this.pfec = pfec;
            this.properties = properties;
        }

        public LayerDiff getContributions() { return contributions; }
        public LayerDiff getRib() { return rib; }
        public LayerDiff getFib() { return fib; }
        public LayerDiff getPfec() { return pfec; }
        public LayerDiff getProperties() { return properties; }
        public boolean isEmpty() {
            return contributions.isEmpty() && rib.isEmpty() && fib.isEmpty()
                    && pfec.isEmpty() && properties.isEmpty();
        }
    }
}
