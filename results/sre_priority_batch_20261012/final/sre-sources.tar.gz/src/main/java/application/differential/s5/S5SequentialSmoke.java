package application.differential.s5;

import application.differential.s0.OspfCostManifest;
import application.differential.s0.OspfCostUpdate;
import application.differential.s0.S0Snapshot;
import application.differential.s0.S0ResourceSample;
import application.differential.s1.OspfDormantContributionIndex;
import application.differential.s1.OspfCostContributionTransaction;
import application.differential.s2.AffectedPrefixRibFibTransaction;
import application.differential.s3.AffectedSourceSpfTransaction;
import application.differential.s4.PfecPartitionSnapshot;
import application.differential.s4.ReachabilityPropertySet;
import bdd.NDDManager;
import controlplane.network.NDDCPExecutor;
import controlplane.network.NDDL3Edge;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.process.ospf.NDDOspfExecutor;
import dataplane.analysis.NDDDPAnalyzer;
import dataplane.analysis.NDDReachabilityDB;
import datamodel.ipv4.Prefix;
import main.Configuration;
import main.NDDController;
import main.storage.Storage;
import sre.ndd.NDD;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Short persistent sequence with rollback/replay and fresh-full checkpoints. */
public final class S5SequentialSmoke {
    private S5SequentialSmoke() { }

    public static void main(String[] args) throws Exception {
        if (args.length < 1 || args.length > 4) {
            throw new IllegalArgumentException(
                    "usage: <input-dir> [event-indices] [mf] [gc-sample]");
        }
        Path input = Paths.get(args[0]);
        int[] eventIndices = parseIndices(args.length >= 2 ? args[1] : "48,49");
        int mf = args.length >= 3 ? Integer.parseInt(args[2]) : 1;
        boolean gcSample = args.length >= 4
                && Boolean.parseBoolean(args[3]);
        boolean forceFull = Boolean.getBoolean("delta.sre.forceFull");
        boolean freshFinal = Boolean.getBoolean("delta.sre.freshFinal");
        boolean failureProperty = Boolean.getBoolean(
                "delta.sre.failureProperty");
        boolean skipCheckpoint = Boolean.getBoolean(
                "delta.sre.skipCheckpoint");
        reset(mf);
        if (freshFinal) {
            runFreshFinal(input, eventIndices);
            return;
        }

        Context live = context(input, "s5-live");
        NDDController.cpExecutorStack.add(live.executor);
        NDDController.bddManager = new NDDManager(1_000_000, 100_000);
        System.out.println("s5_budget_index_bytes:"
                + OspfCostContributionTransaction.maxIndexBytes());
        System.out.println("s5_budget_index_roots:"
                + OspfCostContributionTransaction.maxIndexRoots());
        System.out.println("s5_budget_direct_contributions:"
                + OspfCostContributionTransaction.maxDirectContributions());
        System.out.println("s5_budget_affected_prefixes:"
                + AffectedPrefixRibFibTransaction.maxAffectedPrefixes());
        System.out.println("s5_budget_affected_sources:"
                + AffectedSourceSpfTransaction.maxAffectedSources());
        System.out.println("s5_budget_spf_nodes:"
                + AffectedSourceSpfTransaction.maxStoredNodes());
        System.out.println("s5_budget_loop_prunes:"
                + AffectedSourceSpfTransaction.maxLoopPrunes());
        System.out.println("s5_admission_source_fraction:"
                + IncrementalAdmissionPolicy.maxSourceFraction());
        System.out.println("s5_admission_direct_owner_fraction:"
                + IncrementalAdmissionPolicy.maxDirectOwnerFraction());
        System.out.println("s5_force_full:" + forceFull);
        live.executor.buildOspfTopology();
        Context preparedForcedFull = null;
        if (forceFull) {
            preparedForcedFull = context(input, "s5-fallback-0");
            preparedForcedFull.executor.buildOspfTopology();
        }
        OspfCostManifest manifest = OspfCostManifest.generate(
                input.getFileName().toString(), live.executor.getOspfTopology(), 1);

        activate(live.executor);
        NDDController.storage = live.storage;
        NDDController.cpExecutor = live.executor;
        OspfDormantContributionIndex index = runOld(live.executor);
        Collection<NDDRouter> sources = reachabilitySources(live);
        PersistentGenerationCoordinator generations =
                new PersistentGenerationCoordinator();
        try (PersistentSreState state = new PersistentSreState(
                live.executor, index, sources)) {
            if (failureProperty) {
                runFailurePropertyUpdate(state);
                return;
            }
            OspfCostUpdate first = manifest.getUpdates().get(eventIndices[0]);
            boolean rollbackExact;
            try (S0Snapshot before = S0Snapshot.capture(
                            live.executor.getRouters().values(),
                            state.getReachability(), null);
                    PersistentGenerationCoordinator.Transaction injected =
                            state.prepare(first)) {
                injected.apply();
                injected.rollback();
                try (S0Snapshot restored = S0Snapshot.capture(
                        live.executor.getRouters().values(),
                        state.getReachability(), null)) {
                    rollbackExact = before.semanticallyEquivalent(restored);
                }
            }
            if (!rollbackExact) {
                throw new IllegalStateException("injected rollback mismatch");
            }

            List<OspfCostUpdate> committed = new ArrayList<>();
            for (int sequence = 0; sequence < eventIndices.length; sequence++) {
                OspfCostUpdate update = manifest.getUpdates().get(
                        eventIndices[sequence]);
                NDDController.cpExecutor = state.getExecutor();
                List<OspfCostUpdate> candidateUpdates =
                        new ArrayList<>(committed);
                candidateUpdates.add(update);
                final int eventSequence = sequence;
                final Context prebuiltFallback = eventSequence == 0
                        ? preparedForcedFull : null;
                long updateStart = System.nanoTime();
                PersistentGenerationCoordinator.Outcome outcome = generations.execute(
                        update.getId(), () -> forceFull
                                ? forcedFull()
                                : state.prepare(update),
                        () -> {
                            Context fallback = prebuiltFallback;
                            if (fallback == null) {
                                fallback = context(input,
                                        "s5-fallback-" + eventSequence);
                                fallback.executor.buildOspfTopology();
                            }
                            return state.replaceWithFull(buildFullState(
                                    fallback, candidateUpdates));
                        });
                NDDController.cpExecutorStack.clear();
                NDDController.cpExecutorStack.add(state.getExecutor());
                long updateNanos = System.nanoTime() - updateStart;
                committed.add(update);
                long beforeReplay = generations.getGeneration();
                long replayStart = System.nanoTime();
                PersistentGenerationCoordinator.Outcome replay = generations.execute(
                        update.getId(),
                        () -> { throw new AssertionError("replay prepared"); },
                        () -> { throw new AssertionError("replay fell back"); });
                boolean replayStable = replay.getMode()
                        == PersistentGenerationCoordinator.Mode.REPLAY
                        && generations.getGeneration() == beforeReplay;
                long replayNanos = System.nanoTime() - replayStart;
                if (!replayStable) throw new IllegalStateException("replay advanced");
                System.out.println("s5_event:" + update.getId());
                System.out.println("s5_generation:" + outcome.getGeneration());
                System.out.println("s5_mode:" + outcome.getMode());
                System.out.println("s5_fallback_reason:"
                        + outcome.getFallbackReason());
                System.out.println("s5_update_nanos:" + updateNanos);
                System.out.println("s5_direct_contributions:"
                        + state.getLastDirectContributions());
                System.out.println("s5_worklist_pops:"
                        + state.getLastWorklistPops());
                System.out.println("s5_cloned_contributions:"
                        + state.getLastClonedContributions());
                System.out.println("s5_recomputed_buckets:"
                        + state.getLastRecomputedBuckets());
                System.out.println("s5_affected_prefixes:"
                        + state.getLastAffectedPrefixes());
                System.out.println("s5_affected_routers:"
                        + state.getLastAffectedRouters());
                System.out.println("s5_direct_owner_routers:"
                        + state.getLastDirectOwnerRouters());
                System.out.println("s5_changed_fib_rules:"
                        + state.getLastChangedFibRules());
                System.out.println("s5_added_fib_rules:"
                        + state.getLastAddedFibRules());
                System.out.println("s5_affected_sources:"
                        + state.getLastAffectedSources());
                System.out.println("s5_affected_source_fraction:"
                        + state.getLastAffectedSourceFraction());
                System.out.println("s5_spf_nodes:" + state.getLastSpfNodes());
                System.out.println("s5_dependent_properties:"
                        + state.getLastDependentProperties());
                System.out.println("s5_stage_contribution_prepare_nanos:"
                        + state.getLastContributionPrepareNanos());
                System.out.println("s5_stage_contribution_apply_nanos:"
                        + state.getLastContributionApplyNanos());
                System.out.println("s5_stage_contribution_structural_nanos:"
                        + state.getLastContributionStructuralBuildNanos());
                System.out.println("s5_stage_contribution_propagation_nanos:"
                        + state.getLastContributionPropagationNanos());
                System.out.println("s5_stage_contribution_finalization_nanos:"
                        + state.getLastContributionFinalizationNanos());
                System.out.println("s5_stage_rib_fib_nanos:"
                        + state.getLastRibFibNanos());
                System.out.println("s5_stage_fwd_nanos:"
                        + state.getLastFwdNanos());
                System.out.println("s5_stage_selection_nanos:"
                        + state.getLastSelectionNanos());
                System.out.println("s5_stage_spf_nanos:"
                        + state.getLastSpfNanos());
                System.out.println("s5_stage_property_nanos:"
                        + state.getLastPropertyNanos());
                System.out.println("s5_stage_index_advance_nanos:"
                        + state.getLastIndexAdvanceNanos());
                System.out.println("s5_index_compacted:"
                        + state.wasLastIndexCompacted());
                System.out.println("s5_dormant_index_size:"
                        + state.getDormantIndexSize());
                System.out.println("s5_dormant_index_slots:"
                        + state.getDormantIndexSlots());
                System.out.println("s5_dormant_index_bytes:"
                        + state.getDormantIndexBytes());
                System.out.println("s5_dormant_index_roots:"
                        + state.getDormantIndexRoots());
                System.out.println("s5_dormant_traversal_references:"
                        + state.getDormantTraversalReferences());
                System.out.println("s5_dormant_reused_during_advance:"
                        + state.getDormantReusedDuringAdvance());
                System.out.println("s5_dormant_created_during_advance:"
                        + state.getDormantCreatedDuringAdvance());
                if (gcSample) {
                    NDD.gc();
                    NDD.gcLabelEngine();
                    System.gc();
                }
                S0ResourceSample resources = S0ResourceSample.capture();
                System.out.println("s5_ndd_nodes:" + resources.getNddNodes());
                System.out.println("s5_label_nodes:" + resources.getLabelNodes());
                System.out.println("s5_ndd_created:" + NDD.getTotalCreated());
                System.out.println("s5_label_created:" + NDD.getLabelTotalCreated());
                System.out.println("s5_rss_bytes:" + resources.getRssBytes());
                System.out.println("s5_replay_stable:true");
                System.out.println("s5_replay_nanos:" + replayNanos);
            }
            if (skipCheckpoint) {
                System.out.println("s5_checkpoint_skipped:true");
                System.out.println("s5_sequence_length:" + eventIndices.length);
                System.out.println("s5_final_generation:"
                        + generations.getGeneration());
                return;
            }
            long checkpointStart = System.nanoTime();
            Context full = context(input, "s5-full");
            full.executor.buildOspfTopology();
            CheckpointResult checkpoint = checkpoint(state, full, committed);
            long checkpointNanos = System.nanoTime() - checkpointStart;
            if (!checkpoint.exact) {
                throw new IllegalStateException("final full checkpoint mismatch");
            }
            System.out.println("s5_checkpoint_exact:true");
            System.out.println("s5_checkpoint_nanos:" + checkpointNanos);
            System.out.println("s5_checkpoint_full_nanos:"
                    + checkpoint.fullNanos);
            System.out.println("s5_oracle_nanos:" + checkpoint.oracleNanos);
            System.out.println("s5_rollback_exact:true");
            System.out.println("s5_sequence_length:" + eventIndices.length);
            System.out.println("s5_final_generation:" + generations.getGeneration());
        }
    }

    private static void runFailurePropertyUpdate(PersistentSreState state) {
        int healthy = exactFailureCondition(java.util.Collections.emptySet());
        try {
            for (NDDRouter source : state.getSources()) {
                List<NDDL3Edge> incident = new ArrayList<>();
                for (NDDL3Edge edge : NDDL3Edge.getAllL3Edge()) {
                    if (source.getRouterName().equals(
                                    edge.getSrc().getRouterName())
                            || source.getRouterName().equals(
                                    edge.getDst().getRouterName())) {
                        incident.add(edge);
                    }
                }
                for (int first = 0; first < incident.size(); first++) {
                    for (int second = first + 1;
                            second < incident.size(); second++) {
                        Set<NDDL3Edge> failed = new HashSet<>();
                        failed.add(incident.get(first));
                        failed.add(incident.get(second));
                        int cut = exactFailureCondition(failed);
                        try {
                            for (NDDRouter destination
                                    : state.getExecutor().getRouters().values()) {
                    if (source == destination) continue;
                    PfecPartitionSnapshot.PairKey id =
                            new PfecPartitionSnapshot.PairKey(
                                    source.getRouterName(),
                                    destination.getRouterName());
                    int pairCoverage = state.getCoverage().coverage(id);
                    int header = NDDController.bddManager.getBDDTCWrapper()
                            .projectLinkFields(pairCoverage);
                    NDD.deref(pairCoverage);
                    int baseQuery = NDD.ref(NDD.and(header, healthy));
                    int cutQuery = NDD.ref(NDD.and(header, cut));
                    NDD.deref(header);
                    try (ReachabilityPropertySet base =
                                    ReachabilityPropertySet.ofQuery(
                                            id.getSource(), id.getDestination(),
                                            baseQuery);
                            ReachabilityPropertySet changed =
                                    ReachabilityPropertySet.ofQuery(
                                            id.getSource(), id.getDestination(),
                                            cutQuery);
                            ReachabilityPropertySet.Evaluation baseResult =
                                    base.evaluate(state.getCoverage(),
                                            java.util.Collections.singleton(id));
                            ReachabilityPropertySet.Evaluation changedResult =
                                    changed.evaluate(state.getCoverage(),
                                            java.util.Collections.singleton(id))) {
                        if (!baseResult.isSafe(id)
                                || changedResult.isSafe(id)) continue;
                        int repetitions = 31;
                        long[] deltaNanos = new long[repetitions];
                        long[] fullNanos = new long[repetitions];
                        for (int repetition = -5; repetition < repetitions;
                                repetition++) {
                            long deltaStart = System.nanoTime();
                            try (ReachabilityPropertySet.Evaluation delta =
                                            changed.evaluate(state.getCoverage(),
                                                    java.util.Collections.singleton(id))) {
                                long deltaElapsed = System.nanoTime() - deltaStart;
                                long fullStart = System.nanoTime();
                                try (PfecPartitionSnapshot fullPartition =
                                                PfecPartitionSnapshot.capture(
                                                        state.getReachability(),
                                                        java.util.Collections.singleton(
                                                                id.getSource()));
                                        ReachabilityPropertySet.Evaluation full =
                                                changed.evaluate(fullPartition,
                                                        java.util.Collections.singleton(id))) {
                                    long fullElapsed = System.nanoTime() - fullStart;
                                    if (!delta.semanticallyEquivalent(full)) {
                                        throw new IllegalStateException(
                                                "failure property oracle mismatch");
                                    }
                                    if (repetition >= 0) {
                                        deltaNanos[repetition] = deltaElapsed;
                                        fullNanos[repetition] = fullElapsed;
                                    }
                                }
                            }
                        }
                        try (ReachabilityPropertySet.Evaluation restored =
                                base.evaluate(state.getCoverage(),
                                        java.util.Collections.singleton(id))) {
                            if (!restored.isSafe(id)) {
                                throw new IllegalStateException(
                                        "failure property restore mismatch");
                            }
                            java.util.Arrays.sort(deltaNanos);
                            java.util.Arrays.sort(fullNanos);
                            long deltaMedian = deltaNanos[repetitions / 2];
                            long fullMedian = fullNanos[repetitions / 2];
                            System.out.println("s5_property_update_family:"
                                    + "failure_condition");
                            System.out.println("s5_property_pair:" + id);
                            System.out.println("s5_property_cut:"
                                    + incident.get(first) + "&&"
                                    + incident.get(second));
                            System.out.println("s5_property_flip:"
                                    + "safe->violation->safe");
                            System.out.println("s5_property_repetitions:"
                                    + repetitions);
                            System.out.println("s5_property_delta_median_nanos:"
                                    + deltaMedian);
                            System.out.println("s5_property_full_median_nanos:"
                                    + fullMedian);
                            System.out.println("s5_property_median_speedup:"
                                    + ((double) fullMedian / deltaMedian));
                            System.out.println("s5_property_exact:true");
                            return;
                        }
                    } finally {
                        NDD.deref(baseQuery);
                        NDD.deref(cutQuery);
                    }
                }
                        } finally {
                            NDD.deref(cut);
                        }
                    }
                }
            }
        } finally {
            NDD.deref(healthy);
        }
        throw new IllegalStateException(
                "no nonzero two-link failure property found");
    }

    private static int exactFailureCondition(Set<NDDL3Edge> failed) {
        int condition = NDD.ref(NDD.getTrue());
        for (NDDL3Edge edge : NDDL3Edge.getAllL3Edge()) {
            int literal = failed.contains(edge)
                    ? NDD.not(edge.getTC()) : edge.getTC();
            int next = NDD.ref(NDD.and(condition, literal));
            NDD.deref(condition);
            condition = next;
        }
        return condition;
    }

    /** Builds only the requested final generation for an independent RSS baseline. */
    private static void runFreshFinal(Path input, int[] eventIndices) {
        Context fresh = context(input, "s5-fresh-final");
        NDDController.cpExecutorStack.add(fresh.executor);
        NDDController.bddManager = new NDDManager(1_000_000, 100_000);
        fresh.executor.buildOspfTopology();
        OspfCostManifest manifest = OspfCostManifest.generate(
                input.getFileName().toString(),
                fresh.executor.getOspfTopology(), 1);
        List<OspfCostUpdate> updates = new ArrayList<>();
        for (int eventIndex : eventIndices) {
            updates.add(manifest.getUpdates().get(eventIndex));
        }
        NDDController.storage = fresh.storage;
        NDDController.cpExecutor = fresh.executor;
        for (OspfCostUpdate update : updates) {
            try (OspfCostUpdate.Bound bound = update.bind(
                    fresh.executor.getRouters(),
                    fresh.executor.getOspfTopology())) {
                bound.apply();
                bound.commit();
            }
        }
        activate(fresh.executor);
        OspfDormantContributionIndex index = runOld(fresh.executor);
        try (PersistentSreState state = new PersistentSreState(
                fresh.executor, index, reachabilitySources(fresh))) {
            int contributions;
            int ribRoutes;
            int fibRules;
            int pfecs;
            try (S0Snapshot snapshot = S0Snapshot.capture(
                    state.getExecutor().getRouters().values(),
                    state.getReachability(), null)) {
                contributions = snapshot.getContributionCount();
                ribRoutes = snapshot.getRibRouteCount();
                fibRules = snapshot.getFibRuleCount();
                pfecs = snapshot.getPfecCount();
            }
            NDD.gc();
            NDD.gcLabelEngine();
            System.gc();
            S0ResourceSample resources = S0ResourceSample.capture();
            System.out.println("s5_fresh_final:true");
            System.out.println("s5_sequence_length:" + updates.size());
            System.out.println("s5_snapshot_contributions:" + contributions);
            System.out.println("s5_snapshot_rib_routes:" + ribRoutes);
            System.out.println("s5_snapshot_fib_rules:" + fibRules);
            System.out.println("s5_snapshot_pfecs:" + pfecs);
            System.out.println("s5_property_results:"
                    + state.getPropertyResults().size());
            System.out.println("s5_dormant_index_size:"
                    + state.getDormantIndexSize());
            System.out.println("s5_dormant_index_roots:"
                    + state.getDormantIndexRoots());
            System.out.println("s5_ndd_nodes:" + resources.getNddNodes());
            System.out.println("s5_label_nodes:" + resources.getLabelNodes());
            System.out.println("s5_heap_used_bytes:"
                    + resources.getHeapUsedBytes());
            System.out.println("s5_rss_bytes:" + resources.getRssBytes());
        }
    }

    private static PersistentSreState buildFullState(Context context,
            List<OspfCostUpdate> updates) {
        NDDController.storage = context.storage;
        NDDController.cpExecutor = context.executor;
        for (OspfCostUpdate update : updates) {
            try (OspfCostUpdate.Bound bound = update.bind(
                    context.executor.getRouters(),
                    context.executor.getOspfTopology())) {
                bound.apply();
                bound.commit();
            }
        }
        activate(context.executor);
        OspfDormantContributionIndex index = runOld(context.executor);
        return new PersistentSreState(context.executor, index,
                reachabilitySources(context));
    }

    private static CheckpointResult checkpoint(PersistentSreState state,
            Context full, List<OspfCostUpdate> updates) {
        long fullStart = System.nanoTime();
        NDDController.storage = full.storage;
        NDDController.cpExecutor = full.executor;
        for (OspfCostUpdate update : updates) {
            try (OspfCostUpdate.Bound bound = update.bind(
                    full.executor.getRouters(), full.executor.getOspfTopology())) {
                bound.apply();
                bound.commit();
            }
        }
        activate(full.executor);
        OspfDormantContributionIndex fullIndex = runOld(full.executor);
        Collection<NDDRouter> fullSources = reachabilitySources(full);
        NDDDPAnalyzer analyzer = new NDDDPAnalyzer(full.executor);
        analyzer.analyzeDataPlane(fullSources);
        Set<String> sourceNames = sourceNames(state.getSources());
        try (OspfDormantContributionIndex ownedFullIndex = fullIndex;
                NDDReachabilityDB fullReachability = analyzer._reachabilityDB;
                ReachabilityPropertySet fullPropertySet =
                        ReachabilityPropertySet.forRouters(fullSources,
                                full.executor.getRouters().values());
                PfecPartitionSnapshot fullPartition =
                        PfecPartitionSnapshot.capture(fullReachability, sourceNames);
                ReachabilityPropertySet.Evaluation fullProperties =
                        fullPropertySet.evaluate(
                                fullPartition,
                                fullPropertySet.getPropertyIds())) {
            Map<String, Integer> incrementalMetadata =
                    state.getDormantMetadataHistogram();
            Map<String, Integer> freshMetadata =
                    ownedFullIndex.metadataHistogram();
            System.out.println("s5_dormant_metadata_extra:"
                    + multisetDifference(incrementalMetadata, freshMetadata));
            System.out.println("s5_dormant_metadata_missing:"
                    + multisetDifference(freshMetadata, incrementalMetadata));
            System.out.println("s5_dormant_false_arrive_extra:"
                    + multisetDifference(state.getDormantFalseArriveHistogram(),
                            ownedFullIndex.falseArriveMetadataHistogram()));
            System.out.println("s5_dormant_metadata_extra_sample:"
                    + differenceSample(incrementalMetadata, freshMetadata));
            long fullNanos = System.nanoTime() - fullStart;
            long oracleStart = System.nanoTime();
            try (S0Snapshot incremental = S0Snapshot.capture(
                            state.getExecutor().getRouters().values(),
                            state.getReachability(), null);
                    S0Snapshot freshFull = S0Snapshot.capture(
                            full.executor.getRouters().values(),
                            fullReachability, null);
                    PfecPartitionSnapshot incrementalPartition =
                            PfecPartitionSnapshot.capture(
                                    state.getReachability(), sourceNames)) {
                boolean exact = incremental.semanticallyEquivalent(freshFull)
                        && incrementalPartition.semanticallyEquivalent(fullPartition)
                        && state.getPropertyResults().semanticallyEquivalent(
                                fullProperties);
                return new CheckpointResult(exact, fullNanos,
                        System.nanoTime() - oracleStart);
            }
        }
    }

    private static int multisetDifference(Map<String, Integer> left,
            Map<String, Integer> right) {
        int difference = 0;
        for (Map.Entry<String, Integer> entry : left.entrySet()) {
            difference += Math.max(0, entry.getValue()
                    - right.getOrDefault(entry.getKey(), 0));
        }
        return difference;
    }

    private static List<String> differenceSample(Map<String, Integer> left,
            Map<String, Integer> right) {
        List<String> sample = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : left.entrySet()) {
            int extra = entry.getValue()
                    - right.getOrDefault(entry.getKey(), 0);
            if (extra > 0) sample.add(entry.getKey() + " x" + extra);
            if (sample.size() == 3) break;
        }
        return sample;
    }

    private static OspfDormantContributionIndex runOld(NDDCPExecutor executor) {
        executor.genConnectedRoute();
        executor.installOriginalRoutes();
        NDDOspfExecutor.executeRetainingDeadRoutes(executor.getOspfTopology());
        OspfDormantContributionIndex index = OspfDormantContributionIndex.capture(
                executor.getOspfTopology().getEdges().rowKeySet());
        NDDOspfExecutor.cleanDeadRoutes(executor.getOspfTopology());
        executor.installIgpRoutes();
        executor.buildBgpTopology();
        executor.computeBgpRoutes();
        executor.installBgpRoutes();
        executor.rib2fib();
        return index;
    }

    private static Context context(Path input, String name) {
        Storage storage = new Storage(input, input.resolve(name));
        NDDController.storage = storage;
        NDDCPExecutor executor = new NDDCPExecutor();
        NDDController.cpExecutor = executor;
        executor.init();
        for (NDDRouter router : executor.getRouters().values()) {
            for (Prefix prefix : router.getPrefixes()) prefix.setInterested(true);
        }
        return new Context(storage, executor);
    }

    private static void activate(NDDCPExecutor executor) {
        executor.getRouters().values().forEach(router -> {
            router.getOspfProcesses().values().forEach(process ->
                    process.setValid(true));
            if (router.getBgpProcess() != null) router.getBgpProcess().setValid(true);
        });
    }

    private static Collection<NDDRouter> reachabilitySources(Context context) {
        if (Files.isRegularFile(context.storage.input._edgePorts)) {
            return context.executor.getEdgeRouters();
        }
        Set<NDDRouter> sources = new LinkedHashSet<>();
        for (NDDPort port : context.executor.getPorts().values()) {
            if (port.getLinkedPort() == null) {
                port.setEdge();
                sources.add(port.getRouter());
            }
        }
        return sources;
    }

    private static Set<String> sourceNames(Collection<NDDRouter> sources) {
        Set<String> names = new HashSet<>();
        sources.forEach(source -> names.add(source.getRouterName()));
        return names;
    }

    private static int[] parseIndices(String text) {
        String[] values = text.split(",");
        int[] indices = new int[values.length];
        for (int index = 0; index < values.length; index++) {
            indices[index] = Integer.parseInt(values[index]);
        }
        return indices;
    }

    private static PersistentGenerationCoordinator.Transaction forcedFull() {
        return new PersistentGenerationCoordinator.Transaction() {
            public boolean isFallback() { return true; }
            public String fallbackReason() { return "forced_full"; }
            public void apply() { }
            public void verify() { }
            public void commit() { }
            public void rollback() { }
            public void close() { }
        };
    }

    private static void reset(int mf) {
        NDDL3Edge.clearCache();
        NDDController.storageStack.clear();
        NDDController.cpExecutorStack.clear();
        NDDController.dpAnalyzerStack.clear();
        NDDController.bddManagerStack.clear();
        NDDController.mfStack.clear();
        NDDController.ospfValidRouters.clear();
        NDDController.bgpValidRouters.clear();
        NDDController.MF = mf;
        Configuration.ALL_IN_ONE = true;
        Configuration.FILTER = false;
        Configuration.SORT = false;
    }

    private static final class Context {
        private final Storage storage;
        private final NDDCPExecutor executor;

        private Context(Storage storage, NDDCPExecutor executor) {
            this.storage = storage;
            this.executor = executor;
        }
    }

    private static final class CheckpointResult {
        private final boolean exact;
        private final long fullNanos;
        private final long oracleNanos;

        private CheckpointResult(boolean exact, long fullNanos,
                long oracleNanos) {
            this.exact = exact;
            this.fullNanos = fullNanos;
            this.oracleNanos = oracleNanos;
        }
    }
}
