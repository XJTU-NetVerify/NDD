package application.differential.s4;

import controlplane.network.NDDRouter;
import dataplane.analysis.NDDReachabilityDB;
import dataplane.analysis.NDDReachabilityNode;
import multimap.Table;
import sre.ndd.NDD;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** Owned source/destination coverage without materializing PFEC behaviors. */
public final class ReachabilityCoverageSnapshot implements AutoCloseable {
    private final Map<PfecPartitionSnapshot.PairKey, Integer> coverage =
            new LinkedHashMap<>();
    private boolean closed;

    public static ReachabilityCoverageSnapshot capture(
            NDDReachabilityDB database, Collection<String> sourceNames) {
        ReachabilityCoverageSnapshot snapshot =
                new ReachabilityCoverageSnapshot();
        Set<String> sources = new HashSet<>(sourceNames);
        for (Table.Cell<NDDRouter, NDDRouter,
                java.util.HashSet<NDDReachabilityNode>> cell
                : database.reachabilityForest.cellSet()) {
            if (!sources.contains(cell.getRowKey().getRouterName())) continue;
            PfecPartitionSnapshot.PairKey pair =
                    new PfecPartitionSnapshot.PairKey(
                            cell.getRowKey().getRouterName(),
                            cell.getColumnKey().getRouterName());
            for (NDDReachabilityNode node : cell.getValue()) {
                int region = NDD.ref(NDD.and(node.getTuple().getFirst(),
                        node.getTuple().getSecond()));
                Integer previous = snapshot.coverage.putIfAbsent(pair, region);
                if (previous != null) {
                    int merged = NDD.ref(NDD.or(previous, region));
                    NDD.deref(previous);
                    NDD.deref(region);
                    snapshot.coverage.put(pair, merged);
                }
            }
        }
        return snapshot;
    }

    public PfecPartitionSnapshot.CoverageDelta coverageDelta(
            ReachabilityCoverageSnapshot newer) {
        Map<PfecPartitionSnapshot.PairKey, Integer> changed =
                new LinkedHashMap<>();
        Set<PfecPartitionSnapshot.PairKey> pairs =
                new HashSet<>(coverage.keySet());
        pairs.addAll(newer.coverage.keySet());
        for (PfecPartitionSnapshot.PairKey pair : pairs) {
            int oldRegion = coverage.getOrDefault(pair, NDD.getFalse());
            int newRegion = newer.coverage.getOrDefault(pair, NDD.getFalse());
            int removed = NDD.ref(NDD.diff(oldRegion, newRegion));
            int added = NDD.ref(NDD.diff(newRegion, oldRegion));
            int difference = NDD.ref(NDD.or(removed, added));
            NDD.deref(removed);
            NDD.deref(added);
            if (NDD.isFalse(difference)) NDD.deref(difference);
            else changed.put(pair, difference);
        }
        return new PfecPartitionSnapshot.CoverageDelta(changed);
    }

    public ReachabilityCoverageSnapshot subset(Collection<String> sourceNames) {
        Set<String> sources = new HashSet<>(sourceNames);
        ReachabilityCoverageSnapshot subset =
                new ReachabilityCoverageSnapshot();
        coverage.forEach((pair, region) -> {
            if (sources.contains(pair.getSource())) {
                subset.coverage.put(pair, NDD.ref(region));
            }
        });
        return subset;
    }

    public ReachabilityCoverageSnapshot updatedSources(
            ReachabilityCoverageSnapshot changes,
            Collection<String> sourceNames) {
        Set<String> sources = new HashSet<>(sourceNames);
        ReachabilityCoverageSnapshot updated =
                new ReachabilityCoverageSnapshot();
        coverage.forEach((pair, region) -> {
            if (!sources.contains(pair.getSource())) {
                updated.coverage.put(pair, NDD.ref(region));
            }
        });
        changes.coverage.forEach((pair, region) ->
                updated.coverage.put(pair, NDD.ref(region)));
        return updated;
    }

    public int coverage(PfecPartitionSnapshot.PairKey pair) {
        return NDD.ref(coverage.getOrDefault(pair, NDD.getFalse()));
    }

    @Override
    public void close() {
        if (closed) return;
        coverage.values().forEach(NDD::deref);
        closed = true;
    }
}
