package application.config2spec;

import bdd.BDDManager;
import controlplane.network.CPExecutor;
import dataplane.analysis.DPAnalyzer;
import main.Controller;
import main.SRELogger;
import main.storage.Storage;
import org.jgrapht.Graph;
import util.TimeUtil;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

public class AllPairReach {
    public static Path inputBase, outputBase;
    public static boolean PREFIX_PRUNE = false;
    public static int ROUTE_PRUNE_MF;
    public static int PREFIX_PRUNE_MF;

    // only consider bgp
    public static void getValidRouter() {
        if (!PREFIX_PRUNE) {
            Controller.bgpValidRouters.addAll(Controller.cpExecutor.getRouters().values().stream().filter(r -> r.getBgpProcess().getNetworks().size() > 0).collect(Collectors.toSet()));
        }
         else {
            Controller.cpExecutor.getL3Topology().getKEdgeComponent(PREFIX_PRUNE_MF + 1)
                    .stream()
                    .map(Graph::vertexSet)
                    .filter(set -> set.size() > 1)
                    .forEach(set -> Controller.bgpValidRouters.addAll(set.stream().filter(r -> r.getBgpProcess().getNetworks().size() > 0).collect(Collectors.toSet())));
        }
    }

    public static void run() {
        TimeUtil timer = new TimeUtil();
        timer.begin();

        long start, end;

        /* Set up Storage */
        Controller.pushStorage(new Storage(inputBase, outputBase));

        /* Set up CPExecutor */
        CPExecutor cpExecutor = new CPExecutor();
        Controller.pushCPExecutor(cpExecutor);
        Controller.cpExecutor.init();

        /* Set MF */
        Controller.pushMF(ROUTE_PRUNE_MF);

        getValidRouter();

        /* Set up BDDManager */
        start = System.nanoTime();
        Controller.pushBDDManager(new BDDManager());
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* SRC */
        start = System.nanoTime();
        Controller.generateDataPlane();
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* SPF */
        start = System.nanoTime();
        Controller.pushDPAnalyzer(new DPAnalyzer());
        Controller.analyzeDataPlane(Controller.cpExecutor.getEdgeRouters());
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* FPA */
        start = System.nanoTime();
        Controller.mineSpecification(null);
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");


        timer.end(SRELogger.LEVEL.INFO, "mf: "+ ROUTE_PRUNE_MF + " finished");
    }

    public static void main(String[] args) {
        long start = System.nanoTime();

        inputBase = Paths.get(args[0]);
        outputBase = Paths.get(args[1]);
        ROUTE_PRUNE_MF = Integer.parseInt(args[2]);
        PREFIX_PRUNE_MF = Integer.parseInt(args[3]);
        PREFIX_PRUNE = PREFIX_PRUNE_MF >= 0;

        String[] params = {
                inputBase.getFileName().toString(),
                args[2],
                args[3]
        };
        System.out.print(String.join("\t", params) + "\t");

        AllPairReach.run();

        System.out.print((System.nanoTime() - start) / 1e9 + "\n");
    }
}
