package application.differential.s4;

import controlplane.network.NDDRouter;
import main.NDDController;
import sre.ndd.NDD;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** Stable reachability queries and exact reachable/violation witness evaluation. */
public final class ReachabilityPropertySet implements AutoCloseable {
    private final Map<PfecPartitionSnapshot.PairKey, Integer> queries =
            new LinkedHashMap<>();
    private boolean closed;

    public static ReachabilityPropertySet forRouters(
            Collection<NDDRouter> sources, Collection<NDDRouter> destinations) {
        ReachabilityPropertySet properties = new ReachabilityPropertySet();
        for (NDDRouter source : sources) {
            for (NDDRouter destination : destinations) {
                if (source.getRouterName().equals(destination.getRouterName())) continue;
                int query = NDD.ref(NDD.and(destination.getPrefixBDD(),
                        NDDController.bddManager.FILTER_BDD));
                if (!NDD.isFalse(query)) {
                    properties.queries.put(new PfecPartitionSnapshot.PairKey(
                            source.getRouterName(), destination.getRouterName()), query);
                } else {
                    NDD.deref(query);
                }
            }
        }
        return properties;
    }

    public static ReachabilityPropertySet ofQuery(String source,
            String destination, int borrowedQuery) {
        ReachabilityPropertySet properties = new ReachabilityPropertySet();
        properties.queries.put(new PfecPartitionSnapshot.PairKey(
                source, destination), NDD.ref(borrowedQuery));
        return properties;
    }

    public Set<PfecPartitionSnapshot.PairKey> dependencies(
            PfecPartitionSnapshot.CoverageDelta changedCoverage) {
        Set<PfecPartitionSnapshot.PairKey> affected = new HashSet<>();
        for (PfecPartitionSnapshot.PairKey pair : changedCoverage.getPairs()) {
            Integer query = queries.get(pair);
            if (query != null && !NDD.isFalse(NDD.and(
                    query, changedCoverage.getRegion(pair)))) {
                affected.add(pair);
            }
        }
        return affected;
    }

    public Evaluation evaluate(PfecPartitionSnapshot partition,
            Collection<PfecPartitionSnapshot.PairKey> propertyIds) {
        Map<PfecPartitionSnapshot.PairKey, State> states = new LinkedHashMap<>();
        for (PfecPartitionSnapshot.PairKey id : propertyIds) {
            Integer query = queries.get(id);
            if (query == null) continue;
            int coverage = partition.coverage(id);
            int reachable = NDD.ref(NDD.and(query, coverage));
            int violation = NDD.ref(NDD.diff(query, reachable));
            NDD.deref(coverage);
            states.put(id, new State(reachable, violation));
        }
        return new Evaluation(states);
    }

    public Evaluation evaluate(ReachabilityCoverageSnapshot coverage,
            Collection<PfecPartitionSnapshot.PairKey> propertyIds) {
        Map<PfecPartitionSnapshot.PairKey, State> states = new LinkedHashMap<>();
        for (PfecPartitionSnapshot.PairKey id : propertyIds) {
            Integer query = queries.get(id);
            if (query == null) continue;
            int covered = coverage.coverage(id);
            int reachable = NDD.ref(NDD.and(query, covered));
            int violation = NDD.ref(NDD.diff(query, reachable));
            NDD.deref(covered);
            states.put(id, new State(reachable, violation));
        }
        return new Evaluation(states);
    }

    public Set<PfecPartitionSnapshot.PairKey> getPropertyIds() {
        return Collections.unmodifiableSet(queries.keySet());
    }

    @Override
    public void close() {
        if (closed) return;
        queries.values().forEach(NDD::deref);
        closed = true;
    }

    private static boolean equivalent(int left, int right) {
        return left == right || (NDD.isFalse(NDD.diff(left, right))
                && NDD.isFalse(NDD.diff(right, left)));
    }

    public static final class Evaluation implements AutoCloseable {
        private final Map<PfecPartitionSnapshot.PairKey, State> states;
        private boolean closed;

        private Evaluation(Map<PfecPartitionSnapshot.PairKey, State> states) {
            this.states = states;
        }

        public boolean semanticallyEquivalent(Evaluation other) {
            if (!states.keySet().equals(other.states.keySet())) return false;
            for (PfecPartitionSnapshot.PairKey id : states.keySet()) {
                State left = states.get(id);
                State right = other.states.get(id);
                if (left.safe != right.safe
                        || !ReachabilityPropertySet.equivalent(
                                left.reachable, right.reachable)
                        || !ReachabilityPropertySet.equivalent(
                                left.violation, right.violation)) return false;
            }
            return true;
        }

        public Set<PfecPartitionSnapshot.PairKey> changedIds(Evaluation other) {
            Set<PfecPartitionSnapshot.PairKey> ids = new HashSet<>(states.keySet());
            ids.addAll(other.states.keySet());
            Set<PfecPartitionSnapshot.PairKey> changed = new HashSet<>();
            for (PfecPartitionSnapshot.PairKey id : ids) {
                State left = states.get(id);
                State right = other.states.get(id);
                if (left == null || right == null || left.safe != right.safe
                        || !ReachabilityPropertySet.equivalent(
                                left.reachable, right.reachable)
                        || !ReachabilityPropertySet.equivalent(
                                left.violation, right.violation)) {
                    changed.add(id);
                }
            }
            return changed;
        }

        public Evaluation updatedWith(Evaluation changes) {
            Map<PfecPartitionSnapshot.PairKey, State> updated = new LinkedHashMap<>();
            states.forEach((id, state) -> updated.put(id, state.copy()));
            changes.states.forEach((id, state) -> {
                State previous = updated.put(id, state.copy());
                if (previous != null) previous.close();
            });
            return new Evaluation(updated);
        }

        public boolean isSafe(PfecPartitionSnapshot.PairKey id) {
            State state = states.get(id);
            return state != null && state.safe;
        }

        public int getWitness(PfecPartitionSnapshot.PairKey id) {
            State state = states.get(id);
            return state == null ? NDD.getFalse() : state.violation;
        }

        public int size() { return states.size(); }

        @Override
        public void close() {
            if (closed) return;
            states.values().forEach(State::close);
            closed = true;
        }
    }

    private static final class State implements AutoCloseable {
        private final int reachable;
        private final int violation;
        private final boolean safe;

        private State(int reachable, int violation) {
            this.reachable = reachable;
            this.violation = violation;
            this.safe = NDD.isFalse(violation);
        }

        private State copy() {
            return new State(NDD.ref(reachable), NDD.ref(violation));
        }

        @Override
        public void close() {
            NDD.deref(reachable);
            NDD.deref(violation);
        }
    }
}
