package application.differential.s3;

import controlplane.network.NDDRouter;
import sre.ndd.NDD;

import java.util.Collections;
import java.util.Collection;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

/** Intersects changed forwarding regions with exact old source-arrival regions. */
public final class SpfAffectedSourceProbe {
    private SpfAffectedSourceProbe() { }

    public static Result select(SpfReachabilityIndex oldReachability,
            FibPortSnapshot.ChangedPortRegions changedPorts) {
        return select(oldReachability, changedPorts, Collections.emptyList());
    }

    /**
     * Selects old-path dependencies and conservatively includes sources whose
     * newly reachable paths cannot be represented by the old-path index.
     */
    public static Result select(SpfReachabilityIndex oldReachability,
            FibPortSnapshot.ChangedPortRegions changedPorts,
            Collection<NDDRouter> newlyReachableCandidates) {
        Map<NDDRouter, Integer> affected = new IdentityHashMap<>();
        for (NDDRouter router : changedPorts.getRouters()) {
            for (int changedRegion : changedPorts.getPorts(router).values()) {
                for (Map.Entry<NDDRouter, Integer> arrival
                        : oldReachability.getArrivals(router).entrySet()) {
                    int overlap = NDD.ref(NDD.and(arrival.getValue(), changedRegion));
                    if (NDD.isFalse(overlap)) {
                        NDD.deref(overlap);
                        continue;
                    }
                    Integer previous = affected.putIfAbsent(
                            arrival.getKey(), overlap);
                    if (previous != null) {
                        int merged = NDD.ref(NDD.or(previous, overlap));
                        NDD.deref(previous);
                        NDD.deref(overlap);
                        affected.put(arrival.getKey(), merged);
                    }
                }
            }
        }
        for (NDDRouter source : newlyReachableCandidates) {
            Integer previous = affected.put(source, NDD.ref(NDD.getTrue()));
            if (previous != null) NDD.deref(previous);
        }
        return new Result(affected);
    }

    public static final class Result implements AutoCloseable {
        private final Map<NDDRouter, Integer> affected;
        private boolean closed;

        private Result(Map<NDDRouter, Integer> affected) {
            this.affected = affected;
        }

        public Set<NDDRouter> getSources() {
            return Collections.unmodifiableSet(affected.keySet());
        }

        public int getAffectedSourceCount() {
            return affected.size();
        }

        public int getRegion(NDDRouter source) {
            return affected.getOrDefault(source, NDD.getFalse());
        }

        @Override
        public void close() {
            if (closed) return;
            affected.values().forEach(NDD::deref);
            closed = true;
        }
    }
}
