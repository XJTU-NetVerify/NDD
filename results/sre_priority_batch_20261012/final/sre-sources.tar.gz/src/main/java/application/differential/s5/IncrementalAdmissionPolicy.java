package application.differential.s5;

/** Structural break-even guard evaluated before shadow SPF recomputation. */
public final class IncrementalAdmissionPolicy {
    public static final double MAX_SOURCE_FRACTION = 1.0;
    private static final String SOURCE_FRACTION_PROPERTY =
            "delta.sre.maxIncrementalSourceFraction";
    public static final double MAX_DIRECT_OWNER_FRACTION = 1.0;
    private static final String DIRECT_OWNER_FRACTION_PROPERTY =
            "delta.sre.maxDirectOwnerFraction";

    private IncrementalAdmissionPolicy() { }

    public static boolean accepts(int affectedSources, int totalSources) {
        return acceptsFraction(affectedSources, totalSources);
    }

    public static boolean acceptsAffectedRouters(int affectedRouters,
            int totalRouters) {
        return acceptsFraction(affectedRouters, totalRouters);
    }

    public static boolean acceptsDirectOwners(int directOwners,
            int totalRouters) {
        if (directOwners == 0 || totalRouters == 0) return true;
        return (double) directOwners / totalRouters <= maxDirectOwnerFraction();
    }

    public static double maxSourceFraction() {
        String configured = System.getProperty(SOURCE_FRACTION_PROPERTY);
        return configured == null
                ? MAX_SOURCE_FRACTION
                : Double.parseDouble(configured);
    }

    public static double maxDirectOwnerFraction() {
        String configured = System.getProperty(DIRECT_OWNER_FRACTION_PROPERTY);
        return configured == null
                ? MAX_DIRECT_OWNER_FRACTION
                : Double.parseDouble(configured);
    }

    private static boolean acceptsFraction(int affected, int total) {
        if (affected == 0 || total == 0) return true;
        return (double) affected / total <= maxSourceFraction();
    }
}
