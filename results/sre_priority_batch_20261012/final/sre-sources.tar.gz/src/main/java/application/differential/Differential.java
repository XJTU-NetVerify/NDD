package application.differential;

import bdd.BDDManager;
import multimap.HashBasedTable;
import multimap.Table;
import com.google.gson.stream.JsonWriter;
import controlplane.network.CPExecutor;
import controlplane.network.Router;
import dataplane.analysis.DPAnalyzer;
import main.Configuration;
import main.Controller;
import main.SRELogger;
import main.storage.Storage;
import util.MemorizeUtil;
import util.TimeUtil;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;

public class Differential {
    static {
        Configuration.FILTER = false;
    }

    Path inputBase;
    Path[] snapshots;
    Path outputBase;
    int n;
    int mf;

    public Differential(Path inputBase, Path[] snapshots, int mf) {
        this.inputBase = inputBase;
        this.snapshots = snapshots;
        this.n = snapshots.length;
        this.mf = mf;
    }

    public void run() {
        TimeUtil timer = new TimeUtil();
        timer.begin();
        double t0 = init() / 1e9;
        double t1 = src() / 1e9;
        double t2 = spf() / 1e9;
        double t3 = diff() / 1e9;
        double t4 = t0 + t1 + t2 + t3;
        timer.end(SRELogger.LEVEL.INFO, "mf: "+ mf + " finished");
        printDiff();
        System.out.print(t0 + "\t" + t1 + "\t" + t2 + "\t" + t3 + "\t" + t4 + "\t");
    }

    protected void check(Router r) {
        if (r.getOspfProcesses().values().stream().anyMatch(p -> p.getPrefixes().size() > 0)) {
            Controller.ospfValidRouters.add(r);
        }
        if (r.getBgpProcess().getNetworks().size() > 0) {
            r.getBgpProcess().getNetworks().forEach(prefix -> prefix.setInterested(true));
            Controller.bgpValidRouters.add(r);
        }
    }


    public void getValidRouters() {
        for (CPExecutor cpe : Controller.cpExecutorStack) {
//            cpe.getL3Topology().getKEdgeComponent(mf + 1)
//                    .stream()
//                    .map(Graph::vertexSet)
//                    .filter(set -> set.size() > 1)
//                    .collect(Collectors.toSet())
//                    .forEach(set -> set.forEach(this::check));
            cpe.getRouters().values().forEach(this::check);
        }
    }

    void initOutput() {
        StringBuilder builder = new StringBuilder(snapshots[0].getFileName().toString());
        for (int i = 1; i < n; i++) builder.append("_").append(snapshots[i].getFileName().toString());
        outputBase = Paths.get("output",
                "differential",
                inputBase.getFileName().toString(),
                builder.toString(),
                Storage.TODAY);
    }

    public long init() {
        long start = System.nanoTime();
        initOutput();
        for (Path snapshot : snapshots) {
            Storage storage = new Storage(snapshot, outputBase.resolve(snapshot.getFileName()));
            storage.output._log = outputBase.resolve("log" + mf + ".txt");
            Controller.pushStorage(storage);
            Controller.pushCPExecutor(new CPExecutor());
            Controller.cpExecutor.init();
            Controller.pushDPAnalyzer(new DPAnalyzer());
        }
        Controller.pushMF(mf);
        getValidRouters();
        Controller.pushBDDManager(new BDDManager());
        return System.nanoTime() - start;
    }

    public long src() {
        long start = System.nanoTime();
        for (int i = 0; i < n; i++) {
            Controller.cpExecutor.generateDataPlane();
//            MemorizeUtil.printRIB();
            Controller.popStorage();
            Controller.popCPExecutor();
        }
        return System.nanoTime() - start;
    }

    public long spf() {
        long start = System.nanoTime();
        for (int i = 0; i < n; i++) {
            Controller.dpAnalyzer.analyzeDataPlane(Controller.cpExecutor.getEdgeRouters());
            Controller.popStorage();
            Controller.popCPExecutor();
            Controller.popDPAnalyzer();
        }
        return System.nanoTime() - start;
    }

    Table<String, String, int[]> stpTable;
    Table<String, String, Diff[]> diffTable;

    public long diff() {
        long start = System.nanoTime();
        stpTable = HashBasedTable.create();
        for (int i = 0; i < n; i++) {
            HashSet<Router> edgeRouters = Controller.cpExecutorStack.get(i).getEdgeRouters();
            for (Table.Cell<Router, Router, Integer> cell : Controller.dpAnalyzerStack.get(i)._reachabilityDB.getAllPairReachability().cellSet()) {
                if (edgeRouters.contains(cell.getRowKey()) && edgeRouters.contains(cell.getColumnKey())) {
                    String src = Objects.requireNonNull(cell.getRowKey()).getRouterName();
                    String dst = Objects.requireNonNull(cell.getColumnKey()).getRouterName();
                    int[] stpList;
                    if (stpTable.contains(src, dst)) {
                        stpList = stpTable.get(src, dst);
                    } else {
                        stpList = new int[n];
                    }
                    stpList[i] = Objects.requireNonNull(cell.getValue());
                    stpList[i] = Controller.bddManager.and(stpList[i], cell.getColumnKey().getPrefixBDD());
                    stpTable.put(src, dst, stpList);
                }
            }
        }
        diffTable = HashBasedTable.create();
        stpTable.cellSet()
                .stream()
                .filter(cell -> Arrays.stream(cell.getValue()).anyMatch(stp -> stp != Objects.requireNonNull(cell.getValue())[0]))
                .forEach(cell -> {
                    int[] stpList = cell.getValue();
                    Diff[] diffList = new Diff[n - 1];
                    for (int i = 0; i < n - 1; i++) diffList[i] = new Diff(stpList[i + 1], stpList[i]);
                    diffTable.put(Objects.requireNonNull(cell.getRowKey()), Objects.requireNonNull(cell.getColumnKey()), diffList);
                });
        return System.nanoTime() - start;
    }

    public void printDiff() {
        try {
            File file = outputBase.resolve("diff" + mf + ".json").toFile();
            if (!file.exists()) MemorizeUtil.creatFileIfAbsent(file);
            JsonWriter diffWriter = new JsonWriter(new FileWriter(file));
            diffWriter.setIndent(" ");
            diffWriter.beginObject();
            diffWriter.name("reachability_diffs");
            diffWriter.beginArray();
            for (String src : diffTable.rowKeySet()) {
                for (String dst : diffTable.row(src).keySet()) {
                    int[] stps = stpTable.get(src, dst);
                    diffWriter.beginObject();
                    diffWriter.name("src");
                    diffWriter.value(src);
                    diffWriter.name("dst");
                    diffWriter.value(dst);
                    diffWriter.name("symbolic_topo_packets");
                    diffWriter.beginArray();
                    for (int i : stps) diffWriter.value(i);
                    diffWriter.endArray();
                    diffWriter.name("diffs");
                    diffWriter.beginArray();
                    for (Diff diff : diffTable.get(src, dst)) {
                        diff.visualizeDiff(diffWriter);
                    }
                    diffWriter.endArray();
                    diffWriter.endObject();
                }
            }
            diffWriter.endArray();
            diffWriter.endObject();
            diffWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Path inputBase = Paths.get(args[0]);
        int n = args.length - 1;
        Path[] snapshots = new Path[n - 1];
        for (int i = 1; i < n; i++) {
            snapshots[i - 1] = inputBase.resolve(args[i]);
            System.out.print(snapshots[i - 1].getFileName().toString() + "\t");
        }
        int mf = Integer.parseInt(args[n]);
        Differential differential = new Differential(inputBase, snapshots, mf);
        differential.run();
        System.out.print("\n");
    }
}
