package application.singleprefix;

import bdd.BDDManager;
import controlplane.network.CPExecutor;
import controlplane.network.Router;
import dataplane.analysis.DPAnalyzer;
import main.Configuration;
import main.Controller;
import main.SRELogger;
import main.storage.Storage;
import org.jgrapht.Graph;
import util.TimeUtil;

import java.nio.file.Path;
import java.nio.file.Paths;

public class SinglePrefix {
    public static Path inputBase, outputBase;
    public static boolean PREFIX_TRIM = false;
    public static int ROUTE_FILTER_MF;
    public static int PREFIX_FILTER_MF;
    public static String destination;

    public static void getValidRouter() {
        Router dst = Controller.cpExecutor.getRouters().get(destination);
        if (
                !PREFIX_TRIM
                || Controller.cpExecutor.getL3Topology().getKEdgeComponent(PREFIX_FILTER_MF + 1)
                        .stream()
                        .map(Graph::vertexSet)
                        .anyMatch(set -> set.contains(dst) && set.size() > 1)
        ) {
            Controller.bgpValidRouters.add(dst);
        }
    }

    public static void run() {
        Configuration.FILTER = false;
        Configuration.SORT_METHOD = Configuration.LinkVarSortMethod.PROPAGATION;

        TimeUtil timer = new TimeUtil();
        timer.begin();

        long start, end;

        /* Set up Storage */
        Controller.pushStorage(new Storage(inputBase, outputBase));

        /* Set up CPExecutor */
        CPExecutor cpExecutor = new CPExecutor();
        Controller.pushCPExecutor(cpExecutor);
        Controller.cpExecutor.init();

        /* Set MF */
        Controller.pushMF(ROUTE_FILTER_MF);

        getValidRouter();

        /* Set up BDDManager */
        start = System.nanoTime();
        Controller.pushBDDManager(new BDDManager());
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* SRC */
        start = System.nanoTime();
        Controller.generateDataPlane();
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* SPF */
        start = System.nanoTime();
        Controller.pushDPAnalyzer(new DPAnalyzer());
        Controller.analyzeDataPlane(Controller.cpExecutor.getEdgeRouters());
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");

        /* FPA */
        start = System.nanoTime();
        Controller.mineSpecification(null);
        end = System.nanoTime();
        System.out.print((end - start) / 1e9 + "\t");


        timer.end(SRELogger.LEVEL.INFO, "mf: "+ ROUTE_FILTER_MF + " finished");
    }

    public static void main(String[] args) {
        long start = System.nanoTime();

        inputBase = Paths.get(args[0]);
        outputBase = Paths.get(args[1]);
        ROUTE_FILTER_MF = Integer.parseInt(args[2]);
        PREFIX_FILTER_MF = Integer.parseInt(args[3]);
        PREFIX_TRIM = PREFIX_FILTER_MF >= 0;
        destination = args[4];

        String[] params = {
                inputBase.getFileName().toString(),
                args[2],
                args[3],
                args[4]
        };
        System.out.print(String.join("\t", params) + "\t");

        SinglePrefix.run();

        System.out.print((System.nanoTime() - start) / 1e9 + "\n");
    }
}
