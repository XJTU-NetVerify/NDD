package dataplane.fib;

import sre.ndd.NDD;
import datamodel.ipv4.Ip;
import controlplane.network.PortName;
import controlplane.route.NDDRoute;
import controlplane.route.Route;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import main.Controller;
import org.jetbrains.annotations.NotNull;
import util.BDDUtil;
import util.NDDUtil;
import util.NameUtil;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class NDDForwardingRule implements NDDSortedMultiListItem {
    Prefix prefix;
    Ip nextHop;
    PortName outPort;

    int arriveTC;
    int listTC;
    int innerIdx = -1;
    int outerIdx = -1;
    NDDSortedMultiList list = null;
    private boolean nddOwnershipReleased;

    public NDDForwardingRule(NDDRoute route) {
        this.boundedBudget = route.getBoundedBudget();
        this.prefix = route.getPrefix();
        this.nextHop = route.getNextHop();
        this.outPort = route.getOutPort().getPortName();
        this.arriveTC = NDD.ref(route.getListTC());
        this.listTC = NDD.ref(route.getListTC());
    }

    public NDDForwardingRule(Ip nextHop, List<NDDRoute> routes) {
        this.prefix = routes.get(0).getPrefix();
        this.nextHop = nextHop;
        this.outPort = routes.get(routes.size() - 1).getOutPort().getPortName();
        this.arriveTC = NDDUtil.andInBatch(routes.stream().map(NDDRoute::getListTC).collect(Collectors.toSet()));
    }

    public Prefix getPrefix() {
        return prefix;
    }

    public Ip getNextHop() {
        return nextHop;
    }

    public PortName getOutPort() {
        return outPort;
    }

    @Override
    public void setList(NDDSortedMultiList list) {
        this.list = list;
    }

    @Override
    public NDDSortedMultiList getList() {
        return list;
    }

    @Override
    public void setOuterIdx(int idx) {
        this.outerIdx = idx;
    }

    @Override
    public int getOuterIdx() {
        return outerIdx;
    }

    @Override
    public void setInnerIdx(int idx) {
        this.innerIdx = idx;
    }

    @Override
    public int getInnerIdx() {
        return innerIdx;
    }

    @Override
    public void setListTC(int tc) {
        boundedBudget = -1;
        NDD.deref(listTC);
        listTC = tc;
    }

    private int boundedBudget = -1;
    /** Called by the priority selector after intersecting its result with budget. */
    public void markBudgetBounded(int budget) { boundedBudget = budget; }
    @Override public int getBoundedBudget() { return boundedBudget; }
    public boolean isBudgetBounded(int budget) { return boundedBudget == budget; }

    @Override
    public int getListTC() {
        return listTC;
    }

    @Override
    public void setArriveTC(int tc) {
        NDD.deref(arriveTC);
        arriveTC = tc;
    }

    @Override
    public int getArriveTC() {
        return arriveTC;
    }

    /** Release the two symbolic roots owned by this detached rule. */
    public void releaseNddOwnership() {
        if (nddOwnershipReleased) return;
        NDD.deref(arriveTC);
        NDD.deref(listTC);
        nddOwnershipReleased = true;
    }

    @Override
    public boolean isDead() {
        return NDD.isFalse(arriveTC) || NDD.isFalse(listTC);
    }

    @Override
    public String toString() {
        return prefix.toString() + '\t' + nextHop.toString() + "\t" + outPort.getInterfaceName();
    }

    @Override
    public int compareTo(@NotNull NDDSortedMultiListItem another) {
        if (!(another instanceof NDDForwardingRule)) {
            throw new IllegalArgumentException();
        }
        return Comparator.comparing(NDDForwardingRule::getPrefix)
                .thenComparing(NDDForwardingRule::getNextHop)
                .thenComparing(NDDForwardingRule::getOutPort)
                .compare(this, (NDDForwardingRule) another);
    }

    public static String[] CSV_HEADER = { "router", "vrf", "prefix", "out port", "next hop" };

    public String[] toCsvString() {
        String[] hostVrf = NameUtil.splitHostVrf(outPort.getRouterName());
        return new String[] {
                hostVrf[0],
                hostVrf[1],
                prefix.toString(),
                outPort.getInterfaceName().equals("blackhole") ? null : outPort.getInterfaceName(),
                nextHop.toString(),
        };
    }
}
