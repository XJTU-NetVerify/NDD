package dataplane.analysis;

import bdd.BDDTuple;
import multimap.HashBasedTable;
import multimap.HashMultimap;
import multimap.Multimap;
import multimap.Table;
import controlplane.network.Port;
import controlplane.network.Router;
import main.Configuration;
import main.Controller;
import util.BDDUtil;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Objects;
import java.util.Vector;
import java.util.stream.Collectors;

import application.config2spec.Config2spec;

public class ReachabilityDB {
    public Table<Router, Router, HashSet<ReachabilityNode>> reachabilityForest;
    private Table<Router, Router, Integer> allPairReachability;
    public Table<Router, Router, Integer> pfecNums;
    public HashMap<Router, Integer> fwdPathNums;
    public Multimap<Port, ReachabilityNode> in;
    public Multimap<Port, ReachabilityNode> out;

    public ReachabilityDB() {
        reachabilityForest = HashBasedTable.create();
        // allPairReachability = HashBasedTable.create();
        pfecNums = HashBasedTable.create();
        fwdPathNums = new HashMap<>();
        in = HashMultimap.create();
        out = HashMultimap.create();
    }

    private void insertNode(Router src, Router dst, ReachabilityNode node) {
        if (reachabilityForest.contains(src, dst)) {
            HashSet<ReachabilityNode> set = reachabilityForest.get(src, dst);
            set.add(node);
            reachabilityForest.put(src, dst, set);

            // allPairReachability.put(src, dst,
            // Controller.bddManager.orTo(allPairReachability.get(src, dst),
            // node.tuple.getBDD()));

            int pfecN = pfecNums.get(src, dst);
            pfecNums.put(src, dst, pfecN + 1);
        } else {
            HashSet<ReachabilityNode> set = new HashSet<>();
            set.add(node);
            reachabilityForest.put(src, dst, set);

            // allPairReachability.put(src, dst,
            // Controller.bddManager.ref(node.tuple.getBDD()));

            pfecNums.put(src, dst, 1);
        }
    }

    public Table<Router, Router, Integer> getAllPairReachability() {
        if (allPairReachability == null) {
            allPairReachability = HashBasedTable.create();
            for (Table.Cell<Router, Router, HashSet<ReachabilityNode>> cell : reachabilityForest.cellSet()) {
                int stp = BDDUtil.orInBatch(
                        Controller.bddManager.getBDD(),
                        Objects.requireNonNull(cell.getValue())
                                .stream()
                                .map(node -> node.getTuple().getBDD())
                                .collect(Collectors.toSet()));
                allPairReachability.put(
                        Objects.requireNonNull(cell.getRowKey()),
                        Objects.requireNonNull(cell.getColumnKey()),
                        stp);
            }
        }
        return allPairReachability;
    }

    public void buildReachabilityTree(Router root) {
        if (Configuration.FORWARD)
            buildReachabilityTree(root, BDDTuple.FULL);
        else
            buildReachabilityTree(root, new BDDTuple(root.getPrefixBDD(), 1));
    }

    public void buildReachabilityTree(Router root, BDDTuple tuple) {
        ReachabilityNode node = new ReachabilityNode(root, tuple, new Vector<>());
        if (Configuration.FORWARD)
            traverseForward(root, node);
        else
            traverseBackward(root, node);
    }

    private void traverseForward(Router root, ReachabilityNode curNode) {
        boolean terminate = true;
        for (Port port : curNode.router.getPorts().values()) {
            ReachabilityNode nxtNode = forward(root, curNode, port);
            if (nxtNode != null) {
                terminate = false;
                traverseForward(root, nxtNode);
            }
        }
        if (terminate)
            fwdPathNums.put(root, fwdPathNums.getOrDefault(root, 0) + 1);
    }

    private void traverseBackward(Router root, ReachabilityNode curNode) {
        boolean terminate = true;
        for (Port port : curNode.router.getPorts().values()) {
            ReachabilityNode nxtNode = backward(root, curNode, port);
            if (nxtNode != null) {
                terminate = false;
                traverseBackward(root, nxtNode);
            }
        }
        if (terminate)
            fwdPathNums.put(root, fwdPathNums.getOrDefault(root, 0) + 1);
    }

    public void buildReachabilityTreeLazy(Router root) {
        buildReachabilityTreeLazy(root, BDDTuple.FULL);
    }

    public void buildReachabilityTreeLazy(Router root, BDDTuple tuple) {
        ReachabilityNode node = new ReachabilityNode(root, tuple, new Vector<>());
        traverseLazy(root, node, tuple);
    }

    HashSet<Router> hs = new HashSet<>();

    private void traverseLazy(Router root, ReachabilityNode curNode, BDDTuple tuple) {
        if (!hs.contains(curNode.router)) {
            DPAnalyzer.computeFwdBDD(curNode.router, tuple.getFirst());
            DPAnalyzer.computeAclBDD(curNode.router);
            hs.add(curNode.router);
        }
        for (Port port : curNode.router.getPorts().values()) {
            ReachabilityNode nxtNode;
            if (Configuration.FORWARD)
                nxtNode = forward(root, curNode, port);
            else
                nxtNode = backward(root, curNode, port);
            if (nxtNode != null)
                traverseLazy(root, nxtNode, tuple);
        }
    }

    private ReachabilityNode forward(Router root, ReachabilityNode curNode, Port outPort) {
        if (outPort.isEdge()) {
            BDDTuple finalTuple = BDDTuple.intersect(curNode.tuple, outPort.getPortFwdBDD(),
                    outPort.getPortAclOutBDD());
            if (!finalTuple.isEmpty()) {
                Router finalRouter = outPort.getRouter();
                Vector<Router> finalPath = new Vector<>(curNode.path);
                finalPath.add(finalRouter);
                ReachabilityNode finalNode = new ReachabilityNode(finalRouter, outPort, finalTuple, finalPath);
                insertNode(root, outPort.getRouter(), finalNode);
                out.put(outPort, finalNode);
            }
            return null;
        } else if (outPort.isBlackhole()) {
            return null;
        } else {
            Port nxtPort = outPort.getLinkedPort();
            if (nxtPort == null)
                return null;

            BDDTuple newTuple = BDDTuple.intersect(curNode.tuple, outPort.getPortFwdBDD(), 1);
            newTuple = BDDTuple.intersect(newTuple, 1, outPort.getPortAclOutBDD()); // ACLout
            newTuple = BDDTuple.intersect(newTuple, 1, nxtPort.getPortAclInBDD()); // ACLin
            if (newTuple.isEmpty())
                return null;

            Router nxtRouter = nxtPort.getRouter();

            Vector<Router> newPath = new Vector<>(curNode.path);
            newPath.add(curNode.router);

            ReachabilityNode nxtNode = new ReachabilityNode(nxtRouter, newTuple, newPath);

            if (nxtNode.isLoopDetected)
                return null;

            out.put(outPort, nxtNode);
            in.put(nxtPort, nxtNode);

            return nxtNode;
        }
    }

    @Deprecated
    private ReachabilityNode backward(Router root, ReachabilityNode curNode, Port inPort) {
        Port prePort = inPort.getLinkedPort();
        if (prePort == null)
            return null;

        Router preRouter = prePort.getRouter();

        Vector<Router> newPath = new Vector<>(curNode.path);
        newPath.add(curNode.router);

        BDDTuple newTuple = BDDTuple.intersect(curNode.tuple, prePort.getPortFwdBDD(), 1);
        newTuple = BDDTuple.intersect(newTuple, 1, prePort.getPortAclOutBDD()); // ACLout
        newTuple = BDDTuple.intersect(newTuple, 1, inPort.getPortAclInBDD()); // ACLin
        if (newTuple.isEmpty()) {
            fwdPathNums.put(root, fwdPathNums.getOrDefault(root, 0) + 1);
            return null;
        }

        ReachabilityNode nxtNode = new ReachabilityNode(preRouter, newTuple, newPath);

        if (nxtNode.isLoopDetected) {
            fwdPathNums.put(root, fwdPathNums.getOrDefault(root, 0) + 1);
            return null;
        }

        in.put(inPort, nxtNode);
        out.put(prePort, nxtNode);

        insertNode(preRouter, root, nxtNode);

        return nxtNode;
    }

    public int getNumOfPFEC() {
        return pfecNums.values().stream().reduce(0, Integer::sum);
    }

    public int getNumOfFwdPath() {
        return fwdPathNums.values().stream().reduce(0, Integer::sum);
    }

    public void clear() {
        reachabilityForest = null;
        allPairReachability = null;
        pfecNums = null;
        fwdPathNums = null;
        in = null;
        out = null;
    }

    public void reset() {
        reachabilityForest = HashBasedTable.create();
        allPairReachability = HashBasedTable.create();
        pfecNums = HashBasedTable.create();
        fwdPathNums = new HashMap<>();
        in = HashMultimap.create();
        out = HashMultimap.create();
    }

    public void printReachability() {
        System.out.println("print reach");
        getAllPairReachability();
        try {
            FileWriter fw = new FileWriter(
                    "/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/exp/fattree/bgp/" + Config2spec.dataset + "/OutBDD/test/src_reach",
                    false);
            PrintWriter pw = new PrintWriter(fw);
            pw.println("check reachability");
            for (Router src : allPairReachability.rowKeySet()) {
                pw.println("row");
                for (Router dst : allPairReachability.columnKeySet()) {
                    pw.println("col");
                    if (allPairReachability.contains(src, dst)) {
                        int packets = allPairReachability.get(src, dst);
                        pw.println("========= check 1 =========");
                        pw.println(src.getRouterName() + " " + dst.getRouterName() + " "
                                + Controller.bddManager.getBDD().satCount(packets));
                        pw.flush();
                    }
                }
            }
            pw.close();
        } catch (IOException e) {
            // TODO: handle exception
        }
    }
}
