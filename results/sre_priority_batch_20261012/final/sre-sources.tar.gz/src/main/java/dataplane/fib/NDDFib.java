package dataplane.fib;

import controlplane.network.NDDRouter;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.SortedMultiList;

import java.util.Map;
import java.util.TreeMap;

public class NDDFib {
    NDDRouter router;
    Map<Prefix, NDDSortedMultiList> rules;

    public NDDFib(NDDRouter router) {
        this.router = router;
        this.rules = new TreeMap<>();
    }

    public void insert(Prefix prefix, NDDSortedMultiList list) {
        rules.put(prefix, list);
    }

    public NDDSortedMultiList remove(Prefix prefix) {
        return rules.remove(prefix);
    }

    public NDDRouter getRouter() {
        return router;
    }

    public Map<Prefix, NDDSortedMultiList> getFib() {
        return rules;
    }

    public Map<Prefix, NDDSortedMultiList> detachRules() {
        Map<Prefix, NDDSortedMultiList> detached = rules;
        rules = new TreeMap<>();
        return detached;
    }

    public void attachRules(Map<Prefix, NDDSortedMultiList> detached) {
        if (!rules.isEmpty()) {
            throw new IllegalStateException("FIB is not empty");
        }
        rules = detached;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        rules.values().forEach(list -> builder.append(list.toString()).append("\n\n"));
        return builder.toString();
    }

    public void clear() {
        rules = null;
    }

    public void reset() {
        rules = new TreeMap<>();
    }
}
