package dataplane.analysis;

import bdd.BDDTuple;
import controlplane.network.Port;
import controlplane.network.Router;

import java.util.Objects;
import java.util.Vector;

public class ReachabilityNode {
    Router router;
    Port outPort;
    BDDTuple tuple;
    Vector<Router> path;
    boolean isLoopDetected;

    public ReachabilityNode(Router router, BDDTuple tuple, Vector<Router> path) {
        this.router = router;
        this.tuple = tuple;
        this.path = path;
        detectLoop();
    }

    public ReachabilityNode(Router router, Port outPort, BDDTuple tuple, Vector<Router> path) {
        this.router = router;
        this.outPort = outPort;
        this.tuple = tuple;
        this.path = path;
    }

    private void detectLoop() {
        isLoopDetected = false;
        for (Router r : path) {
            if (r == router) {
                isLoopDetected = true;
                break;
            }
        }
    }

    public BDDTuple getTuple() {
        return tuple;
    }

    public Router getRouter() {
        return router;
    }

    public Port getOutPort() {
        return outPort;
    }

    public Vector<Router> getPath() {
        return path;
    }

    public boolean isLoopDetected() {
        return isLoopDetected;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReachabilityNode that = (ReachabilityNode) o;
        return isLoopDetected == that.isLoopDetected &&
                Objects.equals(outPort, that.outPort) &&
                Objects.equals(tuple, that.tuple) &&
                Objects.equals(path, that.path);
    }

    @Override
    public int hashCode() {
        return Objects.hash(outPort, tuple, path, isLoopDetected);
    }
}
