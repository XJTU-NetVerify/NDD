package dataplane.analysis;

import sre.ndd.NDD;
import application.config2spec.NDDConfig2spec;
import bdd.*;
import multimap.HashBasedTable;
import multimap.Table;
import controlplane.network.NDDRouter;
import controlplane.network.Router;
import datamodel.ipv4.Header;
import datamodel.ipv4.Prefix;
import datamodel.property.*;
import jdd.bdd.BDDIO;
import main.Controller;
import main.NDDController;
import util.BDDUtil;
import util.MemorizeUtil;
import util.NDDUtil;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class NDDSpecificationDB {
    NDDReachabilityDB reachabilityDB;

    public NDDSpecificationDB(NDDReachabilityDB reachabilityDB) {
        this.reachabilityDB = reachabilityDB;
    }

    Set<NDDProperty> reachabilitySet;
    Set<NDDProperty> blockSet;
    Set<NDDProperty> loadBalancingSet;
    Set<NDDProperty> waypointSet;

    public void mine(Collection<NDDRouter> waypoints) {
        if (NDDConfig2spec.reach && reachabilitySet == null) {
            mineReachability();
            MemorizeUtil.printNDDSpecifications(reachabilitySet, Property.Type.REACHABILITY);
        }
        if (NDDConfig2spec.block && blockSet == null) {
            mineBlock();
            // MemorizeUtil.printNDDSpecifications(blockSet, Property.Type.BLOCK);
        }
        if (NDDConfig2spec.loadbalancing && loadBalancingSet == null) {
            mineLoadBalancing();
            // MemorizeUtil.printNDDSpecifications(loadBalancingSet,
            // Property.Type.LOAD_BALANCING);
        }
        if (NDDConfig2spec.waypoint) {
            mineWaypoint(waypoints);
            // MemorizeUtil.printNDDSpecifications(waypointSet, Property.Type.WAYPOINT);
        }
    }

    public void printReachability() {
        System.out.println("print mine reach");
        try {
            // FileWriter fw = new
            // FileWriter("/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/exp/fattree/bgp/"+NDDConfig2spec.dataset+"/OutNDD/test/mine_reach",
            // false);
            FileWriter fw = new FileWriter("/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/exp/fattree/bgp/" + NDDConfig2spec.dataset
                    + "/OutBddVector/test/mine_reach", false);
            PrintWriter pw = new PrintWriter(fw);
            for (NDDProperty p : reachabilitySet) {
                pw.println("========= check 2 =========");
                pw.println(((NDDReachability) p).toString());
                pw.flush();
            }
            pw.close();
        } catch (IOException e) {
            // TODO: handle exception
        }
    }

    public Set<NDDProperty> mineReachability() {
        NDDManager manager = NDDController.bddManager;
        NDDPredicateWrapper predicateWrapper = manager.getBDDPredicateWrapper();
        NDDTCWrapper tcWrapper = manager.getBDDTCWrapper();

        reachabilitySet = new HashSet<>();
        reachabilityDB.getAllPairReachability().cellSet().forEach(cell -> {
            NDDRouter src = Objects.requireNonNull(cell.getRowKey());
            NDDRouter dst = Objects.requireNonNull(cell.getColumnKey());
            if (src != dst) {
                predicateWrapper.splitHeaderTC(Objects.requireNonNull(cell.getValue()))
                        .forEach((header, tc) -> {
                            Flow flow = new Flow(header, src.getRouterName());
                            NDDReachability reachability = new NDDReachability(flow, dst.getRouterName());
                            reachability.setTC(tc);
                            reachability.setMF(tcWrapper.getTCFailureMax(tc));
                            reachabilitySet.add(reachability);
                        });
            }
        });
        return reachabilitySet;
    }

    public Set<NDDProperty> mineBlock() {
        NDDManager manager = NDDController.bddManager;
        NDDPredicateWrapper predicateWrapper = manager.getBDDPredicateWrapper();
        NDDTCWrapper tcWrapper = manager.getBDDTCWrapper();

        Table<NDDRouter, NDDRouter, Integer> table = reachabilityDB.getAllPairReachability();
        Map<String, NDDRouter> routers = NDDController.cpExecutor.getRouters();
        blockSet = new HashSet<>();
        for (NDDRouter src : routers.values()) {
            for (NDDRouter dst : routers.values()) {
                if (src != dst) {
                    int tmp = dst.getPrefixBDD();
                    if (table.contains(src, dst))
                        tmp = NDD.ref(NDD.diff(tmp, table.get(src, dst)));
                    predicateWrapper.splitHeaderTC(tmp)
                            .forEach((header, tc) -> {
                                Flow flow = new Flow(header, src.getRouterName());
                                NDDBlock block = new NDDBlock(flow);
                                block.setTC(tc);
                                block.setMF(tcWrapper.getTCFailureMax(tc));
                                blockSet.add(block);
                            });
                }
            }
        }
        return blockSet;
    }

    // TODO we need to consider edge-disjoint/node-disjoint
    public Set<NDDProperty> mineLoadBalancing() {
        NDDManager manager = NDDController.bddManager;
        NDDPredicateWrapper predicateWrapper = manager.getBDDPredicateWrapper();
        NDDTCWrapper tcWrapper = manager.getBDDTCWrapper();

        loadBalancingSet = new HashSet<>();
        reachabilityDB.reachabilityForest.rowMap().forEach((src, tree) -> tree.forEach((dst, set) -> {
            if (dst != src && set.size() >= 2) {
                Table<Header, NDDReachabilityNode, Integer> table = HashBasedTable.create();
                set.forEach(node -> predicateWrapper.splitHeaderTC(node.getTuple().getNDD())
                        .forEach((header, tc) -> table.put(header, node, tc)));
                table.rowMap().forEach((header, node2tc) -> {
                    int s = node2tc.size();
                    if (s >= 2) {
                        int[] notTC = new int[s];
                        int i = 0;
                        for (int tc : node2tc.values()) {
                            notTC[i++] = NDD.ref(NDD.not(tc));
                        }
                        int[] hs = new int[s + 1];
                        hs[s] = NDDUtil.andInBatch(notTC);
                        for (int j = 0; j < s; j++) {
                            int tmp = notTC[j];
                            notTC[j] = NDD.ref(NDD.not(tmp));
                            hs[j] = NDDUtil.andInBatch(notTC);
                            NDD.deref(notTC[j]);
                            notTC[j] = tmp;
                        }
                        int tc = manager.filter(NDD.ref(NDD.not(NDDUtil.orInBatch(hs))));
                        if (!NDD.isFalse(tc)) {
                            Flow flow = new Flow(header, src.getRouterName());
                            NDDLoadBalancing loadBalancing = new NDDLoadBalancing(flow);
                            loadBalancing.setTC(tc);
                            loadBalancing.setMF(tcWrapper.getTCFailureMax(tc));
                            loadBalancingSet.add(loadBalancing);
                        }
                        NDDUtil.derefInBatch(notTC);
                    }
                });
            }
        }));
        return loadBalancingSet;
    }

    public Set<NDDProperty> mineWaypoint(Collection<NDDRouter> waypoints) {
        if (waypoints == null || waypoints.isEmpty())
            return null;
        NDDManager manager = NDDController.bddManager;
        NDDPredicateWrapper predicateWrapper = manager.getBDDPredicateWrapper();
        NDDTCWrapper tcWrapper = manager.getBDDTCWrapper();

        waypointSet = new HashSet<>();
        reachabilityDB.reachabilityForest.rowMap().forEach((src, tree) -> tree.forEach((dst, nodes) -> {
            HashMap<NDDRouter, Integer> map = new HashMap<>();
            waypoints.forEach(point -> map.put(point, NDD.getFalse()));
            nodes.forEach(node -> {
                HashSet<NDDRouter> candidates = new HashSet<>(node.getPath());
                candidates.retainAll(waypoints);
                candidates.remove(src);
                candidates.forEach(candidate -> map.put(candidate, NDD.orTo(map.get(candidate), node.tuple.getNDD())));
            });
            map.forEach((point, bdd) -> {
                if (!NDD.isFalse(bdd)) {
                    predicateWrapper.splitHeaderTC(bdd).forEach((header, tc) -> {
                        Flow flow = new Flow(header, src.getRouterName());
                        NDDWaypoint waypoint = new NDDWaypoint(flow, point.getRouterName());
                        waypoint.setTC(tc);
                        waypoint.setMF(tcWrapper.getTCFailureMax(tc));
                        waypointSet.add(waypoint);
                    });
                }
            });
        }));
        return waypointSet;
    }
}
