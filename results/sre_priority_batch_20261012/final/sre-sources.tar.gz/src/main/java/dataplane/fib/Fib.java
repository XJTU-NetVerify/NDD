package dataplane.fib;

import controlplane.network.Router;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;

import java.util.Map;
import java.util.TreeMap;

public class Fib {
    Router router;
    Map<Prefix, SortedMultiList> rules;

    public Fib(Router router) {
        this.router = router;
        this.rules = new TreeMap<>();
    }

    public void insert(Prefix prefix, SortedMultiList list) {
        rules.put(prefix, list);
    }

    public Router getRouter() {
        return router;
    }

    public Map<Prefix, SortedMultiList> getFib() {
        return rules;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        rules.values().forEach(list -> builder.append(list.toString()).append("\n\n"));
        return builder.toString();
    }

    public void clear() {
        rules = null;
    }

    public void reset() {
        rules = new TreeMap<>();
    }
}
