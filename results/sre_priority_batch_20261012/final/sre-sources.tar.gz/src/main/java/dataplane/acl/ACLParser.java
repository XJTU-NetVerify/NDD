/*
 * Atomic Predicates Verifier
 * 
 * Copyright (c) 2013 UNIVERSITY OF TEXAS AUSTIN. All rights reserved. Developed
 * by: HONGKUN YANG and SIMON S. LAM http://www.cs.utexas.edu/users/lam/NRL/
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimers.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimers in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. Neither the name of the UNIVERSITY OF TEXAS AUSTIN nor the names of the
 * developers may be used to endorse or promote products derived from this
 * Software without specific prior written permission.
 * 
 * 4. Any report or paper describing results derived from using any part of this
 * Software must cite the following publication of the developers: Hongkun Yang
 * and Simon S. Lam, Real-time Verification of Network Properties using Atomic
 * Predicates, IEEE/ACM Transactions on Networking, April 2016, Volume 24, No.
 * 2, pages 887-900 (first published March 2015, Digital Object Identifier:
 * 10.1109/TNET.2015.2398197).
 * 
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS WITH
 * THE SOFTWARE.
 */

package dataplane.acl;

import java.util.*;

/**
 * Helper functions to process ACL rules.
 * 
 * Some functions are taken from E. G. W. W. Wong. Validating Network Security
 * Policies Via Static Analysis of Router ACL Configuration (Thesis, Naval 
 * Postgraduate School, December 2006). https://calhoun.nps.edu/handle/10945/2426
 */
public class ACLParser {

	public static enum ACLType{
		standard, extend
	}

	public static void getArgument(Scanner tokenInline, ArrayList<String> argument) {
		argument.clear();
		while(tokenInline.hasNext()) {
			argument.add(tokenInline.next());
		}
	}

	/**
	 * aclNumbers[0] -- previous acl number
	 * aclNumbers[1] -- current acl number
	 * return true the acl is valid
	 * return false the acl is invalid
	 * */
	public static boolean checkValidACL(ArrayList<String> argument, int[] aclNumbers) {
		try {
			if(aclNumbers[0] == -1) {
				aclNumbers[0] = Integer.parseInt(argument.get(0));
				aclNumbers[1] = aclNumbers[0];
				argument.remove(0);
			}
			else {
				aclNumbers[1] = Integer.parseInt(argument.get(0));
				argument.remove(0);
			}
		} catch(NumberFormatException e) {
			//the acl rule is not valid
			return false;
		}

		return !argument.get(0).equals("remark");
	}

	public static void addDynamic(ACLRule oneRule, ArrayList<String> argument) {
		if (argument.get(0).equals ("dynamic")) {
			oneRule.dynamic="dynamic";
			argument.remove(0);
			oneRule.dynamicName=argument.get(0);
			argument.remove(0);
		}
	}

	public static void checkPermitDeny(ACLRule oneRule, ArrayList<String> argument) {
		if(argument.get(0).equals("permit")) {
			oneRule.permitDeny = "permit";
		}
		else {
			oneRule.permitDeny = "deny";
		}
		argument.remove(0); 
	}

	public static void handleACLRuleStandard(ACLRule oneRule, ArrayList<String> argument) {
		// acl number has been removed.
		// the first argument is the ip address
		if(argument.get(0).equals("host")) {
			argument.remove(0);
		}

		oneRule.source = argument.get(0);
		argument.remove(0);
		if(!argument.isEmpty()) {
			if(!argument.get(0).equals("log")){
				oneRule.sourceWildcard = argument.get(0);
			}
		}

	}

	public static void handleACLRuleExtend(ACLRule oneRule, ArrayList<String> argument) {
		// first is the protocol
		oneRule.protocolLower = PortProtocolParser.getProtocolNumber(argument.get(0));
		if (oneRule.protocolLower.equals("256")) {
			oneRule.protocolLower = "0";
			oneRule.protocolUpper = "255";
		}else {
			oneRule.protocolUpper = oneRule.protocolLower;
		}
		argument.remove(0);

		// then is the source field
		if (argument.get(0).equals("any")) {
			oneRule.source = "any";
			argument.remove(0);
			PortProtocolParser.parsePort(oneRule, argument, "source");
		}
		else if (argument.get(0).equals("host")) {
			argument.remove(0);
			oneRule.source = argument.get(0);
			argument.remove(0);
			PortProtocolParser.parsePort(oneRule, argument, "source");
		}
		else {// the last case uses wildcard
			oneRule.source = argument.get(0);
			argument.remove(0);
			oneRule.sourceWildcard = argument.get(0);
			argument.remove(0);
			PortProtocolParser.parsePort(oneRule, argument, "source");
		}

		// the last is the destination field
		/* If the destination keyword is "any" */
		if (argument.get(0).equals("any")) {
			oneRule.destination = "any";
			argument.remove(0);
			if (!argument.isEmpty()){
				PortProtocolParser.parsePort(oneRule, argument, "destination");
			}
		}
		else if (argument.get(0).equals("host")) {
			argument.remove(0);
			oneRule.destination = argument.get(0);
			argument.remove(0);
			if (! argument.isEmpty()){
				PortProtocolParser.parsePort(oneRule, argument, "destination");
			}
		}
		else {
			oneRule.destination = argument.get(0);
			argument.remove(0);
			oneRule.destinationWildcard = argument.get(0);
			argument.remove(0);
			if (! argument.isEmpty()){
				PortProtocolParser.parsePort(oneRule, argument, "destination");
			}
		}
	}

	public static ACLType checkACLType(int aclNum) {
		if (aclNum >= 1 && aclNum <= 99 )
			return ACLType.standard ;
		else if (aclNum >= 100 && aclNum <= 199 )
			return ACLType.extend;
		else if (aclNum >= 1300 && aclNum <= 1999 )
			return ACLType.standard;
		else if (aclNum >= 2000 && aclNum <= 2699 )
			return ACLType.extend;
		//by default
		return ACLType.extend;
	}

}
