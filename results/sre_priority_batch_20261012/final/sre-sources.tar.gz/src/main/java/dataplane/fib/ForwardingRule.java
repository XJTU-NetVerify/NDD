package dataplane.fib;

import controlplane.network.PortName;
import controlplane.route.Route;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import main.Controller;
import org.jetbrains.annotations.NotNull;
import util.BDDUtil;
import util.NameUtil;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ForwardingRule implements SortedMultiListItem {
    Prefix prefix;
    Ip nextHop;
    PortName outPort;

    int arriveTC;
    int listTC;
    int innerIdx = -1;
    int outerIdx = -1;
    SortedMultiList list = null;

    /**
     * For a route with out-port and next-hop-ip (e.g. {@link controlplane.route.OspfRoute}),
     * we don't need to resolve it, create forwarding rule directly.
     */
    public ForwardingRule(Route route) {
        this.prefix = route.getPrefix();
        this.nextHop = route.getNextHop();
        this.outPort = route.getOutPort().getPortName();
        this.arriveTC = route.getListTC();
        this.listTC = route.getListTC();
    }

    /**
     * @param nextHop final next-hop-ip
     * @param routes resolution steps
     * For a route with only next-hop-ip (e.g. {@link controlplane.route.StaticRoute})
     * we have to do recursive look up on its next-hop-ip,
     * then create a forwarding rule according to its resolution steps and final next-hop-ip.
     */
    public ForwardingRule(Ip nextHop, List<Route> routes) {
        this.prefix = routes.get(0).getPrefix();
        this.nextHop = nextHop;
        this.outPort = routes.get(routes.size() - 1).getOutPort().getPortName();
        this.arriveTC = BDDUtil.andInBatch(Controller.bddManager.getBDD(), routes.stream().map(Route::getListTC).collect(Collectors.toSet()));
    }

    public Prefix getPrefix() {
        return prefix;
    }

    public Ip getNextHop() {
        return nextHop;
    }

    public PortName getOutPort() {
        return outPort;
    }

    @Override
    public void setList(SortedMultiList list) {
        this.list = list;
    }

    @Override
    public SortedMultiList getList() {
        return list;
    }

    @Override
    public void setOuterIdx(int idx) {
        this.outerIdx = idx;
    }

    @Override
    public int getOuterIdx() {
        return outerIdx;
    }

    @Override
    public void setInnerIdx(int idx) {
        this.innerIdx = idx;
    }

    @Override
    public int getInnerIdx() {
        return innerIdx;
    }

    @Override
    public void setListTC(int tc) {
        Controller.bddManager.deref(listTC);
        listTC = tc;
    }

    @Override
    public int getListTC() {
        return listTC;
    }

    @Override
    public void setArriveTC(int tc) {
        Controller.bddManager.deref(arriveTC);
        arriveTC = tc;
    }

    @Override
    public int getArriveTC() {
        return arriveTC;
    }

    @Override
    public boolean isDead() {
        return arriveTC == 0 || listTC == 0;
    }

    @Override
    public String toString() {
        return prefix.toString() + '\t' + nextHop.toString() + "\t" + outPort.getInterfaceName();
    }

    @Override
    public int compareTo(@NotNull SortedMultiListItem another) {
        if (!(another instanceof ForwardingRule)) {
            throw new IllegalArgumentException();
        }
        return Comparator.comparing(ForwardingRule::getPrefix)
                .thenComparing(ForwardingRule::getNextHop)
                .thenComparing(ForwardingRule::getOutPort)
                .compare(this, (ForwardingRule) another);
    }

    public static String[] CSV_HEADER = {"router", "vrf", "prefix", "out port", "next hop"};

    public String[] toCsvString() {
        String[] hostVrf = NameUtil.splitHostVrf(outPort.getRouterName());
        return new String[] {
                hostVrf[0],
                hostVrf[1],
                prefix.toString(),
                outPort.getInterfaceName().equals("blackhole") ? null : outPort.getInterfaceName(),
                nextHop.toString(),
        };
    }
}
