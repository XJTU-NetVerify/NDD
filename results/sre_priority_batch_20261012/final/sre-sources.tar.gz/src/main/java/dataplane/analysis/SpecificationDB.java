package dataplane.analysis;

import application.config2spec.Config2spec;
import bdd.BDDManager;
import bdd.BDDPredicateWrapper;
import bdd.BDDTCWrapper;
import multimap.HashBasedTable;
import multimap.Table;
import controlplane.network.Router;
import datamodel.ipv4.Header;
import datamodel.property.*;
import main.Controller;
import util.BDDUtil;
import util.MemorizeUtil;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class SpecificationDB {
    ReachabilityDB reachabilityDB;

    public SpecificationDB(ReachabilityDB reachabilityDB) {
        this.reachabilityDB = reachabilityDB;
    }

    Set<Property> reachabilitySet;
    Set<Property> blockSet;
    Set<Property> loadBalancingSet;
    Set<Property> waypointSet;

    public void mine(Collection<Router> waypoints) {
        if (Config2spec.reach && reachabilitySet == null) {
            mineReachability();
            MemorizeUtil.printSpecifications(reachabilitySet, Property.Type.REACHABILITY);
//            MemorizeUtil.printSpecifications(reachabilitySet, Property.Type.REACHABILITY, true);
//            MemorizeUtil.printReachabilityPairwise(reachabilitySet);
        }
        if (Config2spec.block && blockSet == null) {
            mineBlock();
//            MemorizeUtil.printSpecifications(blockSet, Property.Type.BLOCK);
        }
        if (Config2spec.loadbalancing && loadBalancingSet == null) {
            mineLoadBalancing();
//            MemorizeUtil.printSpecifications(loadBalancingSet, Property.Type.LOAD_BALANCING);
        }
        if (Config2spec.waypoint) {
            mineWaypoint(waypoints);
//            MemorizeUtil.printSpecifications(waypointSet, Property.Type.WAYPOINT);
        }
    }

    public void printReachability()
    {
        System.out.println("print mine reach");
        try {
            FileWriter fw = new FileWriter("/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/exp/fattree/bgp/"+Config2spec.dataset+"/OutBDD/test/mine_reach", false);
            PrintWriter pw = new PrintWriter(fw);
            for(Property p : reachabilitySet)
            {
                pw.println(((Reachability) p).toString());
                pw.flush();
            }
        } catch (IOException e) {
            //TODO: handle exception
        }
    }

    public Set<Property> mineReachability() {
        BDDManager manager = Controller.bddManager;
        BDDPredicateWrapper predicateWrapper = manager.getBDDPredicateWrapper();
        BDDTCWrapper tcWrapper = manager.getBDDTCWrapper();

        reachabilitySet = new HashSet<>();
        reachabilityDB.getAllPairReachability().cellSet().forEach(cell -> {
            Router src = Objects.requireNonNull(cell.getRowKey());
            Router dst = Objects.requireNonNull(cell.getColumnKey());
            if (src != dst) {
                predicateWrapper.splitHeaderTC(Objects.requireNonNull(cell.getValue()))
                        .forEach((header, tc) -> {
                            Flow flow = new Flow(header, src.getRouterName());
                            Reachability reachability = new Reachability(flow, dst.getRouterName());
                            reachability.setTC(tc);
                            reachability.setMF(tcWrapper.getTCFailureMax(tc));
                            reachabilitySet.add(reachability);
                        });
//                predicateWrapper.extract(Objects.requireNonNull(cell.getValue())).forEach((headerBin, tc) -> tcWrapper.getTCFailureMax(tc));
            }
        });
        return reachabilitySet;
    }

    // TODO check
    public Set<Property> mineBlock() {
        BDDManager manager = Controller.bddManager;
        BDDPredicateWrapper predicateWrapper = manager.getBDDPredicateWrapper();
        BDDTCWrapper tcWrapper = manager.getBDDTCWrapper();

        Table<Router, Router, Integer> table = reachabilityDB.getAllPairReachability();
        Map<String, Router> routers = Controller.cpExecutor.getRouters();
        blockSet = new HashSet<>();
        for (Router src : routers.values()) {
            for (Router dst : routers.values()) {
                if (src != dst) {
                    int tmp = dst.getPrefixBDD();
                    if (table.contains(src, dst)) tmp = manager.minus(tmp, table.get(src, dst));
                    predicateWrapper.splitHeaderTC(tmp)
                            .forEach((header, tc) -> {
                                Flow flow = new Flow(header, src.getRouterName());
                                Block block = new Block(flow);
                                block.setTC(tc);
                                block.setMF(tcWrapper.getTCFailureMax(tc));
                                blockSet.add(block);
                            });
                }
            }
        }
        return blockSet;
    }

    // TODO we need to consider edge-disjoint/node-disjoint
    public Set<Property> mineLoadBalancing() {
        BDDManager manager = Controller.bddManager;
        BDDPredicateWrapper predicateWrapper = manager.getBDDPredicateWrapper();
        BDDTCWrapper tcWrapper = manager.getBDDTCWrapper();

        loadBalancingSet = new HashSet<>();
        reachabilityDB.reachabilityForest.rowMap().forEach((src, tree) ->
                tree.forEach((dst, set) -> {
                    if (dst != src && set.size() >= 2) {
                        Table<Header, ReachabilityNode, Integer> table = HashBasedTable.create();
                        set.forEach(node -> predicateWrapper.splitHeaderTC(node.getTuple().getBDD()).forEach((header, tc) -> table.put(header, node, tc)));
                        table.rowMap().forEach((header, node2tc) -> {
                            int s = node2tc.size();
                            if (s >= 2) {
                                int[] notTC = new int[s];
                                int i = 0;
                                for (int tc : node2tc.values()) {
                                    notTC[i++] = manager.not(tc);
                                }
                                int[] hs = new int[s + 1];
                                hs[s] = BDDUtil.andInBatch(manager.getBDD(), notTC);
                                for (int j = 0; j < s; j++) {
                                    int tmp = notTC[j];
                                    notTC[j] = manager.not(tmp);
                                    hs[j] = BDDUtil.andInBatch(manager.getBDD(), notTC);
                                    manager.deref(notTC[j]);
                                    notTC[j] = tmp;
                                }
                                int tc = manager.filter(manager.not(BDDUtil.orInBatch(manager.getBDD(), hs)));
                                if (tc != 0) {
                                    Flow flow = new Flow(header, src.getRouterName());
                                    LoadBalancing loadBalancing = new LoadBalancing(flow);
                                    loadBalancing.setTC(tc);
                                    loadBalancing.setMF(tcWrapper.getTCFailureMax(tc));
                                    loadBalancingSet.add(loadBalancing);
                                }
                                BDDUtil.derefInBatch(manager.getBDD(), notTC);
                            }
                        });
                    }
        }));
        return loadBalancingSet;
    }

    public Set<Property> mineWaypoint(Collection<Router> waypoints) {
        if (waypoints == null || waypoints.isEmpty()) return null;
        BDDManager manager = Controller.bddManager;
        BDDPredicateWrapper predicateWrapper = manager.getBDDPredicateWrapper();
        BDDTCWrapper tcWrapper = manager.getBDDTCWrapper();

        waypointSet = new HashSet<>();
        reachabilityDB.reachabilityForest.rowMap().forEach((src, tree) ->
                tree.forEach((dst, nodes) -> {
                    HashMap<Router, Integer> map = new HashMap<>();
                    waypoints.forEach(point -> map.put(point, 0));
                    nodes.forEach(node -> {
                        HashSet<Router> candidates = new HashSet<>(node.getPath());
                        candidates.retainAll(waypoints);
                        candidates.remove(src);
                        candidates.forEach(candidate -> map.put(candidate, manager.orTo(map.get(candidate), node.tuple.getBDD())));
                    });
                    map.forEach((point, bdd) -> {
                        if (bdd != 0) {
                            predicateWrapper.splitHeaderTC(bdd).forEach((header, tc) -> {
                                Flow flow = new Flow(header, src.getRouterName());
                                Waypoint waypoint = new Waypoint(flow, point.getRouterName());
                                waypoint.setTC(tc);
                                waypoint.setMF(tcWrapper.getTCFailureMax(tc));
                                waypointSet.add(waypoint);
                            });
                        }
                    });
                })
        );
        return waypointSet;
    }

}
