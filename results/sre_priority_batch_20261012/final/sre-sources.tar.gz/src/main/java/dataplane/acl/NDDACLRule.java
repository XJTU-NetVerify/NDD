package dataplane.acl;

import sre.ndd.NDD;
import bdd.BDDManager;
import jdd.bdd.BDD;

import java.io.Serializable;

public class NDDACLRule implements Serializable {
    private static final long serialVersionUID = 4261146103254314479L;

    // constants for ACL fields
    static int octetLength = 8;
    static final long octet1Multiplier = 16777216L;
    static final int octet2Multiplier = 65536;
    static final int octet3Multiplier = 256;
    static final int octet4Multiplier = 1;
    final static long minIntegerIP = 0L;
    /* 4294967295 is max value of an IP (255.255.255.255) in decimal value */
    final static long maxIntegerIP = 4294967295L;
    final static long minPort = 0L;
    final static long maxPort = 65535L;
    final static long minProtocol = 0;
    final static long maxProtocol = 255;

    public String accessList;
    public String accessListNumber;
    public String dynamic;
    public String dynamicName;
    public String timeout;
    public String timeoutMinutes;
    public String permitDeny;
    public String protocolLower;
    public String protocolUpper;
    public String source;
    public String sourceWildcard;
    public String sourcePortLower;
    public String sourcePortUpper;
    public String destination;
    public String destinationWildcard;
    public String destinationPortLower;
    public String destinationPortUpper;
    public String precedenceKeyword;
    public String precedence;
    public String tosKeyword;
    public String tos;
    public String logKeyword;
    public String logInput;
    public Boolean remark;

    int val_ndd;
    int permit_ndd;
    int deny_ndd;
    boolean visible;

    public void set_visible(boolean visible) {
        this.visible = visible;
    }

    public boolean is_visible() {
        return visible;
    }

    public void insert_vals(int val_ndd, int permit_ndd, int deny_ndd) {
        this.val_ndd = val_ndd;
        this.permit_ndd = permit_ndd;
        this.deny_ndd = deny_ndd;
    }

    public int get_val_ndd() {
        return val_ndd;
    }

    /**
     * deref the old bdd values
     *
     * @param new_permit
     * @param new_deny
     */
    public void update_ndds(int new_permit, int new_deny) {
        NDD.deref(permit_ndd);
        NDD.deref(deny_ndd);
        this.permit_ndd = new_permit;
        this.deny_ndd = new_deny;
    }

    public int get_permit() {
        return permit_ndd;
    }

    public int get_deny() {
        return deny_ndd;
    }

    public NDDACLRule() {
        accessList = null;
        accessListNumber = null;
        dynamic = null;
        dynamicName = null;
        timeout = null;
        timeoutMinutes = null;
        permitDeny = null;
        protocolLower = null;
        protocolUpper = null;
        source = null;
        sourceWildcard = null;
        sourcePortLower = null;
        sourcePortUpper = null;
        destination = null;
        destinationWildcard = null;
        destinationPortLower = null;
        destinationPortUpper = null;
        precedenceKeyword = null;
        precedence = null;
        tosKeyword = null;
        tos = null;
        logKeyword = null;
        logInput = null;
        remark = false;

        visible = true;
        val_ndd = NDD.getFalse();
        permit_ndd = NDD.getFalse();
        deny_ndd = NDD.getFalse();
    }

    public String toString() {
        return accessList
                + " "
                + accessListNumber
                + " "
                // + dynamic + " "
                // + dynamicName + " "
                // + timeout + " "
                // + timeoutMinutes + " "
                + permitDeny + " " + protocolLower + " " + protocolUpper + " "
                + source + " " + sourceWildcard + " " + sourcePortLower + " "
                + sourcePortUpper + " " + destination + " "
                + destinationWildcard + " " + destinationPortLower + " "
                + destinationPortUpper + " "
                // + precedenceKeyword + " "
                // + precedence + " "
                // + tosKeyword + " "
                // + tos + " "
                // + logKeyword + " "
                // + logInput + " "
                // + remark
                ;
    }

    /**
     * check whether the acl rule is a permit rule or a deny rule
     */
    public static boolean CheckPermit(NDDACLRule aclr) {
        if (aclr.permitDeny.equalsIgnoreCase("permit")) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * The following are helper functions to controlplane.process ACL rules.
     */

    public static Range convertPortToRange(String inputLower, String inputUpper) {
        Range outputRange = new Range();
        if (inputLower == null || inputLower.equalsIgnoreCase("any")) {
            outputRange.lower = minPort;
            outputRange.upper = maxPort;
        } else {
            outputRange.lower = Long.parseLong(inputLower);
            if (inputUpper == null)
                outputRange.upper = maxPort;
            else
                outputRange.upper = Long.parseLong(inputUpper);
        }
        return outputRange;
    }

    public static Range convertProtocolToRange(String inputLower, String inputUpper) {
        Range outputRange = new Range();
        if (inputLower == null || inputLower.equalsIgnoreCase("any")) {
            outputRange.lower = minProtocol;
            outputRange.upper = maxProtocol;
        } else {
            outputRange.lower = Long.parseLong(inputLower);
            if (inputUpper == null)
                outputRange.upper = maxProtocol;
            else
                outputRange.upper = Long.parseLong(inputUpper);
        }
        return outputRange;
    }
}
