package dataplane.analysis;

import bdd.BDDTuple;
import controlplane.network.CPExecutor;
import controlplane.network.Port;
import controlplane.network.PortName;
import controlplane.network.Router;
import datamodel.list.SortedMultiList;
import datamodel.property.Property;
import java.util.*;
import main.Configuration;
import main.Controller;
import main.SRELogger;
import util.TimeUtil;


public class DPAnalyzer {
    CPExecutor _cpExecutor;
    public ReachabilityDB _reachabilityDB;
    public SpecificationDB _specificationBD;
    public PropertyChecker _propertyChecker;

    public DPAnalyzer(CPExecutor CPExecutor) {
        _cpExecutor = CPExecutor;
        _reachabilityDB = new ReachabilityDB();
        _specificationBD = new SpecificationDB(_reachabilityDB);
        _propertyChecker = new PropertyChecker(this);
    }

    public DPAnalyzer() {
        this(Controller.cpExecutor);
    }

    public void analyzeDataPlane(Collection<Router> routers) {
        if (!Configuration.LAZY) {
            SRELogger.pushContext("DPA");

            if (Configuration.FORWARD)
                SRELogger.pushContext("FORWARD");
            else
                SRELogger.pushContext("BACKWARD");
            TimeUtil timer1 = new TimeUtil();
            timer1.begin();

            computeFwdBDD(1);
            computeAclBDD();

            SRELogger.pushContext("REACHABILITY");
            TimeUtil timer2 = new TimeUtil();
            timer2.begin();
            routers.forEach(r -> _reachabilityDB.buildReachabilityTree(r));
            if (Configuration.checkCorrectness) // check 1
                _reachabilityDB.printReachability();
            timer2.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();

            timer1.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();

            SRELogger.popContext();
        } else {
            analyzeDataPlaneLazy(routers);
        }

    }

    public void analyzeDataPlane(Collection<Router> routers, BDDTuple tuple) {
        if (!Configuration.LAZY) {
            SRELogger.pushContext("DPA");

            if (Configuration.FORWARD)
                SRELogger.pushContext("FORWARD");
            else
                SRELogger.pushContext("BACKWARD");
            TimeUtil timer1 = new TimeUtil();
            timer1.begin();

            computeFwdBDD(tuple.getFirst());
            computeAclBDD();

            SRELogger.pushContext("REACHABILITY");
            TimeUtil timer2 = new TimeUtil();
            timer2.begin();
            routers.forEach(r -> _reachabilityDB.buildReachabilityTree(r, tuple));
            timer2.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();

            timer1.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();
            SRELogger.popContext();
        }
    }

    public void analyzeDataPlane(Map<Router, BDDTuple> routers) {
        if (!Configuration.LAZY) {
            SRELogger.pushContext("DPA");

            if (Configuration.FORWARD)
                SRELogger.pushContext("FORWARD");
            else
                SRELogger.pushContext("BACKWARD");
            TimeUtil timer1 = new TimeUtil();
            timer1.begin();

            int fwd = 0;
            int acl = 0;
            for (BDDTuple tuple : routers.values()) {
                fwd = Controller.bddManager.orTo(fwd, tuple.getFirst());
                acl = Controller.bddManager.orTo(acl, tuple.getSecond());
            }

            computeFwdBDD(fwd);
            computeAclBDD();

            SRELogger.pushContext("REACHABILITY");
            TimeUtil timer2 = new TimeUtil();
            timer2.begin();
            routers.forEach((router, tuple) -> _reachabilityDB.buildReachabilityTree(router, tuple));
            timer2.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();

            timer1.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();
            SRELogger.popContext();
        } else {
            analyzeDataPlaneLazy(routers);
        }
    }

    private void analyzeDataPlaneLazy(Collection<Router> routers) {
        SRELogger.pushContext("DPA LAZY");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        routers.forEach(r -> _reachabilityDB.buildReachabilityTreeLazy(r));
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    private void analyzeDataPlaneLazy(Map<Router, BDDTuple> routers) {
        SRELogger.pushContext("DPA LAZY");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        routers.forEach((r, t) -> _reachabilityDB.buildReachabilityTreeLazy(r, t));
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public void computeFwdBDD() {
        computeFwdBDD(1);
    }

    public void computeFwdBDD(int fwd) {
        SRELogger.pushContext("FWD");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        for (Router router : _cpExecutor.getRouters().values()) {
            computeFwdBDD(router, fwd);
        }
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public static void computeFwdBDD(Router router, int fwd) {
        SortedMultiList rules = new SortedMultiList(null);
        for (SortedMultiList entries : router.getFib().getFib().values()) {
            rules.addAll(entries);
        }
        HashMap<PortName, Integer> fwdBDDs = Controller.bddManager.getBDDPredicateWrapper().getPortPredicates(rules,
                router.ecmp(), fwd);
        fwdBDDs.forEach((port, bdd) -> router.getPorts().get(port).setPortFwdBDD(bdd));
    }

    public void computeAclBDD() {
        SRELogger.pushContext("ACL");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        for (Router router : _cpExecutor.getRouters().values()) {
            computeAclBDD(router);
        }
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public static void computeAclBDD(Router router) {
        for (Port port : router.getPorts().values()) {
            port.setPortAclInBDD(Controller.bddManager.getBDDACLWrapper().ConvertACLs(port.getAclIn()));
            port.setPortAclOutBDD(Controller.bddManager.getBDDACLWrapper().ConvertACLs(port.getAclOut()));
        }
    }

    public void checkProperties(Collection<Property> properties) {
        SRELogger.pushContext("CHECK PROPERTY");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        properties.forEach(property -> _propertyChecker.checkProperty(property));
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public void checkProperty(Property property) {
        SRELogger.pushContext("CHECK PROPERTY");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        _propertyChecker.checkProperty(property);
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public void mineSpecification(Collection<Router> routers) {
        SRELogger.pushContext("MINING");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        _specificationBD.mine(routers);
        if (Configuration.checkCorrectness) // check 2
            _specificationBD.printReachability();
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    // public HashSet<Integer> computeFwdAP() {
    // SRELogger.pushContext("FWD AP");
    // TimeUtil timer = new TimeUtil();
    // timer.begin();
    // ArrayList<Integer> predicates = new ArrayList<>();
    // _cpExecutor.getPorts().values().forEach(port ->
    // predicates.add(port.getPortFwdBDD()));
    // APComputer apComputer = new APComputer();
    // apComputer.ComputeAP(predicates);
    // timer.end(SRELogger.LEVEL.INFO, "");
    // SRELogger.popContext();
    // return apComputer.getAllAP();
    // }

    // public HashSet<Integer> computeAclAP() {
    // SRELogger.pushContext("ACL AP");
    // TimeUtil timer = new TimeUtil();
    // timer.begin();
    // ArrayList<Integer> predicates = new ArrayList<>();
    // _cpExecutor.getPorts().values().forEach(port -> {
    // predicates.add(port.getPortAclInBDD());
    // predicates.add(port.getPortAclOutBDD());
    // });
    // APComputer apComputer = new APComputer();
    // apComputer.ComputeAP(predicates);
    // timer.end(SRELogger.LEVEL.INFO, "");
    // SRELogger.popContext();
    // return apComputer.getAllAP();
    // }
}
