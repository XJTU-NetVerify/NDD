package dataplane.analysis;

import sre.ndd.NDD;
import bdd.NDDTuple;
import controlplane.network.*;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.SortedMultiList;
import datamodel.property.NDDProperty;
import datamodel.property.Property;
import main.Configuration;
import main.NDDController;
import main.SRELogger;
import util.TimeUtil;

import java.util.*;

public class NDDDPAnalyzer {
    NDDCPExecutor _cpExecutor;
    public NDDReachabilityDB _reachabilityDB;
    public NDDSpecificationDB _specificationBD;
    public NDDPropertyChecker _propertyChecker;

    public NDDDPAnalyzer(NDDCPExecutor CPExecutor) {
        _cpExecutor = CPExecutor;
        _reachabilityDB = new NDDReachabilityDB();
        _specificationBD = new NDDSpecificationDB(_reachabilityDB);
        _propertyChecker = new NDDPropertyChecker(this);
    }

    public NDDDPAnalyzer() {
        this(NDDController.cpExecutor);
    }

    public void analyzeDataPlane(Collection<NDDRouter> routers) {
        if (!Configuration.LAZY) {
            SRELogger.pushContext("DPA");

            if (Configuration.FORWARD)
                SRELogger.pushContext("FORWARD");
            else
                SRELogger.pushContext("BACKWARD");
            TimeUtil timer1 = new TimeUtil();
            timer1.begin();

            long fwdStart = System.nanoTime();
            computeFwdBDD(NDD.getTrue());
            long fwdEnd = System.nanoTime();
            computeAclBDD();
            long aclEnd = System.nanoTime();

            SRELogger.pushContext("REACHABILITY");
            TimeUtil timer2 = new TimeUtil();
            timer2.begin();
            routers.forEach(r -> _reachabilityDB.buildReachabilityTree(r));
            long reachabilityEnd = System.nanoTime();
            System.out.println("spf_fwd:" + (fwdEnd - fwdStart) / 1000000000.0);
            System.out.println("spf_acl:" + (aclEnd - fwdEnd) / 1000000000.0);
            System.out.println("spf_reachability:" + (reachabilityEnd - aclEnd) / 1000000000.0);
            if (Configuration.checkCorrectness) // check 1
                _reachabilityDB.printReachability();
            timer2.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();
            timer1.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();
            SRELogger.popContext();
        } else {
            analyzeDataPlaneLazy(routers);
        }
    }

    public void analyzeDataPlane(Collection<NDDRouter> routers, NDDTuple tuple) {
        if (!Configuration.LAZY) {
            SRELogger.pushContext("DPA");
            if (Configuration.FORWARD)
                SRELogger.pushContext("FORWARD");
            else
                SRELogger.pushContext("BACKWARD");
            TimeUtil timer1 = new TimeUtil();
            timer1.begin();

            computeFwdBDD(tuple.getFirst());
            computeAclBDD();

            SRELogger.pushContext("REACHABILITY");
            TimeUtil timer2 = new TimeUtil();
            timer2.begin();
            routers.forEach(r -> _reachabilityDB.buildReachabilityTree(r, tuple));
            timer2.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();

            timer1.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();
            SRELogger.popContext();
        }
    }

    public void analyzeDataPlane(Map<NDDRouter, NDDTuple> routers) {
        if (!Configuration.LAZY) {
            SRELogger.pushContext("DPA");

            if (Configuration.FORWARD)
                SRELogger.pushContext("FORWARD");
            else
                SRELogger.pushContext("BACKWARD");
            TimeUtil timer1 = new TimeUtil();
            timer1.begin();

            int fwd = NDD.getFalse();
            int acl = NDD.getFalse();
            for (NDDTuple tuple : routers.values()) {
                fwd = NDD.orTo(fwd, tuple.getFirst());
                acl = NDD.orTo(acl, tuple.getSecond());
            }

            computeFwdBDD(fwd);
            computeAclBDD();

            SRELogger.pushContext("REACHABILITY");
            TimeUtil timer2 = new TimeUtil();
            timer2.begin();
            routers.forEach((router, tuple) -> _reachabilityDB.buildReachabilityTree(router, tuple));
            timer2.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();

            timer1.end(SRELogger.LEVEL.INFO, "");
            SRELogger.popContext();
            SRELogger.popContext();
        } else {
            analyzeDataPlaneLazy(routers);
        }
    }

    public void analyzeDataPlaneLazy(Collection<NDDRouter> routers) {
        SRELogger.pushContext("DPA LAZY");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        routers.forEach(r -> _reachabilityDB.buildReachabilityTreeLazy(r));
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public void analyzeDataPlaneLazy(Map<NDDRouter, NDDTuple> routers) {
        SRELogger.pushContext("DPA LAZY");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        routers.forEach((r, t) -> _reachabilityDB.buildReachabilityTreeLazy(r, t));
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public void computeFwdBDD() {
        computeFwdBDD(NDD.getTrue());
    }

    public void computeFwdBDD(int fwd) {
        SRELogger.pushContext("FWD");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        for (NDDRouter router : _cpExecutor.getRouters().values()) {
            computeFwdBDD(router, fwd);
        }
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public static void computeFwdBDD(NDDRouter router, int fwd) {
        NDDSortedMultiList rules = new NDDSortedMultiList(null);
        for (NDDSortedMultiList entries : router.getFib().getFib().values()) {
            rules.addAll(entries);
        }
        HashMap<PortName, Integer> fwdBDDs = NDDController.bddManager.getBDDPredicateWrapper().getPortPredicates(rules,
                router.ecmp(), fwd);
        fwdBDDs.forEach((port, bdd) -> router.getPorts().get(port).setPortFwdNDD(bdd));
    }

    public void computeAclBDD() {
        SRELogger.pushContext("ACL");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        for (NDDRouter router : _cpExecutor.getRouters().values()) {
            computeAclBDD(router);
        }
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public static void computeAclBDD(NDDRouter router) {
        for (NDDPort port : router.getPorts().values()) {
            port.setPortAclInNDD(NDDController.bddManager.getBDDACLWrapper().ConvertACLs(port.getAclIn()));
            port.setPortAclOutNDD(NDDController.bddManager.getBDDACLWrapper().ConvertACLs(port.getAclOut()));
        }
    }

    public void checkProperties(Collection<NDDProperty> properties) {
        SRELogger.pushContext("CHECK PROPERTY");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        properties.forEach(property -> _propertyChecker.checkProperty(property));
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public void checkProperty(NDDProperty property) {
        SRELogger.pushContext("CHECK PROPERTY");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        _propertyChecker.checkProperty(property);
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    public void mineSpecification(Collection<NDDRouter> routers) {
        SRELogger.pushContext("MINING");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        _specificationBD.mine(routers);
        if (Configuration.checkCorrectness) // check 2
            _specificationBD.printReachability();
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    // public HashSet<Integer> computeFwdAP() {
    // SRELogger.pushContext("FWD AP");
    // TimeUtil timer = new TimeUtil();
    // timer.begin();
    // ArrayList<Integer> predicates = new ArrayList<>();
    // _cpExecutor.getPorts().values().forEach(port ->
    // predicates.add(port.getPortFwdBDD()));
    // APComputer apComputer = new APComputer();
    // apComputer.ComputeAP(predicates);
    // timer.end(SRELogger.LEVEL.INFO, "");
    // SRELogger.popContext();
    // return apComputer.getAllAP();
    // }

    // public HashSet<Integer> computeAclAP() {
    // SRELogger.pushContext("ACL AP");
    // TimeUtil timer = new TimeUtil();
    // timer.begin();
    // ArrayList<Integer> predicates = new ArrayList<>();
    // _cpExecutor.getPorts().values().forEach(port -> {
    // predicates.add(port.getPortAclInBDD());
    // predicates.add(port.getPortAclOutBDD());
    // });
    // APComputer apComputer = new APComputer();
    // apComputer.ComputeAP(predicates);
    // timer.end(SRELogger.LEVEL.INFO, "");
    // SRELogger.popContext();
    // return apComputer.getAllAP();
    // }
}
