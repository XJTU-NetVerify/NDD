package dataplane.analysis;

import bdd.BDDManager;
import bdd.BDDTuple;
import controlplane.network.CPExecutor;
import controlplane.network.Router;
import datamodel.ipv4.Header;
import datamodel.ipv4.Prefix;
import datamodel.property.*;
import main.Controller;
import main.SRELogger;

import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

public class PropertyChecker {
    ReachabilityDB _reachabilityDB;
    SpecificationDB _specificationDB;
    CPExecutor _CPExecutor;

    public PropertyChecker(DPAnalyzer dpAnalyzer) {
        _reachabilityDB = dpAnalyzer._reachabilityDB;
        _specificationDB = dpAnalyzer._specificationBD;
        _CPExecutor = dpAnalyzer._cpExecutor;
    }

    public void checkProperty(Property property) {
        switch (property.getType()) {
            case REACHABILITY:
                checkReachability(property);
                break;
            case WAYPOINT:
                checkWaypoint(property);
                break;
            case EGRESS:
                checkEgress(property);
                break;
            case PATH_LENGTH:
                checkPathLength(property);
                break;
            default:
                SRELogger.logWorkFlow(SRELogger.LEVEL.INFO, "Unsupported property type!");
        }
    }

    public int checkHelper(Prefix prefix, BDDTuple tuple) {
        BDDManager manager = Controller.bddManager;
        int tc = 0;
        Map<Header, Integer> map = manager.getBDDPredicateWrapper().splitHeaderTC(tuple.getBDD());
        for (Map.Entry<Header, Integer> entry : map.entrySet()) {
            if (entry.getKey().getSource().prefixMatchLoose(prefix)) {
                tc = manager.orTo(tc, entry.getValue());
            }
        }
        return tc;
    }

    // TODO
    public int checkSingleFlowProperty(SingleFlowProperty property, Function<ReachabilityNode, Boolean> func) {
        BDDManager manager = Controller.bddManager;
        Flow flow = property.getFlow();
        Router src = _CPExecutor.getRouters().get(flow.getSrc());
        Prefix prefix = flow.getHeader().getDestination();
        Collection<Router> dsts = _CPExecutor.getPrefixOwners().get(prefix);
        int prefixBDD = manager.getBDDACLWrapper().encodeDstIPPrefix(prefix.getIp().asLong(), prefix.getPreLength());
        int tc = 0;
        int ntc = 0;
        for (Router dst : dsts) {
            Collection<ReachabilityNode> nodes = _reachabilityDB.reachabilityForest.get(src, dst);
            if (nodes != null) {
                for (ReachabilityNode node : nodes) {
                    BDDTuple tmp = BDDTuple.intersect(node.tuple, prefixBDD);
                    if (!tmp.isEmpty()) {
                        if (func.apply(node)) {
                            tc = manager.orDerefBoth(tc, checkHelper(prefix, tmp));
                        }
                        else {
                            ntc = manager.orDerefBoth(ntc, checkHelper(prefix, tmp));
                        }
                    }
                }
            }
        }
        tc = manager.minusDerefBoth(tc, ntc);
        return tc;
    }

    public void checkReachability(Property property) {
        int tc = 0;
        if (property instanceof Reachability) {
            tc = checkSingleFlowProperty((Reachability) property, node -> true);
        }
        property.setTC(tc);
    }

    public void checkWaypoint(Property property) {
        int tc = 0;
        if (property instanceof Waypoint) {
            Waypoint waypoint = (Waypoint) property;
            Router point = _CPExecutor.getRouters().get(waypoint.getPoint());
            tc = checkSingleFlowProperty(waypoint, node -> node.path.contains(point));
        }
        property.setTC(tc);
    }

    public void checkEgress(Property property) {
        int tc = 0;
        if (property instanceof Egress) {
            Egress egress = (Egress) property;
            Router exit = _CPExecutor.getRouters().get(egress.getEgress());
            tc = checkSingleFlowProperty(egress, node -> node.path.get(node.path.size() - 1) == exit);
        }
        property.setTC(tc);
    }

    public void checkPathLength(Property property) {
        int tc = 0;
        if (property instanceof PathLength) {
            PathLength pathLength = (PathLength) property;
            int length = pathLength.getLength();
            tc = checkSingleFlowProperty(pathLength, node -> node.path.size() == length);
        }
        property.setTC(tc);
    }
}
