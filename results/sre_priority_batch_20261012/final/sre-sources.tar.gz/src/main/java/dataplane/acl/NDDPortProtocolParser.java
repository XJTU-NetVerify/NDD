package dataplane.acl;

import java.util.ArrayList;

public class NDDPortProtocolParser {
    public static void parsePort(NDDACLRule aclRule, ArrayList<String> argument, String port) {
        // handles eq, gt, lt, range
        // to include handling for neq
        if (argument.get(0).equalsIgnoreCase("eq")) { // handles eq
            argument.remove(0);
            if (port.equals("source")) {
                aclRule.sourcePortLower = getPortNumber(argument.get(0));
                aclRule.sourcePortUpper = aclRule.sourcePortLower;
                argument.remove(0);
            }
            else if (port.equals("destination")) {
                aclRule.destinationPortLower = getPortNumber(argument.get(0));
                aclRule.destinationPortUpper = aclRule.destinationPortLower;
            }
        }
        else if (argument.get(0).equalsIgnoreCase("gt")) {
            argument.remove(0);
            if (port.equals("source")) {
                aclRule.sourcePortLower = getPortNumber(argument.get(0));
                argument.remove(0);
            }
            else if (port.equals("destination"))
                aclRule.destinationPortLower = getPortNumber(argument.get(0));
        }
        else if (argument.get(0).equalsIgnoreCase("lt")) {
            argument.remove(0);
            if (port.equals("source")) {
                aclRule.sourcePortUpper = getPortNumber(argument.get(0));
                argument.remove(0);
            }
            else if (port.equals("destination"))
                aclRule.destinationPortUpper = getPortNumber(argument.get(0));
        }
        else if (argument.get(0).equalsIgnoreCase("range")) {
            argument.remove(0);
            if (port.equals("source")) {
                aclRule.sourcePortLower = getPortNumber(argument.get(0));
                argument.remove(0);
                aclRule.sourcePortUpper = getPortNumber(argument.get(0));
                argument.remove(0);
            }
            else if (port.equals("destination")) {
                aclRule.destinationPortLower = getPortNumber(argument.get(0));
                argument.remove(0);
                aclRule.destinationPortUpper = getPortNumber(argument.get(0));
            }
        }
    }

    static String getPortNumber(String port) {
        String portNumber;
        // Note switch statement does not work with strings
        if (port.equalsIgnoreCase("tcpmux")) portNumber = "1";
        else if (port.equalsIgnoreCase("ftp-data")) portNumber = "20";
        else if (port.equalsIgnoreCase("ftp")) portNumber = "21";
        else if (port.equalsIgnoreCase("ssh")) portNumber = "22";
        else if (port.equalsIgnoreCase("telnet")) portNumber = "23";
        else if (port.equalsIgnoreCase("smtp")) portNumber= "25";
        else if (port.equalsIgnoreCase("dsp")) portNumber= "33";
        else if (port.equalsIgnoreCase("time")) portNumber= "37";
        else if (port.equalsIgnoreCase("rap")) portNumber= "38";
        else if (port.equalsIgnoreCase("rlp")) portNumber= "39";
        else if (port.equalsIgnoreCase("name")) portNumber= "42";
        else if (port.equalsIgnoreCase("nameserver")) portNumber= "42";
        else if (port.equalsIgnoreCase("nicname")) portNumber= "43";
        else if (port.equalsIgnoreCase("dns")) portNumber = "53";
        else if (port.equalsIgnoreCase("domain")) portNumber = "53";
        else if (port.equalsIgnoreCase("bootps")) portNumber = "67";
        else if (port.equalsIgnoreCase("bootpc")) portNumber = "68";
        else if (port.equalsIgnoreCase("tftp")) portNumber = "69";
        else if (port.equalsIgnoreCase("gopher")) portNumber = "70";
        else if (port.equalsIgnoreCase("finger")) portNumber = "79";
        else if (port.equalsIgnoreCase("http")) portNumber = "80";
        else if (port.equalsIgnoreCase("www")) portNumber = "80";
        else if (port.equalsIgnoreCase("kerberos")) portNumber = "88";
        else if (port.equalsIgnoreCase("pop2")) portNumber = "109";
        else if (port.equalsIgnoreCase("pop3")) portNumber = "110";
        else if (port.equalsIgnoreCase("sunrpc")) portNumber = "111";
        else if (port.equalsIgnoreCase("ident")) portNumber = "113";
        else if (port.equalsIgnoreCase("auth")) portNumber = "113";
        else if (port.equalsIgnoreCase("sftp")) portNumber = "115";
        else if (port.equalsIgnoreCase("nntp")) portNumber = "119";
        else if (port.equalsIgnoreCase("ntp")) portNumber = "123";
        else if (port.equalsIgnoreCase("netbios-ns")) portNumber = "137";
        else if (port.toLowerCase().startsWith("netbios-dg")) portNumber = "138";
        else if (port.toLowerCase().startsWith("netbios-ss")) portNumber = "139";
        else if (port.equalsIgnoreCase("sqlsrv")) portNumber = "156";
        else if (port.equalsIgnoreCase("snmp")) portNumber = "161";
        else if (port.equalsIgnoreCase("snmptrap")) portNumber = "162";
        else if (port.equalsIgnoreCase("bgp")) portNumber = "179";
        else if (port.equalsIgnoreCase("exec")) portNumber = "512";
        else if (port.equalsIgnoreCase("shell")) portNumber = "514";
        else if (port.equalsIgnoreCase("isakmp")) portNumber = "500";
        else if (port.equalsIgnoreCase("biff")) portNumber = "512";
        else if (port.equalsIgnoreCase("lpd")) portNumber = "515";
        else if (port.equalsIgnoreCase("cmd")) portNumber = "514";
        else if (port.equalsIgnoreCase("syslog")) portNumber = "514";
        else if (port.equalsIgnoreCase("whois")) portNumber = "43";
        else if (port.equals("lLth9012b03GJ")) portNumber = "390"; //this is ad hoc
        else portNumber = port;
        return portNumber;
    }

    public static String getProtocolNumber(String protocol) {
        String protocolNumber;
        if(protocol.equalsIgnoreCase("icmp")) protocolNumber = "1" ;
        else if(protocol.equalsIgnoreCase("igmp")) protocolNumber = "2" ;
            // else if(protocol.equalsIgnoreCase("ip")) protocolNumber = "4" ;
        else if(protocol.equalsIgnoreCase("ip")) protocolNumber = "256" ;
            // special case to indicate all protocols. No actual protocol number 256.
        else if(protocol.equalsIgnoreCase("tcp")) protocolNumber = "6" ;
        else if(protocol.equalsIgnoreCase("egp")) protocolNumber = "8" ;
        else if(protocol.equalsIgnoreCase("igp")) protocolNumber = "9" ;
        else if(protocol.equalsIgnoreCase("udp")) protocolNumber = "17" ;
        else if(protocol.equalsIgnoreCase("rdp")) protocolNumber = "27" ;
        else if(protocol.equalsIgnoreCase("ipv6")) protocolNumber = "41" ;
        else if(protocol.equalsIgnoreCase("rsvp")) protocolNumber = "46" ;
        else if(protocol.equalsIgnoreCase("eigrp")) protocolNumber = "88" ;
        else if(protocol.equalsIgnoreCase("l2tp")) protocolNumber = "115" ;
        else if(protocol.equalsIgnoreCase("esp")) protocolNumber = "50";
        else if(protocol.equalsIgnoreCase("ahp")) protocolNumber = "51";
        else if(protocol.equalsIgnoreCase("gre")) protocolNumber = "47";
        else if(protocol.equalsIgnoreCase("ospf")) protocolNumber = "89";
        else {
            System.out.println("Unknown Protocol: " + protocol + "----------------------------");
            protocolNumber = protocol ;
        }
        return protocolNumber;
    }
}
