package dataplane.analysis;

import sre.ndd.NDD;
import java.util.Collection;
import java.util.Map;
import java.util.function.Function;


import bdd.NDDManager;
import bdd.NDDTuple;
import controlplane.network.NDDCPExecutor;
import controlplane.network.NDDRouter;
import datamodel.ipv4.Header;
import datamodel.ipv4.Prefix;
import datamodel.property.Flow;
import datamodel.property.NDDEgress;
import datamodel.property.NDDPathLength;
import datamodel.property.NDDProperty;
import datamodel.property.NDDReachability;
import datamodel.property.NDDSingleFlowProperty;
import datamodel.property.NDDWaypoint;
import main.NDDController;
import main.SRELogger;

public class NDDPropertyChecker {
    NDDReachabilityDB _reachabilityDB;
    NDDSpecificationDB _specificationDB;
    NDDCPExecutor _CPExecutor;

    public NDDPropertyChecker(NDDDPAnalyzer dpAnalyzer) {
        _reachabilityDB = dpAnalyzer._reachabilityDB;
        _specificationDB = dpAnalyzer._specificationBD;
        _CPExecutor = dpAnalyzer._cpExecutor;
    }

    public void checkProperty(NDDProperty property) {
        switch (property.getType()) {
            case REACHABILITY:
                checkReachability(property);
                break;
            case WAYPOINT:
                checkWaypoint(property);
                break;
            case EGRESS:
                checkEgress(property);
                break;
            case PATH_LENGTH:
                checkPathLength(property);
                break;
            default:
                SRELogger.logWorkFlow(SRELogger.LEVEL.INFO, "Unsupported property type!");
        }
    }

    public int checkHelper(Prefix prefix, NDDTuple tuple) {
        NDDManager manager = NDDController.bddManager;
        int tc = NDD.getFalse();
        Map<Header, Integer> map = manager.getBDDPredicateWrapper().splitHeaderTC(tuple.getNDD());
        for (Map.Entry<Header, Integer> entry : map.entrySet()) {
            if (entry.getKey().getSource().prefixMatchLoose(prefix)) {
                tc = NDD.orTo(tc, entry.getValue());
            }
        }
        return tc;
    }

    // TODO
    public int checkSingleFlowProperty(NDDSingleFlowProperty property, Function<NDDReachabilityNode, Boolean> func) {
        NDDManager manager = NDDController.bddManager;
        Flow flow = property.getFlow();
        NDDRouter src = _CPExecutor.getRouters().get(flow.getSrc());
        Prefix prefix = flow.getHeader().getDestination();
        Collection<NDDRouter> dsts = _CPExecutor.getPrefixOwners().get(prefix);
        int prefixBDD = manager.getBDDACLWrapper().encodeDstIPPrefix(prefix.getIp().asLong(), prefix.getPreLength());
        int tc = NDD.getFalse();
        int ntc = NDD.getFalse();
        for (NDDRouter dst : dsts) {
            Collection<NDDReachabilityNode> nodes = _reachabilityDB.reachabilityForest.get(src, dst);
            if (nodes != null) {
                for (NDDReachabilityNode node : nodes) {
                    NDDTuple tmp = NDDTuple.intersect(node.tuple, prefixBDD);
                    if (!tmp.isEmpty()) {
                        if (func.apply(node)) {
                            tc = manager.orDerefBoth(tc, checkHelper(prefix, tmp));
                        }
                        else {
                            ntc = manager.orDerefBoth(ntc, checkHelper(prefix, tmp));
                        }
                    }
                }
            }
        }
        tc = manager.minusDerefBoth(tc, ntc);
        return tc;
    }

    public void checkReachability(NDDProperty property) {
        int tc = NDD.getFalse();
        if (property instanceof NDDReachability) {
            tc = checkSingleFlowProperty((NDDReachability) property, node -> true);
        }
        property.setTC(tc);
    }

    public void checkWaypoint(NDDProperty property) {
        int tc = NDD.getFalse();
        if (property instanceof NDDWaypoint) {
            NDDWaypoint waypoint = (NDDWaypoint) property;
            NDDRouter point = _CPExecutor.getRouters().get(waypoint.getPoint());
            tc = checkSingleFlowProperty(waypoint, node -> node.path.contains(point));
        }
        property.setTC(tc);
    }

    public void checkEgress(NDDProperty property) {
        int tc = NDD.getFalse();
        if (property instanceof NDDEgress) {
            NDDEgress egress = (NDDEgress) property;
            NDDRouter exit = _CPExecutor.getRouters().get(egress.getEgress());
            tc = checkSingleFlowProperty(egress, node -> node.path.get(node.path.size() - 1) == exit);
        }
        property.setTC(tc);
    }

    public void checkPathLength(NDDProperty property) {
        int tc = NDD.getFalse();
        if (property instanceof NDDPathLength) {
            NDDPathLength pathLength = (NDDPathLength) property;
            int length = pathLength.getLength();
            tc = checkSingleFlowProperty(pathLength, node -> node.path.size() == length);
        }
        property.setTC(tc);
    }
}
