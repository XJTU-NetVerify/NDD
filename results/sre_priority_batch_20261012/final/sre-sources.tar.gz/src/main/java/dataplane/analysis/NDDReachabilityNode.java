package dataplane.analysis;

import bdd.NDDTuple;
import controlplane.network.NDDRouter;
import controlplane.network.NDDPort;

import java.util.Objects;
import java.util.Vector;

public class NDDReachabilityNode {
    NDDRouter source;
    NDDRouter router;
    NDDPort outPort;
    NDDTuple tuple;
    Vector<NDDRouter> path;
    boolean isLoopDetected;

    public NDDReachabilityNode(NDDRouter router, NDDTuple tuple, Vector<NDDRouter> path) {
        this.router = router;
        this.tuple = tuple;
        this.path = path;
        detectLoop();
    }

    public NDDReachabilityNode(NDDRouter router, NDDPort outPort, NDDTuple tuple, Vector<NDDRouter> path) {
        this.router = router;
        this.outPort = outPort;
        this.tuple = tuple;
        this.path = path;
    }

    private void detectLoop() {
        isLoopDetected = false;
        for (NDDRouter r : path) {
            if (r == router) {
                isLoopDetected = true;
                break;
            }
        }
    }

    public NDDTuple getTuple() {
        return tuple;
    }

    public NDDRouter getRouter() {
        return router;
    }

    public NDDRouter getSource() {
        return source;
    }

    void setSource(NDDRouter source) {
        this.source = source;
    }

    public NDDPort getOutPort() {
        return outPort;
    }

    public Vector<NDDRouter> getPath() {
        return path;
    }

    public boolean isLoopDetected() {
        return isLoopDetected;
    }

    public void releaseNddOwnership() {
        tuple.releaseNddOwnership();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NDDReachabilityNode that = (NDDReachabilityNode) o;
        return isLoopDetected == that.isLoopDetected &&
            Objects.equals(outPort, that.outPort) &&
            Objects.equals(tuple, that.tuple) &&
            Objects.equals(path, that.path);
    }

    @Override
    public int hashCode() {
        return Objects.hash(outPort, tuple, path, isLoopDetected);
    }
}
