package sre.ndd;

import bdd.NDDManager;
import controlplane.network.NDDL3Edge;
import controlplane.network.PortName;
import datamodel.ipv4.Header;
import datamodel.ipv4.Prefix;
import main.Configuration;
import main.NDDController;
import org.junit.Test;
import org.junit.Assume;
import java.util.*;
import static org.junit.Assert.*;

public class ParallelMigrationTest {
    @Test public void ownedBatchResultsSurviveCollectionAndMatchScalar() {
        for (String mode : new String[]{"java", "native"}) {
            if (mode.equals("native") && System.getProperty("pndd.library") == null) continue;
            System.setProperty("sre.ndd.engine", mode);
            try {
                NDD.initNDD(20000, 4096, 20000, 4096);
                NDD.declareField(2, NDD.LabelMode.COMPLEMENTED_BDD);
                NDD.declareField(3, NDD.LabelMode.COMPLEMENTED_BDD); NDD.generateFields();
                int x = NDD.ref(NDD.getVar(0, 0)), y = NDD.ref(NDD.getNotVar(1, 2));
                int[] a = {x, y, x, y, 0, 1, x, x}, b = {y, x, y, x, x, y, x, y};
                System.setProperty("sre.ndd.collectEvery", "1");
                int[] out = NDD.andBatchOwned(a, b);
                NDD.gc();
                for (int i = 0; i < out.length; ++i) {
                    assertEquals(NDD.and(a[i], b[i]), out[i]);
                    assertTrue(out[i] <= 1 || NDD.getReferenceCount(out[i]) > 0);
                }
                assertEquals(out[0], out[1]); assertEquals(out[0], out[7]);
                for (int id : out) NDD.deref(id);
                int[] sparse = NDD.andBatchOwned(new int[]{0, 1, x, x}, new int[]{x, y, x, y});
                NDD.gc(); assertEquals(0, sparse[0]); assertEquals(y, sparse[1]); assertEquals(x, sparse[2]);
                assertEquals(NDD.and(x, y), sparse[3]);
                for (int id : sparse) NDD.deref(id);
                NDD.deref(x); NDD.deref(y); NDD.gc();
            } finally { NDD.closeNative(); System.clearProperty("sre.ndd.engine"); System.clearProperty("sre.ndd.collectEvery"); }
        }
    }
    @Test public void bcddHeadersRoundTripWithEitherEngine() {
        for (String mode : new String[]{"java", "native"}) {
            if (mode.equals("native") && System.getProperty("pndd.library") == null) continue;
            System.setProperty("sre.ndd.engine", mode);
            try {
                NDDL3Edge.clearCache(); NDDL3Edge.of(new PortName("left", "eth0"), new PortName("right", "eth0"));
                Configuration.configureNDD(new String[]{"backend=f"}); NDDController.MF = -1;
                NDDManager manager = new NDDManager(4096, 4096); NDDController.bddManager = manager;
                int root = manager.getBDDACLWrapper().encodeDstIPPrefix(Prefix.of("192.0.2.0/24"));
                Map<Header, Integer> split = manager.getBDDPredicateWrapper().splitHeaderTC(root);
                assertEquals(1, split.size());
                assertEquals(Prefix.of("192.0.2.0/24"), split.keySet().iterator().next().getDestination());
            } finally {
                NDD.closeNative(); System.clearProperty("sre.ndd.engine"); Configuration.configureNDD(new String[]{"backend=a"});
            }
        }
    }
    @Test public void wideFieldsAndBorrowedHandlesSurviveAdapterGc() {
        Assume.assumeTrue(System.getProperty("pndd.library") != null);
        List<Long> expected = new ArrayList<>();
        for (String mode : new String[]{"java", "native"}) {
            System.setProperty("sre.ndd.engine", mode);
            try {
                NDD.initNDD(20000, 4096, 20000, 4096);
                NDD.declareField(32, NDD.LabelMode.COMPLEMENTED_BDD);
                NDD.declareField(108, NDD.LabelMode.COMPLEMENTED_BDD); NDD.generateFields();
                int a = NDD.ref(NDD.getVar(1, 0)), b = NDD.ref(NDD.getNotVar(1, 107));
                int both = NDD.ref(NDD.and(a, b)), either = NDD.ref(NDD.or(a, b));
                int header = NDD.ref(NDD.encodePrefix(new int[]{1, 0, 1, 1}, 0));
                int root = NDD.ref(NDD.and(header, both));
                if (mode.equals("native")) {
                    System.setProperty("sre.ndd.collectEvery", "1");
                    Map<Integer, Integer> edges = new HashMap<>();
                    edges.put(both, NDD.getEdgeLabel(header, 0));
                    assertEquals(root, NDD.addAtField(0, edges));
                    System.clearProperty("sre.ndd.collectEvery");
                }
                NDD.gc(); NDD.clearFingerprints();
                int[] roots = {a, b, both, either, header, root};
                for (int i = 0; i < roots.length; ++i) {
                    if (i >= 2) {
                        int before = NDD.getReferenceCount(roots[i]); NDD.ref(roots[i]);
                        assertEquals(before + 1, NDD.getReferenceCount(roots[i])); NDD.deref(roots[i]);
                    }
                    long digest = NDD.fingerprint(roots[i]);
                    if (mode.equals("java")) expected.add(digest); else assertEquals("root " + i, (long)expected.get(i), digest);
                }
                int target = NDD.getEdgeTarget(root, 0); // borrowed subgraph, retained by root
                NDD.gc(); assertEquals(NDD.fingerprint(both), NDD.fingerprint(target));
                for (int id : roots) NDD.deref(id); NDD.gc();
            } finally { NDD.clearFingerprints(); NDD.closeNative(); System.clearProperty("sre.ndd.engine"); System.clearProperty("sre.ndd.collectEvery"); }
        }
    }
}
