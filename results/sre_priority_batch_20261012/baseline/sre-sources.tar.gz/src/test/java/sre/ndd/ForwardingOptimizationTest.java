package sre.ndd;

import bdd.NDDManager;
import controlplane.network.NDDL3Edge;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.network.PortName;
import controlplane.route.NDDOspfRoute;
import controlplane.route.builder.NDDOspfRouteBuilder;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import dataplane.fib.NDDForwardingRule;
import main.Configuration;
import main.NDDController;
import org.junit.Test;
import org.junit.Assume;
import java.util.*;
import static org.junit.Assert.*;

public class ForwardingOptimizationTest {
    @Test public void clippedForwardingPreservesPriorityMultipathAndMapKeys() {
        Assume.assumeTrue(System.getProperty("pndd.library") != null);
        System.setProperty("sre.ndd.engine", "native");
        boolean oldFilter = Configuration.FILTER;
        int oldMf = NDDController.MF;
        try {
            Configuration.FILTER = false; Configuration.configureNDD(new String[]{"backend=f"}); NDDController.MF = 0;
            NDDL3Edge.clearCache(); NDDL3Edge.of(new PortName("left", "eth0"), new PortName("right", "eth0"));
            NDDManager manager = new NDDManager(20000, 4096); NDDController.bddManager = manager;
            NDDRouter router = new NDDRouter("router", 1);
            int up = NDD.ref(NDD.getVar(5, 0)), down = NDD.ref(NDD.not(up));
            NDD.deref(manager.FILTER_BDD); manager.FILTER_BDD = NDD.ref(up);
            for (boolean multipath : new boolean[]{false, true}) for (boolean exhaust : new boolean[]{false, true}) {
                NDDSortedMultiList rules = new NDDSortedMultiList();
                ArrayList<NDDSortedMultiListItem> first = new ArrayList<>(), second = new ArrayList<>();
                first.add(rule(router, "a", exhaust ? "0.0.0.0/0" : "10.0.0.0/8", 1));
                first.add(rule(router, "b", "10.0.0.0/8", down));
                second.add(rule(router, "c", "0.0.0.0/0", 1));
                second.add(rule(router, "d", "172.16.0.0/12", down)); rules.add(first); rules.add(second);
                System.setProperty("sre.ndd.clipForwarding", "false");
                Map<PortName,Integer> original = manager.getBDDPredicateWrapper().getPortPredicates(rules, multipath, 1);
                System.setProperty("sre.ndd.clipForwarding", "true");
                Map<PortName,Integer> clipped = manager.getBDDPredicateWrapper().getPortPredicates(rules, multipath, 1);
                NDD.gc();
                assertEquals(original.keySet(), clipped.keySet());
                for (PortName port : original.keySet()) assertEquals(NDD.fingerprint(original.get(port)), NDD.fingerprint(clipped.get(port)));
                for (int root : original.values()) NDD.deref(root);
                for (int root : clipped.values()) NDD.deref(root);
                for (NDDSortedMultiListItem item : rules.flat()) ((NDDForwardingRule)item).releaseNddOwnership();
            }
            NDDSortedMultiList selectedRules = new NDDSortedMultiList();
            ArrayList<NDDSortedMultiListItem> group = new ArrayList<>();
            NDDForwardingRule selectedRule = rule(router, "selected", "10.0.0.0/8", 1);
            group.add(selectedRule); selectedRules.add(group);
            manager.getBDDTCWrapper().calTC(selectedRules, true);
            assertTrue(selectedRule.isBudgetBounded(manager.FILTER_BDD));
            selectedRule.setListTC(NDD.ref(1));
            assertFalse(selectedRule.isBudgetBounded(manager.FILTER_BDD));
            selectedRule.releaseNddOwnership();
            NDD.deref(up); NDD.deref(down);
        } finally {
            NDD.closeNative(); NDD.clearFingerprints(); Configuration.FILTER = oldFilter; NDDController.MF = oldMf;
            System.clearProperty("sre.ndd.clipForwarding"); System.clearProperty("sre.ndd.engine");
            Configuration.configureNDD(new String[]{"backend=a"});
        }
    }
    private static NDDForwardingRule rule(NDDRouter router, String port, String prefix, int condition) {
        NDDPort out = new NDDPort(new PortName(router.getRouterName(), port), router, null, false);
        NDDOspfRoute route = new NDDOspfRouteBuilder().setPrefix(Prefix.of(prefix)).setOutPort(out)
                .setListTC(NDD.ref(condition)).build();
        NDDForwardingRule rule = new NDDForwardingRule(route); route.releaseNddOwnership(); return rule;
    }
}
