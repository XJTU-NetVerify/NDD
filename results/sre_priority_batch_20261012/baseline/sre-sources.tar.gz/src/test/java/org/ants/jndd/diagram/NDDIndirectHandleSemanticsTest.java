package org.ants.jndd.diagram;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class NDDIndirectHandleSemanticsTest {

    @Test
    public void booleanOpsPreserveSemanticsAcrossGc() {
        NDD.initNDD(64, 1024, 256);
        NDD.declareField(1);
        NDD.generateFields();

        int x = NDD.getVar(0, 0);
        int notX = NDD.getNotVar(0, 0);

        assertEquals(1.0, NDD.satCount(x), 0.0);
        assertEquals(1.0, NDD.satCount(notX), 0.0);

        int union = NDD.ref(NDD.or(x, notX));
        int intersection = NDD.ref(NDD.and(x, notX));

        assertEquals(2.0, NDD.satCount(union), 0.0);
        assertEquals(0.0, NDD.satCount(intersection), 0.0);

        NDD.gc();

        assertEquals(2.0, NDD.satCount(union), 0.0);
        assertEquals(0.0, NDD.satCount(intersection), 0.0);

        NDD.deref(union);
        NDD.deref(intersection);
    }

    @Test
    public void atMostKEncodingPreservesExpectedSatCount() {
        NDD.initNDD(128, 2048, 512);
        NDD.declareField(1);
        NDD.declareField(1);
        NDD.generateFields();

        int[] vars = new int[] {
                NDD.getBDDVars(0)[0],
                NDD.getBDDVars(1)[0]
        };

        int atMostOne = NDD.ref(NDD.encodeAtMostKFailureVarsSorted(NDD.getBDDEngine(), vars, 0, 1, 1));
        assertEquals(3.0, NDD.satCount(atMostOne), 0.0);

        NDD.gc();

        assertEquals(3.0, NDD.satCount(atMostOne), 0.0);
        NDD.deref(atMostOne);
    }
}
