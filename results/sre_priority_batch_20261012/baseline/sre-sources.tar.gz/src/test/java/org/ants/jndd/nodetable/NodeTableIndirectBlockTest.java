package org.ants.jndd.nodetable;

import org.ants.jndd.diagram.NDD;
import org.junit.Test;

import java.lang.reflect.Field;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class NodeTableIndirectBlockTest {

    private static int readPrivateInt(NodeTable table, String fieldName) throws Exception {
        Field field = NodeTable.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.getInt(table);
    }

    @Test
    public void safePointMaintenanceCompactsEdgeStorageWithoutBreakingLiveNodes() throws Exception {
        NDD.initNDD(4, 1024, 256);
        NDD.declareField(3);
        NDD.generateFields();
        NodeTable table = new NodeTable(4, 1024, 256);
        table.declareField();

        int[] variables = NDD.getBDDVars(0);
        int liveLabel1 = NDD.refLabel(0, variables[0]);
        int liveLabel2 = NDD.refLabel(0, variables[1]);
        int deadLabel = NDD.refLabel(0, variables[2]);

        int liveNode = table.mk(0, new int[]{1, 1}, new int[]{liveLabel1, liveLabel2});
        int deadNode = table.mk(0, new int[]{1}, new int[]{deadLabel});

        table.ref(liveNode);
        table.ref(deadNode);
        table.deref(deadNode);

        table.gc();

        int edgeTopBefore = readPrivateInt(table, "edgeTop");

        table.compactEdgesAtSafePoint();

        int edgeTopAfter = readPrivateInt(table, "edgeTop");

        assertTrue("expected compaction to reclaim dead edge storage", edgeTopAfter < edgeTopBefore);
        assertEquals(2, table.getEdgeCount(liveNode));

        assertEquals(1, table.getEdgeTarget(liveNode, 0));
        assertEquals(1, table.getEdgeTarget(liveNode, 1));
    }

    @Test
    public void safePointMaintenanceRecyclesRetiredNodeAndBlockSlots() {
        NDD.initNDD(8, 1024, 256);
        NDD.declareField(3);
        NDD.generateFields();
        NodeTable table = new NodeTable(8, 1024, 256);
        table.declareField();

        int[] variables = NDD.getBDDVars(0);
        int liveLabel = NDD.refLabel(0, variables[0]);
        int deadLabel = NDD.refLabel(0, variables[1]);
        int newLabel = NDD.refLabel(0, variables[2]);

        int liveNode = table.mk(0, new int[]{1}, new int[]{liveLabel});
        int deadNode = table.mk(0, new int[]{1}, new int[]{deadLabel});
        int deadBlock = table.nodeEdgeBlock[deadNode];

        table.ref(liveNode);
        table.ref(deadNode);
        table.deref(deadNode);
        table.gc();

        table.compactEdgesAtSafePoint();

        int recycledNode = table.mk(0, new int[]{liveNode}, new int[]{newLabel});

        assertEquals("expected retired node slot to be recycled at safe point", deadNode, recycledNode);
        assertEquals("expected retired block slot to be recycled at safe point", deadBlock, table.nodeEdgeBlock[recycledNode]);
    }
}
