package application.differential.s1;

import application.differential.s0.OspfCostUpdate;
import application.differential.s0.S0Snapshot;
import application.differential.s2.AffectedPrefixRibFibTransaction;
import bdd.NDDManager;
import controlplane.network.NDDL3Edge;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.network.PortName;
import controlplane.process.ospf.NDDOspfExecutor;
import controlplane.process.ospf.NDDOspfNeighborConfig;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.process.ospf.NDDOspfTopology;
import controlplane.process.ospf.OspfIntfSetting;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import datamodel.ipv4.Mask;
import datamodel.ipv4.Prefix;
import dataplane.fib.NDDForwardingRule;
import main.Configuration;
import main.NDDController;
import org.ants.jndd.diagram.NDD;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class OspfCostContributionTransactionTest {

    @Test
    public void affectedPrefixBudgetRejectsBroadClosure() {
        Map<String, Set<Prefix>> affected = new HashMap<>();
        Set<Prefix> prefixes = new HashSet<>();
        for (int index = 0;
                index < AffectedPrefixRibFibTransaction.MAX_AFFECTED_PREFIXES;
                index++) {
            prefixes.add(Prefix.of("10.0." + index + ".0/24"));
        }
        affected.put("router", prefixes);
        assertTrue(AffectedPrefixRibFibTransaction.isWithinBudget(affected));
        prefixes.add(Prefix.of("10.0.255.0/24"));
        assertFalse(AffectedPrefixRibFibTransaction.isWithinBudget(affected));
    }

    @Test
    public void prefixLocalRibFibMatchesFullAndRollsBack() {
        NDDL3Edge.clearCache();
        NDDController.MF = 1;
        Configuration.FILTER = false;
        Configuration.SORT = false;
        NDDL3Edge first = NDDL3Edge.of(new PortName("left", "eth0"),
                new PortName("middle", "eth0"));
        NDDL3Edge second = NDDL3Edge.of(new PortName("middle", "eth1"),
                new PortName("right", "eth0"));
        NDDController.bddManager = new NDDManager(32768, 32768);
        Fixture live = fixture(10, first.getTC(), second.getTC(), true);
        Fixture fullNew = fixture(20, first.getTC(), second.getTC(), false);
        OspfCostUpdate update = new OspfCostUpdate("cost-middle-left", 0,
                "line3", "middle", 1, "eth0", "left",
                OspfCostUpdate.Direction.LOCAL_INTERFACE, 10, 20);

        try (S0Snapshot oldState = S0Snapshot.capture(
                        live.routers.values(), null, null);
                S0Snapshot fullNewState = S0Snapshot.capture(
                        fullNew.routers.values(), null, null);
                OspfDormantContributionIndex index = live.index;
                OspfCostUpdate.Bound bound = update.bind(
                        live.routers, live.topology)) {
            bound.apply();
            try (OspfCostContributionTransaction contribution =
                            OspfCostContributionTransaction.prepare(update,
                                    live.routers, live.topology, index)) {
                contribution.apply();
                try (S0Snapshot contributionBeforeRibFib = S0Snapshot.capture(
                                live.routers.values(), null, null);
                        AffectedPrefixRibFibTransaction ribFib =
                                new AffectedPrefixRibFibTransaction(live.routers,
                                        contribution.getAffectedPrefixesByRouter())) {
                    ribFib.apply();
                    try (S0Snapshot incremental = S0Snapshot.capture(
                            live.routers.values(), null, null)) {
                        assertTrue(contributionBeforeRibFib.diff(incremental)
                                .getContributions().isEmpty());
                        assertTrue(incremental.semanticallyEquivalent(fullNewState));
                    }
                    ribFib.rollback();
                }
                contribution.rollback();
            }
            bound.rollback();
            try (S0Snapshot restored = S0Snapshot.capture(
                    live.routers.values(), null, null)) {
                assertTrue(oldState.semanticallyEquivalent(restored));
            }
        }
    }

    @Test
    public void prefixLocalCommitRemainsExactAfterClose() {
        NDDL3Edge.clearCache();
        NDDController.MF = 1;
        Configuration.FILTER = false;
        Configuration.SORT = false;
        NDDL3Edge first = NDDL3Edge.of(new PortName("left", "eth0"),
                new PortName("middle", "eth0"));
        NDDL3Edge second = NDDL3Edge.of(new PortName("middle", "eth1"),
                new PortName("right", "eth0"));
        NDDController.bddManager = new NDDManager(32768, 32768);
        Fixture live = fixture(10, first.getTC(), second.getTC(), true);
        Fixture fullNew = fixture(20, first.getTC(), second.getTC(), false);
        OspfCostUpdate update = new OspfCostUpdate("cost-middle-left", 0,
                "line3", "middle", 1, "eth0", "left",
                OspfCostUpdate.Direction.LOCAL_INTERFACE, 10, 20);

        try (S0Snapshot fullNewState = S0Snapshot.capture(
                        fullNew.routers.values(), null, null);
                OspfDormantContributionIndex index = live.index;
                OspfCostUpdate.Bound bound = update.bind(
                        live.routers, live.topology)) {
            bound.apply();
            try (OspfCostContributionTransaction contribution =
                            OspfCostContributionTransaction.prepare(update,
                                    live.routers, live.topology, index)) {
                contribution.apply();
                try (AffectedPrefixRibFibTransaction ribFib =
                                new AffectedPrefixRibFibTransaction(live.routers,
                                        contribution.getAffectedPrefixesByRouter())) {
                    ribFib.apply();
                    ribFib.commit();
                }
                contribution.commit();
            }
            bound.commit();
            try (S0Snapshot committed = S0Snapshot.capture(
                    live.routers.values(), null, null)) {
                assertTrue(committed.semanticallyEquivalent(fullNewState));
            }
        }
    }

    @Test
    public void forwardingRuleOwnsAndReleasesRoots() {
        NDDL3Edge.clearCache();
        NDDController.MF = 1;
        Configuration.FILTER = false;
        Configuration.SORT = false;
        NDDL3Edge first = NDDL3Edge.of(new PortName("left", "eth0"),
                new PortName("middle", "eth0"));
        NDDL3Edge second = NDDL3Edge.of(new PortName("middle", "eth1"),
                new PortName("right", "eth0"));
        NDDController.bddManager = new NDDManager(32768, 32768);
        Fixture live = fixture(10, first.getTC(), second.getTC(), false);
        controlplane.route.NDDRoute route = live.routers.values().stream()
                .flatMap(router -> router.getGlobalRib().getRib().values().stream())
                .flatMap(list -> list.flat().stream())
                .map(item -> (controlplane.route.NDDRoute) item)
                .filter(item -> item.getListTC() > 1
                        && NDD.getReferenceCount(item.getListTC())
                                != Integer.MAX_VALUE)
                .findFirst().get();
        int root = route.getListTC();
        int before = NDD.getReferenceCount(root);
        NDDForwardingRule rule = new NDDForwardingRule(route);
        assertEquals(before + 2, NDD.getReferenceCount(root));
        rule.releaseNddOwnership();
        rule.releaseNddOwnership();
        assertEquals(before, NDD.getReferenceCount(root));
    }

    @Test
    public void detachedWorklistMatchesFullAndRollsBack() {
        NDDL3Edge.clearCache();
        NDDController.MF = 1;
        Configuration.FILTER = false;
        Configuration.SORT = false;
        NDDL3Edge first = NDDL3Edge.of(new PortName("left", "eth0"),
                new PortName("middle", "eth0"));
        NDDL3Edge second = NDDL3Edge.of(new PortName("middle", "eth1"),
                new PortName("right", "eth0"));
        NDDController.bddManager = new NDDManager(32768, 32768);

        Fixture live = fixture(10, first.getTC(), second.getTC(), true);
        OspfCostUpdate update = new OspfCostUpdate("cost-middle-left", 0,
                "line3", "middle", 1, "eth0", "left",
                OspfCostUpdate.Direction.LOCAL_INTERFACE, 10, 20);
        Fixture fullNew = fixture(20, first.getTC(), second.getTC(), true);

        try (S0Snapshot oldState = S0Snapshot.capture(
                        live.routers.values(), null, null);
                S0Snapshot fullNewState = S0Snapshot.capture(
                        fullNew.routers.values(), null, null);
                OspfDormantContributionIndex index = live.index;
                OspfDormantContributionIndex fullNewIndex = fullNew.index;
                OspfCostUpdate.Bound bound = update.bind(
                        live.routers, live.topology)) {
            bound.apply();
            try (OspfCostContributionTransaction transaction =
                            OspfCostContributionTransaction.prepare(update,
                                    live.routers, live.topology, index)) {
                assertFalse(transaction.isFullFallback());
                assertTrue(transaction.getDirectContributions() > 0);
                transaction.advanceIndex();
                assertEquals(fullNewIndex.metadataHistogram(),
                        index.metadataHistogram());
                transaction.apply();
                try (AffectedRibFibTransaction ribFib =
                                new AffectedRibFibTransaction(live.routers,
                                        transaction.getAffectedRouters())) {
                    ribFib.apply();
                    try (S0Snapshot incremental = S0Snapshot.capture(
                            live.routers.values(), null, null)) {
                        assertTrue(incremental.semanticallyEquivalent(fullNewState));
                    }
                    ribFib.rollback();
                }
                transaction.rollback();
            }
            bound.rollback();
            try (S0Snapshot restored = S0Snapshot.capture(
                    live.routers.values(), null, null)) {
                assertTrue(oldState.diff(restored).getContributions().isEmpty());
            }
        }
    }

    private static Fixture fixture(int middleLeftCost, int firstTc,
            int secondTc, boolean retainDormant) {
        NDDRouter left = router("left", "eth0", "10.0.0.0");
        NDDRouter middle = router("middle", "eth0", "10.0.0.1");
        addPort(middle, "eth1", "10.0.0.2");
        NDDRouter right = router("right", "eth0", "10.0.0.3");
        NDDOspfProcess leftProcess = process(left);
        NDDOspfProcess middleProcess = process(middle);
        NDDOspfProcess rightProcess = process(right);
        Prefix prefix = Prefix.of("192.0.2.0/24");
        prefix.setInterested(true);
        leftProcess.addNetwork(prefix);

        NDDOspfTopology topology = new NDDOspfTopology();
        NDDOspfNeighborConfig leftConfig = config(leftProcess, "eth0", 10);
        NDDOspfNeighborConfig middleLeft = config(
                middleProcess, "eth0", middleLeftCost);
        NDDOspfNeighborConfig middleRight = config(middleProcess, "eth1", 10);
        NDDOspfNeighborConfig rightConfig = config(rightProcess, "eth0", 10);
        for (NDDOspfNeighborConfig config : Arrays.asList(leftConfig,
                middleLeft, middleRight, rightConfig)) {
            topology.addNeighborConfig(config);
        }
        topology.addEdge(leftConfig, middleLeft, firstTc);
        topology.addEdge(middleRight, rightConfig, secondTc);

        OspfDormantContributionIndex index = null;
        if (retainDormant) {
            NDDOspfExecutor.executeRetainingDeadRoutes(topology);
            index = OspfDormantContributionIndex.capture(
                    topology.getEdges().rowKeySet());
            NDDOspfExecutor.cleanDeadRoutes(topology);
        } else {
            NDDOspfExecutor.execute(topology);
        }
        Collection<NDDRouter> routers = Arrays.asList(left, middle, right);
        routers.forEach(NDDRouter::installIgpRoutesToGlobalRib);
        routers.forEach(NDDRouter::installGlobalRibToFib);
        Map<String, NDDRouter> byName = new TreeMap<>();
        routers.forEach(router -> byName.put(router.getRouterName(), router));
        return new Fixture(byName, topology, index);
    }

    private static NDDOspfProcess process(NDDRouter router) {
        NDDOspfProcess process = new NDDOspfProcess(router, 1);
        process.setValid(true);
        router.addOspfProcess(process);
        return process;
    }

    private static NDDOspfNeighborConfig config(NDDOspfProcess process,
            String interfaceName, int cost) {
        NDDPort port = process.getRouter().getPorts().get(new PortName(
                process.getRouter().getRouterName(), interfaceName));
        return new NDDOspfNeighborConfig(process,
                new OspfIntfSetting(0, cost, false, 1), port);
    }

    private static NDDRouter router(String name, String interfaceName, String ip) {
        NDDRouter router = new NDDRouter(name, 65000);
        addPort(router, interfaceName, ip);
        return router;
    }

    private static void addPort(NDDRouter router, String interfaceName, String ip) {
        router.addPort(new NDDPort(new PortName(router.getRouterName(), interfaceName),
                router, new IpAddress(Ip.of(ip), Mask.of(31)), false));
    }

    private static final class Fixture {
        private final Map<String, NDDRouter> routers;
        private final NDDOspfTopology topology;
        private final OspfDormantContributionIndex index;

        private Fixture(Map<String, NDDRouter> routers,
                NDDOspfTopology topology, OspfDormantContributionIndex index) {
            this.routers = routers;
            this.topology = topology;
            this.index = index;
        }
    }
}
