package application.differential.s3;

import bdd.NDDTuple;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.network.PortName;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import datamodel.ipv4.Mask;
import dataplane.analysis.NDDReachabilityDB;
import org.ants.jndd.diagram.NDD;
import org.junit.Test;

import java.util.Arrays;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class SpfAffectedSourceProbeTest {
    @Test
    public void sourceBudgetFallsBackBeforeCandidateCreation() {
        ArrayList<NDDRouter> sources = new ArrayList<>();
        for (int index = 0;
                index <= AffectedSourceSpfTransaction.MAX_AFFECTED_SOURCES;
                index++) {
            sources.add(new NDDRouter("source-" + index, 65000));
        }
        try (AffectedSourceSpfTransaction transaction =
                new AffectedSourceSpfTransaction(sources)) {
            transaction.apply();
            assertTrue(transaction.isFallback());
            assertEquals("affected_source_budget",
                    transaction.getFallbackReason());
            assertEquals(null, transaction.getCandidate());
        }
    }

    @Test
    public void selectsOnlySourceWhoseArrivalIntersectsChangedPort() {
        NDD.initNDD(1024, 4096, 1024);
        NDD.declareField(1);
        NDD.declareField(1);
        NDD.generateFields();
        int changedRegion = NDD.getVar(1, 0);

        NDDRouter source = new NDDRouter("source", 65000);
        NDDRouter transit = new NDDRouter("transit", 65000);
        NDDRouter other = new NDDRouter("other", 65000);
        NDDPort sourceLink = port(source, "to-transit", "10.0.0.0");
        NDDPort transitLink = port(transit, "to-source", "10.0.0.1");
        sourceLink.setLinkedPort(transitLink);
        transitLink.setLinkedPort(sourceLink);
        NDDPort transitEdge = port(transit, "host", "192.0.2.1");
        transitEdge.setEdge();
        NDDPort otherEdge = port(other, "host", "198.51.100.1");
        otherEdge.setEdge();
        sourceLink.setPortFwdNDD(NDD.getTrue());
        transitLink.setPortFwdNDD(NDD.getFalse());
        transitEdge.setPortFwdNDD(NDD.ref(changedRegion));
        otherEdge.setPortFwdNDD(NDD.getTrue());

        NDDReachabilityDB oldReachability = new NDDReachabilityDB();
        oldReachability.buildReachabilityTree(source, NDDTuple.FULL);
        oldReachability.buildReachabilityTree(other, NDDTuple.FULL);

        try (SpfReachabilityIndex oldIndex = SpfReachabilityIndex.capture(
                        Arrays.asList(source, other), oldReachability);
                FibPortSnapshot oldPorts = FibPortSnapshot.capture(
                        Arrays.asList(source, transit, other))) {
            transitEdge.setPortFwdNDD(NDD.getFalse());
            try (FibPortSnapshot newPorts = FibPortSnapshot.capture(
                            Arrays.asList(source, transit, other));
                    FibPortSnapshot.ChangedPortRegions delta =
                            oldPorts.diff(newPorts);
                    SpfAffectedSourceProbe.Result affected =
                            SpfAffectedSourceProbe.select(oldIndex, delta)) {
                assertEquals(1, delta.getChangedPortCount());
                assertEquals(1, affected.getAffectedSourceCount());
                assertTrue(affected.getSources().contains(source));
            }
        }
    }

    @Test
    public void conservativelyIncludesSourcesForNewFibRules() {
        NDD.initNDD(1024, 4096, 1024);
        NDD.declareField(1);
        NDD.generateFields();
        NDDRouter first = new NDDRouter("first", 65000);
        NDDRouter second = new NDDRouter("second", 65000);
        try (NDDReachabilityDB oldReachability = new NDDReachabilityDB();
                SpfReachabilityIndex oldIndex = SpfReachabilityIndex.capture(
                        Arrays.asList(first, second), oldReachability);
                FibPortSnapshot oldPorts = FibPortSnapshot.capture(
                        Arrays.asList(first, second));
                FibPortSnapshot newPorts = FibPortSnapshot.capture(
                        Arrays.asList(first, second));
                FibPortSnapshot.ChangedPortRegions delta = oldPorts.diff(newPorts);
                SpfAffectedSourceProbe.Result affected =
                        SpfAffectedSourceProbe.select(oldIndex, delta,
                                Arrays.asList(first, second))) {
            assertEquals(2, affected.getAffectedSourceCount());
            assertTrue(affected.getSources().contains(first));
            assertTrue(affected.getSources().contains(second));
        }
    }

    private static NDDPort port(NDDRouter router, String name, String ip) {
        NDDPort port = new NDDPort(new PortName(router.getRouterName(), name),
                router, new IpAddress(Ip.of(ip), Mask.of(24)), false);
        router.addPort(port);
        return port;
    }
}
