package application.differential.s4;

import bdd.NDDTuple;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.network.PortName;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import datamodel.ipv4.Mask;
import dataplane.analysis.NDDReachabilityDB;
import dataplane.analysis.NDDReachabilityNode;
import org.ants.jndd.diagram.NDD;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.HashSet;
import java.util.Vector;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class PfecPropertyTransactionTest {
    private int header;
    private int link;
    private NDDRouter source;
    private NDDRouter destination;
    private NDDPort firstPort;
    private NDDPort secondPort;

    @Before
    public void initialize() {
        NDD.initNDD(1024, 4096, 1024);
        NDD.declareField(1);
        NDD.declareField(1);
        NDD.generateFields();
        header = NDD.getVar(0, 0);
        link = NDD.getVar(1, 0);
        source = new NDDRouter("source", 65000);
        destination = new NDDRouter("destination", 65000);
        firstPort = port("first", "192.0.2.1");
        secondPort = port("second", "198.51.100.1");
    }

    @Test
    public void splitMergePartitionPreservesCoverageAndDisjointness() {
        int up = NDD.ref(NDD.and(header, link));
        int down = NDD.ref(NDD.and(header, NDD.not(link)));
        try (NDDReachabilityDB oldDb = database(firstPort,
                        NDD.ref(header));
                NDDReachabilityDB splitDb = database(
                        new NDDPort[] { firstPort, secondPort },
                        new int[] { up, down });
                PfecPartitionSnapshot oldPartition =
                        PfecPartitionSnapshot.capture(oldDb,
                                Collections.singleton("source"));
                PfecPartitionSnapshot splitPartition =
                        PfecPartitionSnapshot.capture(splitDb,
                                Collections.singleton("source"))) {
            PfecPartitionSnapshot.Delta split = oldPartition.diff(splitPartition);
            PfecPartitionSnapshot.Delta merge = splitPartition.diff(oldPartition);
            assertTrue(oldPartition.isDisjoint());
            assertTrue(splitPartition.isDisjoint());
            assertTrue(oldPartition.coverageEquivalent(splitPartition));
            assertEquals(1, split.getSplits());
            assertEquals(1, merge.getMerges());
        }
    }

    @Test
    public void reachabilityVerdictAndWitnessFlipBothDirections() {
        int up = NDD.ref(NDD.and(header, link));
        PfecPartitionSnapshot.PairKey id = new PfecPartitionSnapshot.PairKey(
                "source", "destination");
        try (NDDReachabilityDB safeDb = database(firstPort, NDD.ref(header));
                NDDReachabilityDB violationDb = database(firstPort, up);
                PfecPartitionSnapshot safe = PfecPartitionSnapshot.capture(
                        safeDb, Collections.singleton("source"));
                PfecPartitionSnapshot violation = PfecPartitionSnapshot.capture(
                        violationDb, Collections.singleton("source"));
                ReachabilityCoverageSnapshot safeCoverage =
                        ReachabilityCoverageSnapshot.capture(
                                safeDb, Collections.singleton("source"));
                ReachabilityCoverageSnapshot violationCoverage =
                        ReachabilityCoverageSnapshot.capture(
                                violationDb, Collections.singleton("source"));
                ReachabilityPropertySet properties =
                        ReachabilityPropertySet.ofQuery(
                                "source", "destination", header);
                PfecPartitionSnapshot.CoverageDelta forward =
                        safe.coverageDelta(violation);
                PfecPartitionSnapshot.CoverageDelta reverse =
                        violation.coverageDelta(safe);
                PfecPartitionSnapshot.CoverageDelta directForward =
                        safeCoverage.coverageDelta(violationCoverage);
                ReachabilityPropertySet.Evaluation oldResult =
                        properties.evaluate(safe, Collections.singleton(id));
                ReachabilityPropertySet.Evaluation newResult =
                        properties.evaluate(violation, Collections.singleton(id));
                ReachabilityPropertySet.Evaluation fullNewResult =
                        properties.evaluate(violation, Collections.singleton(id));
                ReachabilityPropertySet.Evaluation restoredResult =
                        properties.evaluate(safe, Collections.singleton(id))) {
            assertEquals(Collections.singleton(id), properties.dependencies(forward));
            assertEquals(Collections.singleton(id),
                    properties.dependencies(directForward));
            assertEquals(Collections.singleton(id), properties.dependencies(reverse));
            assertEquals(Collections.singleton(id),
                    oldResult.changedIds(newResult));
            assertEquals(Collections.singleton(id),
                    newResult.changedIds(restoredResult));
            assertTrue(oldResult.isSafe(id));
            assertFalse(newResult.isSafe(id));
            assertTrue(restoredResult.isSafe(id));
            assertTrue(newResult.semanticallyEquivalent(fullNewResult));
            assertTrue(equivalent(newResult.getWitness(id),
                    NDD.and(header, NDD.not(link))));
            assertTrue(oldResult.semanticallyEquivalent(restoredResult));
        }
    }

    private NDDReachabilityDB database(NDDPort port, int ownedRegion) {
        return database(new NDDPort[] { port }, new int[] { ownedRegion });
    }

    private NDDReachabilityDB database(NDDPort[] ports, int[] ownedRegions) {
        NDDReachabilityDB database = new NDDReachabilityDB();
        Vector<NDDRouter> path = new Vector<>();
        path.add(source);
        path.add(destination);
        HashSet<NDDReachabilityNode> nodes = new HashSet<>();
        for (int index = 0; index < ports.length; index++) {
            nodes.add(new NDDReachabilityNode(destination, ports[index],
                    new NDDTuple(ownedRegions[index], NDD.getTrue()),
                    new Vector<>(path)));
        }
        database.reachabilityForest.put(source, destination, nodes);
        return database;
    }

    private NDDPort port(String name, String ip) {
        NDDPort port = new NDDPort(new PortName(destination.getRouterName(), name),
                destination, new IpAddress(Ip.of(ip), Mask.of(24)), false);
        destination.addPort(port);
        return port;
    }

    private static boolean equivalent(int left, int right) {
        return left == right || (NDD.isFalse(NDD.diff(left, right))
                && NDD.isFalse(NDD.diff(right, left)));
    }
}
