package application.differential.s5;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class IncrementalAdmissionPolicyTest {
    @Test
    public void acceptsLocalClosureAndRejectsNearFullClosure() {
        String sourceKey = "delta.sre.maxIncrementalSourceFraction";
        String ownerKey = "delta.sre.maxDirectOwnerFraction";
        try {
            System.setProperty(sourceKey, "0.60");
            System.setProperty(ownerKey, "0.75");
            assertTrue(IncrementalAdmissionPolicy.accepts(12, 20));
            assertFalse(IncrementalAdmissionPolicy.accepts(13, 20));
            assertTrue(IncrementalAdmissionPolicy.acceptsAffectedRouters(8, 20));
            assertFalse(IncrementalAdmissionPolicy.acceptsAffectedRouters(14, 20));
            assertTrue(IncrementalAdmissionPolicy.acceptsDirectOwners(14, 20));
            assertFalse(IncrementalAdmissionPolicy.acceptsDirectOwners(16, 20));
        } finally {
            System.clearProperty(sourceKey);
            System.clearProperty(ownerKey);
        }
    }

    @Test
    public void systemPropertyOverridesTrainingThreshold() {
        String key = "delta.sre.maxIncrementalSourceFraction";
        String previous = System.getProperty(key);
        try {
            System.setProperty(key, "1.0");
            assertTrue(IncrementalAdmissionPolicy.accepts(80, 80));
        } finally {
            if (previous == null) System.clearProperty(key);
            else System.setProperty(key, previous);
        }
    }
}
