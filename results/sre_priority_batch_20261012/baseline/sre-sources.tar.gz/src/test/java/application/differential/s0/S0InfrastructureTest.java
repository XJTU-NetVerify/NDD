package application.differential.s0;

import bdd.NDDTuple;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.network.PortName;
import controlplane.process.ospf.NDDOspfNeighborConfig;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.process.ospf.NDDOspfTopology;
import controlplane.process.ospf.OspfIntfSetting;
import controlplane.route.Path;
import controlplane.route.builder.NDDOspfRouteBuilder;
import datamodel.ipv4.Header;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import datamodel.ipv4.Mask;
import datamodel.ipv4.Prefix;
import datamodel.property.Flow;
import datamodel.property.NDDProperty;
import datamodel.property.NDDReachability;
import dataplane.analysis.NDDReachabilityDB;
import dataplane.analysis.NDDReachabilityNode;
import org.ants.jndd.diagram.NDD;
import org.junit.Before;
import org.junit.Test;

import java.nio.file.Files;
import java.util.Collections;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.Vector;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class S0InfrastructureTest {
    private int header;
    private int link;

    @Before
    public void initializeNdd() {
        NDD.initNDD(1024, 4096, 1024);
        NDD.declareField(1);
        NDD.declareField(1);
        NDD.generateFields();
        header = NDD.getVar(0, 0);
        link = NDD.getVar(1, 0);
    }

    @Test
    public void snapshotFindsLayerChangesAndReverseIsExact() {
        Fixture fixture = fixture();
        NDDProperty property = reachabilityProperty(fixture.prefix, header);
        NDDReachabilityDB oldReachability = reachability(fixture, header, link);

        try (S0Snapshot oldState = S0Snapshot.capture(
                        Collections.singleton(fixture.left), oldReachability,
                        Collections.singleton(property))) {
            fixture.route.setListTC(link);
            fixture.left.getGlobalRib().getRib().get(fixture.prefix)
                    .get(0).get(0).setListTC(link);
            fixture.left.getFib().getFib().get(fixture.prefix).get(0).get(0)
                    .setListTC(link);
            property.setTC(link);
            NDDReachabilityDB changedReachability = reachability(fixture, link, link);

            try (S0Snapshot newState = S0Snapshot.capture(
                            Collections.singleton(fixture.left), changedReachability,
                            Collections.singleton(property))) {
                fixture.route.setListTC(NDD.getTrue());
                fixture.left.getGlobalRib().getRib().get(fixture.prefix)
                        .get(0).get(0).setListTC(NDD.getTrue());
                fixture.left.getFib().getFib().get(fixture.prefix).get(0).get(0)
                        .setListTC(NDD.getTrue());
                property.setTC(header);
                NDDReachabilityDB restoredReachability = reachability(
                        fixture, header, link);

                try (S0Snapshot restored = S0Snapshot.capture(
                                Collections.singleton(fixture.left), restoredReachability,
                                Collections.singleton(property))) {
                    S0Oracle.Result result = S0Oracle.verify(oldState, newState, restored);
                    assertTrue(result.isReverseExact());
                    assertTrue(result.getForward().getContributions().getChangedCount() > 0);
                    assertTrue(result.getForward().getRib().getChangedCount() > 0);
                    assertTrue(result.getForward().getFib().getChangedCount() > 0);
                    assertTrue(result.getForward().getPfec().getChangedCount() > 0);
                    assertTrue(result.getForward().getProperties().getChangedCount() > 0);
                    result.requireReverseExact();
                }
            }
        }
    }

    @Test
    public void identicalSnapshotsAreAnExactNoOp() {
        Fixture fixture = fixture();
        NDDProperty property = reachabilityProperty(fixture.prefix, header);
        NDDReachabilityDB reachability = reachability(fixture, header, link);
        try (S0Snapshot oldState = S0Snapshot.capture(
                        Collections.singleton(fixture.left), reachability,
                        Collections.singleton(property));
                S0Snapshot newState = S0Snapshot.capture(
                        Collections.singleton(fixture.left), reachability,
                        Collections.singleton(property));
                S0Snapshot restored = S0Snapshot.capture(
                        Collections.singleton(fixture.left), reachability,
                        Collections.singleton(property))) {
            S0Oracle.Result result = S0Oracle.verify(oldState, newState, restored);
            assertTrue(result.getForward().isEmpty());
            assertTrue(result.isReverseExact());
        }
    }

    @Test
    public void pfecSplitAndPropertyFlipAreDetectedAndReversible() {
        Fixture fixture = fixture();
        NDDProperty property = reachabilityProperty(fixture.prefix, NDD.getTrue());
        NDDReachabilityDB oldReachability = reachability(fixture, header, link);
        try (S0Snapshot oldState = S0Snapshot.capture(
                        Collections.singleton(fixture.left), oldReachability,
                        Collections.singleton(property))) {
            int headerUp = NDD.ref(NDD.and(header, link));
            int headerDown = NDD.ref(NDD.and(header, NDD.not(link)));
            NDDReachabilityDB split = new NDDReachabilityDB();
            Vector<NDDRouter> path = new Vector<>();
            path.add(fixture.left);
            path.add(fixture.right);
            HashSet<NDDReachabilityNode> nodes = new HashSet<>();
            nodes.add(new NDDReachabilityNode(fixture.right, fixture.port,
                    new NDDTuple(headerUp, NDD.getTrue()), path));
            nodes.add(new NDDReachabilityNode(fixture.right, fixture.port,
                    new NDDTuple(headerDown, NDD.getTrue()), path));
            split.reachabilityForest.put(fixture.left, fixture.right, nodes);
            property.setTC(NDD.getFalse());
            try (S0Snapshot newState = S0Snapshot.capture(
                            Collections.singleton(fixture.left), split,
                            Collections.singleton(property))) {
                property.setTC(NDD.getTrue());
                try (S0Snapshot restored = S0Snapshot.capture(
                                Collections.singleton(fixture.left), oldReachability,
                                Collections.singleton(property))) {
                    S0Oracle.Result result = S0Oracle.verify(
                            oldState, newState, restored);
                    assertTrue(result.isReverseExact());
                    assertTrue(result.getForward().getPfec().getChangedCount() > 0);
                    assertEquals(1,
                            result.getForward().getProperties().getChangedCount());
                }
            } finally {
                NDD.deref(headerUp);
                NDD.deref(headerDown);
            }
        }
    }

    @Test
    public void reachabilityNodeMarksLoopWhenPathAlreadyContainsRouter() {
        NDDRouter router = router("loop", "eth0", "10.0.0.1");
        Vector<NDDRouter> path = new Vector<>();
        path.add(router);
        NDDReachabilityNode node = new NDDReachabilityNode(router,
                new NDDTuple(header, link), path);
        assertTrue(node.isLoopDetected());
    }

    @Test
    public void ownershipAuditConfirmsDetachedProcessAndGlobalRibs() {
        Fixture fixture = fixture();
        RibOwnershipAudit.Report report = RibOwnershipAudit.inspect(
                Collections.singleton(fixture.left));
        assertTrue(report.isDetached());
        assertEquals(0, report.getListAliasCount());
        assertEquals(0, report.getRouteAliasCount());
    }

    @Test
    public void manifestRoundTripsAndBoundUpdateRollsBack() throws Exception {
        NDDRouter left = router("left", "eth0", "10.0.0.1");
        NDDRouter right = router("right", "eth0", "10.0.0.2");
        NDDOspfProcess leftProcess = new NDDOspfProcess(left, 1);
        NDDOspfProcess rightProcess = new NDDOspfProcess(right, 1);
        left.addOspfProcess(leftProcess);
        right.addOspfProcess(rightProcess);
        NDDPort leftPort = left.getPorts().get(new PortName("left", "eth0"));
        NDDPort rightPort = right.getPorts().get(new PortName("right", "eth0"));

        NDDOspfTopology topology = new NDDOspfTopology();
        NDDOspfNeighborConfig leftConfig = new NDDOspfNeighborConfig(
                leftProcess, new OspfIntfSetting(0, 10, false, 1), leftPort);
        NDDOspfNeighborConfig rightConfig = new NDDOspfNeighborConfig(
                rightProcess, new OspfIntfSetting(0, 20, false, 1), rightPort);
        topology.addNeighborConfig(leftConfig);
        topology.addNeighborConfig(rightConfig);
        topology.addEdge(leftConfig, rightConfig, link);

        OspfCostManifest manifest = OspfCostManifest.generate("fixture", topology, 5);
        assertEquals(2, manifest.getUpdates().size());
        OspfCostUpdate update = manifest.getUpdates().stream()
                .filter(candidate -> candidate.getRouter().equals("left"))
                .findFirst().orElseThrow(AssertionError::new);
        assertTrue(update.isCostIncrease());

        TreeMap<String, NDDRouter> routers = new TreeMap<>();
        routers.put("left", left);
        routers.put("right", right);
        try (OspfCostUpdate.Bound bound = update.bind(routers, topology)) {
            bound.apply();
            assertEquals(15, leftConfig.getIntfSetting().getCost());
        }
        assertEquals(10, leftConfig.getIntfSetting().getCost());

        java.nio.file.Path file = Files.createTempFile("s0-ospf-cost", ".json");
        try {
            manifest.write(file);
            assertEquals(manifest.getUpdates(), OspfCostManifest.read(file).getUpdates());
            assertFalse(manifest.reverse().getUpdates().get(0).isCostIncrease());
        } finally {
            Files.deleteIfExists(file);
        }
    }

    private Fixture fixture() {
        NDDRouter left = router("left", "eth0", "10.0.0.1");
        NDDRouter right = router("right", "eth0", "10.0.0.2");
        NDDOspfProcess process = new NDDOspfProcess(left, 1);
        left.addOspfProcess(process);
        NDDPort port = left.getPorts().get(new PortName("left", "eth0"));
        Prefix prefix = Prefix.of("192.0.2.0/24");
        Path<String> routePath = new Path<>();
        routePath.add("right");
        controlplane.route.NDDOspfRoute route = new NDDOspfRouteBuilder()
                .setPrefix(prefix)
                .setNextHop(Ip.of("10.0.0.2"))
                .setOutPort(port)
                .setPath(routePath)
                .setMetric(10)
                .setArriveTC(header)
                .setListTC(NDD.getTrue())
                .build();
        process.getRib().insert(route);
        process.getRib().install(left.getGlobalRib(), true);
        left.getGlobalRib().install(left.getFib());
        return new Fixture(left, right, port, prefix, route);
    }

    private NDDReachabilityDB reachability(Fixture fixture, int first, int second) {
        NDDReachabilityDB db = new NDDReachabilityDB();
        Vector<NDDRouter> path = new Vector<>();
        path.add(fixture.left);
        path.add(fixture.right);
        NDDReachabilityNode node = new NDDReachabilityNode(fixture.right,
                fixture.port, new NDDTuple(first, second), path);
        db.reachabilityForest.put(fixture.left, fixture.right,
                new HashSet<>(Collections.singleton(node)));
        return db;
    }

    private NDDProperty reachabilityProperty(Prefix destination, int tc) {
        Header headerValue = new Header.HeaderBuilder()
                .setDestination(destination).build();
        NDDReachability property = new NDDReachability(
                new Flow(headerValue, "left"), "right");
        property.setTC(tc);
        return property;
    }

    private static NDDRouter router(String name, String intf, String ip) {
        NDDRouter router = new NDDRouter(name, 65000);
        NDDPort port = new NDDPort(new PortName(name, intf), router,
                new IpAddress(Ip.of(ip), Mask.of(24)), false);
        router.addPort(port);
        return router;
    }

    private static final class Fixture {
        private final NDDRouter left;
        private final NDDRouter right;
        private final NDDPort port;
        private final Prefix prefix;
        private final controlplane.route.NDDOspfRoute route;

        private Fixture(NDDRouter left, NDDRouter right, NDDPort port,
                Prefix prefix, controlplane.route.NDDOspfRoute route) {
            this.left = left;
            this.right = right;
            this.port = port;
            this.prefix = prefix;
            this.route = route;
        }
    }
}
