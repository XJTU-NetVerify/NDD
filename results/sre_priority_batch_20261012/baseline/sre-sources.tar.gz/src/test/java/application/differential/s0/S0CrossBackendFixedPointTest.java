package application.differential.s0;

import bdd.BDDManager;
import bdd.NDDManager;
import controlplane.network.L3Edge;
import controlplane.network.NDDL3Edge;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.network.Port;
import controlplane.network.PortName;
import controlplane.network.Router;
import controlplane.process.ospf.NDDOspfExecutor;
import controlplane.process.ospf.NDDOspfNeighborConfig;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.process.ospf.NDDOspfTopology;
import controlplane.process.ospf.OspfExecutor;
import controlplane.process.ospf.OspfIntfSetting;
import controlplane.process.ospf.OspfNeighborConfig;
import controlplane.process.ospf.OspfProcess;
import controlplane.process.ospf.OspfTopology;
import controlplane.route.DynamicRoute;
import controlplane.route.NDDDynamicRoute;
import controlplane.route.NDDRoute;
import controlplane.route.Route;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import datamodel.ipv4.Mask;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import datamodel.property.NDDProperty;
import datamodel.property.Property;
import dataplane.analysis.DPAnalyzer;
import dataplane.analysis.NDDDPAnalyzer;
import dataplane.analysis.NDDReachabilityDB;
import dataplane.analysis.NDDReachabilityNode;
import dataplane.analysis.NDDSpecificationDB;
import dataplane.analysis.ReachabilityDB;
import dataplane.analysis.ReachabilityNode;
import dataplane.analysis.SpecificationDB;
import dataplane.fib.ForwardingRule;
import dataplane.fib.NDDForwardingRule;
import jdd.bdd.BDD;
import main.Configuration;
import main.Controller;
import main.NDDController;
import org.ants.jndd.diagram.NDD;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;

/** Exhaustive one-symbolic-link cross-backend oracle for the full OSPF fixed point. */
public class S0CrossBackendFixedPointTest {

    @Test
    public void bddAndNddAgreeForOldNewAndReverse() {
        Configuration.FILTER = false;
        Configuration.SORT = false;
        Controller.MF = 1;
        NDDController.MF = 1;

        L3Edge.clearCache();
        L3Edge bddLink = L3Edge.of(
                new PortName("left", "eth0"), new PortName("right", "eth0"));
        Controller.bddManager = new BDDManager(8192, 8192);
        BackendSnapshot bddOld = runBdd(10, bddLink);
        BackendSnapshot bddNew = runBdd(20, bddLink);
        BackendSnapshot bddRestored = runBdd(10, bddLink);

        NDDL3Edge.clearCache();
        NDDL3Edge nddLink = NDDL3Edge.of(
                new PortName("left", "eth0"), new PortName("right", "eth0"));
        NDDController.bddManager = new NDDManager(8192, 8192);
        BackendSnapshot nddOld = runNdd(10, nddLink);
        BackendSnapshot nddNew = runNdd(20, nddLink);
        BackendSnapshot nddRestored = runNdd(10, nddLink);

        assertEquals(bddOld, bddRestored);
        assertEquals(nddOld, nddRestored);
        assertNotEquals(bddOld, bddNew);
        assertNotEquals(nddOld, nddNew);
        assertEquals(bddOld, nddOld);
        assertEquals(bddNew, nddNew);
        assertEquals(bddRestored, nddRestored);
    }

    @Test
    public void bddAndNddAgreeForPfecAndMinedReachability() {
        Configuration.FILTER = false;
        Configuration.SORT = false;
        Configuration.LAZY = false;
        Configuration.FORWARD = true;
        Controller.MF = 1;
        NDDController.MF = 1;

        L3Edge.clearCache();
        L3Edge bddLink = L3Edge.of(
                new PortName("left", "eth0"), new PortName("right", "eth0"));
        Controller.bddManager = new BDDManager(16384, 16384);
        DataSnapshot bddOld = runBddDataPlane(10, bddLink);
        DataSnapshot bddNew = runBddDataPlane(20, bddLink);
        DataSnapshot bddRestored = runBddDataPlane(10, bddLink);

        NDDL3Edge.clearCache();
        NDDL3Edge nddLink = NDDL3Edge.of(
                new PortName("left", "eth0"), new PortName("right", "eth0"));
        NDDController.bddManager = new NDDManager(16384, 16384);
        DataSnapshot nddOld = runNddDataPlane(10, nddLink);
        DataSnapshot nddNew = runNddDataPlane(20, nddLink);
        DataSnapshot nddRestored = runNddDataPlane(10, nddLink);

        assertEquals(bddOld, bddRestored);
        assertEquals(nddOld, nddRestored);
        assertEquals(bddOld, nddOld);
        assertEquals(bddNew, nddNew);
        assertEquals(bddRestored, nddRestored);
        assertFalse("fixture must exercise PFEC", bddOld.pfec.isEmpty());
        assertFalse("fixture must exercise property mining", bddOld.properties.isEmpty());
    }

    private static DataSnapshot runBddDataPlane(int rightCost, L3Edge link) {
        Router left = bddDataRouter("left", "10.0.0.0", "192.0.2.1");
        Router right = bddDataRouter("right", "10.0.0.1", "198.51.100.1");
        Port leftLink = left.getPorts().get(new PortName("left", "eth0"));
        Port rightLink = right.getPorts().get(new PortName("right", "eth0"));
        leftLink.setLinkedPort(rightLink);
        rightLink.setLinkedPort(leftLink);
        leftLink.setLink(link);
        rightLink.setLink(link);
        left.genConnectedRoute();
        right.genConnectedRoute();
        left.installOriginalRoutesToGlobalRib();
        right.installOriginalRoutesToGlobalRib();

        OspfProcess leftProcess = new OspfProcess(left, 1);
        OspfProcess rightProcess = new OspfProcess(right, 1);
        left.addOspfProcess(leftProcess);
        right.addOspfProcess(rightProcess);
        leftProcess.addRedistribution(controlplane.route.RoutingProtocol.CONNECTED);
        rightProcess.addRedistribution(controlplane.route.RoutingProtocol.CONNECTED);
        leftProcess.setValid(true);
        rightProcess.setValid(true);
        OspfNeighborConfig leftConfig = new OspfNeighborConfig(leftProcess,
                new OspfIntfSetting(0, 10, false, 1), leftLink);
        OspfNeighborConfig rightConfig = new OspfNeighborConfig(rightProcess,
                new OspfIntfSetting(0, rightCost, false, 1), rightLink);
        OspfTopology topology = new OspfTopology();
        topology.addNeighborConfig(leftConfig);
        topology.addNeighborConfig(rightConfig);
        topology.addEdge(leftConfig, rightConfig, link.getTC());
        OspfExecutor.execute(topology);
        left.installIgpRoutesToGlobalRib();
        right.installIgpRoutesToGlobalRib();
        left.installGlobalRibToFib();
        right.installGlobalRibToFib();

        for (Router router : Arrays.asList(left, right)) {
            DPAnalyzer.computeFwdBDD(router, 1);
            DPAnalyzer.computeAclBDD(router);
        }
        ReachabilityDB db = new ReachabilityDB();
        db.buildReachabilityTree(left);
        db.buildReachabilityTree(right);
        Set<Property> properties = new SpecificationDB(db).mineReachability();
        return captureBddData(db, properties, link);
    }

    private static DataSnapshot runNddDataPlane(int rightCost, NDDL3Edge link) {
        NDDRouter left = nddDataRouter("left", "10.0.0.0", "192.0.2.1");
        NDDRouter right = nddDataRouter("right", "10.0.0.1", "198.51.100.1");
        NDDPort leftLink = left.getPorts().get(new PortName("left", "eth0"));
        NDDPort rightLink = right.getPorts().get(new PortName("right", "eth0"));
        leftLink.setLinkedPort(rightLink);
        rightLink.setLinkedPort(leftLink);
        leftLink.setLink(link);
        rightLink.setLink(link);
        left.genConnectedRoute();
        right.genConnectedRoute();
        left.installOriginalRoutesToGlobalRib();
        right.installOriginalRoutesToGlobalRib();

        NDDOspfProcess leftProcess = new NDDOspfProcess(left, 1);
        NDDOspfProcess rightProcess = new NDDOspfProcess(right, 1);
        left.addOspfProcess(leftProcess);
        right.addOspfProcess(rightProcess);
        leftProcess.addRedistribution(controlplane.route.RoutingProtocol.CONNECTED);
        rightProcess.addRedistribution(controlplane.route.RoutingProtocol.CONNECTED);
        leftProcess.setValid(true);
        rightProcess.setValid(true);
        NDDOspfNeighborConfig leftConfig = new NDDOspfNeighborConfig(leftProcess,
                new OspfIntfSetting(0, 10, false, 1), leftLink);
        NDDOspfNeighborConfig rightConfig = new NDDOspfNeighborConfig(rightProcess,
                new OspfIntfSetting(0, rightCost, false, 1), rightLink);
        NDDOspfTopology topology = new NDDOspfTopology();
        topology.addNeighborConfig(leftConfig);
        topology.addNeighborConfig(rightConfig);
        topology.addEdge(leftConfig, rightConfig, link.getTC());
        NDDOspfExecutor.execute(topology);
        left.installIgpRoutesToGlobalRib();
        right.installIgpRoutesToGlobalRib();
        left.installGlobalRibToFib();
        right.installGlobalRibToFib();

        for (NDDRouter router : Arrays.asList(left, right)) {
            NDDDPAnalyzer.computeFwdBDD(router, NDD.getTrue());
            NDDDPAnalyzer.computeAclBDD(router);
        }
        NDDReachabilityDB db = new NDDReachabilityDB();
        db.buildReachabilityTree(left);
        db.buildReachabilityTree(right);
        Set<NDDProperty> properties = new NDDSpecificationDB(db).mineReachability();
        return captureNddData(db, properties);
    }

    private static Router bddDataRouter(String name, String linkIp, String edgeIp) {
        Router router = new Router(name, 65000);
        router.addPort(new Port(new PortName(name, "eth0"), router,
                new IpAddress(Ip.of(linkIp), Mask.of(31)), false));
        Port edge = new Port(new PortName(name, "host0"), router,
                new IpAddress(Ip.of(edgeIp), Mask.of(24)), false);
        edge.setEdge();
        router.addPort(edge);
        return router;
    }

    private static NDDRouter nddDataRouter(String name, String linkIp, String edgeIp) {
        NDDRouter router = new NDDRouter(name, 65000);
        router.addPort(new NDDPort(new PortName(name, "eth0"), router,
                new IpAddress(Ip.of(linkIp), Mask.of(31)), false));
        NDDPort edge = new NDDPort(new PortName(name, "host0"), router,
                new IpAddress(Ip.of(edgeIp), Mask.of(24)), false);
        edge.setEdge();
        router.addPort(edge);
        return router;
    }

    private static DataSnapshot captureBddData(ReachabilityDB db,
            Collection<Property> properties, L3Edge link) {
        Map<String, String> pfec = new TreeMap<>();
        db.reachabilityForest.cellSet().forEach(cell -> {
            String source = Objects.requireNonNull(cell.getRowKey()).getRouterName();
            String destination = Objects.requireNonNull(cell.getColumnKey()).getRouterName();
            for (ReachabilityNode node : Objects.requireNonNull(cell.getValue())) {
                int predicate = Controller.bddManager.and(
                        node.getTuple().getFirst(), node.getTuple().getSecond());
                try {
                    String base = source + "|" + destination + "|"
                            + node.getOutPort().getPortName() + "|"
                            + node.getPath().stream().map(Router::getRouterName)
                                    .collect(Collectors.joining(">"));
                    Controller.bddManager.getBDDPredicateWrapper().splitHeaderTC(predicate)
                            .forEach((header, tc) -> pfec.put(base + "|" + header,
                                    truthBdd(tc, link)));
                } finally {
                    Controller.bddManager.deref(predicate);
                }
            }
        });
        Map<String, String> propertyStates = new TreeMap<>();
        for (Property property : properties) {
            propertyStates.put(property.getType() + "|" + property.toSpecification()
                    + "|mf=" + property.getMF(), truthBdd(property.getTC(), link));
        }
        return new DataSnapshot(pfec, propertyStates);
    }

    private static DataSnapshot captureNddData(NDDReachabilityDB db,
            Collection<NDDProperty> properties) {
        Map<String, String> pfec = new TreeMap<>();
        db.reachabilityForest.cellSet().forEach(cell -> {
            String source = Objects.requireNonNull(cell.getRowKey()).getRouterName();
            String destination = Objects.requireNonNull(cell.getColumnKey()).getRouterName();
            for (NDDReachabilityNode node : Objects.requireNonNull(cell.getValue())) {
                int predicate = NDD.ref(NDD.and(
                        node.getTuple().getFirst(), node.getTuple().getSecond()));
                try {
                    String base = source + "|" + destination + "|"
                            + node.getOutPort().getPortName() + "|"
                            + node.getPath().stream().map(NDDRouter::getRouterName)
                                    .collect(Collectors.joining(">"));
                    NDDController.bddManager.getBDDPredicateWrapper().splitHeaderTC(predicate)
                            .forEach((header, tc) -> pfec.put(base + "|" + header,
                                    truthNdd(tc)));
                } finally {
                    NDD.deref(predicate);
                }
            }
        });
        Map<String, String> propertyStates = new TreeMap<>();
        for (NDDProperty property : properties) {
            propertyStates.put(property.getType() + "|" + property.toSpecification()
                    + "|mf=" + property.getMF(), truthNdd(property.getTC()));
        }
        return new DataSnapshot(pfec, propertyStates);
    }

    private static BackendSnapshot runBdd(int rightCost, L3Edge link) {
        Router left = bddRouter("left", "10.0.0.1");
        Router right = bddRouter("right", "10.0.0.2");
        OspfProcess leftProcess = new OspfProcess(left, 1);
        OspfProcess rightProcess = new OspfProcess(right, 1);
        left.addOspfProcess(leftProcess);
        right.addOspfProcess(rightProcess);
        addAnnouncedPrefix(leftProcess);
        leftProcess.setValid(true);
        rightProcess.setValid(true);
        Port leftPort = left.getPorts().get(new PortName("left", "eth0"));
        Port rightPort = right.getPorts().get(new PortName("right", "eth0"));
        OspfNeighborConfig leftConfig = new OspfNeighborConfig(leftProcess,
                new OspfIntfSetting(0, 10, false, 1), leftPort);
        OspfNeighborConfig rightConfig = new OspfNeighborConfig(rightProcess,
                new OspfIntfSetting(0, rightCost, false, 1), rightPort);
        OspfTopology topology = new OspfTopology();
        topology.addNeighborConfig(leftConfig);
        topology.addNeighborConfig(rightConfig);
        topology.addEdge(leftConfig, rightConfig, link.getTC());
        OspfExecutor.execute(topology);
        left.installIgpRoutesToGlobalRib();
        right.installIgpRoutesToGlobalRib();
        left.installGlobalRibToFib();
        right.installGlobalRibToFib();
        return captureBdd(Arrays.asList(left, right), link);
    }

    private static BackendSnapshot runNdd(int rightCost, NDDL3Edge link) {
        NDDRouter left = nddRouter("left", "10.0.0.1");
        NDDRouter right = nddRouter("right", "10.0.0.2");
        NDDOspfProcess leftProcess = new NDDOspfProcess(left, 1);
        NDDOspfProcess rightProcess = new NDDOspfProcess(right, 1);
        left.addOspfProcess(leftProcess);
        right.addOspfProcess(rightProcess);
        addAnnouncedPrefix(leftProcess);
        leftProcess.setValid(true);
        rightProcess.setValid(true);
        NDDPort leftPort = left.getPorts().get(new PortName("left", "eth0"));
        NDDPort rightPort = right.getPorts().get(new PortName("right", "eth0"));
        NDDOspfNeighborConfig leftConfig = new NDDOspfNeighborConfig(leftProcess,
                new OspfIntfSetting(0, 10, false, 1), leftPort);
        NDDOspfNeighborConfig rightConfig = new NDDOspfNeighborConfig(rightProcess,
                new OspfIntfSetting(0, rightCost, false, 1), rightPort);
        NDDOspfTopology topology = new NDDOspfTopology();
        topology.addNeighborConfig(leftConfig);
        topology.addNeighborConfig(rightConfig);
        topology.addEdge(leftConfig, rightConfig, link.getTC());
        NDDOspfExecutor.execute(topology);
        left.installIgpRoutesToGlobalRib();
        right.installIgpRoutesToGlobalRib();
        left.installGlobalRibToFib();
        right.installGlobalRibToFib();
        return captureNdd(Arrays.asList(left, right));
    }

    private static void addAnnouncedPrefix(OspfProcess process) {
        Prefix prefix = Prefix.of("192.0.2.0/24");
        prefix.setInterested(true);
        process.addNetwork(prefix);
    }

    private static void addAnnouncedPrefix(NDDOspfProcess process) {
        Prefix prefix = Prefix.of("192.0.2.0/24");
        prefix.setInterested(true);
        process.addNetwork(prefix);
    }

    private static Router bddRouter(String name, String ip) {
        Router router = new Router(name, 65000);
        router.addPort(new Port(new PortName(name, "eth0"), router,
                new IpAddress(Ip.of(ip), Mask.of(24)), false));
        return router;
    }

    private static NDDRouter nddRouter(String name, String ip) {
        NDDRouter router = new NDDRouter(name, 65000);
        router.addPort(new NDDPort(new PortName(name, "eth0"), router,
                new IpAddress(Ip.of(ip), Mask.of(24)), false));
        return router;
    }

    private static BackendSnapshot captureBdd(Iterable<Router> routers, L3Edge link) {
        Map<String, String> states = new TreeMap<>();
        for (Router router : routers) {
            for (OspfProcess process : router.getOspfProcesses().values()) {
                process.getRib().getRib().values().forEach(list ->
                        addBddRoutes(states, "contribution", router.getRouterName(), list, link));
            }
            router.getGlobalRib().getRib().values().forEach(list ->
                    addBddRoutes(states, "rib", router.getRouterName(), list, link));
            router.getFib().getFib().values().forEach(list -> {
                for (int group = 0; group < list.size(); group++) {
                    for (SortedMultiListItem item : list.get(group)) {
                        ForwardingRule rule = (ForwardingRule) item;
                        String key = "fib|" + router.getRouterName() + "|" + rule.getPrefix()
                                + "|" + rule.getNextHop() + "|" + rule.getOutPort()
                                + "|group=" + group;
                        states.put(key, truthBdd(rule.getArriveTC(), link) + "/"
                                + truthBdd(rule.getListTC(), link));
                    }
                }
            });
        }
        return new BackendSnapshot(states);
    }

    private static BackendSnapshot captureNdd(Iterable<NDDRouter> routers) {
        Map<String, String> states = new TreeMap<>();
        for (NDDRouter router : routers) {
            for (NDDOspfProcess process : router.getOspfProcesses().values()) {
                process.getRib().getRib().values().forEach(list ->
                        addNddRoutes(states, "contribution", router.getRouterName(), list));
            }
            router.getGlobalRib().getRib().values().forEach(list ->
                    addNddRoutes(states, "rib", router.getRouterName(), list));
            router.getFib().getFib().values().forEach(list -> {
                for (int group = 0; group < list.size(); group++) {
                    for (NDDSortedMultiListItem item : list.get(group)) {
                        NDDForwardingRule rule = (NDDForwardingRule) item;
                        String key = "fib|" + router.getRouterName() + "|" + rule.getPrefix()
                                + "|" + rule.getNextHop() + "|" + rule.getOutPort()
                                + "|group=" + group;
                        states.put(key, truthNdd(rule.getArriveTC()) + "/"
                                + truthNdd(rule.getListTC()));
                    }
                }
            });
        }
        return new BackendSnapshot(states);
    }

    private static void addBddRoutes(Map<String, String> target, String layer,
            String router, SortedMultiList list, L3Edge link) {
        for (int group = 0; group < list.size(); group++) {
            for (SortedMultiListItem item : list.get(group)) {
                Route route = (Route) item;
                String path = route instanceof DynamicRoute
                        ? ((DynamicRoute) route).getPath().stream().collect(Collectors.joining(">")) : "";
                String key = routeKey(layer, router, route.getPrefix().toString(),
                        route.getProtocol().toString(), route.getMetric(), route.getNextHop().toString(),
                        route.getOutPort().getPortName().toString(), path, group);
                target.put(key, truthBdd(route.getArriveTC(), link) + "/"
                        + truthBdd(route.getListTC(), link));
            }
        }
    }

    private static void addNddRoutes(Map<String, String> target, String layer,
            String router, NDDSortedMultiList list) {
        for (int group = 0; group < list.size(); group++) {
            for (NDDSortedMultiListItem item : list.get(group)) {
                NDDRoute route = (NDDRoute) item;
                String path = route instanceof NDDDynamicRoute
                        ? ((NDDDynamicRoute) route).getPath().stream().collect(Collectors.joining(">")) : "";
                String key = routeKey(layer, router, route.getPrefix().toString(),
                        route.getProtocol().toString(), route.getMetric(), route.getNextHop().toString(),
                        route.getOutPort().getPortName().toString(), path, group);
                target.put(key, truthNdd(route.getArriveTC()) + "/"
                        + truthNdd(route.getListTC()));
            }
        }
    }

    private static String routeKey(String layer, String router, String prefix,
            String protocol, Long metric, String nextHop, String outPort,
            String path, int group) {
        return layer + "|" + router + "|" + prefix + "|" + protocol
                + "|metric=" + metric + "|" + nextHop + "|" + outPort
                + "|" + path + "|group=" + group;
    }

    private static String truthBdd(int root, L3Edge link) {
        BDD bdd = Controller.bddManager.getBDD();
        int linkVariable = bdd.getVar(link.getTC());
        return bit(evaluateBdd(bdd, root, linkVariable, false))
                + bit(evaluateBdd(bdd, root, linkVariable, true));
    }

    private static boolean evaluateBdd(BDD bdd, int root,
            int linkVariable, boolean linkUp) {
        while (root > 1) {
            int variable = bdd.getVar(root);
            boolean value = variable == linkVariable && linkUp;
            root = value ? bdd.getHigh(root) : bdd.getLow(root);
        }
        return root == 1;
    }

    private static String truthNdd(int root) {
        int linkField = NDD.getFieldNum();
        int down = NDD.restrict(root, linkField, 0L);
        int up = NDD.restrict(root, linkField, 1L);
        if ((!NDD.isFalse(down) && !NDD.isTrue(down))
                || (!NDD.isFalse(up) && !NDD.isTrue(up))) {
            throw new AssertionError("route predicate unexpectedly depends on header fields");
        }
        return bit(NDD.isTrue(down)) + bit(NDD.isTrue(up));
    }

    private static String bit(boolean value) { return value ? "1" : "0"; }

    private static final class BackendSnapshot {
        private final Map<String, String> states;
        private BackendSnapshot(Map<String, String> states) { this.states = states; }
        @Override public boolean equals(Object other) {
            return other instanceof BackendSnapshot
                    && states.equals(((BackendSnapshot) other).states);
        }
        @Override public int hashCode() { return states.hashCode(); }
        @Override public String toString() { return states.toString(); }
    }

    private static final class DataSnapshot {
        private final Map<String, String> pfec;
        private final Map<String, String> properties;
        private DataSnapshot(Map<String, String> pfec, Map<String, String> properties) {
            this.pfec = pfec;
            this.properties = properties;
        }
        @Override public boolean equals(Object other) {
            return other instanceof DataSnapshot
                    && pfec.equals(((DataSnapshot) other).pfec)
                    && properties.equals(((DataSnapshot) other).properties);
        }
        @Override public int hashCode() { return Objects.hash(pfec, properties); }
        @Override public String toString() {
            return "pfec=" + pfec + ", properties=" + properties;
        }
    }
}
