package application.differential.s5;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class PersistentGenerationCoordinatorTest {
    @Test
    public void generationAdvancesOnlyAfterVerifiedCommitAndReplayIsStable() {
        PersistentGenerationCoordinator coordinator =
                new PersistentGenerationCoordinator();
        FakeTransaction first = new FakeTransaction(false, false);
        PersistentGenerationCoordinator.Outcome committed = coordinator.execute(
                "e1", () -> first, () -> new FakeTransaction(false, false));
        assertEquals(1, committed.getGeneration());
        assertEquals(PersistentGenerationCoordinator.Mode.INCREMENTAL,
                committed.getMode());
        assertTrue(first.committed);

        PersistentGenerationCoordinator.Outcome replay = coordinator.execute(
                "e1", () -> { throw new AssertionError(); },
                () -> { throw new AssertionError(); });
        assertEquals(1, replay.getGeneration());
        assertEquals(PersistentGenerationCoordinator.Mode.REPLAY, replay.getMode());
    }

    @Test
    public void failedPrefixRollsBackAndFullFallbackUsesSameCommitBoundary() {
        PersistentGenerationCoordinator coordinator =
                new PersistentGenerationCoordinator();
        FakeTransaction failed = new FakeTransaction(false, true);
        try {
            coordinator.execute("failed", () -> failed,
                    () -> new FakeTransaction(false, false));
            fail("verification failure expected");
        } catch (IllegalStateException expected) {
            assertTrue(failed.rolledBack);
            assertEquals(0, coordinator.getGeneration());
        }

        FakeTransaction rejected = new FakeTransaction(true, false);
        FakeTransaction full = new FakeTransaction(false, false);
        PersistentGenerationCoordinator.Outcome outcome = coordinator.execute(
                "fallback", () -> rejected, () -> full);
        assertEquals(PersistentGenerationCoordinator.Mode.FULL, outcome.getMode());
        assertEquals("budget", outcome.getFallbackReason());
        assertEquals(1, coordinator.getGeneration());
        assertTrue(full.committed);
    }

    private static final class FakeTransaction
            implements PersistentGenerationCoordinator.Transaction {
        private final boolean fallback;
        private final boolean failVerification;
        private boolean applied;
        private boolean committed;
        private boolean rolledBack;

        private FakeTransaction(boolean fallback, boolean failVerification) {
            this.fallback = fallback;
            this.failVerification = failVerification;
        }

        public boolean isFallback() { return fallback; }
        public String fallbackReason() { return fallback ? "budget" : "none"; }
        public void apply() { applied = true; }
        public void verify() {
            if (failVerification) throw new IllegalStateException("oracle");
        }
        public void commit() { committed = true; applied = false; }
        public void rollback() { rolledBack |= applied; applied = false; }
        public void close() { rollback(); }
    }
}
