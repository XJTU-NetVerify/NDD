package application.differential.s0;

import bdd.NDDManager;
import controlplane.network.NDDCPExecutor;
import controlplane.network.NDDL3Edge;
import main.Configuration;
import main.NDDController;
import main.storage.Storage;
import org.junit.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/** Real-dataset preflight: parse FT04 and bind every generated event without mutation. */
public class S0Ft04ManifestSmokeTest {

    @Test
    public void ft04ManifestIsDeterministicAndEveryEventBinds() throws Exception {
        NDDL3Edge.clearCache();
        NDDController.cpExecutorStack.clear();
        NDDController.ospfValidRouters.clear();
        NDDController.bgpValidRouters.clear();
        NDDController.MF = 1;
        Configuration.SORT = false;

        Path input = Paths.get("networks/exp/fattree/ospf/ospf_fattree04");
        Path output = Files.createTempDirectory("s0-ft04-output");
        try {
            NDDController.storage = new Storage(input, output);
            NDDCPExecutor executor = new NDDCPExecutor();
            NDDController.cpExecutor = executor;
            NDDController.cpExecutorStack.add(executor);
            executor.init();
            NDDController.bddManager = new NDDManager(200_000, 20_000);
            executor.buildOspfTopology();

            OspfCostManifest first = OspfCostManifest.generate(
                    "ospf_fattree04", executor.getOspfTopology(), 1);
            OspfCostManifest second = OspfCostManifest.generate(
                    "ospf_fattree04", executor.getOspfTopology(), 1);
            assertFalse(first.getUpdates().isEmpty());
            assertEquals(64, first.getUpdates().size());
            assertEquals(first.getUpdates(), second.getUpdates());
            for (OspfCostUpdate update : first.getUpdates()) {
                assertTrue(update.isCostIncrease());
                try (OspfCostUpdate.Bound ignored = update.bind(
                        executor.getRouters(), executor.getOspfTopology())) {
                    // Bind is a read-only prepare step.
                }
            }
        } finally {
            NDDController.cpExecutorStack.clear();
            deleteTree(output);
        }
    }

    private static void deleteTree(Path root) throws Exception {
        try (java.util.stream.Stream<Path> paths = Files.walk(root)) {
            paths.sorted(java.util.Comparator.reverseOrder()).forEach(path -> {
                try {
                    Files.deleteIfExists(path);
                } catch (java.io.IOException exception) {
                    throw new java.io.UncheckedIOException(exception);
                }
            });
        }
    }
}
