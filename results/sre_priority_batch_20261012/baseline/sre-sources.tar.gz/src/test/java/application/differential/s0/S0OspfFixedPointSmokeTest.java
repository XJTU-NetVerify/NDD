package application.differential.s0;

import bdd.NDDManager;
import controlplane.network.NDDL3Edge;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.network.PortName;
import controlplane.process.ospf.NDDOspfExecutor;
import controlplane.process.ospf.NDDOspfNeighborConfig;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.process.ospf.NDDOspfTopology;
import controlplane.process.ospf.OspfIntfSetting;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import datamodel.ipv4.Mask;
import datamodel.ipv4.Prefix;
import main.Configuration;
import main.NDDController;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

/** Small full fixed-point preflight before any dataset locality run. */
public class S0OspfFixedPointSmokeTest {

    @Test
    public void fullOldNewReverseCostRunIsExact() {
        NDDL3Edge.clearCache();
        NDDController.ospfValidRouters.clear();
        NDDController.bgpValidRouters.clear();
        NDDController.cpExecutorStack.clear();
        NDDController.MF = 1;
        Configuration.SORT = false;

        NDDL3Edge link = NDDL3Edge.of(
                new PortName("left", "eth0"), new PortName("right", "eth0"));
        NDDController.bddManager = new NDDManager(8192, 8192);

        FullRun oldRun = run(10, link.getTC());
        FullRun newRun = run(20, link.getTC());
        FullRun restoredRun = run(10, link.getTC());
        try (S0Snapshot oldState = S0Snapshot.capture(oldRun.routers, null, null);
                S0Snapshot newState = S0Snapshot.capture(newRun.routers, null, null);
                S0Snapshot restored = S0Snapshot.capture(restoredRun.routers, null, null)) {
            S0Oracle.Result result = S0Oracle.verify(oldState, newState, restored);
            assertTrue(result.isReverseExact());
            assertTrue(result.getForward().getContributions().getChangedCount() > 0);
            assertTrue(result.getForward().getRib().getChangedCount() > 0);
            // The selected next-hop/predicate is unchanged: this is an exact no-FIB-change case.
            assertEquals(0, result.getForward().getFib().getChangedCount());
        }
    }

    private static FullRun run(int rightCost, int linkTc) {
        NDDRouter left = router("left", "10.0.0.1");
        NDDRouter right = router("right", "10.0.0.2");
        NDDOspfProcess leftProcess = new NDDOspfProcess(left, 1);
        NDDOspfProcess rightProcess = new NDDOspfProcess(right, 1);
        left.addOspfProcess(leftProcess);
        right.addOspfProcess(rightProcess);
        Prefix prefix = Prefix.of("192.0.2.0/24");
        prefix.setInterested(true);
        leftProcess.addNetwork(prefix);
        leftProcess.setValid(true);
        rightProcess.setValid(true);

        NDDPort leftPort = left.getPorts().get(new PortName("left", "eth0"));
        NDDPort rightPort = right.getPorts().get(new PortName("right", "eth0"));
        NDDOspfNeighborConfig leftConfig = new NDDOspfNeighborConfig(
                leftProcess, new OspfIntfSetting(0, 10, false, 1), leftPort);
        NDDOspfNeighborConfig rightConfig = new NDDOspfNeighborConfig(
                rightProcess, new OspfIntfSetting(0, rightCost, false, 1), rightPort);
        NDDOspfTopology topology = new NDDOspfTopology();
        topology.addNeighborConfig(leftConfig);
        topology.addNeighborConfig(rightConfig);
        topology.addEdge(leftConfig, rightConfig, linkTc);

        NDDOspfExecutor.execute(topology);
        left.installIgpRoutesToGlobalRib();
        right.installIgpRoutesToGlobalRib();
        left.installGlobalRibToFib();
        right.installGlobalRibToFib();
        return new FullRun(Arrays.asList(left, right));
    }

    private static NDDRouter router(String name, String ip) {
        NDDRouter router = new NDDRouter(name, 65000);
        NDDPort port = new NDDPort(new PortName(name, "eth0"), router,
                new IpAddress(Ip.of(ip), Mask.of(24)), false);
        router.addPort(port);
        return router;
    }

    private static final class FullRun {
        private final java.util.List<NDDRouter> routers;
        private FullRun(java.util.List<NDDRouter> routers) { this.routers = routers; }
    }
}
