package application.differential.s5;

import application.differential.s4.PfecPartitionSnapshot;
import bdd.NDDTuple;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import controlplane.network.PortName;
import dataplane.analysis.NDDReachabilityDB;
import dataplane.analysis.NDDReachabilityNode;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import datamodel.ipv4.Mask;
import org.ants.jndd.diagram.NDD;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Vector;

import static org.junit.Assert.assertTrue;

public class PersistentReachabilityCommitTest {
    @Test
    public void committedSourceRowsSurviveCandidateCloseAndPreserveUnaffectedRows() {
        NDD.initNDD(1024, 4096, 1024);
        NDD.declareField(1);
        NDD.generateFields();
        int header = NDD.getVar(0, 0);
        NDDRouter first = new NDDRouter("first", 65000);
        NDDRouter second = new NDDRouter("second", 65000);
        NDDRouter destination = new NDDRouter("destination", 65000);
        NDDPort oldPort = port(destination, "old", "192.0.2.1");
        NDDPort newPort = port(destination, "new", "198.51.100.1");
        try (NDDReachabilityDB live = new NDDReachabilityDB();
                NDDReachabilityDB candidate = new NDDReachabilityDB()) {
            insert(live, first, destination, oldPort, NDD.ref(header));
            insert(live, second, destination, oldPort, NDD.ref(NDD.getTrue()));
            insert(candidate, first, destination, newPort,
                    NDD.ref(NDD.not(header)));
            try (PfecPartitionSnapshot expectedAffected =
                            PfecPartitionSnapshot.capture(candidate,
                                    Collections.singleton("first"));
                    PfecPartitionSnapshot expectedUnaffected =
                            PfecPartitionSnapshot.capture(live,
                                    Collections.singleton("second"))) {
                live.replaceSourcesFrom(candidate, Collections.singleton(first));
                candidate.close();
                try (PfecPartitionSnapshot actualAffected =
                                PfecPartitionSnapshot.capture(live,
                                        Collections.singleton("first"));
                        PfecPartitionSnapshot actualUnaffected =
                                PfecPartitionSnapshot.capture(live,
                                        Collections.singleton("second"))) {
                    assertTrue(expectedAffected.semanticallyEquivalent(actualAffected));
                    assertTrue(expectedUnaffected.semanticallyEquivalent(actualUnaffected));
                }
            }
        }
    }

    private static void insert(NDDReachabilityDB database, NDDRouter source,
            NDDRouter destination, NDDPort port, int ownedRegion) {
        Vector<NDDRouter> path = new Vector<>(Arrays.asList(source, destination));
        HashSet<NDDReachabilityNode> nodes = new HashSet<>();
        nodes.add(new NDDReachabilityNode(destination, port,
                new NDDTuple(ownedRegion, NDD.getTrue()), path));
        database.reachabilityForest.put(source, destination, nodes);
        database.pfecNums.put(source, destination, 1);
    }

    private static NDDPort port(NDDRouter router, String name, String ip) {
        NDDPort port = new NDDPort(new PortName(router.getRouterName(), name),
                router, new IpAddress(Ip.of(ip), Mask.of(24)), false);
        router.addPort(port);
        return port;
    }
}
