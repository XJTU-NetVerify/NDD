package bdd;

import controlplane.network.NDDL3Edge;
import controlplane.network.PortName;
import datamodel.ipv4.Header;
import datamodel.ipv4.Prefix;
import dataplane.acl.Range;
import main.Configuration;
import main.NDDController;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.assertEquals;

/** Regression coverage for legacy LSB arrays crossing the MSB-first NDD field API. */
public class NDDHeaderDecompositionTest {
    private NDDManager manager;

    @Before
    public void initialize() {
        NDDL3Edge.clearCache();
        NDDL3Edge.of(new PortName("left", "eth0"),
                new PortName("right", "eth0"));
        NDDController.MF = -1;
        Configuration.FILTER = false;
        manager = new NDDManager(4096, 4096);
        NDDController.bddManager = manager;
    }

    @Test
    public void destinationPrefixRoundTripsWithoutByteOrBitReversal() {
        int predicate = manager.getBDDACLWrapper()
                .encodeDstIPPrefix(Prefix.of("192.0.2.0/24"));
        Map<Header, Integer> split = manager.getBDDPredicateWrapper()
                .splitHeaderTC(predicate);
        assertEquals(1, split.size());
        assertEquals(Prefix.of("192.0.2.0/24"),
                split.keySet().iterator().next().getDestination());
    }

    @Test
    public void destinationPortRangeRoundTripsInFieldOrder() {
        int predicate = manager.getBDDACLWrapper()
                .ConvertDstPort(new Range(1000, 1007));
        Map<Header, Integer> split = manager.getBDDPredicateWrapper()
                .splitHeaderTC(predicate);
        assertEquals(1, split.size());
        assertEquals(new Range(1000, 1007),
                split.keySet().iterator().next().getDestinationPort());
    }
}
