package bdd;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import controlplane.network.*;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import jdd.bdd.BDD;
import main.Configuration;
import main.Controller;
import main.SRELogger;
import org.jgrapht.Graph;
import util.TimeUtil;



public class BDDTCWrapper {
    BDD bdd;
    BDDManager manager;

    L3Edge[] links;
    int[] linkVars;
    int totalLinkBit;

    public BDDTCWrapper(BDDManager manager) {
        this.manager = manager;
        this.bdd = manager.bdd;
        if (!Configuration.TEST_RANDOM_VARIABLE_ORDER) {
            setLinkVars(L3Edge.getAllL3Edge());
        }
    }

    public List<L3Edge> sort(Set<L3Edge> edges) {
        if (Configuration.SORT) {
            switch (Configuration.SORT_METHOD) {
                case RANDOM:
                    SRELogger.log(SRELogger.LEVEL.INFO, "random order");
                    return randomOrder(edges);
                case CONNECTIVITY:
                    SRELogger.log(SRELogger.LEVEL.INFO, "connectivity order");
                    return connectivityOrder(edges);
                case CONNECTIVITY_REVERSE:
                    SRELogger.log(SRELogger.LEVEL.INFO, "connectivity order reversed");
                    return connectivityOrderReverse(edges);
                case PROPAGATION:
                    SRELogger.log(SRELogger.LEVEL.INFO, "propagation order");
                    return propagationOrder(edges);
                case PROPAGATION_REVERSE:
                    SRELogger.log(SRELogger.LEVEL.INFO, "propagation order reversed");
                    return propagationOrderReverse(edges);
            }
            return propagationOrderReverse(edges);
        } else {
            return new ArrayList<>(edges);
        }
    }

    public List<L3Edge> randomOrder(Set<L3Edge> edges) {
        List<L3Edge> list = new ArrayList<>(edges);
        Collections.shuffle(list);
        return list;
    }

    public List<L3Edge> connectivityOrder(Set<L3Edge> edges) {
        List<L3Edge> list = randomOrder(edges);
        for (CPExecutor cpe : Controller.cpExecutorStack) {
            HashMap<L3Edge, Integer> map = new HashMap<>();
            boolean stop = false;
            int mf = 1;
            while (!stop) {
                Collection<Graph<Router, L3Edge>> components = cpe.getL3Topology()
                        .getKEdgeComponent(mf + 1)
                        .stream()
                        .filter(c -> c.vertexSet().size() > 1)
                        .collect(Collectors.toSet());
                stop = components.isEmpty();
                if (!stop) {
                    for (Graph<Router, L3Edge> c : components) {
                        for (L3Edge e : c.edgeSet()) {
                            map.put(e, mf);
                        }
                    }
                }
                mf++;
            }
            map.forEach((l3Edge, cnt) -> l3Edge.setCnt(l3Edge.getCnt() + cnt));
        }
        return list
                .stream()
                .sorted(Comparator.comparing(L3Edge::getCnt))
                .collect(Collectors.toList());
    }

    public List<L3Edge> connectivityOrderReverse(Set<L3Edge> edges) {
        List<L3Edge> list = connectivityOrder(edges);
        Collections.reverse(list);
        return list;
    }

    public List<L3Edge> propagationOrder(Set<L3Edge> edges) {
        ArrayList<L3Edge> list = new ArrayList<>();

        HashSet<Router> vi = new HashSet<>();
        HashSet<Router> cur = new HashSet<>();
        cur.addAll(Controller.ospfValidRouters);
        cur.addAll(Controller.bgpValidRouters);
        while (!cur.isEmpty()) {
            HashMap<L3Edge, Integer> votes = new HashMap<>();
            HashSet<Router> nxt = new HashSet<>();
            for (Router router : cur) {
                for (Port port : router.getPorts().values()) {
                    Port linked = port.getLinkedPort();
                    if (linked != null && !vi.contains(linked.getRouter())) {
                        int v = votes.getOrDefault(linked.getLink(), 0) + 1;
                        votes.put(linked.getLink(), v);
                        if (!cur.contains(linked.getRouter())) {
                            nxt.add(linked.getRouter());
                        }
                    }
                }
            }
            list.addAll(votes.keySet().stream().sorted(Comparator.comparing(votes::get, Comparator.reverseOrder()))
                    .collect(Collectors.toList()));
            vi.addAll(cur);
            cur = nxt;
        }
        HashSet<L3Edge> remain = new HashSet<>(edges);
        remain.removeAll(list);
        list.addAll(remain);

        return list;
    }

    public List<L3Edge> propagationOrderReverse(Set<L3Edge> edges) {
        List<L3Edge> list = propagationOrder(edges);
        Collections.reverse(list);
        return list;
    }

    public void setLinkVars(Set<L3Edge> edges) {
        totalLinkBit = (int) edges.stream().filter(e -> e.getState() == State.SYMBOLIC).count();
        links = new L3Edge[totalLinkBit];
        linkVars = new int[totalLinkBit];
        // final int[] idx = {0};
        // map.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(entry ->
        // {
        // links[idx[0]] = entry.getKey();
        // linkVars[idx[0]] = entry.getValue();
        // idx[0] = idx[0] + 1;
        // });
        // for (L3Edge l3Edge : edges) {
        List<L3Edge> l3Edges = sort(edges);
        int i = 0;
        for (L3Edge l3Edge : l3Edges) {
            if (l3Edge.getState() == State.SYMBOLIC) {
                // int n = l3Edge.getPhysicalEdges().size();
                // int[] vars = new int[n];
                // int i = 0;
                // for (L3Edge physicalEdge : l3Edge.getPhysicalEdges()) {
                // vars[i++] = map.get(physicalEdge);
                // }
                // l3Edge.setTC(BDDUtil.andInBatch(bdd, vars));
                int var = bdd.createVar();
                l3Edge.setTC(var);
                links[i] = l3Edge;
                linkVars[i] = var;
                i++;
            } else if (l3Edge.getState() == State.UP) {
                l3Edge.setTC(1);
            } else {
                l3Edge.setTC(0);
            }
        }
        initMemos();
    }

    public void setLinkVars(Set<L3Edge> edges, ArrayList<Integer> linkVarsRandom) {
        totalLinkBit = (int) edges.stream().filter(e -> e.getState() == State.SYMBOLIC).count();
        links = new L3Edge[totalLinkBit];
        linkVars = new int[totalLinkBit];
        List<L3Edge> l3Edges = sort(edges);
        int i = 0;
        for (L3Edge l3Edge : l3Edges) {
            if (l3Edge.getState() == State.SYMBOLIC) {
                int var = linkVarsRandom.get(i);
                l3Edge.setTC(var);
                links[i] = l3Edge;
                linkVars[i] = var;
                i++;
            } else if (l3Edge.getState() == State.UP) {
                l3Edge.setTC(1);
            } else {
                l3Edge.setTC(0);
            }
        }
        initMemos();
    }

    public L3Edge getLink(int idx) {
        return links[idx];
    }

    public TimeUtil timer = new TimeUtil();

    public void calTC(SortedMultiList list, boolean ecmp) {
        if (list.flat().isEmpty())
            return;

        timer.begin();

        int innerPre = 0, outerPre = 0;
        int o, i;
        for (o = 0; o < list.getOIdx(); o++) {
            for (SortedMultiListItem item : list.get(o)) {
                outerPre = manager.orTo(outerPre, item.getArriveTC());
            }
        }
        for (i = 0; i < list.getIIdx(); i++) {
            innerPre = manager.orTo(innerPre, list.get(o).get(i).getArriveTC());
        }

        if (outerPre == 1) {
            for (; i < list.get(o).size(); i++) {
                list.get(o).get(i).setListTC(0);
            }
        } else {
            for (; i < list.get(o).size(); i++) {
                SortedMultiListItem item = list.get(o).get(i);
                calTC(item, outerPre, innerPre, ecmp);
                innerPre = manager.orTo(innerPre, item.getArriveTC());
            }
        }

        outerPre = manager.orDerefBoth(outerPre, innerPre);
        for (o = o + 1; o < list.size(); o++) {
            if (outerPre == 1) {
                for (SortedMultiListItem item : list.get(o)) {
                    item.setListTC(0);
                }
            } else {
                innerPre = 0;
                for (SortedMultiListItem item : list.get(o)) {
                    calTC(item, outerPre, innerPre, ecmp);
                    innerPre = manager.orTo(innerPre, item.getArriveTC());
                }
                outerPre = manager.orDerefBoth(outerPre, innerPre);
            }
        }

        timer.end();
    }

    public void calTC(SortedMultiListItem item, int outerPre, int innerPre, boolean ecmp) {
        // System.out.println("outerPre " + bdd.satCount(outerPre));
        // System.out.println("outerPre " + outerPre);
        // bdd.printDot("/home/augists/Cheney/SRE-Benchmark/variants/ndd/" + outerPre, outerPre);
        // bdd.printDot("/home/augists/Cheney/SRE-Benchmark/variants/ndd/" + manager.not(outerPre),
        // manager.not(outerPre));
        // System.out.println("temp1 " + manager.not(outerPre) + " " +
        // bdd.satCount(manager.not(outerPre)));
        timer.begin();
        int tc = manager.andTo(manager.not(outerPre), item.getArriveTC());
        // System.out.println("tc " + bdd.satCount(tc));
        if (!ecmp)
            tc = manager.andDerefBoth(tc, manager.not(innerPre));
        // System.out.println(item.toString());
        item.setListTC(manager.filter(tc));
        // System.out.println(item.toString());
        timer.end();
    }

    /**
     * This method will be called if >=1 items are inserted in the middle of the
     * list
     * We recompute TC of all items in the list
     *
     * @see SortedMultiList#insert(SortedMultiListItem)
     */
    // public void calTC(SortedMultiList list, boolean ecmp) {
    // timer.begin();
    // int i = 0;
    // int outerPre = 0;
    // for (ArrayList<SortedMultiListItem> al : list) {
    // int innerPre = 0;
    //
    // if (outerPre != 1) {
    // int nOuterPre = manager.not(outerPre);
    // for (SortedMultiListItem item : al) {
    // int listTC = manager.and(nOuterPre, item.getArriveTC());
    // if (!ecmp) {
    // listTC = manager.andDerefBoth(listTC, manager.not(innerPre));
    // }
    // item.setListTC(manager.filter(listTC));
    // innerPre = manager.orTo(innerPre, item.getArriveTC());
    // }
    // manager.deref(nOuterPre);
    // }
    //
    // if (i++ == list.size() - 1) {
    // list.setOuterPre(outerPre);
    // list.setInnerPre(innerPre);
    // }
    // else {
    // outerPre = manager.orDerefBoth(innerPre, outerPre);
    // }
    //
    // }
    // timer.end();
    // }

    // /**
    // * This method will be called if the item is inserted at the end of the list
    // * We use outerPre and innerPre to speed up TC computation
    // *
    // * @see SortedMultiList#addLast(SortedMultiListItem)
    // */
    // public void calTC(SortedMultiListItem item, boolean ecmp) {
    // timer.begin();
    // SortedMultiList list = item.getList();
    // int outerPre = list.getOuterPre(), innerPre = list.getInnerPre();
    // if (item.getInnerIdx() == 0) {
    // int pre = manager.orDerefBoth(outerPre, innerPre);
    // int tc = manager.andTo(manager.not(pre), item.getArriveTC());
    // item.setListTC(manager.filter(tc));
    // list.setOuterPre(pre);
    // list.setInnerPre(manager.ref(item.getArriveTC()));
    // }
    // else {
    // int tc = manager.andTo(manager.not(outerPre), item.getArriveTC());
    // if (!ecmp) tc = manager.andDerefBoth(tc, manager.not(innerPre));
    // item.setListTC(manager.filter(tc));
    // list.setInnerPre(manager.orTo(list.getInnerPre(), item.getArriveTC()));
    // }
    // timer.end();
    // }

    HashMap<Integer, Integer> tcFailureMaxMemo;
    int mfMemoHit = 0;

    /**
     * @param tc - a bdd that consists of only link vars
     * @return the max link failure this topology condition can tolerate
     */
    public int getTCFailureMax(int tc) {
        if (!tcFailureMaxMemo.containsKey(tc)) {
            int k = Math.max(0, bdd.toZero(tc) - 1);
            tcFailureMaxMemo.put(tc, k);
        } else {
            if (tc != 0 && tc != 1)
                mfMemoHit++;
        }
        return tcFailureMaxMemo.get(tc);
    }

    public int getMfMemoHit() {
        return mfMemoHit;
    }

    LoadingCache<Integer, Collection<byte[]>> tcAllSatCache;
    int allSatMemoHit = 0;

    public Collection<byte[]> allSat(int tc) {
        Collection<byte[]> allSat;
        try {
            allSat = tcAllSatCache.get(tc);
        } catch (ExecutionException e) {
            allSat = allSat_rec(tc);
        }
        return allSat;
    }

    public Collection<byte[]> allSat_rec(int tc) {
        if (tc == 0) {
            return new HashSet<>();
        } else if (tc == 1) {
            byte[] allSymbolic = new byte[totalLinkBit];
            Arrays.fill(allSymbolic, (byte) -1);
            HashSet<byte[]> hs = new HashSet<>();
            hs.add(allSymbolic);
            return hs;
        } else {
            HashSet<byte[]> hs = new HashSet<>();
            int var = bdd.getVar(tc);
            int idx = var - BDDACLWrapper.totalHeaderBit;
            for (byte[] oneSat : allSat(bdd.getLow(tc))) {
                byte[] down = oneSat.clone();
                down[idx] = 0;
                hs.add(down);
            }
            for (byte[] oneSat : allSat(bdd.getHigh(tc))) {
                byte[] up = oneSat.clone();
                up[idx] = 1;
                hs.add(up);
            }
            return hs;
        }
    }

    public int getAllSatMemoHit() {
        return allSatMemoHit;
    }

    private void initMemos() {
        tcFailureMaxMemo = new HashMap<>();
        tcFailureMaxMemo.put(1, totalLinkBit);
        tcFailureMaxMemo.put(0, -1);

        tcAllSatCache = CacheBuilder.newBuilder().softValues().maximumSize(1 << 16)
                .build(CacheLoader.from(this::allSat_rec));
    }

}
