package bdd;

import main.Controller;

import java.util.Objects;

public class BDDTuple {
    public static BDDTuple FULL = new BDDTuple(1, 1);

    protected int i;
    protected int j;

    public BDDTuple(int i, int j) {
        this.i = i;
        this.j = j;
    }

    public BDDTuple(BDDTuple another) {
        this.i = Controller.bddManager.ref(another.i);
        this.j = Controller.bddManager.ref(another.j);
    }

    public static BDDTuple unionTo(BDDTuple tuple1, BDDTuple tuple2) {
        return new BDDTuple(Controller.bddManager.orTo(tuple1.i, tuple2.i), Controller.bddManager.orTo(tuple1.j, tuple2.j));
    }

    public static BDDTuple intersect(BDDTuple tuple, int i, int j) {
        return new BDDTuple(Controller.bddManager.and(tuple.i, i), Controller.bddManager.and(tuple.j, j));
    }

    public static BDDTuple intersect(BDDTuple tuple, int i) {
        return intersect(tuple, i, i);
    }

    public static BDDTuple minus(BDDTuple tuple1, BDDTuple tuple2) {
        return new BDDTuple(Controller.bddManager.minus(tuple1.i, tuple2.i), Controller.bddManager.minus(tuple1.j, tuple2.j));
    }

    public int getFirst() {
        return i;
    }

    public int getSecond() {
        return j;
    }

    public int getBDD() {
        return Controller.bddManager.and(i, j);
    }

    public boolean isEmpty() {
        return i == BDDManager.BDDFalse || j == BDDManager.BDDFalse;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BDDTuple bddTuple = (BDDTuple) o;
        return i == bddTuple.i &&
               j == bddTuple.j;
    }

    @Override
    public int hashCode() {
        return Objects.hash(i, j);
    }

    @Override
    public String toString() {
        return "(" + i + ", " + j + ")";
    }
}
