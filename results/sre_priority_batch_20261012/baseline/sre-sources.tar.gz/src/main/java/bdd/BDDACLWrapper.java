/*
 * Atomic Predicates Verifier
 * 
 * Copyright (c) 2013 UNIVERSITY OF TEXAS AUSTIN. All rights reserved. Developed
 * by: HONGKUN YANG and SIMON S. LAM http://www.cs.utexas.edu/users/lam/NRL/
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimers.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimers in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. Neither the name of the UNIVERSITY OF TEXAS AUSTIN nor the names of the
 * developers may be used to endorse or promote products derived from this
 * Software without specific prior written permission.
 * 
 * 4. Any report or paper describing results derived from using any part of this
 * Software must cite the following publication of the developers: Hongkun Yang
 * and Simon S. Lam, Real-time Verification of Network Properties using Atomic
 * Predicates, IEEE/ACM Transactions on Networking, April 2016, Volume 24, No.
 * 2, pages 887-900 (first published March 2015, Digital Object Identifier:
 * 10.1109/TNET.2015.2398197).
 * 
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS WITH
 * THE SOFTWARE.
 */

package bdd;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Vector;

import datamodel.ipv4.Header;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.ipv4.Subnet;
import dataplane.acl.ACLRule;
import dataplane.acl.Range;
import jdd.bdd.BDD;
import main.Configuration;
import multimap.HashBasedTable;
import multimap.Table;
import util.BDDUtil;
import util.MathUtil;


/**
 * Computes BDD for ACL rules and Forwarding rules
 * 
 * 
 * Note: The true, false, bdd variables, the negation of bdd variables: their
 * reference count are already set to maximal, so they will never be garbage
 * collected. And no need to worry about the reference count for them.
 *
 */
public class BDDACLWrapper implements Serializable {

	private static final long serialVersionUID = 7284490986562707221L;

	BDD bdd;
	BDDManager manager;

	/**
	 * the arrays store BDD variables.
	 */
	final static int protocolBits = 8;
	int[] protocol; // protocol[0] is the lowest bits
	final static int portBits = 16;
	int[] srcPort;
	int[] dstPort;
	final static int ipBits = 32;
	int[] srcIP;
	int[] dstIP;
	final static int totalHeaderBit = 8 + (16 + 32) * 2;

	public static int getPortBits() {
		return portBits;
	}

	public static int getIpBits() {
		return ipBits;
	}

	// for test
	public BDDACLWrapper() {
		this.manager = null;
		this.bdd = new BDD(10000, 10000);

		protocol = new int[protocolBits];
		srcPort = new int[portBits];
		dstPort = new int[portBits];
		srcIP = new int[ipBits];
		dstIP = new int[ipBits];

		DeclareSrcIP();
		DeclareDstIP();
		DeclareSrcPort();
		DeclareDstPort();
		DeclareProtocol();
	}

	public BDDACLWrapper(BDDManager manager) {
		this.manager = manager;
		this.bdd = manager.bdd;

		protocol = new int[protocolBits];
		srcPort = new int[portBits];
		dstPort = new int[portBits];
		srcIP = new int[ipBits];
		dstIP = new int[ipBits];

		/*
		  will try more orders of variables
		 */
		if (!Configuration.TEST_RANDOM_VARIABLE_ORDER) {
			DeclareSrcIP();
			DeclareDstIP();
			DeclareSrcPort();
			DeclareDstPort();
			DeclareProtocol();
		}
	}

	public int encodeSrcIPPrefix(long ipaddr, int prefixlen) {
		int[] ipbin = MathUtil.CalBinRep(ipaddr, ipBits);
		int[] ipbinprefix = new int[prefixlen];
		for (int k = 0; k < prefixlen; k++) {
			ipbinprefix[k] = ipbin[k + ipBits - prefixlen];
		}
		int entrybdd = encodePrefix(ipbinprefix, srcIP, ipBits);
		return entrybdd;
	}

	public Table<Long, Integer, Integer> memo = HashBasedTable.create();

	public int encodeDstIPPrefix(Prefix prefix) {
		return encodeDstIPPrefix(prefix.getIp().asLong(), prefix.getPreLength());
	}

	public int encodeDstIPPrefix(long ipaddr, int prefixlen) {
		if (!memo.contains(ipaddr, prefixlen)) {
			int[] ipbin = MathUtil.CalBinRep(ipaddr, ipBits);
			int[] ipbinprefix = new int[prefixlen];
			for (int k = 0; k < prefixlen; k++) {
				ipbinprefix[k] = ipbin[k + ipBits - prefixlen];
			}
			int entrybdd = encodePrefix(ipbinprefix, dstIP, ipBits);
			memo.put(ipaddr, prefixlen, entrybdd);
		}
		return memo.get(ipaddr, prefixlen);
	}

	public void multipleref(int bddnode, int reftimes) {
		for (int i = 0; i < reftimes; i++) {
			bdd.ref(bddnode);
		}
	}

	/**
	 * 
	 * @param subs
	 *            - has ip information
	 * @param rawBDD
	 * @param reftimes
	 *            - the res need to be referenced for several times
	 * @return
	 */
	public int encodeACLin(ArrayList<Subnet> subs, int rawBDD, int reftimes) {
		// dest ip
		if (subs == null) {
			multipleref(rawBDD, reftimes);
			return rawBDD;
		}
		int destipbdd = encodeDstIPPrefixs(subs);
		int notdestip = bdd.not(destipbdd);
		bdd.ref(notdestip);
		int res = bdd.or(notdestip, rawBDD);

		multipleref(res, reftimes);
		bdd.deref(destipbdd);
		bdd.deref(notdestip);
		return res;
	}

	public int encodeACLout(ArrayList<Subnet> subs, int rawBDD, int reftimes) {
		if (subs == null) {
			multipleref(rawBDD, reftimes);
			return rawBDD;
		}
		// src ip
		int srcipbdd = encodeSrcIPPrefixs(subs);
		int notsrctip = bdd.not(srcipbdd);
		bdd.ref(notsrctip);
		int res = bdd.or(notsrctip, rawBDD);

		multipleref(res, reftimes);
		bdd.deref(srcipbdd);
		bdd.deref(notsrctip);
		return res;
	}

	public int encodeDstIPPrefixs(ArrayList<Subnet> subs) {
		int res = BDDManager.BDDFalse;
		for (int i = 0; i < subs.size(); i++) {
			Subnet onesub = subs.get(i);
			int dstipbdd = encodeDstIPPrefix(onesub.getIpAddr(),
					onesub.getPrefixLen());
			int tmp = bdd.or(res, dstipbdd);
			bdd.ref(tmp);
			bdd.deref(res);
			bdd.deref(dstipbdd);
			res = tmp;
		}
		return res;
	}

	public int encodeSrcIPPrefixs(ArrayList<Subnet> subs) {
		int res = BDDManager.BDDFalse;
		for (int i = 0; i < subs.size(); i++) {
			Subnet onesub = subs.get(i);
			int srcipbdd = encodeSrcIPPrefix(onesub.getIpAddr(),
					onesub.getPrefixLen());
			int tmp = bdd.or(res, srcipbdd);
			bdd.ref(tmp);
			bdd.deref(res);
			bdd.deref(srcipbdd);
			res = tmp;
		}
		return res;
	}

	private void DeclareVars(int[] vars, int bits) {
		for (int i = bits - 1; i >= 0; i--) {
			vars[i] = bdd.createVar();
		}
	}

	// protocol is 8 bits
	public void DeclareProtocol() {
		DeclareVars(protocol, protocolBits);
	}

	public void DeclareSrcPort() {
		DeclareVars(srcPort, portBits);
	}

	public void DeclareDstPort() {
		DeclareVars(dstPort, portBits);
	}

	public void DeclareSrcIP() {
		DeclareVars(srcIP, ipBits);
	}

	public void DeclareDstIP() {
		DeclareVars(dstIP, ipBits);
	}

	/**
	 * 
	 * @param acls
	 *            - the acl that needs to be transformed to bdd
	 * @return a bdd node that represents the acl
	 */
	public int ConvertACLs(LinkedList<ACLRule> acls) {
		if (acls == null) {
			// no acl configured on this interface, permit all
			return BDDManager.BDDTrue;
		}
		if (acls.size() == 0) {
			// acl configured on this interface, but with no rule, deny all by default
			// no need to ref the false node
			return BDDManager.BDDFalse;
		}
		int res = BDDManager.BDDFalse;
		int denyBuffer = BDDManager.BDDFalse;
		int denyBufferNot = BDDManager.BDDTrue;
		for (int i = 0; i < acls.size(); i++) {
			ACLRule acl = acls.get(i);
			// g has been referenced
			int g = ConvertACLRule(acl);

			if (ACLRule.CheckPermit(acl)) {
				if (res == BDDManager.BDDFalse) {
					if (denyBuffer == BDDManager.BDDFalse) {
						res = g;
					} else {
						int tempnode = bdd.and(g, denyBufferNot);
						bdd.ref(tempnode);
						res = tempnode;
						bdd.deref(g);
					}
				} else {
					if (denyBuffer == BDDManager.BDDFalse) {
						// just combine the current res and g
						int tempnode = bdd.or(res, g);
						bdd.ref(tempnode);
						BDDUtil.derefInBatch(bdd, new int[] { res, g });
						res = tempnode;
					} else {
						// the general case
						int tempnode = bdd.and(g, denyBufferNot);
						bdd.ref(tempnode);
						bdd.deref(g);

						int tempnode2 = bdd.or(res, tempnode);
						bdd.ref(tempnode2);
						BDDUtil.derefInBatch(bdd, new int[] { res, tempnode });
						res = tempnode2;
					}
				}

			} else {
				/**
				 * combine to the denyBuffer
				 */
				if (denyBuffer == BDDManager.BDDFalse) {
					denyBuffer = g;
					denyBufferNot = bdd.not(g);
					bdd.ref(denyBufferNot);
				} else {
					int tempnode = bdd.or(denyBuffer, g);
					bdd.ref(tempnode);
					BDDUtil.derefInBatch(bdd, new int[] { denyBuffer, g });
					denyBuffer = tempnode;

					bdd.deref(denyBufferNot);
					denyBufferNot = bdd.not(denyBuffer);
					bdd.ref(denyBufferNot);
				}
			}
			// System.out.println(acl);
			// System.out.println(res);
		}
		/**
		 * we need to de-ref denyBuffer, denyBufferNot
		 */
		// DerefInBatch(new int[]{denyBuffer, denyBufferNot});
		bdd.deref(denyBufferNot);
		bdd.deref(denyBuffer);
		return res;
	}

	/**
	 * 
	 * @param aclr
	 *            - an acl rule
	 * @return a bdd node representing this rule
	 */
	public int ConvertACLRule(ACLRule aclr) {
		/**
		 * protocol
		 */
		// no need to ref the true node
		int protocolNode = BDDManager.BDDTrue;
		if (aclr.protocolLower == null
				|| aclr.protocolLower.equalsIgnoreCase("any")) {
			// do nothing, just a shortcut
		} else {
			Range r = ACLRule.convertProtocolToRange(aclr.protocolLower,
					aclr.protocolUpper);
			protocolNode = ConvertProtocol(r);
		}

		/**
		 * src port
		 */
		int srcPortNode = BDDManager.BDDTrue;
		if (aclr.sourcePortLower == null
				|| aclr.sourcePortLower.equalsIgnoreCase("any")) {
			// do nothing, just a shortcut
		} else {
			Range r = ACLRule.convertPortToRange(aclr.sourcePortLower,
					aclr.sourcePortUpper);
			srcPortNode = ConvertSrcPort(r);
		}

		/**
		 * dst port
		 */
		int dstPortNode = BDDManager.BDDTrue;
		if (aclr.destinationPortLower == null
				|| aclr.destinationPortLower.equalsIgnoreCase("any")) {
			// do nothing, just a shortcut
		} else {
			Range r = ACLRule.convertPortToRange(aclr.destinationPortLower,
					aclr.destinationPortUpper);
			dstPortNode = ConvertDstPort(r);
		}

		/**
		 * src IP
		 */
		int srcIPNode = ConvertIPAddress(aclr.source, aclr.sourceWildcard,
				srcIP);

		/**
		 * dst IP
		 */
		int dstIPNode = ConvertIPAddress(aclr.destination,
				aclr.destinationWildcard, dstIP);

		// put them together
		int[] fiveFields = { protocolNode, srcPortNode, dstPortNode, srcIPNode,
				dstIPNode };
		int tempnode = BDDUtil.andInBatch(bdd, fiveFields);
		// clean up internal nodes
		BDDUtil.derefInBatch(bdd, fiveFields);

		return tempnode;
	}

	/**
	 * @param IP
	 *            address and mask
	 * @return the corresponding bdd node
	 */
	protected int ConvertIPAddress(String IP, String Mask, int[] vars) {
		int tempnode = BDDManager.BDDTrue;
		// case 1 IP = any
		if (IP == null || IP.equalsIgnoreCase("any")) {
			// return TRUE node
			return tempnode;
		}

		// binary representation of IP address
		int[] ipbin = MathUtil.IPBinRep(IP);
		// case 2 Mask = null
		if (Mask == null) {
			// no mask is working
			return encodePrefix(ipbin, vars, ipBits);
		} else {
//			int[] maskbin = MathUtil.IPBinRep(Mask);
//			int numMasked = MathUtil.NumofNonZeros(maskbin);
//
//			int[] prefix = new int[maskbin.length - numMasked];
//			int[] varsUsed = new int[prefix.length];
//			int ind = 0;
//			for (int i = 0; i < maskbin.length; i++) {
//				if (maskbin[i] == 0) {
//					prefix[ind] = ipbin[i];
//					varsUsed[ind] = vars[i];
//					ind++;
//				}
//			}
//
//			return encodePrefixDeprecated(prefix, varsUsed, prefix.length);

			/*
			* Above is original code in apv, we change it since the meaning of mask changes.
			* for apv: a mask will be 0.0.0.255
			* for us: a mask will be 255.255.255.0
			* */
			int[] maskbin = MathUtil.IPBinRep(Mask);
			int numMasked = ipBits - MathUtil.NumofNonZeros(maskbin);

			int[] prefix = new int[maskbin.length - numMasked];
			int[] varsUsed = new int[prefix.length];
			int ind = 0;
			for (int i = 0; i < maskbin.length; i++) {
				if (maskbin[i] == 1) {
					prefix[ind] = ipbin[i];
					varsUsed[ind] = vars[i];
					ind++;
				}
			}

			return encodePrefix(prefix, varsUsed, prefix.length);
		}

	}

	/***
	 * convert a range of protocol numbers to a bdd representation
	 */
	protected int ConvertProtocol(Range r) {
		return ConvertRange(r, protocol, protocolBits);

	}

	/**
	 * convert a range of source port numbers to a bdd representation
	 */
	protected int ConvertSrcPort(Range r) {
		return ConvertRange(r, srcPort, portBits);
	}

	/**
	 * convert a range of destination port numbers to a bdd representation
	 */
	protected int ConvertDstPort(Range r) {
		return ConvertRange(r, dstPort, portBits);
	}

	/**
	 * 
	 * @param r
	 *            - the range
	 * @param vars
	 *            - bdd variables used
	 * @param bits
	 *            - number of bits in the representation
	 * @return the corresponding bdd node
	 */
	private int ConvertRange(Range r, int[] vars, int bits) {

		ArrayList<int[]> prefix = MathUtil.DecomposeInterval(r, bits);
		// System.out.println(vars.length);
		if (prefix.size() == 0) {
			return BDDManager.BDDTrue;
		}

		int tempnode = BDDManager.BDDTrue;
		for (int i = 0; i < prefix.size(); i++) {
			if (i == 0) {
				tempnode = encodePrefix(prefix.get(i), vars, bits);
			} else {
				int tempnode2 = encodePrefix(prefix.get(i), vars, bits);
				int tempnode3 = bdd.or(tempnode, tempnode2);
				bdd.ref(tempnode3);
				BDDUtil.derefInBatch(bdd, new int[] { tempnode, tempnode2 });
				tempnode = tempnode3;
			}
		}
		return tempnode;
	}

	int encodePrefix(int[] prefix, int[] vars, int bits) {
		return bdd.ref(encodePrefix(prefix, vars, bits, prefix.length - 1));
	}

	// we are decreasing idx since vars are in decreasing order
	// e.g. srcIP: [32,31,30,...,1,0]
	private int encodePrefix(int[] prefix, int[] vars, int bits, int idx) {
		if (idx < 0) {
			return 1;
		}
		int l = 0, h = 0, v = bdd.getVar(vars[bits - prefix.length + idx]);
		if (prefix[idx] == 0) {
			l = encodePrefix(prefix, vars, bits, idx - 1);
		}
		if (prefix[idx] == 1) {
			h = encodePrefix(prefix, vars, bits, idx - 1);
		}
		return bdd.mk(v, l, h);
	}

	/**
	 *
	 * @param prefix
	 *            -
	 * @param vars
	 *            - bdd variables used
	 * @param bits
	 *            - number of bits in the representation
	 * @return a bdd node representing the predicate e.g. for protocol, bits = 8,
	 *         prefix = {1,0,1,0}, so the predicate is protocol[4] and (not
	 *         protocol[5]) and protocol[6] and (not protocol[7])
	 */
	@Deprecated
	int encodePrefixDeprecated(int[] prefix, int[] vars, int bits) {
		if (prefix.length == 0) {
			return BDDManager.BDDTrue;
		}

		int tempNode = BDDManager.BDDTrue;
		for (int i = 0; i < prefix.length; i++) {
			if (i == 0) {
				tempNode = encodingVar(vars[bits - prefix.length + i],
						prefix[i]);
			} else {
				int tempNode2 = encodingVar(vars[bits - prefix.length + i],
						prefix[i]);
				int tempNode3 = bdd.and(tempNode, tempNode2);
				bdd.ref(tempNode3);
				// do not need tempNode2, tempNode now
				// aclBDD.deref(tempNode2);
				// aclBDD.deref(tempNode);
				BDDUtil.derefInBatch(bdd, new int[] { tempNode, tempNode2 });
				// refresh tempNode 3
				tempNode = tempNode3;
			}
		}
		return tempNode;
	}

	/***
	 * return a bdd node representing the predicate on the protocol field
	 */
	private int encodeProtocolPrefix(int[] prefix) {
		return encodePrefix(prefix, protocol, protocolBits);
	}

	/**
	 * return the size of the bdd tree
	 */
	public int getNodeSize(int bddNode) {
		int size = bdd.nodeCount(bddNode);
		if (size == 0) {// this means that it is only a terminal node
			size++;
		}
		return size;
	}

	/***
	 * var is a BDD variable if flag == 1, return var if flag == 0, return not
	 * var, the new bdd node is referenced.
	 */
	private int encodingVar(int var, int flag) {
		if (flag == 0) {
			// no need to ref the negation of a variable.
			// the ref count is already set to maximal
			// aclBDD.ref(tempNode);
			return bdd.not(var);
		}
		if (flag == 1) {
			return var;
		}

		// should not reach here
		System.err.println("flag can only be 0 or 1!");
		return -1;
	}

	HashMap<Integer, HashSet<Header>> headerMemo = new HashMap<>();
	int memoHit = 0;

	/**
	 * @param predicate - a bdd that consists of only dst ip vars
	 * @return a set of headers represented by this bdd
	 */
	public HashSet<Header> getHeaders(int predicate) {
		if (!headerMemo.containsKey(predicate)) {
			HashSet<Header> headers = new HashSet<>();
			byte[] headerBin = new byte[BDDACLWrapper.totalHeaderBit];
			Arrays.fill(headerBin, (byte) -1);
			getHeaders_rec(headers, headerBin, predicate);
			headerMemo.put(predicate, headers);
		}
		else memoHit++;
		return headerMemo.get(predicate);
	}

	public void getHeaders_rec(HashSet<Header> headers, byte[] headerBin, int predicate) {
		if (predicate != BDDManager.BDDFalse) {
			if (predicate == BDDManager.BDDTrue) {
				headers.addAll(bitVector2Header(headerBin));
			}
			else {
				int var = bdd.getVar(predicate);
				// pay attention to idx
				int idx = totalHeaderBit - 1 - var;
				headerBin[idx] = 0;
				getHeaders_rec(headers, headerBin, bdd.getLow(predicate));
				headerBin[idx] = 1;
				getHeaders_rec(headers, headerBin, bdd.getHigh(predicate));
				headerBin[idx] = -1;
			}
		}
	}

	public Collection<Header> bitVector2Header(byte[] headerBin) {
		HashSet<Header> headers = new HashSet<>();

		int lBound, rBound = 0;

		// pay attention to the order
		lBound = rBound;
		rBound += protocolBits;
		byte[] protocolBin = Arrays.copyOfRange(headerBin, lBound, rBound);
		Collection<Range> protocols = bitVector2Range(protocolBin);

		lBound = rBound;
		rBound += portBits;
		byte[] destinationPortBin = Arrays.copyOfRange(headerBin, lBound, rBound);
		Collection<Range> destinationPorts = bitVector2Range(destinationPortBin);

		lBound = rBound;
		rBound += portBits;
		byte[] sourcePortBin = Arrays.copyOfRange(headerBin, lBound, rBound);
		Collection<Range> sourcePorts = bitVector2Range(sourcePortBin);

		lBound = rBound;
		rBound += ipBits;
		byte[] destinationBin = Arrays.copyOfRange(headerBin, lBound, rBound);
		Collection<Prefix> destinations = Ip.ipBinToPrefixes(destinationBin);

		lBound = rBound;
		rBound += ipBits;
		byte[] sourceBin = Arrays.copyOfRange(headerBin, lBound, rBound);
		Collection<Prefix> sources = Ip.ipBinToPrefixes(sourceBin);

		for (Range protocol : protocols) {
			for (Prefix source: sources) {
				for (Range sourcePort : sourcePorts) {
					for (Prefix destination : destinations) {
						for (Range destinationPort : destinationPorts) {
							Header header = new Header(protocol, source, sourcePort, destination, destinationPort);
							headers.add(header);
						}
					}
				}
			}
		}

		return headers;
	}

	// {0, 1, 1, 0, 0, 0, 0, 0} -> [ 6 - 6 ]
	// TODO combine neighboring ranges. e.g., [ 64 - 127 ] and [ 128 - 255 ]
	public Collection<Range> bitVector2Range(byte[] rangeBin) {
		int bound = -1;
		while (bound + 1 < rangeBin.length && rangeBin[bound + 1] == -1) bound++;

		Vector<Long> lowers = new Vector<>();
		lowers.add(0L);
		int i = rangeBin.length - 1;
		while (i > bound) {
			if (rangeBin[i] != -1) {
				for (int j = 0; j < lowers.size(); j++) {
					lowers.set(j, (lowers.get(j) << 1) + rangeBin[i]);
				}
			}
			else {
				Vector<Long> tmp = new Vector<>(lowers.size() * 2);
				for (int j = 0; j < lowers.size(); j++) {
					long ipLong = lowers.get(j) << 1;
					tmp.add(2 * j, ipLong);
					tmp.add(2 * j + 1, ipLong + 1);
				}
				lowers = tmp;
			}
			i--;
		}
		for (int j = 0; j < lowers.size(); j++) {
			lowers.set(j, lowers.get(j) << (bound + 1));
		}
		long rangeLen = (1L << (bound + 1)) - 1;

		HashSet<Range> ranges = new HashSet<>();
		for (long num : lowers) {
			ranges.add(new Range(num, num + rangeLen));
		}
		return ranges;
	}

}
