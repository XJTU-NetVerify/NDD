package bdd;

import sre.ndd.NDD;
import main.Controller;

import java.util.Objects;

public class NDDTuple {
    public static NDDTuple FULL = new NDDTuple(NDD.getTrue(), NDD.getTrue());

    protected int i;
    protected int j;
    private boolean nddOwnershipReleased;

    public NDDTuple(int i, int j) {
        this.i = i;
        this.j = j;
    }

    public NDDTuple(NDDTuple another) {
        this.i = NDD.ref(another.i);
        this.j = NDD.ref(another.j);
    }

    public static NDDTuple unionTo(NDDTuple tuple1, NDDTuple tuple2) {
        return new NDDTuple(NDD.orTo(tuple1.i, tuple2.i), NDD.orTo(tuple1.j, tuple2.j));
    }

    public static NDDTuple intersect(NDDTuple tuple, int i, int j) {
        return new NDDTuple(NDD.ref(NDD.and(tuple.i, i)), NDD.ref(NDD.and(tuple.j, j)));
    }

    public static NDDTuple intersect(NDDTuple tuple, int i) {
        return intersect(tuple, i, i);
    }

    public static NDDTuple minus(NDDTuple tuple1, NDDTuple tuple2) {
        return new NDDTuple(NDD.ref(NDD.diff(tuple1.i, tuple2.i)), NDD.ref(NDD.diff(tuple1.j, tuple2.j)));
    }

    public int getFirst() {
        return i;
    }

    public int getSecond() {
        return j;
    }

    public int getNDD() {
        return NDD.ref(NDD.and(i, j));
    }

    public boolean isEmpty() {
        return NDD.isFalse(i) || NDD.isFalse(j);
    }

    public void releaseNddOwnership() {
        if (nddOwnershipReleased) return;
        NDD.deref(i);
        NDD.deref(j);
        nddOwnershipReleased = true;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        NDDTuple nddTuple = (NDDTuple) o;
        return i == nddTuple.i &&
                j == nddTuple.j;
    }

    @Override
    public int hashCode() {
        return Objects.hash(i, j);
    }

    @Override
    public String toString() {
        return "(" + i + ", " + j + ")";
    }
}
