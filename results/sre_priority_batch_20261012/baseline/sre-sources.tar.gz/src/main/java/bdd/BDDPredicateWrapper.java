package bdd;

import controlplane.network.PortName;
import datamodel.ipv4.Header;
import datamodel.ipv4.Prefix;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import dataplane.fib.ForwardingRule;
import java.util.*;
import jdd.bdd.BDD;


/**
 * predicate = acl-predicate + tc-predicate
 */
public class BDDPredicateWrapper {
    BDD bdd;
    BDDManager manager;

    public BDDPredicateWrapper(BDDManager manager) {
        this.manager = manager;
        this.bdd = manager.bdd;
    }

    public HashMap<PortName, Integer> getPortPredicates(SortedMultiList rules, boolean ecmp, int fwd) {
        // System.out.println("===========");
        // System.out.println("fwd " + bdd.satCount(fwd));
        if (!ecmp) {
            return getPortPredicates(rules, fwd);
        }
        HashMap<PortName, Integer> portPredicates = new HashMap<>();

        int alreadyForwarded = 0;
        for (ArrayList<SortedMultiListItem> list : rules) {
            int inner = 0;
            int notAlreadyForwarded = manager.filter(manager.not(alreadyForwarded));

            if (notAlreadyForwarded == 0)
                break;

            for (SortedMultiListItem item : list) {
                ForwardingRule rule = (ForwardingRule) item;
                PortName pName = rule.getOutPort();
                Prefix prefix = rule.getPrefix();
                int dstPrefix = manager.bddACLWrapper.encodeDstIPPrefix(prefix.getIp().asLong(), prefix.getPreLength());
                int care = manager.and(fwd, dstPrefix);
                if (care != 0) {
                    int tc = rule.getListTC();
                    int ruleBDD = manager.and(care, tc);

                    int toAdd = manager.and(ruleBDD, notAlreadyForwarded);
                    inner = manager.orTo(inner, ruleBDD);

                    // System.out.println(pName + " " + ((portPredicates.containsKey(pName)) ?
                    // "true" : "false"));
                    if (portPredicates.containsKey(pName)) {
                        portPredicates.put(pName, manager.orDerefBoth(toAdd, portPredicates.get(pName)));
                    } else {
                        portPredicates.put(pName, toAdd);
                    }
                    // System.out.println("port " + bdd.satCount(portPredicates.get(pName)));
                }
                manager.deref(care);
            }

            manager.deref(notAlreadyForwarded);
            alreadyForwarded = manager.orDerefBoth(alreadyForwarded, inner);
        }
        manager.deref(alreadyForwarded);

        // for (Map.Entry<PortName, Integer> predicate : portPredicates.entrySet()) {
        //     System.out.println(predicate.getKey().getFullName() + " " +
        //             bdd.satCount(predicate.getValue()));
        // }

        return portPredicates;
    }

    private HashMap<PortName, Integer> getPortPredicates(SortedMultiList rules, int fwd) {
        HashMap<PortName, Integer> portPredicates = new HashMap<>();

        int alreadyForwarded = 0;
        for (SortedMultiListItem item : rules.flat()) {
            int notAlreadyForwarded = manager.filter(manager.not(alreadyForwarded));

            if (notAlreadyForwarded == 0)
                break;

            ForwardingRule rule = (ForwardingRule) item;
            PortName pName = rule.getOutPort();
            Prefix prefix = rule.getPrefix();
            int dstPrefix = manager.bddACLWrapper.encodeDstIPPrefix(prefix.getIp().asLong(), prefix.getPreLength());
            int care = manager.and(dstPrefix, fwd);
            if (care != 0) {
                int tc = rule.getListTC();
                int ruleBDD = manager.and(care, tc);

                int toAdd = manager.andTo(notAlreadyForwarded, ruleBDD);
                alreadyForwarded = manager.orTo(alreadyForwarded, ruleBDD);

                if (portPredicates.containsKey(pName)) {
                    portPredicates.put(pName, manager.orDerefBoth(toAdd, portPredicates.get(pName)));
                } else {
                    portPredicates.put(pName, toAdd);
                }
            }
            manager.deref(care);
        }
        manager.deref(alreadyForwarded);

        return portPredicates;
    }

    Map<Integer, Map<Header, Integer>> headerTCMemo = new HashMap<>();
    int memoHit = 0;

    public Map<Header, Integer> splitHeaderTC(int predicate) {
        if (!headerTCMemo.containsKey(predicate)) {
            Map<Header, Integer> map = new HashMap<>();
            byte[] headerBin = new byte[BDDACLWrapper.totalHeaderBit];
            Arrays.fill(headerBin, (byte) -1);
            splitHeaderTC_rec(map, headerBin, predicate);
            headerTCMemo.put(predicate, map);
        } else {
            memoHit++;
        }
        return headerTCMemo.get(predicate);
    }

    private void splitHeaderTC_rec(Map<Header, Integer> ret, byte[] headerBin, int predicate) {
        if (predicate == BDDManager.BDDFalse)
            return;
        int n = BDDACLWrapper.totalHeaderBit;
        int var = bdd.getVar(predicate);
        if (var >= n) {
            Collection<Header> headers = manager.bddACLWrapper.bitVector2Header(headerBin);
            headers.forEach(header -> ret.put(header, predicate));
        } else {
            // pay attention to idx
            int idx = n - 1 - var;
            headerBin[idx] = 0;
            splitHeaderTC_rec(ret, headerBin, bdd.getLow(predicate));
            headerBin[idx] = 1;
            splitHeaderTC_rec(ret, headerBin, bdd.getHigh(predicate));
            headerBin[idx] = -1;
        }
    }

    Map<Integer, Map<byte[], Integer>> extractMemo = new HashMap<>();

    public Map<byte[], Integer> extract(int predicate) {
        if (!extractMemo.containsKey(predicate)) {
            Map<byte[], Integer> map = new HashMap<>();
            byte[] headerBin = new byte[BDDACLWrapper.totalHeaderBit];
            Arrays.fill(headerBin, (byte) -1);
            extract_rec(map, headerBin, predicate);
            extractMemo.put(predicate, map);
        }
        return extractMemo.get(predicate);
    }

    private void extract_rec(Map<byte[], Integer> ret, byte[] headerBin, int predicate) {
        if (predicate == BDDManager.BDDFalse)
            return;
        int n = BDDACLWrapper.totalHeaderBit;
        int var = bdd.getVar(predicate);
        if (var >= n) {
            ret.put(headerBin.clone(), predicate);
        } else {
            // pay attention to idx
            int idx = n - 1 - var;
            headerBin[idx] = 0;
            extract_rec(ret, headerBin, bdd.getLow(predicate));
            headerBin[idx] = 1;
            extract_rec(ret, headerBin, bdd.getHigh(predicate));
            headerBin[idx] = -1;
        }
    }

    /**
     * get prefix-specific failure max
     * prefix vars first
     */
    public Map<Header, Integer> getHeaderFailureMax(int predicate) {
        Map<Header, Integer> ret = new HashMap<>();
        Map<Header, Integer> tmp = splitHeaderTC(predicate);
        tmp.forEach((prefix, tc) -> ret.put(prefix, manager.bddTCWrapper.getTCFailureMax(tc)));
        return ret;
    }
}
