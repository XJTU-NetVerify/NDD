package bdd;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import application.config2spec.Config2spec;
import controlplane.network.L3Edge;
import controlplane.network.State;
import jdd.bdd.BDD;
import jdd.bdd.NodeTableStats;
import main.Configuration;
import main.Controller;
import main.SRELogger;
import util.BDDUtil;
import util.CombinationUtil;
import util.TimeUtil;

public class BDDManager {
    int ntSize;
    int cacheSize;

    BDD bdd;
    BDDACLWrapper bddACLWrapper;
    BDDTCWrapper bddTCWrapper;
    BDDPredicateWrapper bddPredicateWrapper;

    public final static int BDDFalse = 0;
    public final static int BDDTrue = 1;

    int FILTER_BDD = 1;

    /**
     * try to guess the optimal node table size
     */
    public static int calOptimalNTSize() {
        if (Configuration.NT_SIZE != -1)
            return Configuration.NT_SIZE;
        // number of symbolic links and valid routers
        long nSymbolicLink = L3Edge.getAllL3Edge().stream().filter(e -> e.getState() == State.SYMBOLIC).count();
        int nValidRouter = Controller.ospfValidRouters.size() + Controller.bgpValidRouters.size();
        int nTotalRouter = Controller.cpExecutor.getRouters().size();
        double tmp = Controller.MF >= 0 ? CombinationUtil.numItems((int) nSymbolicLink, Controller.MF)
                : Math.pow(2, nSymbolicLink);
        double limit1 = tmp * nValidRouter * nTotalRouter * 30 * Controller.cpExecutorStack.size();
        // maximum memory usage (bytes)
        long xmx = Runtime.getRuntime().maxMemory();
        long limit2 = xmx / 40;
        SRELogger.logMemUse(SRELogger.LEVEL.INFO, "nSymbolicLink: " + nSymbolicLink + " nValidRoute: " + nValidRouter
                + " xmx: " + xmx + " limit1: " + limit1 + " limit2: " + limit2);
        return (int) Math.max(1000000, Math.min(Math.min(limit1, limit2), 710000000));
    }

    public BDDManager() {
        SRELogger.pushContext("BDD INIT");

        TimeUtil timer = new TimeUtil();
        timer.begin();

        ntSize = calOptimalNTSize();
        cacheSize = ntSize / 10;
        SRELogger.logMemUse(SRELogger.LEVEL.INFO, "BDD node table size: " + ntSize);

        // bdd = new BDD(ntSize, cacheSize);
        // System.out.println(ntSize+" "+cacheSize);

        if (Config2spec.dataset.equals("bgp_fattree04")) {
            if (Configuration.testPlan == 0) {
                bdd = new BDD(26000, 2600);
            } else if (Configuration.testPlan == 1) {
                bdd = new BDD(5000, 2500);
            } else {
                bdd = new BDD(26000, 2600);
            }
        } else if (Config2spec.dataset.equals("bgp_fattree08")) {
            if (Configuration.testPlan == 0) {
                bdd = new BDD(71000000, 71000000);
            } else if (Configuration.testPlan == 1) {
                bdd = new BDD(3311645, 331164);
            } else {
                bdd = new BDD(710000000, 71000000);
            }
        } else if (Config2spec.dataset.equals("bgp_fattree12")) {
            if (Configuration.testPlan == 0) {
                bdd = new BDD(710000000, 71000000);
            } else if (Configuration.testPlan == 1) {
                bdd = new BDD(64125544, 6412554);
            } else {
                bdd = new BDD(710000000, 71000000);
            }
        } else if (Config2spec.dataset.equals("bgp_fattree16")) {
            if (Configuration.testPlan == 0) {
                bdd = new BDD(710000000, 71000000);
            } else if (Configuration.testPlan == 1) {
                bdd = new BDD(64125544, 6412554);
            } else {
                bdd = new BDD(710000000, 71000000);
            }
        } else {
            if (Config2spec.dataset.equals("uscarrier")) {
                if (Controller.MF == 1) {
                    bdd = new BDD(16708058, 1670805);
                } else if (Controller.MF == 2) {
                    bdd = new BDD(30524659, 3052465);
                } else if (Controller.MF == 3) {
                    bdd = new BDD(12279592, 1227959);
                }
            } else if (Config2spec.dataset.equals("columbus")) {
                if (Controller.MF == 1) {
                    bdd = new BDD(2263996, 226399);
                } else if (Controller.MF == 2) {
                    bdd = new BDD(3672298, 367229);
                } else if (Controller.MF == 3) {
                    bdd = new BDD(2652287, 265228);
                }
            } else if (Config2spec.dataset.equals("bics")) {
                if (Controller.MF == 1) {
                    bdd = new BDD(501314, 50131);
                } else if (Controller.MF == 2) {
                    bdd = new BDD(873766, 87376);
                } else if (Controller.MF == 3) {
                    bdd = new BDD(743791, 74379);
                }
            }
        }
        if (bdd == null) {
            bdd = new BDD(710000000, 71000000);
        }
        // bdd = new BDD(ntSize, cacheSize);
        // System.out.println(ntSize+" "+cacheSize);
        bddACLWrapper = new BDDACLWrapper(this);
        bddTCWrapper = new BDDTCWrapper(this);
        bddPredicateWrapper = new BDDPredicateWrapper(this);
        if (Configuration.TEST_RANDOM_VARIABLE_ORDER) {
            declareVariablesWithRandomOrder();
        }
        setFilter();

        timer.end(SRELogger.LEVEL.INFO, "");

        SRELogger.popContext();
    }

    /**
     * we must create ACL wrapper first and then TC wrapper,
     * in order to create prefix related bdd vars first
     */
    public BDDManager(int node_table_size, int cache_size) {
        ntSize = node_table_size;
        cacheSize = cache_size;
        bdd = new BDD(node_table_size, cache_size);
        bddACLWrapper = new BDDACLWrapper(this);
        bddTCWrapper = new BDDTCWrapper(this);
        bddPredicateWrapper = new BDDPredicateWrapper(this);
        setFilter();
    }

    private void declareVariablesWithRandomOrder() {
        Random random = new Random();
        // random order of 5 tuple
        HashSet<Integer> chosenField = new HashSet<> ();
        ArrayList<Integer> fiveTupleOrder = new ArrayList<> ();
        while (fiveTupleOrder.size() < 5) {
            int randomField = random.nextInt(5);
            if (!chosenField.contains(randomField)) {
                chosenField.add(randomField);
                fiveTupleOrder.add(randomField);
            }
        }
        
        // random link variables between 2 fields of 5 tuple
        Set<L3Edge> edges = L3Edge.getAllL3Edge();
        int totalLinkBit = (int) edges.stream().filter(e -> e.getState() == State.SYMBOLIC).count();
        int unassignedVarNumber = totalLinkBit;
        ArrayList<Integer> linkVarNumber = new ArrayList<> ();
        if (Configuration.DECLARE_FIVE_TUPLE_FIRST) {
            for (int i = 0; i < 5; i++) {
                linkVarNumber.add(0);
            }
            linkVarNumber.add(totalLinkBit);
        } else {
            for (int i = 0; i < 5; i++) {
                int varToAssign = random.nextInt(unassignedVarNumber + 1);
                linkVarNumber.add(varToAssign);
                unassignedVarNumber -= varToAssign;
            }
            linkVarNumber.add(unassignedVarNumber);
        }

        // declare variables
        ArrayList<Integer> linkVars = new ArrayList<> ();
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < linkVarNumber.get(i); j++) {
                linkVars.add(bdd.createVar());
            }
            int fieldToDeclare = fiveTupleOrder.get(i);
            if (fieldToDeclare == 0) {
                bddACLWrapper.DeclareSrcIP();
            } else if (fieldToDeclare == 1) {
                bddACLWrapper.DeclareDstIP();
            } else if (fieldToDeclare == 2) {
                bddACLWrapper.DeclareSrcPort();
            } else if (fieldToDeclare == 3) {
                bddACLWrapper.DeclareDstPort();
            } else {
                bddACLWrapper.DeclareProtocol();
            }
        }
        for (int i = 0; i < linkVarNumber.get(5); i++) {
            linkVars.add(bdd.createVar());
        }

        // assign link variables with random order
        Configuration.SetRamdomLinkVar();
        bddTCWrapper.setLinkVars(L3Edge.getAllL3Edge(), linkVars);
    }

    public BDD getBDD() {
        return bdd;
    }

    public BDDTCWrapper getBDDTCWrapper() {
        return bddTCWrapper;
    }

    public BDDACLWrapper getBDDACLWrapper() {
        return bddACLWrapper;
    }

    public BDDPredicateWrapper getBDDPredicateWrapper() {
        return bddPredicateWrapper;
    }

    /**
     * @return the size of bdd (in bytes)
     */
    public long getBDDSize() {
        return bdd.getMemoryUsage();
    }

    public void setFilter() {
        if (Controller.MF < 0) {
            SRELogger.log(SRELogger.LEVEL.INFO, "no filter");
        } else {
            if (Configuration.FILTER) {
                filter(false);
            } else {
                long nSymbolicLink = L3Edge.getAllL3Edge().stream().filter(e -> e.getState() == State.SYMBOLIC).count();
                long nCombination = CombinationUtil.numItems((int) nSymbolicLink, Controller.MF);
                // if (nCombination <= Configuration.MAX_COMBINATIONS_FOR_FILTER_BDD)
                // filterBDD();
                // else filter(true);
                if (nCombination <= Configuration.MAX_COMBINATIONS_FOR_FILTER_BDD)
                    filterBDD();
                else {
                    System.out.println("still use filterBDD policy");
                    filterBDD();
                }
                // System.out.println("use another policy");
                // filter(true);
            }
        }
    }

    private void filter(boolean autoChange) {
        Configuration.FILTER = true;
        String info = autoChange ? "Too many combinations! Automatically changing to filter" : "filter";
        SRELogger.log(SRELogger.LEVEL.INFO, info);
    }

    private void filterBDD() {
        SRELogger.log(SRELogger.LEVEL.INFO, "filter bdd");
        FILTER_BDD = BDDUtil.encodeAtMostKFailureVarsSorted(bdd, bddTCWrapper.linkVars, Controller.MF);
        // System.out.println("1: " + bdd.getVar(1));
        // System.out.println("0: " + bdd.getVar(0));
        // System.out.println("filter bdd " + bdd.satCount(FILTER_BDD));
    }

    public TimeUtil timer = new TimeUtil();

    public int filter(int i) {
        int ret = i;
        if (Controller.MF >= 0) {
            timer.begin();
            if (Configuration.FILTER) {
                ret = bdd.ref(filter_rec(i, 0));
            } else {
                ret = bdd.andTo(i, FILTER_BDD);
                // ret = bdd.ref(bdd.simplify(MFBDD, i));
            }
            timer.end();
        }
        return ret;
    }

    private int filter_rec(int i, int k) {
        if (k > Controller.MF) {
            return 0;
        }
        if (i <= 1) {
            return i;
        }
        int var = bdd.getVar(i), l, h;
        if (var >= BDDACLWrapper.totalHeaderBit) {
            l = bdd.ref(filter_rec(bdd.getLow(i), k + 1));
            h = bdd.ref(filter_rec(bdd.getHigh(i), k));
        } else {
            l = bdd.ref(filter_rec(bdd.getLow(i), 0));
            h = bdd.ref(filter_rec(bdd.getHigh(i), 0));
        }
        int ret = bdd.mk(var, l, h);
        bdd.deref(i);
        bdd.deref(l);
        bdd.deref(h);
        return ret;
    }

    public int and(int i, int j) {
        return bdd.ref(bdd.and(i, j));
    }

    public int andTo(int i, int j) {
        return bdd.andTo(i, j);
    }

    public int andDerefBoth(int i, int j) {
        int ret = bdd.ref(bdd.and(i, j));
        bdd.deref(i);
        bdd.deref(j);
        return ret;
    }

    public int or(int i, int j) {
        return bdd.ref(bdd.or(i, j));
    }

    public int orTo(int i, int j) {
        return bdd.orTo(i, j);
    }

    public int orDerefBoth(int i, int j) {
        int ret = bdd.ref(bdd.or(i, j));
        bdd.deref(i);
        bdd.deref(j);
        return ret;
    }

    public int not(int i) {
        return bdd.ref(bdd.not(i));
    }

    public int minus(int i, int j) {
        return andTo(not(j), i);
    }

    public int minusDerefFirst(int i, int j) {
        int ret = minus(i, j);
        bdd.deref(i);
        return ret;
    }

    public int minusDerefBoth(int i, int j) {
        int ret = minus(i, j);
        bdd.deref(i);
        bdd.deref(j);
        return ret;
    }

    public int ref(int i) {
        return bdd.ref(i);
    }

    public void deref(int i) {
        bdd.deref(i);
    }

    public void showStats() {
        System.out.println(
                "-------------------------------------------------------------------------------------------------------------");
        bdd.showStats();
        System.out.println(
                "-------------------------------------------------------------------------------------------------------------");
    }

    public void logUsage() {
        /* log bdd node table usage */
        SRELogger.pushContext("BDD USAGE");
        bdd.gc();
        NodeTableStats stats = bdd.getStats();
        SRELogger.log(SRELogger.LEVEL.INFO, stats.get_table_size() + " " + stats.get_free_nodes_count());
        SRELogger.popContext();
    }

    public void clean() {
        bdd.cleanup();
    }

    public void clear() {
        bdd = null;
        bddACLWrapper = null;
        bddTCWrapper = null;
        bddPredicateWrapper = null;
    }

    public void reset() {
        bdd = new BDD(ntSize, cacheSize);
        bddACLWrapper = new BDDACLWrapper(this);
        bddTCWrapper = new BDDTCWrapper(this);
        bddPredicateWrapper = new BDDPredicateWrapper(this);
    }
}
