package bdd;

import sre.ndd.NDD;

import application.config2spec.NDDConfig2spec;
import controlplane.network.NDDL3Edge;
import controlplane.network.State;
import jdd.bdd.BDD;
import main.Configuration;
import main.NDDController;
import main.SRELogger;
import util.CombinationUtil;
import util.TimeUtil;

public class NDDManager {
    int ndd_table_size;
    int ndd_cache_size;
    int ntSize;
    int cacheSize;

    BDD bdd;

    public int[] bddVars;
    public int[] bddNotVars;
    public int[] totalBDDVars;
    // public Permutation[] permutations;

    NDDACLWrapper nddACLWrapper;
    NDDTCWrapper nddTCWrapper;
    NDDPredicateWrapper nddPredicateWrapper;

    public int FILTER_BDD = NDD.getTrue();

    /**
     * try to guess the optimal node table size
     */
    public static int calOptimalNTSize() {
        if (Configuration.NT_SIZE != -1)
            return Configuration.NT_SIZE;
        // number of symbolic links and valid routers
        long nSymbolicLink = NDDL3Edge.getAllL3Edge().stream().filter(e -> e.getState() == State.SYMBOLIC).count();
        int nValidRouter = NDDController.ospfValidRouters.size() + NDDController.bgpValidRouters.size();
        int nTotalRouter = NDDController.cpExecutor.getRouters().size();
        double tmp = NDDController.MF >= 0 ? CombinationUtil.numItems((int) nSymbolicLink, NDDController.MF)
                : Math.pow(2, nSymbolicLink);
        double limit1 = tmp * nValidRouter * nTotalRouter * 30 * NDDController.cpExecutorStack.size();
        // maximum memory usage (bytes)
        long xmx = Runtime.getRuntime().maxMemory();
        long limit2 = xmx / 40;
        SRELogger.logMemUse(SRELogger.LEVEL.INFO, "nSymbolicLink: " + nSymbolicLink + " nValidRoute: " + nValidRouter
                + " xmx: " + xmx + " limit1: " + limit1 + " limit2: " + limit2);
        return (int) Math.max(1000000, Math.min(Math.min(limit1, limit2), 700000000));
    }

    public NDDManager() {
        SRELogger.pushContext("BDD INIT");
        TimeUtil timer = new TimeUtil();
        timer.begin();
        ntSize = calOptimalNTSize();
        cacheSize = ntSize / 10;
        SRELogger.logMemUse(SRELogger.LEVEL.INFO, "BDD node table size: " + ntSize);

        if (NDDConfig2spec.dataset.equals("bgp_fattree04")) {
            if (Configuration.testPlan == 0) {
                ntSize = 12000;
                cacheSize = 1200;
            } else if (Configuration.testPlan == 1) {
                ntSize = 5000;
                cacheSize = 2500;
            } else {
                ntSize = 20000;
                cacheSize = 2000;
            }
        } else if (NDDConfig2spec.dataset.equals("bgp_fattree08")) {
            if (Configuration.testPlan == 0) {
                ntSize = 5000000;
                cacheSize = 500000;
            } else if (Configuration.testPlan == 1) {
                ntSize = 226180;
                cacheSize = 22618;
            } else {
                ntSize = 5000000;
                cacheSize = 500000;
            }
        } else if (NDDConfig2spec.dataset.equals("bgp_fattree12")) {
            if (Configuration.testPlan == 0) {
                ntSize = 350000000;
                cacheSize = 35000000;
            } else if (Configuration.testPlan == 1) {
                ntSize = 2105175;
                cacheSize = 210517;
            } else {
                ntSize = 350000000;
                cacheSize = 35000000;
            }
        } else if (NDDConfig2spec.dataset.equals("bgp_fattree16")) {
            if (Configuration.testPlan == 0) {
                ntSize = 350000000;
                cacheSize = 35000000;
            } else if (Configuration.testPlan == 1) {
                ntSize = 15748757;
                cacheSize = 1574875;
            } else {
                ntSize = 350000000;
                cacheSize = 35000000;
            }
        } else if (NDDConfig2spec.dataset.equals("bgp_fattree20")) {
            if (Configuration.testPlan == 0) {
                ntSize = 700000000;
                cacheSize = 70000000;
            } else if (Configuration.testPlan == 1) {
                ntSize = 92807773;
                cacheSize = 9280777;
            } else {
                ntSize = 700000000;
                cacheSize = 70000000;
            }
        } else {
            if (NDDConfig2spec.dataset.equals("uscarrier")) {
                if (NDDController.MF == 1) {
                    ntSize = 1629907;
                    cacheSize = 162990;
                } else if (NDDController.MF == 2) {
                    ntSize = 2678869;
                    cacheSize = 267886;
                } else if (NDDController.MF == 3) {
                    ntSize = 2425386;
                    cacheSize = 242538;
                }
            } else if (NDDConfig2spec.dataset.equals("columbus")) {
                if (NDDController.MF == 1) {
                    ntSize = 275739;
                    cacheSize = 27573;
                } else if (NDDController.MF == 2) {
                    ntSize = 313735;
                    cacheSize = 31373;
                } else if (NDDController.MF == 3) {
                    ntSize = 321480;
                    cacheSize = 32148;
                }
            } else if (NDDConfig2spec.dataset.equals("bics")) {
                if (NDDController.MF == 1) {
                    ntSize = 80292;
                    cacheSize = 8029;
                } else if (NDDController.MF == 2) {
                    ntSize = 92370;
                    cacheSize = 9237;
                } else if (NDDController.MF == 3) {
                    ntSize = 88783;
                    cacheSize = 8878;
                }
            }
        }
        if (NDDConfig2spec.dataset.equals("bgp_fattree04")) {
            ndd_table_size = 8000;
            ndd_cache_size = 8000;
        } else if (NDDConfig2spec.dataset.equals("bgp_fattree08")) {
            ndd_table_size = 1000000;
            ndd_cache_size = 100000;
        } else if (NDDConfig2spec.dataset.contains("fattree")) {
            ndd_table_size = 100000000;
            ndd_cache_size = 10000000;
        } else {
            if (NDDConfig2spec.dataset.equals("uscarrier")) {
                ndd_table_size = 600000;
                ndd_cache_size = 60000;
            } else if (NDDConfig2spec.dataset.equals("columbus")) {
                ndd_table_size = 200000;
                ndd_cache_size = 20000;
            } else if (NDDConfig2spec.dataset.equals("bics")) {
                ndd_table_size = 70000;
                ndd_cache_size = 7000;
            }
        }
        NDD.initNDD(ndd_table_size, ndd_cache_size, ntSize, cacheSize);
        configureMixedBackendCapacities();
        nddTCWrapper = new NDDTCWrapper(this);
        // Backends are created lazily by the current NDD when fields are declared/generated.
        bdd = NDD.getBDDEngine();
        nddACLWrapper = new NDDACLWrapper(this);
        nddPredicateWrapper = new NDDPredicateWrapper(this);
        setFilter();
        timer.end(SRELogger.LEVEL.INFO, "");
        SRELogger.popContext();
    }

    /**
     * we must create ACL wrapper first and then TC wrapper,
     * in order to create prefix related bdd vars first
     */
    public NDDManager(int node_table_size, int cache_size) {
        NDD.initNDD(node_table_size, cache_size, node_table_size, cache_size);
        configureMixedBackendCapacities();
        nddTCWrapper = new NDDTCWrapper(this);
        bdd = NDD.getBDDEngine();
        nddACLWrapper = new NDDACLWrapper(this);
        nddPredicateWrapper = new NDDPredicateWrapper(this);
        setFilter();
    }

    public NDDTCWrapper getBDDTCWrapper() {
        return nddTCWrapper;
    }

    public NDDACLWrapper getBDDACLWrapper() {
        return nddACLWrapper;
    }

    public NDDPredicateWrapper getBDDPredicateWrapper() {
        return nddPredicateWrapper;
    }

    /**
     * @return the size of bdd (in bytes)
     */
    // public long getBDDSize() {
        // return bdd.getMemoryUsage();
    // }

    public void setFilter() {
        if (NDDController.MF < 0) {
            SRELogger.log(SRELogger.LEVEL.INFO, "no filter");
        } else {
            if (Configuration.FILTER) {
                filter(false);
            } else {
                long nSymbolicLink = NDDL3Edge.getAllL3Edge().stream().filter(e -> e.getState() == State.SYMBOLIC)
                        .count();
                long nCombination = CombinationUtil.numItems((int) nSymbolicLink, NDDController.MF);
                // if (nCombination <= Configuration.MAX_COMBINATIONS_FOR_FILTER_BDD)
                // filterBDD();
                // else filter(true);
                if (nCombination <= Configuration.MAX_COMBINATIONS_FOR_FILTER_BDD)
                    filterBDD();
                else {
                    System.out.println("still use filterBDD policy");
                    filterBDD();
                }
            }
        }
    }

    private void filter(boolean autoChange) {
        Configuration.FILTER = true;
        String info = autoChange ? "Too many combinations! Automatically changing to filter" : "filter";
        SRELogger.log(SRELogger.LEVEL.INFO, info);
    }

    private void filterBDD() {
        SRELogger.log(SRELogger.LEVEL.INFO, "backend-neutral failure filter");
        NDD.deref(FILTER_BDD);
        FILTER_BDD = nddTCWrapper.encodeAtMostFailures(NDDController.MF);
//         NDD.printDot("/home/augists/Cheney/SRE-Benchmark/variants/ndd/output/parallel/filter/NDD", FILTER_BDD);
    }

    public TimeUtil timer = new TimeUtil();

    public int filter(int i) {
        int ret = i;
        if (NDDController.MF >= 0) {
            timer.begin();
            if (Configuration.FILTER) {
                // ret = bdd.ref(filter_rec(i, 0)); //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                NDD.deref(i);
                ret = NDD.getFalse();
            } else {
                ret = NDD.andTo(i, FILTER_BDD);
            }
            timer.end();
        }
        return ret;
    }

    // private int filter_rec(int i, int k) {
    // if (k > Controller.MF) {
    // return 0;
    // }
    // if (i <= 1) {
    // return i;
    // }
    // int var = bdd.getVar(i), l, h;
    // if (var >= BDDACLWrapper.totalHeaderBit) {
    // l = filter_rec(bdd.getLow(i), k + 1);
    // h = filter_rec(bdd.getHigh(i), k);
    // }
    // else {
    // l = filter_rec(bdd.getLow(i), 0);
    // h = filter_rec(bdd.getHigh(i), 0);
    // }
    // bdd.deref(i);
    // return bdd.mk(var, l, h);
    // }

    public int andDerefBoth(int i, int j) {
        int ret = NDD.ref(NDD.and(i, j));
        NDD.deref(i);
        NDD.deref(j);
        return ret;
    }

    public int orDerefBoth(int i, int j) {
        int ret = NDD.ref(NDD.or(i, j));
        NDD.deref(i);
        NDD.deref(j);
        return ret;
    }

    public int minusDerefBoth(int i, int j) {
        int ret = NDD.ref(NDD.diff(i, j));
        NDD.deref(i);
        NDD.deref(j);
        return ret;
    }

    /** Consume the left operand while treating the right operand as borrowed. */
    public int minusDerefLeft(int ownedLeft, int borrowedRight) {
        int ret = NDD.ref(NDD.diff(ownedLeft, borrowedRight));
        NDD.deref(ownedLeft);
        return ret;
    }

    public void showStats() {
        System.out.println(
                "-------------------------------------------------------------------------------------------------------------");
        // bdd.showStats();
        System.out.println(
                "-------------------------------------------------------------------------------------------------------------");
    }

    public void logUsage() {
        /* log bdd node table usage */
        SRELogger.pushContext("BDD USAGE");
        // bdd.gc();
        // NodeTableStats stats = bdd.getStats();
        // SRELogger.log(SRELogger.LEVEL.INFO, stats.get_table_size() + " " + stats.get_free_nodes_count());
        SRELogger.popContext();
    }

    public void clean() {
        // bdd.cleanup();
    }

    public void clear() {
        nddACLWrapper = null;
        nddTCWrapper = null;
        nddPredicateWrapper = null;
    }

    public void reset() {
        NDD.initNDD(ndd_table_size, ndd_cache_size, ntSize, cacheSize);
        configureMixedBackendCapacities();
        nddACLWrapper = new NDDACLWrapper(this);
        nddTCWrapper = new NDDTCWrapper(this);
        nddPredicateWrapper = new NDDPredicateWrapper(this);
    }

    private void configureMixedBackendCapacities() {
        if (Configuration.testPlan != 1) {
            return;
        }
        Configuration.NDDBackendProfile profile = Configuration.NDD_BACKEND_PROFILE;
        NDD.LabelMode header = Configuration.NDD_BACKEND_PROFILE.headerMode();
        NDD.LabelMode link = Configuration.NDD_BACKEND_PROFILE.linkMode();

        if (NDDConfig2spec.dataset.equals("bgp_fattree08")) {
            if (profile == Configuration.NDDBackendProfile.HEADER_BCDD_LINK_ZDD) {
                configureCapacity(header, 230000, 262144);
                configureCapacity(link, 400000, 40000);
            } else if (profile == Configuration.NDDBackendProfile.HEADER_BDD_LINK_BCDD) {
                configureCapacity(header, 230000, 23000);
                configureCapacity(link, NDDController.MF >= 3 ? 2000000 : 400000, 2097152);
            } else if (profile == Configuration.NDDBackendProfile.ALL_BCDD) {
                configureCapacity(header, NDDController.MF >= 3 ? 2500000 : 600000, 2097152);
            }
            return;
        }

        if (!NDDConfig2spec.dataset.equals("bgp_fattree12")) return;
        if (profile == Configuration.NDDBackendProfile.HEADER_BDD_LINK_ZDD) {
            configureCapacity(header, 1000000, 100000);
            configureCapacity(link, 800000, 80000);
        } else if (profile == Configuration.NDDBackendProfile.HEADER_BCDD_LINK_ZDD) {
            configureCapacity(header, 1000000, 1048576);
            configureCapacity(link, 800000, 80000);
        } else if (profile == Configuration.NDDBackendProfile.HEADER_BDD_LINK_BCDD) {
            configureCapacity(header, 1000000, 100000);
            configureCapacity(link, NDDController.MF >= 2 ? 10000000 : 1800000,
                    NDDController.MF >= 2 ? 8388608 : 2097152);
        } else if (profile == Configuration.NDDBackendProfile.ALL_BCDD) {
            configureCapacity(header, NDDController.MF >= 2 ? 11000000 : 2500000,
                    NDDController.MF >= 2 ? 8388608 : 2097152);
        }
    }

    private void configureCapacity(NDD.LabelMode mode, int table, int cache) {
        NDD.configureBackendCapacity(mode, table, cache);
        System.out.println("ndd_backend_capacity:" + mode + "=" + table + "/" + cache);
    }
}
