package bdd;

import sre.ndd.NDD;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Vector;


import datamodel.ipv4.Header;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Mask;
import datamodel.ipv4.Prefix;
import dataplane.acl.NDDACLRule;
import dataplane.acl.Range;
import jdd.bdd.BDD;
import multimap.HashBasedTable;
import multimap.Table;
import util.MathUtil;
import util.NDDUtil;

public class NDDACLWrapper implements Serializable {
    private static final long serialVersionUID = 7284490986562707221L;

    BDD bdd;
    NDDManager manager;

    /**
     * the arrays store BDD variables.
     */
    final static int protocolBits = 8;
    int[] protocol; // protocol[0] is the lowest bits
    final static int portBits = 16;
    int[] srcPort;
    int[] dstPort;
    final static int ipBits = 32;
    int[] srcIP;
    int[] dstIP;
    final static int totalHeaderBit = 8 + (16 + 32) * 2;

    public static int getPortBits() {
        return portBits;
    }

    public static int getIpBits() {
        return ipBits;
    }

    public NDDACLWrapper(NDDManager manager) {
        this.manager = manager;
        this.bdd = manager.bdd;

        protocol = new int[protocolBits];
        srcPort = new int[portBits];
        dstPort = new int[portBits];
        srcIP = new int[ipBits];
        dstIP = new int[ipBits];

        /*
         * will try more orders of variables
         */
        DeclareSrcIP();
        DeclareDstIP();
        DeclareSrcPort();
        DeclareDstPort();
        DeclareProtocol();
    }

    public enum Field {
        dstIP(0, 32),
        srcIP(1, 32),
        dstPort(2, 16),
        srcPort(3, 16),
        protocol(4, 8);

        final int logicalIndex;
        final int bitWidth;
        int fieldNum;
        static int num = 5;

        Field(int logicalIndex, int bitWidth) {
            this.logicalIndex = logicalIndex;
            this.bitWidth = bitWidth;
            this.fieldNum = logicalIndex;
        }

        static void setPhysicalStart(int firstHeaderField) {
            for (Field field : values()) {
                field.fieldNum = firstHeaderField + field.logicalIndex;
            }
        }

        static Field byLogicalIndex(int logicalIndex) {
            for (Field field : values()) {
                if (field.logicalIndex == logicalIndex) return field;
            }
            throw new IllegalArgumentException("unknown logical header field: " + logicalIndex);
        }

        static Field fromPhysicalField(int physicalField) {
            for (Field field : values()) {
                if (field.fieldNum == physicalField) return field;
            }
            return null;
        }

        public static int getLen(int logicalIndex) {
            return byLogicalIndex(logicalIndex).bitWidth;
        }
    }

    public int encodeSrcIPPrefix(long ipaddr, int prefixlen) {
        int[] ipbin = MathUtil.CalBinRep(ipaddr, ipBits);
        int[] ipbinprefix = new int[prefixlen];
        for (int k = 0; k < prefixlen; k++) {
            ipbinprefix[k] = ipbin[ipBits - 1 - k];
        }
        int entrybdd = NDD.encodePrefix(ipbinprefix, Field.srcIP.fieldNum);
        // int entrybdd = encodePrefix(ipbinprefix, Field.srcIP, ipBits);
        return entrybdd;
    }

    public Table<Long, Integer, Integer> memo = HashBasedTable.create();

    public int encodeDstIPPrefix(Prefix prefix) {
        return encodeDstIPPrefix(prefix.getIp().asLong(), prefix.getPreLength());
    }

    public int encodeDstIPPrefix(long ipaddr, int prefixlen) {
        if (!memo.contains(ipaddr, prefixlen)) {
            int[] ipbin = MathUtil.CalBinRep(ipaddr, ipBits);
            int[] ipbinprefix = new int[prefixlen];
            for (int k = 0; k < prefixlen; k++) {
                ipbinprefix[k] = ipbin[ipBits - 1 - k];
            }
            int entrybdd = NDD.encodePrefix(ipbinprefix, Field.dstIP.fieldNum);
            // int entrybdd = encodePrefix(ipbinprefix, Field.dstIP, ipBits);
            memo.put(ipaddr, prefixlen, NDD.ref(entrybdd));
        }
        return memo.get(ipaddr, prefixlen);
    }

    public void multipleref(int bddnode, int reftimes) {
        for (int i = 0; i < reftimes; i++) {
            NDD.ref(bddnode);
        }
    }

    /**
     *
     * @param subs
     *                 - has ip information
     * @param rawBDD
     * @param reftimes
     *                 - the res need to be referenced for several times
     * @return
    public int encodeACLin(ArrayList<Subnet> subs, int rawBDD, int reftimes) {
        // dest ip
        if (subs == null) {
            multipleref(rawBDD, reftimes);
            return rawBDD;
        }
        int destipbdd = encodeDstIPPrefixs(subs);
        int notdestip = NDD.not(destipbdd);
        NDD.ref(notdestip);
        int res = NDD.or(notdestip, rawBDD);

        multipleref(res, reftimes);
        NDD.deref(destipbdd);
        NDD.deref(notdestip);
        return res;
    }

    public int encodeACLout(ArrayList<Subnet> subs, int rawBDD, int reftimes) {
        if (subs == null) {
            multipleref(rawBDD, reftimes);
            return rawBDD;
        }
        // src ip
        int srcipbdd = encodeSrcIPPrefixs(subs);
        int notsrctip = NDD.not(srcipbdd);
        NDD.ref(notsrctip);
        int res = NDD.or(notsrctip, rawBDD);

        multipleref(res, reftimes);
        NDD.deref(srcipbdd);
        NDD.deref(notsrctip);
        return res;
    }

    public Table<Long, Integer, Integer> memoBDD = HashBasedTable.create();

    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    public int encodeOnePrefixBDD(long ipaddr, int prefixlen) {
        if (!memoBDD.contains(ipaddr, prefixlen)) {
            int[] ipbin = MathUtil.CalBinRep(ipaddr, ipBits);
            int[] ipbinprefix = new int[prefixlen];
            for (int k = 0; k < prefixlen; k++) {
                ipbinprefix[k] = ipbin[k + ipBits - prefixlen];
            }
            int entrybdd = NDD.encodePrefixBDD(ipbinprefix, manager.bddVars, manager.bddNotVars);
            // int entrybdd = encodePrefixBDD(ipbinprefix, manager.bddVars, ipBits);
            memoBDD.put(ipaddr, prefixlen, entrybdd);
        }
        return memoBDD.get(ipaddr, prefixlen);
    }

    int encodePrefixBDD(int[] prefix, int[] vars, int bits) {
        return bdd.ref(encodePrefixBDD(prefix, vars, bits, prefix.length - 1));
    }

    // we are decreasing idx since vars are in decreasing order
    // e.g. srcIP: [32,31,30,...,1,0]
    private int encodePrefixBDD(int[] prefix, int[] vars, int bits, int idx) {
        if (idx < 0) {
            return 1;
        }
        int l = 0, h = 0, v = bdd.getVar(vars[bits - prefix.length + idx]);
        if (prefix[idx] == 0) {
            l = encodePrefixBDD(prefix, vars, bits, idx - 1);
        }
        if (prefix[idx] == 1) {
            h = encodePrefixBDD(prefix, vars, bits, idx - 1);
        }
        return bdd.mk(v, l, h);
    }

    public int encodeDstIPPrefixs(ArrayList<Subnet> subs) {
        int res = BDDManager.BDDFalse;
        for (int i = 0; i < subs.size(); i++) {
            Subnet onesub = subs.get(i);
            int dstipbdd = encodeOnePrefixBDD(onesub.getIpAddr(),
                    onesub.getPrefixLen());
            int tmp = bdd.or(res, dstipbdd);
            bdd.ref(tmp);
            bdd.deref(res);
            bdd.deref(dstipbdd);
            res = tmp;
        }
        HashMap<Integer, Integer> edges = new HashMap<>();
        edges.put(NDD.getTrue(), res);
        return NDD.ref(NDD.addAtField(Field.dstIP.fieldNum, edges));
    }

    public int encodeSrcIPPrefixs(ArrayList<Subnet> subs) {
        int res = BDDManager.BDDFalse;
        for (int i = 0; i < subs.size(); i++) {
            Subnet onesub = subs.get(i);
            int srcipbdd = encodeOnePrefixBDD(onesub.getIpAddr(),
                    onesub.getPrefixLen());
            int tmp = bdd.or(res, srcipbdd);
            bdd.ref(tmp);
            bdd.deref(res);
            bdd.deref(srcipbdd);
            res = tmp;
        }
        HashMap<Integer, Integer> edges = new HashMap<>();
        edges.put(NDD.getTrue(), res);
        return NDD.ref(NDD.addAtField(Field.srcIP.fieldNum, edges));
    }
    */

    private void DeclareNDDVars(int[] vars, int bits, Field f) {
        for (int i = 0; i < bits; i++) {
            vars[i] = NDD.ref(NDD.getVar(f.fieldNum, i));
        }
        /*
        for (int i = bits - 1; i >= 0; i--) {
            int var = manager.bddVars[i];
            HashMap<Integer, Integer> edges = new HashMap<>();
            edges.put(NDD.getTrue(), var);
            vars[i] = NDD.ref(NDD.addAtField(f.fieldNum, edges));
        }
        */
    }

    // protocol is 8 bits
    private void DeclareProtocol() {
        DeclareNDDVars(protocol, protocolBits, Field.protocol);
    }

    private void DeclareSrcPort() {
        DeclareNDDVars(srcPort, portBits, Field.srcPort);
    }

    private void DeclareDstPort() {
        DeclareNDDVars(dstPort, portBits, Field.dstPort);
    }

    private void DeclareSrcIP() {
        DeclareNDDVars(srcIP, ipBits, Field.srcIP);
    }

    private void DeclareDstIP() {
        DeclareNDDVars(dstIP, ipBits, Field.dstIP);
    }

    /**
     *
     * @param acls
     *             - the acl that needs to be transformed to bdd
     * @return a bdd node that represents the acl
     */
    public int ConvertACLs(LinkedList<NDDACLRule> acls) {
        if (acls == null) {
            // no acl configured on this interface, permit all
            return NDD.getTrue();
        }
        if (acls.size() == 0) {
            // acl configured on this interface, but with no rule, deny all by default
            // no need to ref the false node
            return NDD.getFalse();
        }
        int res = NDD.getFalse();
        int denyBuffer = NDD.getFalse();
        int denyBufferNot = NDD.getTrue();
        for (int i = 0; i < acls.size(); i++) {
            NDDACLRule acl = acls.get(i);
            // g has been referenced
            int g = ConvertACLRule(acl);

            if (NDDACLRule.CheckPermit(acl)) {
                if (NDD.isFalse(res)) {
                    if (NDD.isFalse(denyBuffer)) {
                        res = g;
                    } else {
                        int tempnode = NDD.and(g, denyBufferNot);
                        NDD.ref(tempnode);
                        res = tempnode;
                        NDD.deref(g);
                    }
                } else {
                    if (NDD.isFalse(denyBuffer)) {
                        // just combine the current res and g
                        int tempnode = NDD.or(res, g);
                        NDD.ref(tempnode);
                        NDDUtil.derefInBatch(new int[] { res, g });
                        res = tempnode;
                    } else {
                        // the general case
                        int tempnode = NDD.and(g, denyBufferNot);
                        NDD.ref(tempnode);
                        NDD.deref(g);

                        int tempnode2 = NDD.or(res, tempnode);
                        NDD.ref(tempnode2);
                        NDDUtil.derefInBatch(new int[] { res, tempnode });
                        res = tempnode2;
                    }
                }

            } else {
                /**
                 * combine to the denyBuffer
                 */
                if (NDD.isFalse(denyBuffer)) {
                    denyBuffer = g;
                    denyBufferNot = NDD.not(g);
                    NDD.ref(denyBufferNot);
                } else {
                    int tempnode = NDD.or(denyBuffer, g);
                    NDD.ref(tempnode);
                    NDDUtil.derefInBatch(new int[] { denyBuffer, g });
                    denyBuffer = tempnode;

                    NDD.deref(denyBufferNot);
                    denyBufferNot = NDD.not(denyBuffer);
                    NDD.ref(denyBufferNot);
                }
            }
            // System.out.println(acl);
            // System.out.println(res);
        }
        /**
         * we need to de-ref denyBuffer, denyBufferNot
         */
        // DerefInBatch(new int[]{denyBuffer, denyBufferNot});
        NDD.deref(denyBufferNot);
        NDD.deref(denyBuffer);
        return res;
    }

    /**
     *
     * @param aclr
     *             - an acl rule
     * @return a bdd node representing this rule
     */
    public int ConvertACLRule(NDDACLRule aclr) {
        int ret = NDD.getTrue();
        if (aclr.protocolLower != null
                && !aclr.protocolLower.equalsIgnoreCase("any")) {
            Range r = NDDACLRule.convertProtocolToRange(aclr.protocolLower,
                    aclr.protocolUpper);
            ret = NDD.andTo(ret, ConvertProtocol(r));
        }
        if (aclr.sourcePortLower != null
                && aclr.sourcePortLower.equalsIgnoreCase("any")) {
            Range r = NDDACLRule.convertPortToRange(aclr.sourcePortLower,
                    aclr.sourcePortUpper);
            ret = NDD.andTo(ret, ConvertSrcPort(r));
        }
        if (aclr.destinationPortLower != null
                && aclr.destinationPortLower.equalsIgnoreCase("any")) {
            Range r = NDDACLRule.convertPortToRange(aclr.destinationPortLower,
                    aclr.destinationPortUpper);
            ret = NDD.andTo(ret, ConvertDstPort(r));
        }

        /*
        int ret = NDD.getTrue();
        // protocol
        // no need to ref the true node
        int protocolNode = BDDManager.BDDTrue;
        if (aclr.protocolLower == null
                || aclr.protocolLower.equalsIgnoreCase("any")) {
            // do nothing, just a shortcut
        } else {
            Range r = NDDACLRule.convertProtocolToRange(aclr.protocolLower,
                    aclr.protocolUpper);
            protocolNode = ConvertProtocol(r);
        }
        HashMap<Integer, Integer> edges = new HashMap<>();
        edges.put(ret, protocolNode);
        int t = NDD.ref(NDD.mk(Field.protocol.fieldNum, edges));
        NDD.deref(ret);
        ret = t;

        // src port
        int srcPortNode = BDDManager.BDDTrue;
        if (aclr.sourcePortLower == null
                || aclr.sourcePortLower.equalsIgnoreCase("any")) {
            // do nothing, just a shortcut
        } else {
            Range r = NDDACLRule.convertPortToRange(aclr.sourcePortLower,
                    aclr.sourcePortUpper);
            srcPortNode = ConvertSrcPort(r);
        }
        edges = new HashMap<>();
        edges.put(ret, srcPortNode);
        t = NDD.ref(NDD.mk(Field.srcPort.fieldNum, edges));
        NDD.deref(ret);
        ret = t;

        // dst port
        int dstPortNode = BDDManager.BDDTrue;
        if (aclr.destinationPortLower == null
                || aclr.destinationPortLower.equalsIgnoreCase("any")) {
            // do nothing, just a shortcut
        } else {
            Range r = NDDACLRule.convertPortToRange(aclr.destinationPortLower,
                    aclr.destinationPortUpper);
            dstPortNode = ConvertDstPort(r);
        }
        edges = new HashMap<>();
        edges.put(ret, dstPortNode);
        t = NDD.ref(NDD.mk(Field.dstPort.fieldNum, edges));
        NDD.deref(ret);
        ret = t;
        */

        // Build per-field BDD list for encodeACL
        ArrayList<NDD.Pair<Integer, Integer>> perFieldBDD = new ArrayList<>();

        // src IP
        int srcIPNode = ConvertIPAddress(aclr.source, aclr.sourceWildcard);
        perFieldBDD.add(new NDD.Pair<>(Field.srcIP.fieldNum, srcIPNode));

        // dst IP
        int dstIPNode = ConvertIPAddress(aclr.destination, aclr.destinationWildcard);
        perFieldBDD.add(new NDD.Pair<>(Field.dstIP.fieldNum, dstIPNode));

        int nddFromFields = NDD.ref(NDD.encodeACL(perFieldBDD));

        // Combine with protocol/port constraints
        if (!NDD.isTrue(ret)) {
            int combined = NDD.andTo(ret, nddFromFields);
            NDD.deref(nddFromFields);
            return combined;
        } else {
            return nddFromFields;
        }
    }

    /**
     * @param IP
     *           address and mask
     * @return the corresponding bdd node
     */
    protected int ConvertIPAddress(String IP, String Mask) {
        int tempnode = BDDManager.BDDTrue;
        // case 1 IP = any
        if (IP == null || IP.equalsIgnoreCase("any")) {
            // return TRUE node
            return tempnode;
        }

        // binary representation of IP address
        int[] ipbin = MathUtil.IPBinRep(IP);
        // case 2 Mask = null
        if (Mask == null) {
            // no mask is working
            return NDD.encodePrefixBDD(ipbin, manager.bddVars, manager.bddNotVars);
            // return encodePrefixBDD(ipbin, vars, ipBits);
        } else {
            // int[] maskbin = MathUtil.IPBinRep(Mask);
            // int numMasked = MathUtil.NumofNonZeros(maskbin);
            //
            // int[] prefix = new int[maskbin.length - numMasked];
            // int[] varsUsed = new int[prefix.length];
            // int ind = 0;
            // for (int i = 0; i < maskbin.length; i++) {
            // if (maskbin[i] == 0) {
            // prefix[ind] = ipbin[i];
            // varsUsed[ind] = vars[i];
            // ind++;
            // }
            // }
            //
            // return encodePrefixDeprecated(prefix, varsUsed, prefix.length);

            /*
             * Above is original code in apv, we change it since the meaning of mask
             * changes.
             * for apv: a mask will be 0.0.0.255
             * for us: a mask will be 255.255.255.0
             */
            int[] maskbin = MathUtil.IPBinRep(Mask);
            int numMasked = ipBits - MathUtil.NumofNonZeros(maskbin);

            int[] prefix = new int[maskbin.length - numMasked];
            int[] varsUsed = new int[prefix.length];
            int[] varsUsedNot = new int[prefix.length];
            int ind = 0;
            for (int i = 0; i < maskbin.length; i++) {
                if (maskbin[i] == 1) {
                    prefix[ind] = ipbin[i];
                    varsUsed[ind] = manager.bddVars[i];
                    varsUsedNot[ind] = manager.bddNotVars[i];
                    ind++;
                }
            }

            return NDD.encodePrefixBDD(prefix, varsUsed, varsUsedNot);
            // return encodePrefixBDD(prefix, varsUsed, prefix.length);
        }

    }

    /***
     * convert a range of protocol numbers to a bdd representation
     */
    protected int ConvertProtocol(Range r) {
        return ConvertRange(r, protocolBits, Field.protocol.fieldNum);

    }

    /**
     * convert a range of source port numbers to a bdd representation
     */
    protected int ConvertSrcPort(Range r) {
        return ConvertRange(r, portBits, Field.srcPort.fieldNum);
    }

    /**
     * convert a range of destination port numbers to a bdd representation
     */
    protected int ConvertDstPort(Range r) {
        return ConvertRange(r, portBits, Field.dstPort.fieldNum);
    }

    /**
     *
     * @param r
     *             - the range
     * @param bits
     *             - number of bits in the representation
     * @return the corresponding bdd node
     */
    private int ConvertRange(Range r, int bits, int fieldNum) {
        ArrayList<int[]> prefix = MathUtil.DecomposeInterval(r, bits);
        // System.out.println(vars.length);
        if (prefix.size() == 0) {
            return NDD.getTrue();
        }
        ArrayList<int[]> fieldOrder = new ArrayList<>(prefix.size());
        for (int[] onePrefix : prefix) {
            int[] reversed = new int[onePrefix.length];
            for (int index = 0; index < onePrefix.length; index++) {
                reversed[index] = onePrefix[onePrefix.length - 1 - index];
            }
            fieldOrder.add(reversed);
        }
        return NDD.encodePrefixs(fieldOrder, fieldNum);
        /* 
        int[] vars = manager.bddVars;
        LinkedList<int[]> prefix = MathUtil.DecomposeInterval(r, bits);
        // System.out.println(vars.length);
        if (prefix.size() == 0) {
            return BDDManager.BDDTrue;
        }

        for (int i = 0; i < prefix.size(); i++) {
            if (i == 0) {
                tempnode = NDD.encodePrefixBDD(prefix.get(i), manager.bddVars, manager.bddNotVars);
                // tempnode = encodePrefixBDD(prefix.get(i), vars, bits);
            } else {
                int tempnode2 = NDD.encodePrefixBDD(prefix.get(i), manager.bddVars, manager.bddNotVars);
                // int tempnode2 = encodePrefixBDD(prefix.get(i), vars, bits);
                int tempnode3 = bdd.or(tempnode, tempnode2);
                bdd.ref(tempnode3);
                BDDUtil.derefInBatch(bdd, new int[] { tempnode, tempnode2 });
                tempnode = tempnode3;
            }
        }
        return tempnode;
        */
    }

    /*
    int encodePrefix(int[] prefix, Field f, int bits) {
        int retBDD = encodePrefixBDD(prefix, manager.bddVars, bits, prefix.length - 1);
        bdd.ref(retBDD);
        HashMap<Integer, Integer> edges = new HashMap<>();
        edges.put(NDD.getTrue(), retBDD);
        return NDD.ref(NDD.addAtField(f.fieldNum, edges));
    }
    */

    /**
     *
     * @param prefix
     *               -
     * @param bits
     *               - number of bits in the representation
     * @return a bdd node representing the predicate e.g. for protocol, bits = 8,
     *         prefix = {1,0,1,0}, so the predicate is protocol[4] and (not
     *         protocol[5]) and protocol[6] and (not protocol[7])
    @Deprecated
    int encodePrefixDeprecated(int[] prefix, Field f, int bits) {
        if (prefix.length == 0) {
            return NDD.getTrue();
        }

        int[] vars = manager.bddVars;

        int tempNode = BDDManager.BDDTrue;
        for (int i = 0; i < prefix.length; i++) {
            if (i == 0) {
                tempNode = encodingVar(vars[bits - prefix.length + i],
                        prefix[i]);
            } else {
                int tempNode2 = encodingVar(vars[bits - prefix.length + i],
                        prefix[i]);
                int tempNode3 = bdd.and(tempNode, tempNode2);
                bdd.ref(tempNode3);
                // do not need tempNode2, tempNode now
                // aclBDD.deref(tempNode2);
                // aclBDD.deref(tempNode);
                BDDUtil.derefInBatch(bdd, new int[] { tempNode, tempNode2 });
                // refresh tempNode 3
                tempNode = tempNode3;
            }
        }

        HashMap<Integer, Integer> edges = new HashMap<>();
        edges.put(NDD.getTrue(), tempNode);
        return NDD.ref(NDD.addAtField(f.fieldNum, edges));
    }
     */

    /***
     * return a bdd node representing the predicate on the protocol field
    private int encodeProtocolPrefix(int[] prefix) {
        return encodePrefix(prefix, Field.protocol, protocolBits);
    }
    */

    /**
     * return the size of the bdd tree
    public int getNodeSize(int bddNode) {
        int size = bdd.nodeCount(bddNode);
        if (size == 0) {// this means that it is only a terminal node
            size++;
        }
        return size;
    }
     */

    /***
     * var is a BDD variable if flag == 1, return var if flag == 0, return not
     * var, the new bdd node is referenced.
    private int encodingVar(int var, int flag) {
        if (flag == 0) {
            // no need to ref the negation of a variable.
            // the ref count is already set to maximal
            // aclBDD.ref(tempNode);
            return bdd.not(var);
        }
        if (flag == 1) {
            return var;
        }

        // should not reach here
        System.err.println("flag can only be 0 or 1!");
        return -1;
    }
     */

    // HashMap<Integer, HashSet<Header>> headerMemo = new HashMap<>();
    // int memoHit = 0;
    //
    // /**
    // * @param predicate - a bdd that consists of only dst ip vars
    // * @return a set of headers represented by this bdd
    // */
    // public HashSet<Header> getHeaders(int predicate) {
    // if (!headerMemo.containsKey(predicate)) {
    // HashSet<Header> headers = new HashSet<>();
    // byte[] headerBin = new byte[BDDACLWrapper.totalHeaderBit];
    // Arrays.fill(headerBin, (byte) -1);
    // getHeaders_rec(headers, headerBin, predicate);
    // headerMemo.put(predicate, headers);
    // }
    // else memoHit++;
    // return headerMemo.get(predicate);
    // }
    //
    // public void getHeaders_rec(HashSet<Header> headers, byte[] headerBin, int
    // predicate) {
    // if (predicate != BDDManager.BDDFalse) {
    // if (predicate == BDDManager.BDDTrue) {
    // headers.addAll(bitVector2Header(headerBin));
    // }
    // else {
    // int var = bdd.getVar(predicate);
    // // pay attention to idx
    // int idx = totalHeaderBit - 1 - var;
    // headerBin[idx] = 0;
    // getHeaders_rec(headers, headerBin, bdd.getLow(predicate));
    // headerBin[idx] = 1;
    // getHeaders_rec(headers, headerBin, bdd.getHigh(predicate));
    // headerBin[idx] = -1;
    // }
    // }
    // }

    public Collection<Header> predVector2Header(int[] headerPred) {
        Collection[] collections = new Collection[Field.num];
        for (int i = 0; i < Field.num; i++) {
            int bitNum = 0;
            if (i == Field.dstIP.logicalIndex) {
                collections[i] = new HashSet<Prefix>();
                bitNum = 32;
            } else if (i == Field.srcIP.logicalIndex) {
                collections[i] = new HashSet<Prefix>();
                bitNum = 32;
            } else if (i == Field.dstPort.logicalIndex) {
                collections[i] = new HashSet<Range>();
                bitNum = 16;
            } else if (i == Field.srcPort.logicalIndex) {
                collections[i] = new HashSet<Range>();
                bitNum = 16;
            } else {
                collections[i] = new HashSet<Range>();
                bitNum = 8;
            }
            byte[] headerBin = new byte[bitNum];
            Arrays.fill(headerBin, (byte) -1);
            int physicalField = Field.byLogicalIndex(i).fieldNum;
            for (byte[] cube : NDD.labelCubes(physicalField, headerPred[i], bitNum)) {
                for (int bit = 0; bit < bitNum; ++bit) headerBin[bitNum - bit - 1] = cube[bit];
                if (i == Field.dstIP.logicalIndex || i == Field.srcIP.logicalIndex)
                    bitVector2Prefix(headerBin, (HashSet<Prefix>)collections[i]);
                else bitVector2Range(headerBin, (HashSet<Range>)collections[i]);
            }
        }

        HashSet<Header> headers = new HashSet<>();
        for (Range protocol : (HashSet<Range>) collections[Field.protocol.logicalIndex]) {
            for (Prefix source : (HashSet<Prefix>) collections[Field.srcIP.logicalIndex]) {
                for (Range sourcePort : (HashSet<Range>) collections[Field.srcPort.logicalIndex]) {
                    for (Prefix destination : (HashSet<Prefix>) collections[Field.dstIP.logicalIndex]) {
                        for (Range destinationPort : (HashSet<Range>) collections[Field.dstPort.logicalIndex]) {
                            Header header = new Header(protocol, source, sourcePort, destination, destinationPort);
                            headers.add(header);
                        }
                    }
                }
            }
        }
        return headers;
    }

    private void predVector2Header_rec(int predicate, byte[] headerBin, int bitNum, Collection collection, int field) {
        if (predicate == 0)
            return;
        int n = bitNum;
        int var = bdd.getVar(predicate);
        if (var >= n) {
            if (field == Field.dstIP.logicalIndex || field == Field.srcIP.logicalIndex) {
                bitVector2Prefix(headerBin, (HashSet<Prefix>) collection);
            } else {
                bitVector2Range(headerBin, (HashSet<Range>) collection);
            }
        } else {
            // Per-field backend variables are allocated in reverse creation order:
            // handle variable 31 is the IPv4 MSB and variable 0 is the LSB.
            // Header vectors use the same LSB-at-index-0 convention as MathUtil.CalBinRep,
            // so the backend variable id is already the correct vector index.
            int idx = var;
            headerBin[idx] = 0;
            predVector2Header_rec(bdd.getLow(predicate), headerBin, bitNum, collection, field);
            headerBin[idx] = 1;
            predVector2Header_rec(bdd.getHigh(predicate), headerBin, bitNum, collection, field);
            headerBin[idx] = -1;
        }
    }

    /**
     * -------- 10000000 00000000 00001010
     * prefix{ip:80.0.1.0, mask:255.255.255.0}
     */
    private void bitVector2Prefix(byte[] prefixBin, HashSet<Prefix> collection) {
        // bound is the right most -1 in bin
        int bound = -1;
        while (bound + 1 < prefixBin.length && prefixBin[bound + 1] == -1)
            bound++;

        Vector<Long> ipLongs = new Vector<>();
        ipLongs.add(0L);
        int i = prefixBin.length - 1;
        while (i > bound) {
            if (prefixBin[i] != -1) {
                for (int j = 0; j < ipLongs.size(); j++) {
                    ipLongs.set(j, (ipLongs.get(j) << 1) + prefixBin[i]);
                }
            } else {
                Vector<Long> tmp = new Vector<>(ipLongs.size() * 2);
                for (int j = 0; j < ipLongs.size(); j++) {
                    long ipLong = ipLongs.get(j) << 1;
                    tmp.add(2 * j, ipLong);
                    tmp.add(2 * j + 1, ipLong + 1);
                }
                ipLongs = tmp;
            }
            i--;
        }
        for (int j = 0; j < ipLongs.size(); j++) {
            ipLongs.set(j, ipLongs.get(j) << (bound + 1));
        }

        for (long ipLong : ipLongs) {
            collection.add(Prefix.of(Ip.of(ipLong), Mask.of(ipBits - bound - 1)));
        }
    }

    // {0, 1, 1, 0, 0, 0, 0, 0} -> [ 6 - 6 ]
    // TODO combine neighboring ranges. e.g., [ 64 - 127 ] and [ 128 - 255 ]
    private void bitVector2Range(byte[] rangeBin, HashSet<Range> collection) {
        int bound = -1;
        while (bound + 1 < rangeBin.length && rangeBin[bound + 1] == -1)
            bound++;

        Vector<Long> lowers = new Vector<>();
        lowers.add(0L);
        int i = rangeBin.length - 1;
        while (i > bound) {
            if (rangeBin[i] != -1) {
                for (int j = 0; j < lowers.size(); j++) {
                    lowers.set(j, (lowers.get(j) << 1) + rangeBin[i]);
                }
            } else {
                Vector<Long> tmp = new Vector<>(lowers.size() * 2);
                for (int j = 0; j < lowers.size(); j++) {
                    long ipLong = lowers.get(j) << 1;
                    tmp.add(2 * j, ipLong);
                    tmp.add(2 * j + 1, ipLong + 1);
                }
                lowers = tmp;
            }
            i--;
        }
        for (int j = 0; j < lowers.size(); j++) {
            lowers.set(j, lowers.get(j) << (bound + 1));
        }
        long rangeLen = (1L << (bound + 1)) - 1;

        for (long num : lowers) {
            collection.add(new Range(num, num + rangeLen));
        }
    }

    // public Collection<Header> bitVector2Header(byte[] headerBin) {
    // HashSet<Header> headers = new HashSet<>();
    //
    // int lBound, rBound = 0;
    //
    // // pay attention to the order
    // lBound = rBound;
    // rBound += protocolBits;
    // byte[] protocolBin = Arrays.copyOfRange(headerBin, lBound, rBound);
    // Collection<Range> protocols = bitVector2Range(protocolBin);
    //
    // lBound = rBound;
    // rBound += portBits;
    // byte[] destinationPortBin = Arrays.copyOfRange(headerBin, lBound, rBound);
    // Collection<Range> destinationPorts = bitVector2Range(destinationPortBin);
    //
    // lBound = rBound;
    // rBound += portBits;
    // byte[] sourcePortBin = Arrays.copyOfRange(headerBin, lBound, rBound);
    // Collection<Range> sourcePorts = bitVector2Range(sourcePortBin);
    //
    // lBound = rBound;
    // rBound += ipBits;
    // byte[] destinationBin = Arrays.copyOfRange(headerBin, lBound, rBound);
    // Collection<Prefix> destinations = Ip.ipBinToPrefixes(destinationBin);
    //
    // lBound = rBound;
    // rBound += ipBits;
    // byte[] sourceBin = Arrays.copyOfRange(headerBin, lBound, rBound);
    // Collection<Prefix> sources = Ip.ipBinToPrefixes(sourceBin);
    //
    // for (Range protocol : protocols) {
    // for (Prefix source: sources) {
    // for (Range sourcePort : sourcePorts) {
    // for (Prefix destination : destinations) {
    // for (Range destinationPort : destinationPorts) {
    // Header header = new Header(protocol, source, sourcePort, destination,
    // destinationPort);
    // headers.add(header);
    // }
    // }
    // }
    // }
    // }
    //
    // return headers;
    // }
    //
    // // {0, 1, 1, 0, 0, 0, 0, 0} -> [ 6 - 6 ]
    // // TODO combine neighboring ranges. e.g., [ 64 - 127 ] and [ 128 - 255 ]
    // public Collection<Range> bitVector2Range(byte[] rangeBin) {
    // int bound = -1;
    // while (bound + 1 < rangeBin.length && rangeBin[bound + 1] == -1) bound++;
    //
    // Vector<Long> lowers = new Vector<>();
    // lowers.add(0L);
    // int i = rangeBin.length - 1;
    // while (i > bound) {
    // if (rangeBin[i] != -1) {
    // for (int j = 0; j < lowers.size(); j++) {
    // lowers.set(j, (lowers.get(j) << 1) + rangeBin[i]);
    // }
    // }
    // else {
    // Vector<Long> tmp = new Vector<>(lowers.size() * 2);
    // for (int j = 0; j < lowers.size(); j++) {
    // long ipLong = lowers.get(j) << 1;
    // tmp.add(2 * j, ipLong);
    // tmp.add(2 * j + 1, ipLong + 1);
    // }
    // lowers = tmp;
    // }
    // i--;
    // }
    // for (int j = 0; j < lowers.size(); j++) {
    // lowers.set(j, lowers.get(j) << (bound + 1));
    // }
    // long rangeLen = (1L << (bound + 1)) - 1;
    //
    // HashSet<Range> ranges = new HashSet<>();
    // for (long num : lowers) {
    // ranges.add(new Range(num, num + rangeLen));
    // }
    // return ranges;
    // }
}
