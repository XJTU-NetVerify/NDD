package main;

import java.util.Locale;

import sre.ndd.NDD;

import util.CombinationUtil;

public class Configuration {
    public enum NDDBackendProfile {
        ALL_BDD,
        HEADER_BDD_LINK_ZDD,
        HEADER_BCDD_LINK_ZDD,
        HEADER_BDD_LINK_BCDD,
        ALL_BCDD;

        public NDD.LabelMode headerMode() {
            return this == HEADER_BCDD_LINK_ZDD || this == ALL_BCDD
                    ? NDD.LabelMode.COMPLEMENTED_BDD : NDD.LabelMode.BDD;
        }

        public NDD.LabelMode linkMode() {
            if (this == HEADER_BDD_LINK_ZDD || this == HEADER_BCDD_LINK_ZDD)
                return NDD.LabelMode.ZDD;
            if (this == HEADER_BDD_LINK_BCDD || this == ALL_BCDD)
                return NDD.LabelMode.COMPLEMENTED_BDD;
            return NDD.LabelMode.BDD;
        }
    }

    public enum NDDDomainOrder {
        HEADER_LINK,
        LINK_HEADER
    }

    public static NDDBackendProfile NDD_BACKEND_PROFILE = NDDBackendProfile.ALL_BDD;
    public static NDDDomainOrder NDD_DOMAIN_ORDER = NDDDomainOrder.HEADER_LINK;

    public static void configureNDD(String[] args) {
        for (String arg : args) {
            String normalized = arg.toLowerCase(Locale.ROOT);
            if (normalized.equals("backend=all-bdd") || normalized.equals("backend=a")) {
                NDD_BACKEND_PROFILE = NDDBackendProfile.ALL_BDD;
            } else if (normalized.equals("backend=mixed") || normalized.equals("backend=b")) {
                NDD_BACKEND_PROFILE = NDDBackendProfile.HEADER_BDD_LINK_ZDD;
            } else if (normalized.equals("backend=d")) {
                NDD_BACKEND_PROFILE = NDDBackendProfile.HEADER_BCDD_LINK_ZDD;
            } else if (normalized.equals("backend=e")) {
                NDD_BACKEND_PROFILE = NDDBackendProfile.HEADER_BDD_LINK_BCDD;
            } else if (normalized.equals("backend=f")) {
                NDD_BACKEND_PROFILE = NDDBackendProfile.ALL_BCDD;
            } else if (normalized.equals("order=header-link")) {
                NDD_DOMAIN_ORDER = NDDDomainOrder.HEADER_LINK;
            } else if (normalized.equals("order=link-header")) {
                NDD_DOMAIN_ORDER = NDDDomainOrder.LINK_HEADER;
            } else if (normalized.startsWith("plan=")) {
                testPlan = Integer.parseInt(normalized.substring("plan=".length()));
            }
        }
    }

    /* BDDManager configurations */
    // BDD node table size.
    // If equals -1, optimize it according to network configurations.
    public static int NT_SIZE = -1;
    // Use filter bdd or not
    public static boolean FILTER = false;
    public static long MAX_COMBINATIONS_FOR_FILTER_BDD = CombinationUtil.numItems(1000, 3);

    public static boolean checkCorrectness = false; // check 1 and 2
    public static int testPlan = 0; // 0 time 1 memory 2 node count
    public static boolean testBDDFattree16 = false;
    public static boolean TEST_RANDOM_VARIABLE_ORDER = false;
    public static boolean DECLARE_FIVE_TUPLE_FIRST = false;
    public static boolean RUN_BATCH_TIMES = true;

    public enum LinkVarSortMethod {
        RANDOM,
        CONNECTIVITY,
        CONNECTIVITY_REVERSE,
        PROPAGATION,
        PROPAGATION_REVERSE;

        public static LinkVarSortMethod get(int id) {
            switch (id) {
                case 1:
                    return CONNECTIVITY;
                case 2:
                    return CONNECTIVITY_REVERSE;
                case 3:
                    return PROPAGATION;
                case 4:
                    return PROPAGATION_REVERSE;
                default:
                    return RANDOM;
            }
        }
    }

    /* BDDTCWrapper configurations */
    // Sort links or not
    public static boolean SORT = true;
    // Sorting strategy
    public static LinkVarSortMethod SORT_METHOD = LinkVarSortMethod.CONNECTIVITY_REVERSE;

    public static void SetRamdomLinkVar() {
        SORT_METHOD = LinkVarSortMethod.RANDOM;
    }

    /* SRC configurations */
    // Announce prefixes at once or one by one in SRC stage
    public static boolean ALL_IN_ONE = true;
    // Maximum route computation rounds for BGP and OSPF
    public static int MAX_SRC_ROUNDS = 100;
    // Route computation timeout in seconds
    public static int SRC_TIMEOUT_SECONDS = 3600;

    /* SPF configurations */
    // Build reachability trees forwards or backwards
    public static boolean FORWARD = true;
    public static boolean LAZY = false;

    // Total execution timeout in seconds
    public static int TIMEOUT_SECONDS = 3600;

    public static String HOST_VRF_CONNECTOR = "-";
    public static String ROUTER_INTF_CONNECTOR = "#";
}
