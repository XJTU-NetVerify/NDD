package main;

import bdd.BDDManager;
import bdd.BDDTuple;
import bdd.NDDManager;
import bdd.NDDTuple;
import controlplane.network.CPExecutor;
import controlplane.network.NDDCPExecutor;
import controlplane.network.NDDRouter;
import controlplane.network.Router;
import dataplane.analysis.DPAnalyzer;
import dataplane.analysis.NDDDPAnalyzer;
import main.storage.Storage;

import java.util.*;

public class NDDController {
    /* initialization */
    public static String ID = "";

    public static LinkedList<Storage> storageStack = new LinkedList<>();
    public static Storage storage;
    public static LinkedList<NDDManager> bddManagerStack = new LinkedList<>();
    public static NDDManager bddManager;
    public static LinkedList<NDDCPExecutor> cpExecutorStack = new LinkedList<>();
    public static NDDCPExecutor cpExecutor;
    public static LinkedList<NDDDPAnalyzer> dpAnalyzerStack = new LinkedList<>();
    public static NDDDPAnalyzer dpAnalyzer;
    public static LinkedList<Integer> mfStack = new LinkedList<>();
    public static int MF = -1;

    public static void pushStorage(Storage storage) {
        storageStack.push(storage);
        NDDController.storage = storage;
        storage.init();
    }

    public static void pushBDDManager(NDDManager bddManager) {
        bddManagerStack.push(bddManager);
        NDDController.bddManager = bddManager;
    }

    public static void pushCPExecutor(NDDCPExecutor cpExecutor) {
        cpExecutorStack.push(cpExecutor);
        NDDController.cpExecutor = cpExecutor;
    }

    public static void pushDPAnalyzer(NDDDPAnalyzer dpAnalyzer) {
        dpAnalyzerStack.push(dpAnalyzer);
        NDDController.dpAnalyzer = dpAnalyzer;
    }

    public static void pushMF(int mf) {
        mfStack.push(mf);
        MF = mf;
    }

    public static void popStorage() {
        if (!storageStack.isEmpty()) {
            storageStack.addLast(storageStack.pop());
            storage = storageStack.peekFirst();
            assert storage != null;
            storage.init();
        }
    }

    public static void popBDDManager() {
        if (!bddManagerStack.isEmpty()) {
            bddManagerStack.addLast(bddManagerStack.pop());
            bddManager = bddManagerStack.peekFirst();
        }
    }

    public static void popCPExecutor() {
        if (!cpExecutorStack.isEmpty()) {
            cpExecutorStack.addLast(cpExecutorStack.pop());
            cpExecutor = cpExecutorStack.peekFirst();
        }
    }

    public static void popDPAnalyzer() {
        if (!dpAnalyzerStack.isEmpty()) {
            dpAnalyzerStack.addLast(dpAnalyzerStack.pop());
            dpAnalyzer = dpAnalyzerStack.peekFirst();
        }
    }

    public static void popMF() {
        if (!mfStack.isEmpty()) {
            mfStack.addLast(mfStack.pop());
            MF = mfStack.peekFirst();
        }
    }

    /* workflow */
    public static Set<NDDRouter> ospfValidRouters = new HashSet<>();
    public static Set<NDDRouter> bgpValidRouters = new HashSet<>();

    public static void generateDataPlane() {
        cpExecutor.generateDataPlane();
    }

    public static void analyzeDataPlane(Collection<NDDRouter> routers) {
        dpAnalyzer.analyzeDataPlane(routers);
    }

    public static void analyzeDataPlane(Map<NDDRouter, NDDTuple> routers) {
        dpAnalyzer.analyzeDataPlane(routers);
    }

    public static void mineSpecification(Collection<NDDRouter> routers) {
        dpAnalyzer.mineSpecification(routers);
    }
}
