package main;

import bdd.BDDManager;
import bdd.BDDTuple;
import controlplane.network.CPExecutor;
import controlplane.network.Router;
import dataplane.analysis.DPAnalyzer;
import main.storage.Storage;

import java.util.*;

public class Controller {
    /* initialization */
    // ID = "" means single thread execution
    public static String ID = "";

    public static LinkedList<Storage> storageStack = new LinkedList<>();
    public static Storage storage;
    public static LinkedList<BDDManager> bddManagerStack = new LinkedList<>();
    public static BDDManager bddManager;
    public static LinkedList<CPExecutor> cpExecutorStack = new LinkedList<>();
    public static CPExecutor cpExecutor;
    public static LinkedList<DPAnalyzer> dpAnalyzerStack = new LinkedList<>();
    public static DPAnalyzer dpAnalyzer;
    public static LinkedList<Integer> mfStack = new LinkedList<>();
    public static int MF = -1;

    public static void pushStorage(Storage storage) {
        storageStack.push(storage);
        Controller.storage = storage;
        storage.init();
    }

    public static void pushBDDManager(BDDManager bddManager) {
        bddManagerStack.push(bddManager);
        Controller.bddManager = bddManager;
    }

    public static void pushCPExecutor(CPExecutor cpExecutor) {
        cpExecutorStack.push(cpExecutor);
        Controller.cpExecutor = cpExecutor;
    }

    public static void pushDPAnalyzer(DPAnalyzer dpAnalyzer) {
        dpAnalyzerStack.push(dpAnalyzer);
        Controller.dpAnalyzer = dpAnalyzer;
    }

    public static void pushMF(int mf) {
        mfStack.push(mf);
        MF = mf;
    }

    public static void popStorage() {
        if (!storageStack.isEmpty()) {
            storageStack.addLast(storageStack.pop());
            storage = storageStack.peekFirst();
            assert storage != null;
            storage.init();
        }
    }

    public static void popBDDManager() {
        if (!bddManagerStack.isEmpty()) {
            bddManagerStack.addLast(bddManagerStack.pop());
            bddManager = bddManagerStack.peekFirst();
        }
    }

    public static void popCPExecutor() {
        if (!cpExecutorStack.isEmpty()) {
            cpExecutorStack.addLast(cpExecutorStack.pop());
            cpExecutor = cpExecutorStack.peekFirst();
        }
    }

    public static void popDPAnalyzer() {
        if (!dpAnalyzerStack.isEmpty()) {
            dpAnalyzerStack.addLast(dpAnalyzerStack.pop());
            dpAnalyzer = dpAnalyzerStack.peekFirst();
        }
    }

    public static void popMF() {
        if (!mfStack.isEmpty()) {
            mfStack.addLast(mfStack.pop());
            MF = mfStack.peekFirst();
        }
    }

    /* workflow */
    public static Set<Router> ospfValidRouters = new HashSet<>();
    public static Set<Router> bgpValidRouters = new HashSet<>();

    public static void generateDataPlane() {
        cpExecutor.generateDataPlane();
    }

    public static void analyzeDataPlane(Collection<Router> routers) {
        dpAnalyzer.analyzeDataPlane(routers);
    }

    public static void analyzeDataPlane(Map<Router, BDDTuple> routers) {
        dpAnalyzer.analyzeDataPlane(routers);
    }

    public static void mineSpecification(Collection<Router> routers) {
        dpAnalyzer.mineSpecification(routers);
    }
}
