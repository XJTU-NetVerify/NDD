package inputparser;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import controlplane.network.Port;
import controlplane.network.PortName;
import controlplane.network.Router;
import datamodel.ipv4.IpAddress;

public class PortParser {
    public static void parsePorts(JsonObject root, Router router) {
        JsonArray jsonPorts = root.getAsJsonArray("intfs");
        for (int i = 0; i < jsonPorts.size(); i++) {
            JsonObject jsonPort = jsonPorts.get(i).getAsJsonObject();
            parsePort(jsonPort, router);
        }
    }

    public static void parsePort(JsonObject jsonPort, Router router) {
        String name = jsonPort.get("intf").getAsString();
        PortName portName = new PortName(router.getRouterName(), name);
        IpAddress ipAddress = Ipv4Parser.parseIpAddress(jsonPort.getAsJsonObject("prefix"));
        if (router.getPorts().containsKey(portName)) {
            router.getPorts().get(portName).addSecondaryIpAddress(ipAddress);
        }
        else {
            boolean loopback = name.toLowerCase().startsWith("loopback");
            Port port = new Port(portName, router, ipAddress, loopback);
            router.addPort(port);
            if (loopback) router.setLoopback(port);
        }
    }
}
