package inputparser;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import controlplane.network.*;
import controlplane.process.ospf.*;

import java.util.HashMap;

public class NDDOspfParser {
    NDDOspfTopology topology;

    public NDDOspfParser() {
        topology = new NDDOspfTopology();;
    }

    public HashMap<Integer, NDDOspfProcess> parseOspfProcesses(JsonObject root, NDDRouter router) {
        HashMap<Integer, NDDOspfProcess> ospfProcesses = new HashMap<>();

        JsonArray jsonOspfIntfSettings = root.getAsJsonArray("ospfIntfSetting");
        for (int i = 0; i < jsonOspfIntfSettings.size(); i++) {
            JsonObject setting = jsonOspfIntfSettings.get(i).getAsJsonObject();
            int area = setting.get("area").getAsInt();
            int cost = setting.get("cost").getAsInt();
            PortName portName = new PortName(router.getRouterName(), setting.get("intf").getAsString());
            NDDPort port = router.getPorts().get(portName);
            // TODO check why port can be null ??? We only have active interfaces in cfg
            if (port == null) {
                continue;
            }
            boolean passive = setting.get("passive").getAsBoolean();
            int processId = setting.get("process").getAsInt();
            if (!ospfProcesses.containsKey(processId)) {
                ospfProcesses.put(processId, new NDDOspfProcess(router, processId));
            }
            NDDOspfProcess ospfProcess = ospfProcesses.get(processId);
            port.getIpAddresses().forEach(ipAddress -> ospfProcess.addNetwork(ipAddress.toPrefix()));
            if (!passive) {
                OspfIntfSetting ospfIntfSetting = new OspfIntfSetting(area, cost, passive, processId);
                NDDOspfNeighborConfig config = new NDDOspfNeighborConfig(ospfProcess, ospfIntfSetting, port);
                topology.addNeighborConfig(config);
            }
        }

        JsonArray jsonOspfRedises = root.getAsJsonArray("ospfRedises");
        for (int i = 0; i < jsonOspfRedises.size(); i++) {
            JsonObject redis = jsonOspfRedises.get(i).getAsJsonObject();
            if (redis.get("enable").getAsBoolean()) {
                int processId = redis.get("processId").getAsInt();
                String protocol = redis.get("protocol").getAsString();
                if (ospfProcesses.containsKey(processId)) {
                    ospfProcesses.get(processId).addRedistribution(NDDConfigurationParser.protocolMap.get(protocol));
                }
            }
        }

        return ospfProcesses;
    }
}
