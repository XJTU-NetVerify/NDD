package inputparser;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import controlplane.Owner;
import controlplane.network.Port;
import controlplane.network.PortName;
import controlplane.network.Router;
import controlplane.process.bgp.BgpProcess;
import controlplane.process.bgp.BgpTopology;
import controlplane.process.ospf.OspfProcess;
import controlplane.process.ospf.OspfTopology;
import controlplane.route.RoutingProtocol;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import datamodel.ipv4.Prefix;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.file.Path;
import java.util.*;

public class ConfigurationParser {
    public static HashMap<String, RoutingProtocol> protocolMap;
    static {
        protocolMap = new HashMap<>();
        protocolMap.put("connected", RoutingProtocol.CONNECTED);
        protocolMap.put("static", RoutingProtocol.STATIC);
        protocolMap.put("loopback", RoutingProtocol.LOOPBACK);
        protocolMap.put("ospf", RoutingProtocol.OSPF);
        protocolMap.put("bgp", RoutingProtocol.BGP);
    }

    BgpParser bgpParser;
    OspfParser ospfParser;

    TreeMap<String, Router> routers;
    TreeMap<PortName, Port> ports;
    Owner<Prefix, Router> prefixOwners;
    Owner<Ip, Router> ipOwners;

    public ConfigurationParser() {
        bgpParser = new BgpParser();
        ospfParser = new OspfParser();
        routers = new TreeMap<>();
        ports = new TreeMap<>();
        prefixOwners = new Owner<>();
        ipOwners = new Owner<>();
    }

    public void parse(Path cfgs, Path acls) {
        File cfgDir = cfgs.toFile();
        if (cfgDir.isDirectory()) {
            String[] cfgFiles = cfgDir.list();
            assert cfgFiles != null;
            for (String cfgFile : cfgFiles) {
                Router router = parseFile(cfgs.resolve(cfgFile), acls.resolve(cfgFile));
                routers.put(router.getRouterName(), router);
            }
            routers.values().forEach(router -> {
                ports.putAll(router.getPorts());
                router.getPorts().values().forEach(port -> {
                    if (!port.isBlackhole() && !port.isSink()) {
                        addIpAddressToOwner(port.getPrimaryIpAddress(), router);
                        if (port.getSecondaryIpAddresses() != null) {
                            port.getSecondaryIpAddresses().forEach(ipAddress ->
                                    addIpAddressToOwner(ipAddress, router));
                        }
                    }
                });
                router.getPrefixes().forEach(prefix -> prefixOwners.add(prefix, router));
            });
        }
    }

    public Router parseFile(Path cfg, Path acl) {
        Router router = null;
        JsonParser parser = new JsonParser();
        try {
            JsonObject root = (JsonObject) parser.parse(new FileReader(cfg.toFile()));

            // parse router
            String name = cfg.getFileName().toString().split("\\.")[0];
            router = RouterParser.parseRouter(name, root);

            // parse ports
            PortParser.parsePorts(root, router);

            // parse ospf settings
            HashMap<Integer, OspfProcess> ospfProcesses = ospfParser.parseOspfProcesses(root, router);
            router.setOspfProcesses(ospfProcesses);

            // parse bgp settings
            BgpProcess bgpProcess = bgpParser.parseBgpProcess(root, router);
            router.setBgpProcess(bgpProcess);

            StaticRouteParser.parseStaticRoute(root, router);

            // parse ACLs
            ACLParser.parseACLs(router, acl);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return router;
    }

    public void addIpAddressToOwner(IpAddress ipAddress, Router router) {
        ipOwners.add(ipAddress.getIp(), router);
        prefixOwners.add(ipAddress.toPrefix(), router);
        prefixOwners.add(ipAddress.toPrefix32(), router);
    }

    public TreeMap<String, Router> getRouters() {
        return routers;
    }

    public TreeMap<PortName, Port> getPorts() {
        return ports;
    }

    public Owner<Prefix, Router> getPrefixOwners() {
        return prefixOwners;
    }

    public Owner<Ip, Router> getIpOwners() {
        return ipOwners;
    }

    public BgpTopology getBgpTopology() {
        return bgpParser.topology;
    }

    public OspfTopology getOspfTopology() {
        return ospfParser.topology;
    }
}
