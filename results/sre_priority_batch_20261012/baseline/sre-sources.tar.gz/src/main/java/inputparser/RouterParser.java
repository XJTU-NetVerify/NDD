package inputparser;

import com.google.gson.JsonObject;
import controlplane.network.Router;

public class RouterParser {
    public static Router parseRouter(String name, JsonObject root) {
        JsonObject jsonNode = root.getAsJsonObject("node");
        int as = jsonNode.get("as").getAsInt();
        long id = jsonNode.get("id").getAsLong();
        return new Router(name, as, id);
    }
}
