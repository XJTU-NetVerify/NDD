package inputparser;

import multimap.Sets;
import controlplane.network.L3Edge;
import controlplane.network.PortName;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashSet;

public class TopologyParser {
    public TopologyParser() {}

    public HashSet<L3Edge> parseL3Edges(Path path) {
        HashSet<L3Edge> l3Edges = new HashSet<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(path.toFile()));
            String oneLine;
            while ((oneLine = reader.readLine()) != null) {
                String[] parts = oneLine.split(" ");
                PortName p1 = new PortName(parts[0], parts[1]);
                PortName p2 = new PortName(parts[2], parts[3]);
                l3Edges.add(L3Edge.of(p1, p2));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return l3Edges;
    }

    public HashSet<PortName> parseEdgePorts(Path path) {
        HashSet<PortName> edgePorts = new HashSet<>();
        if (path != null) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader(path.toFile()));
                String oneLine;
                while ((oneLine = reader.readLine()) != null) {
                    String[] parts = oneLine.split(" ");
                    edgePorts.add(new PortName(parts[0], parts[1]));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return edgePorts;
    }
}
