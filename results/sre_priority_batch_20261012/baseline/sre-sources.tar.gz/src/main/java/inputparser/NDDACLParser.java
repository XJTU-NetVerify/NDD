package inputparser;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import controlplane.network.*;
import dataplane.acl.ACLRule;
import dataplane.acl.NDDACLRule;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.Map;

public class NDDACLParser {

    public static void parseACLs(NDDRouter router, Path aclConfig) {
        if (!aclConfig.toFile().exists()) return;
        try {
            JsonParser parser = new JsonParser();
            JsonObject root = (JsonObject) parser.parse(new FileReader(aclConfig.toFile()));
            JsonArray aclsArray = root.getAsJsonArray("acl");

            for (int i = 0; i < aclsArray.size(); i++) {
                JsonObject acls = aclsArray.get(i).getAsJsonObject();
                for (Map.Entry<String, JsonElement> entry : acls.entrySet()) {
                    JsonArray applications = entry.getValue().getAsJsonObject().getAsJsonArray("applications");
                    if (applications.size() > 0) {
                        JsonArray rules = entry.getValue().getAsJsonObject().getAsJsonArray("rules");
                        LinkedList<NDDACLRule> aclRules = new LinkedList<>();
                        for (int j = 0; j < rules.size(); j++) {
                            NDDACLRule rule = parseRule(rules.get(j).getAsString());
                            aclRules.add(rule);
                        }
                        for (int j = 0; j < applications.size(); j++) {
                            String intf = applications.get(j).getAsJsonObject().get("interface").getAsString();
                            String direction = applications.get(j).getAsJsonObject().get("direction").getAsString();
                            NDDPort port = router.getPorts().get(new PortName(router.getRouterName(), intf));
                            if (port != null) {
                                if (direction.equalsIgnoreCase("in")) {
                                    port.setAclIn(aclRules);
                                }
                                if (direction.equalsIgnoreCase("out")) {
                                    port.setAclOut(aclRules);
                                }
                            }
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static String helper(String str) {
        return str.equalsIgnoreCase("null") ? null : str;
    }

    public static NDDACLRule parseRule(String str) {
        NDDACLRule rule = new NDDACLRule();
        String[] tokens = str.split(" ");
        rule.permitDeny = tokens[2];
        rule.protocolLower = helper(tokens[3]);
        rule.protocolUpper = helper(tokens[4]);
        rule.source = tokens[5];
        rule.sourceWildcard = tokens[6];
        rule.sourcePortLower = helper(tokens[7]);
        rule.sourcePortUpper = helper(tokens[8]);
        rule.destination = tokens[9];
        rule.destinationWildcard = tokens[10];
        rule.destinationPortLower = helper(tokens[11]);
        rule.destinationPortUpper = helper(tokens[12]);
        rule.precedence = tokens[13];
        return rule;
    }
}
