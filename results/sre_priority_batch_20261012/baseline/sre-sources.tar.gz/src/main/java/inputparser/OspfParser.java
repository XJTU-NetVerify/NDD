package inputparser;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import controlplane.network.Port;
import controlplane.network.PortName;
import controlplane.network.Router;
import controlplane.process.ospf.OspfIntfSetting;
import controlplane.process.ospf.OspfNeighborConfig;
import controlplane.process.ospf.OspfProcess;
import controlplane.process.ospf.OspfTopology;

import java.util.HashMap;

public class OspfParser {
    OspfTopology topology;

    public OspfParser() {
        topology = new OspfTopology();
    }

    public HashMap<Integer, OspfProcess> parseOspfProcesses(JsonObject root, Router router) {
        HashMap<Integer, OspfProcess> ospfProcesses = new HashMap<>();

        // An interface exists in the ospfIntfSetting list iff it's covered by the ospf network command.
        JsonArray jsonOspfIntfSettings = root.getAsJsonArray("ospfIntfSetting");
        for (int i = 0; i < jsonOspfIntfSettings.size(); i++) {
            JsonObject setting = jsonOspfIntfSettings.get(i).getAsJsonObject();
            int area = setting.get("area").getAsInt();
            int cost = setting.get("cost").getAsInt();
            PortName portName = new PortName(router.getRouterName(), setting.get("intf").getAsString());
            Port port = router.getPorts().get(portName);
            // TODO check why port can be null ??? We only have active interfaces in cfg
            if (port == null) {
                continue;
            }
            boolean passive = setting.get("passive").getAsBoolean();
            int processId = setting.get("process").getAsInt();
            if (!ospfProcesses.containsKey(processId)) {
                ospfProcesses.put(processId, new OspfProcess(router, processId));
            }
            OspfProcess ospfProcess = ospfProcesses.get(processId);
            port.getIpAddresses().forEach(ipAddress -> ospfProcess.addNetwork(ipAddress.toPrefix()));
            if (!passive) {
                // We only add non-passive interfaces into ospf topology
                OspfIntfSetting ospfIntfSetting = new OspfIntfSetting(area, cost, passive, processId);
                OspfNeighborConfig config = new OspfNeighborConfig(ospfProcess, ospfIntfSetting, port);
                topology.addNeighborConfig(config);
            }
        }

        JsonArray jsonOspfRedises = root.getAsJsonArray("ospfRedises");
        for (int i = 0; i < jsonOspfRedises.size(); i++) {
            JsonObject redis = jsonOspfRedises.get(i).getAsJsonObject();
            if (redis.get("enable").getAsBoolean()) {
                int processId = redis.get("processId").getAsInt();
                String protocol = redis.get("protocol").getAsString();
                if (ospfProcesses.containsKey(processId)) {
                    ospfProcesses.get(processId).addRedistribution(ConfigurationParser.protocolMap.get(protocol));
                }
            }
        }

        return ospfProcesses;
    }

}
