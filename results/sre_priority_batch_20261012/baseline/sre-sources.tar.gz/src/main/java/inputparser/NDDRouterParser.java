package inputparser;

import com.google.gson.JsonObject;
import controlplane.network.NDDRouter;
import controlplane.network.Router;

public class NDDRouterParser {
    public static NDDRouter parseRouter(String name, JsonObject root) {
        JsonObject jsonNode = root.getAsJsonObject("node");
        int as = jsonNode.get("as").getAsInt();
        long id = jsonNode.get("id").getAsLong();
        return new NDDRouter(name, as, id);
    }
}
