package inputparser;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import controlplane.Owner;
import controlplane.network.*;
import controlplane.process.bgp.NDDBgpTopology;
import controlplane.process.bgp.BgpProcess;
import controlplane.process.bgp.BgpTopology;
import controlplane.process.bgp.NDDBgpProcess;
import controlplane.process.ospf.NDDOspfProcess;
import controlplane.process.ospf.NDDOspfTopology;
import controlplane.process.ospf.OspfProcess;
import controlplane.process.ospf.OspfTopology;
import controlplane.route.RoutingProtocol;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import datamodel.ipv4.Prefix;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.TreeMap;

public class NDDConfigurationParser {
    public static HashMap<String, RoutingProtocol> protocolMap;
    static {
        protocolMap = new HashMap<>();
        protocolMap.put("connected", RoutingProtocol.CONNECTED);
        protocolMap.put("static", RoutingProtocol.STATIC);
        protocolMap.put("loopback", RoutingProtocol.LOOPBACK);
        protocolMap.put("ospf", RoutingProtocol.OSPF);
        protocolMap.put("bgp", RoutingProtocol.BGP);
    }

    NDDBgpParser bgpParser;
    NDDOspfParser ospfParser;

    TreeMap<String, NDDRouter> routers;
    TreeMap<PortName, NDDPort> ports;
    Owner<Prefix, NDDRouter> prefixOwners;
    Owner<Ip, NDDRouter> ipOwners;

    public NDDConfigurationParser() {
        bgpParser = new NDDBgpParser();
        ospfParser = new NDDOspfParser();
        routers = new TreeMap<>();
        ports = new TreeMap<>();
        prefixOwners = new Owner<>();
        ipOwners = new Owner<>();
    }

    public void parse(Path cfgs, Path acls) {
        File cfgDir = cfgs.toFile();
        if (cfgDir.isDirectory()) {
            String[] cfgFiles = cfgDir.list();
            assert cfgFiles != null;
            for (String cfgFile : cfgFiles) {
                NDDRouter router = parseFile(cfgs.resolve(cfgFile), acls.resolve(cfgFile));
                routers.put(router.getRouterName(), router);
            }
            routers.values().forEach(router -> {
                ports.putAll(router.getPorts());
                router.getPorts().values().forEach(port -> {
                    if (!port.isBlackhole() && !port.isSink()) {
                        addIpAddressToOwner(port.getPrimaryIpAddress(), router);
                        if (port.getSecondaryIpAddresses() != null) {
                            port.getSecondaryIpAddresses().forEach(ipAddress ->
                                    addIpAddressToOwner(ipAddress, router));
                        }
                    }
                });
                router.getPrefixes().forEach(prefix -> prefixOwners.add(prefix, router));
            });
        }
    }

    public NDDRouter parseFile(Path cfg, Path acl) {
        NDDRouter router = null;
        JsonParser parser = new JsonParser();
        try {
            JsonObject root = (JsonObject) parser.parse(new FileReader(cfg.toFile()));

            // parse router
            String name = cfg.getFileName().toString().split("\\.")[0];
            router = NDDRouterParser.parseRouter(name, root);

            // parse ports
            NDDPortParser.parsePorts(root, router);

            // parse ospf settings
            HashMap<Integer, NDDOspfProcess> ospfProcesses = ospfParser.parseOspfProcesses(root, router);
            router.setOspfProcesses(ospfProcesses);

            // parse bgp settings
            NDDBgpProcess bgpProcess = bgpParser.parseBgpProcess(root, router);
            router.setBgpProcess(bgpProcess);

            NDDStaticRouteParser.parseStaticRoute(root, router);

            // parse ACLs
            NDDACLParser.parseACLs(router, acl);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return router;
    }

    public void addIpAddressToOwner(IpAddress ipAddress, NDDRouter router) {
        ipOwners.add(ipAddress.getIp(), router);
        prefixOwners.add(ipAddress.toPrefix(), router);
        prefixOwners.add(ipAddress.toPrefix32(), router);
    }

    public TreeMap<String, NDDRouter> getRouters() {
        return routers;
    }

    public TreeMap<PortName, NDDPort> getPorts() {
        return ports;
    }

    public Owner<Prefix, NDDRouter> getPrefixOwners() {
        return prefixOwners;
    }

    public Owner<Ip, NDDRouter> getIpOwners() {
        return ipOwners;
    }

    public NDDBgpTopology getBgpTopology() {
        return bgpParser.topology;
    }

    public NDDOspfTopology getOspfTopology() {
        return ospfParser.topology;
    }
}
