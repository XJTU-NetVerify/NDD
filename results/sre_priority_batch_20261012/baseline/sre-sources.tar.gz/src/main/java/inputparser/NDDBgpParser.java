package inputparser;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import controlplane.network.NDDRouter;
import controlplane.network.Router;
import controlplane.process.bgp.routeaggregation.NDDRouteAggregation;
import controlplane.process.bgp.BgpNeighborConfig;
import controlplane.process.bgp.NDDBgpNeighborConfig;
import controlplane.process.bgp.NDDBgpProcess;
import controlplane.process.bgp.NDDBgpTopology;
import controlplane.process.bgp.routemap.*;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;

import java.util.HashSet;
import java.util.Vector;

public class NDDBgpParser {
    NDDBgpTopology topology;
    NDDBgpProcess bgpProcess;

    public NDDBgpParser() {
        topology = new NDDBgpTopology();
    }

    public NDDBgpProcess parseBgpProcess(JsonObject root, NDDRouter router) {
        bgpProcess = new NDDBgpProcess(router);

        parseBgpNeighbors(root.getAsJsonArray("eBgpNeighbors"), BgpNeighborConfig.NeighborType.EBGP);
        parseBgpNeighbors(root.getAsJsonArray("iBgpNeighbors"), BgpNeighborConfig.NeighborType.IBGP);
        parseBgpNeighbors(root.getAsJsonArray("bgpRouteReflector"), BgpNeighborConfig.NeighborType.REFLECTOR);
        parseBgpNeighbors(root.getAsJsonArray("bgpReflectClients"), BgpNeighborConfig.NeighborType.CLIENT);
        bgpProcess.setNetworks(parseNetworks(root.getAsJsonArray("bgpNetworks")));
        bgpProcess.setRouteMapIn(parseRouteMap(root.getAsJsonArray("routeMapIns"), true));
        bgpProcess.setRouteMapOut(parseRouteMap(root.getAsJsonArray("routeMapOuts"), false));
        parseBgpRouteAggregation(root.getAsJsonArray("bgpAggregations"));
        parseBgpMultipath(root.getAsJsonObject("bgpMultipath"));

        return bgpProcess;
    }

    public void parseBgpMultipath(JsonObject object) {
        bgpProcess.setMultipath(object.get("num").getAsInt() > 1);
    }

    public void parseBgpRouteAggregation(JsonArray array) {
        Vector<NDDRouteAggregation> ras = new Vector<>();
        if (array != null) {
            for (int i = 0; i < array.size(); i++) {
                Prefix prefix = Ipv4Parser.parsePrefix(array.get(i).getAsJsonObject().getAsJsonObject("prefix"));
                NDDRouteAggregation ra = new NDDRouteAggregation(bgpProcess, prefix, true);
                ras.add(ra);
            }
        }
        bgpProcess.setRouteAggregations(ras);
    }

    public void parseBgpNeighbors(JsonArray array, BgpNeighborConfig.NeighborType type) {
        if (array != null) {
            for (int i = 0; i < array.size(); i++) {
                Ip localIp = Ip.of(array.get(i).getAsJsonObject().get("ip1").getAsString());
                Ip neighborIp = Ip.of(array.get(i).getAsJsonObject().get("ip2").getAsString());
                NDDBgpNeighborConfig n = new NDDBgpNeighborConfig(localIp, neighborIp, bgpProcess, type);
                topology.addNeighborConfig(n);
            }
        }
    }

    public HashSet<Prefix> parseNetworks(JsonArray array) {
        HashSet<Prefix> networks = new HashSet<>();
        if (array != null) {
            for (int i = 0; i < array.size(); i++) {
                JsonObject jsonPrefix = array.get(i).getAsJsonObject().getAsJsonObject("prefix");
                Prefix prefix = Ipv4Parser.parsePrefix(jsonPrefix);
                networks.add(prefix);
            }
        }
        return networks;
    }

    public NDDRouteMap parseRouteMap(JsonArray jsonRouteMap, boolean in) {
        if (jsonRouteMap != null && jsonRouteMap.size() > 0) {
            NDDRouteMap routeMap = new NDDRouteMap();
            for (int i = 0; i < jsonRouteMap.size(); i++) {
                JsonObject jsonRouteMapRule = jsonRouteMap.get(i).getAsJsonObject();
                NDDRouteMapRule rule = parseRouteMapRule(jsonRouteMapRule, in);
                routeMap.addRule(rule);
            }
            return routeMap;
        }
        return null;
    }

    public NDDRouteMapRule parseRouteMapRule(JsonObject jsonRouteMapRule, boolean in) {
        String neighbor;
        if (in) {
            JsonElement from = jsonRouteMapRule.get("from_node");
            if (from.isJsonObject()) neighbor = from.getAsJsonObject().get("node").getAsString();
            else neighbor = from.getAsString();
        }
        else {
            JsonElement to = jsonRouteMapRule.get("to_node");
            if (to.isJsonObject()) neighbor = to.getAsJsonObject().get("node").getAsString();
            else neighbor = to.getAsString();
        }
        JsonArray policy = jsonRouteMapRule.getAsJsonArray("policy");
        Vector<NDDRouteMapPolicy> policies = new Vector<>();
        for (int i = 0; i < policy.size(); i++) {
            policies.add(parseRouteMapPolicy(policy.get(i).getAsJsonObject()));
        }
        return new NDDRouteMapRule(neighbor, policies);
    }

    public NDDRouteMapPolicy parseRouteMapPolicy(JsonObject jsonRouteMapPolicy) {
        Vector<NDDRouteMapMatch> matches = null;
        if (jsonRouteMapPolicy.get("matchConditions").isJsonObject()) {
            JsonObject match = jsonRouteMapPolicy.get("matchConditions").getAsJsonObject();
            matches = parseRouteMapMatch(match);
        }

        Vector<NDDRouteMapAction> actions = null;
        if (jsonRouteMapPolicy.get("setAttributes").isJsonObject()) {
            JsonObject action = jsonRouteMapPolicy.get("setAttributes").getAsJsonObject();
            actions = parseRouteMapAction(action);
        }

        boolean permit = jsonRouteMapPolicy.get("permit").getAsBoolean();
        return new NDDRouteMapPolicy(permit, matches, actions);
    }

    public Vector<NDDRouteMapMatch> parseRouteMapMatch(JsonObject jsonRouteMapMatch) {
        Vector<NDDRouteMapMatch> matches = new Vector<>();
        JsonObject matchPrefixList = jsonRouteMapMatch.getAsJsonObject("MatchPrefixList");
        if (matchPrefixList != null) {
            JsonArray prefixSet = matchPrefixList.getAsJsonArray("prefixSet");
            Vector<Prefix> list = new Vector<>();
            for (int i = 0; i < prefixSet.size(); i++) {
                Prefix prefix = Ipv4Parser.parsePrefix(prefixSet.get(i).getAsJsonObject());
                list.add(prefix);
            }
            matches.add(new NDDRouteMapMatch(RouteMapMatch.MatchType.PrefixList, list));
        }
        return matches;
    }

    public Vector<NDDRouteMapAction> parseRouteMapAction(JsonObject jsonRouteMapAction) {
        Vector<NDDRouteMapAction> actions = new Vector<>();
        JsonObject setCommunity = jsonRouteMapAction.getAsJsonObject("SetCommunity");
        if (setCommunity != null) {
            int additive = setCommunity.get("additive").getAsBoolean() ? 1 : 0;
            int as = setCommunity.getAsJsonObject("community").get("as").getAsInt();
            int tag = setCommunity.getAsJsonObject("community").get("tag").getAsInt();
            actions.add(new NDDRouteMapAction(RouteMapAction.ActionType.Community, new int[]{additive, as, tag}));
        }
        JsonObject setLocalPreference = jsonRouteMapAction.getAsJsonObject("SetLocalPref");
        if (setLocalPreference != null) {
            int lp = setLocalPreference.get("localPref").getAsInt();
            actions.add(new NDDRouteMapAction(RouteMapAction.ActionType.LocalPreference, lp));
        }
        return actions;
    }
}
