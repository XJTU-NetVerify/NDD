package inputparser;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import controlplane.network.Router;
import controlplane.route.builder.StaticRouteBuilder;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;

public class StaticRouteParser {
    // TODO some static routes may appoint next-hop-ip, others may appoint out-port
    public static void parseStaticRoute(JsonObject root, Router router) {
        JsonArray jsonStaticRoutes = root.getAsJsonArray("staticRoutes");
        if (jsonStaticRoutes != null) {
            for (int i = 0; i < jsonStaticRoutes.size(); i++) {
                JsonObject jsonStaticRoute = jsonStaticRoutes.get(i).getAsJsonObject();
                Prefix prefix = Ipv4Parser.parsePrefix(jsonStaticRoute.get("prefix").getAsJsonObject());
                Ip nextHop = Ip.of(jsonStaticRoute.get("nhip").getAsString());
                int ad = 1;
                if (jsonStaticRoute.has("adminCost")) ad = jsonStaticRoute.get("adminCost").getAsInt();
                router.insertStaticRoute(new StaticRouteBuilder()
                                            .setPrefix(prefix)
                                            .setNextHop(nextHop)
                                            .setAD(ad)
                                            .setArriveTC(1)
                                            .setListTC(1)
                                            .build());
            }
        }
    }
}
