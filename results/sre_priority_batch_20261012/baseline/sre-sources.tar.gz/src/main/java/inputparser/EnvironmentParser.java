package inputparser;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import controlplane.network.PortName;
import controlplane.network.L3Edge;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashSet;

public class EnvironmentParser {
    HashSet<String> nodesUp;
    HashSet<String> nodesDown;
    HashSet<L3Edge> linksUp;
    HashSet<L3Edge> linksDown;

    public void parseEnvironment(Path environment) {
        try {
            JsonParser parser = new JsonParser();
            JsonObject root = (JsonObject) parser.parse(new FileReader(environment.toFile()));
            nodesUp = parseNodeEnvironment(root, true);
            nodesDown = parseNodeEnvironment(root, false);
            linksUp = parseLinkEnvironment(root, true);
            linksDown = parseLinkEnvironment(root, false);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public HashSet<String> parseNodeEnvironment(JsonObject root, boolean up) {
        HashSet<String> nodes = new HashSet<>();
        String str = up ? "up" : "down";
        JsonObject object = root.getAsJsonObject("nodes");
        if (object != null) {
            JsonArray array = object.getAsJsonArray(str);
            for (int i = 0; i < array.size(); i++) {
                nodes.add(array.get(i).getAsString());
            }
        }
        return nodes;
    }

    public HashSet<L3Edge> parseLinkEnvironment(JsonObject root, boolean up) {
        HashSet<L3Edge> l3Edges = new HashSet<>();
        String str = up ? "up" : "down";
        JsonObject object = root.getAsJsonObject("links");
        if (object != null) {
            JsonArray array = object.getAsJsonArray(str);
            for (int i = 0; i < array.size(); i++) {
                JsonObject o = array.get(i).getAsJsonObject();
                PortName p1 = new PortName(o.get("node1").getAsString(), o.get("intf1").getAsString());
                PortName p2 = new PortName(o.get("node2").getAsString(), o.get("intf2").getAsString());
                L3Edge l3Edge = L3Edge.of(p1, p2);
                l3Edges.add(l3Edge);
            }
        }
        return l3Edges;
    }

    public HashSet<String> getNodesUp() {
        return nodesUp;
    }

    public HashSet<String> getNodesDown() {
        return nodesDown;
    }

    public HashSet<L3Edge> getLinksUp() {
        return linksUp;
    }

    public HashSet<L3Edge> getLinksDown() {
        return linksDown;
    }
}
