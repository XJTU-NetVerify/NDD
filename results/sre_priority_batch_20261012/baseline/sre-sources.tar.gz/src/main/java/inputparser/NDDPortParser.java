package inputparser;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import controlplane.network.*;
import datamodel.ipv4.IpAddress;

public class NDDPortParser {
    public static void parsePorts(JsonObject root, NDDRouter router) {
        JsonArray jsonPorts = root.getAsJsonArray("intfs");
        for (int i = 0; i < jsonPorts.size(); i++) {
            JsonObject jsonPort = jsonPorts.get(i).getAsJsonObject();
            parsePort(jsonPort, router);
        }
    }

    public static void parsePort(JsonObject jsonPort, NDDRouter router) {
        String name = jsonPort.get("intf").getAsString();
        PortName portName = new PortName(router.getRouterName(), name);
        IpAddress ipAddress = Ipv4Parser.parseIpAddress(jsonPort.getAsJsonObject("prefix"));
        if (router.getPorts().containsKey(portName)) {
            router.getPorts().get(portName).addSecondaryIpAddress(ipAddress);
        }
        else {
            boolean loopback = name.toLowerCase().startsWith("loopback");
            NDDPort port = new NDDPort(portName, router, ipAddress, loopback);
            router.addPort(port);
            if (loopback) router.setLoopback(port);
        }
    }
}
