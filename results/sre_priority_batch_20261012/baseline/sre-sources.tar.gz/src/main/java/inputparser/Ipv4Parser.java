package inputparser;

import com.google.gson.JsonObject;
import datamodel.ipv4.Ip;
import datamodel.ipv4.IpAddress;
import datamodel.ipv4.Mask;
import datamodel.ipv4.Prefix;

public class Ipv4Parser {
    public static Prefix parsePrefix(JsonObject jsonPrefix) {
        String ip = jsonPrefix.get("ip").getAsString();
        String mask = jsonPrefix.get("mask").getAsString();
        return Prefix.of(Ip.of(ip), Mask.of(Ip.of(mask)));
    }

    public static IpAddress parseIpAddress(JsonObject jsonIpAddress) {
        String ip = jsonIpAddress.get("ip").getAsString();
        String mask = jsonIpAddress.get("mask").getAsString();
        return new IpAddress(Ip.of(ip), Mask.of(Ip.of(mask)));
    }
}
