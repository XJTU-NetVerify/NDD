package inputparser;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import datamodel.ipv4.Header;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Mask;
import datamodel.ipv4.Prefix;
import datamodel.property.*;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.file.Path;
import java.util.HashSet;

public class PropertyParser {

    public static Property parseProperty(Path path) {
        try {
            JsonParser parser = new JsonParser();
            JsonObject root = (JsonObject) parser.parse(new FileReader(path.toFile()));
            return parseProperty(root.getAsJsonObject("property"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Property parseProperty(JsonObject o) {
        String type = o.get("type").getAsString();
        switch (type) {
            case "Reachable":
                return parseReachability(o);
            case "Waypoint":
                return parseWaypoint(o);
            case "Egress":
                return parseEgress(o);
            case "PathLength":
                return parsePathLength(o);
            default:
                return null;
        }
    }

    public static Reachability parseReachability(JsonObject object) {
        return new Reachability(parseFlow(object.getAsJsonObject("flow")));
    }

    public static Waypoint parseWaypoint(JsonObject object) {
        return new Waypoint(parseFlow(object.getAsJsonObject("flow")), object.get("waypoint").getAsString());
    }

    public static Egress parseEgress(JsonObject object) {
        return new Egress(parseFlow(object.getAsJsonObject("flow")), object.get("egress").getAsString());
    }

    public static PathLength parsePathLength(JsonObject object) {
        return new PathLength(parseFlow(object.getAsJsonObject("flow")), object.get("length").getAsInt());
    }

    public static HashSet<Flow> parseFlows(JsonArray array) {
        HashSet<Flow> flows = new HashSet<>();
        for (int i = 0; i < array.size(); i++) {
            flows.add(parseFlow(array.get(i).getAsJsonObject()));
        }
        return flows;
    }

    public static Flow parseFlow(JsonObject object) {
        String src = object.get("src").getAsString();
        String[] dst = object.get("dst").getAsString().split("/");
        Prefix prefix = Prefix.of(Ip.of(dst[0]), Mask.of(Integer.parseInt(dst[1])));
        Header header = new Header.HeaderBuilder().setDestination(prefix).build();
        return new Flow(header, src);
    }

}
