package javafx.util;

import java.io.Serializable;
import java.util.Objects;

/** Lightweight stand-in for JavaFX Pair to avoid pulling JavaFX runtime. */
public final class Pair<K, V> implements Serializable {
    private static final long serialVersionUID = 1L;

    private final K key;
    private final V value;

    public Pair(K key, V value) {
        this.key = key;
        this.value = value;
    }

    public K getKey() {
        return key;
    }

    public V getValue() {
        return value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Pair)) return false;
        Pair<?, ?> pair = (Pair<?, ?>) o;
        return Objects.equals(key, pair.key) && Objects.equals(value, pair.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key, value);
    }

    @Override
    public String toString() {
        return "Pair[" + String.valueOf(key) + ", " + String.valueOf(value) + "]";
    }
}
