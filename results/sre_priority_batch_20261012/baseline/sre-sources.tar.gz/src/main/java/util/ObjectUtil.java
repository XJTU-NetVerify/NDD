package util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.util.DefaultIndenter;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.guava.GuavaModule;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import main.SRELogger;

import java.io.*;
import java.nio.file.Path;

public class ObjectUtil {
    public static void writeObject(Object obj, Path path) {
        FileOutputStream fos;
        ObjectOutputStream out;
        try {
            fos = new FileOutputStream(path.toFile());
            out = new ObjectOutputStream(fos);
            out.writeObject(obj);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        SRELogger.logWorkFlow(SRELogger.LEVEL.DEBUG, path + " is written.");
    }

    public static Object loadObject(Path path) {
        FileInputStream fis;
        ObjectInputStream in;
        Object obj = null;
        try {
            fis = new FileInputStream(path.toFile());
            in = new ObjectInputStream(fis);
            obj = in.readObject();
            in.close();
        } catch(IOException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        SRELogger.logWorkFlow(SRELogger.LEVEL.DEBUG, path + " is loaded.");
        return obj;
    }

    public static class JacksonWriter {
        private static final ObjectMapper MAPPER;
        private static final PrettyPrinter PRETTY_PRINTER;
        private static final ObjectWriter PRETTY_WRITER;

        static {
            MAPPER = baseMapper();
            PRETTY_PRINTER = new PrettyPrinter();
            PRETTY_WRITER = MAPPER.enable(SerializationFeature.INDENT_OUTPUT).writer(PRETTY_PRINTER);
        }

        private static ObjectMapper baseMapper() {
            ObjectMapper mapper = new ObjectMapper();
            mapper.disable(MapperFeature.AUTO_DETECT_CREATORS);
            mapper.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
            mapper.enable(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY);
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            mapper.registerModule(new Jdk8Module());
            mapper.setDefaultPropertyInclusion(JsonInclude.Value.construct(JsonInclude.Include.NON_EMPTY, JsonInclude.Include.ALWAYS));
            mapper.registerModule(new GuavaModule());
            return mapper;
        }

        public static String writePrettyString(Object o) throws JsonProcessingException {
            return PRETTY_WRITER.writeValueAsString(o);
        }

        private static class PrettyPrinter extends DefaultPrettyPrinter {
            private static final long serialVersionUID = 6337852760656441221L;

            public DefaultPrettyPrinter createInstance() {
                return this;
            }

            public PrettyPrinter() {
                this._arrayIndenter = DefaultIndenter.SYSTEM_LINEFEED_INSTANCE;
            }
        }
    }
}
