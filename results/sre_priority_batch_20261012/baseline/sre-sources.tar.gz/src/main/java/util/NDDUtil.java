package util;

import sre.ndd.NDD;
import bdd.BDDManager;
import jdd.bdd.BDD;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;

public class NDDUtil {
    public static int andInBatch(Collection<Integer> set) {
        int[] bddNodes = new int[set.size()];
        int i = 0;
        for (int j : set) {
            bddNodes[i++] = j;
        }
        return andInBatch(bddNodes);
    }

    /**
     * @param bddNodes an array of bdd nodes
     * @return the bdd node which is the AND of all input nodes all temporary
     *         nodes are de-referenced. the input nodes are not de-referenced.
     */
    public static int andInBatch(int[] bddNodes) {
        int tempNode = NDD.getTrue();
        for (int i = 0; i < bddNodes.length; i++) {
            if (i == 0) {
                tempNode = bddNodes[i];
                NDD.ref(tempNode);
            } else {
                if (NDD.isTrue(bddNodes[i])) {
                    // short cut, TRUE does not affect anything
                    continue;
                }
                if (NDD.isFalse(bddNodes[i])) {
                    // short cut, once FALSE, the result is false
                    // the current tempNode is useless now
                    NDD.deref(tempNode);
                    tempNode = NDD.getFalse();
                    break;
                }
                int tempNode2 = NDD.and(tempNode, bddNodes[i]);
                NDD.ref(tempNode2);
                // do not need current tempNode
                NDD.deref(tempNode);
                // refresh
                tempNode = tempNode2;
            }
        }
        return tempNode;
    }

    public static int orInBatch(Collection<Integer> set) {
        int[] bddNodes = new int[set.size()];
        int i = 0;
        for (int j : set) {
            bddNodes[i++] = j;
        }
        return orInBatch(bddNodes);
    }

    /**
     * @param bddNodes an array of bdd nodes
     * @return the bdd node which is the OR of all input nodes all temporary
     *         nodes are de-referenced. the input nodes are not de-referenced.
     */
    public static int orInBatch(int[] bddNodes) {
        int tempNode = NDD.getFalse();
        for (int i = 0; i < bddNodes.length; i++) {
            if (i == 0) {
                tempNode = bddNodes[i];
                NDD.ref(tempNode);
            } else {
                if (NDD.isFalse(bddNodes[i])) {
                    // short cut, FALSE does not affect anything
                    continue;
                }
                if (NDD.isTrue(bddNodes[i])) {
                    // short cut, once TRUE, the result is true
                    // the current tempNode is useless now
                    NDD.deref(tempNode);
                    tempNode = NDD.getTrue();
                    break;
                }
                int tempNode2 = NDD.or(tempNode, bddNodes[i]);
                NDD.ref(tempNode2);
                // do not need current tempNode
                NDD.deref(tempNode);
                // refresh
                tempNode = tempNode2;
            }
        }
        return tempNode;
    }

    public static void derefInBatch(Collection<Integer> hs) {
        for (int var : hs) {
            NDD.deref(var);
        }
    }

    /**
     * @param vars a list of bdd nodes that we do not need anymore
     */
    public static void derefInBatch(int[] vars) {
        for (int var : vars) {
            NDD.deref(var);
        }
    }

    // public static int encodeBitVector2BDDVarsUnsorted(BDD bdd, byte[] bitVector,
    // int[] vars) {
    // int ret = BDDManager.BDDTrue;
    // for (int i = 0; i < bitVector.length; i++) {
    // if (bitVector[i] == 1) {
    // int tmp = bdd.ref(bdd.and(ret, vars[i]));
    // bdd.deref(ret);
    // ret = tmp;
    // }
    // else if (bitVector[i] == 0) {
    // int tmp = bdd.ref(bdd.and(ret, bdd.not(vars[i])));
    // bdd.deref(ret);
    // ret = tmp;
    // }
    // }
    // return ret;
    // }
    //
    // /* This method use less time and memory comparing to the unsorted method */
    // public static int encodeBitVector2BDDVarsSorted(BDD bdd, byte[] bitVector,
    // int[] vars) {
    // return bdd.ref(encodeBitVector2BDDVarsSorted(bdd, bitVector, vars, 0));
    // }
    //
    // public static int encodeBitVector2BDDVarsSorted(BDD bdd, byte[] bitVector,
    // int[] vars, int idx) {
    // if (idx >= vars.length) {
    // return 1;
    // }
    // int l = 0, h = 0, v = bdd.getVar(vars[idx]);
    // if (bitVector[idx] == 0) {
    // l = encodeBitVector2BDDVarsSorted(bdd, bitVector, vars, idx + 1);
    // }
    // if (bitVector[idx] == 1) {
    // h = encodeBitVector2BDDVarsSorted(bdd, bitVector, vars, idx + 1);
    // }
    // return bdd.mk(v, l, h);
    // }

    // public static int encodeAtMostKFailureVarsUnsorted(BDD bdd, int[] vars, int
    // k) {
    // byte[] state = new byte[vars.length];
    // Arrays.fill(state, (byte) 1);
    // HashSet<Integer> hs = new HashSet<>();
    // encodeAtMostKFailureVarsUnsorted(bdd, vars, state, 0, 0, k, hs);
    // int ret = orInBatch(bdd, hs);
    // derefInBatch(bdd, hs);
    // return ret;
    // }
    //
    // private static void encodeAtMostKFailureVarsUnsorted(BDD bdd, int[] vars,
    // byte[] state, int idx, int cnt, int k, HashSet<Integer> hs) {
    // if (cnt > k) {
    // return;
    // }
    // if (idx == vars.length) {
    // hs.add(encodeBitVector2BDDVarsUnsorted(bdd, state, vars));
    // return;
    // }
    // state[idx] = 0;
    // encodeAtMostKFailureVarsUnsorted(bdd, vars, state, idx + 1, cnt + 1, k, hs);
    // state[idx] = 1;
    // encodeAtMostKFailureVarsUnsorted(bdd, vars, state, idx + 1, cnt, k, hs);
    // }

    // /* This method use less time and memory comparing to the unsorted method */
    // public static int encodeAtMostKFailureVarsSorted(BDD bdd, int[] vars, int k)
    // {
    // return bdd.ref(encodeAtMostKFailureVarsSorted(bdd, vars, 0, k));
    // }
    //
    // private static int encodeAtMostKFailureVarsSorted(BDD bdd, int[] vars, int
    // idx, int k) {
    // // terminal cases
    // if (k < 0) {
    // return 0;
    // }
    // if (idx >= vars.length) {
    // return 1;
    // }
    // int low = encodeAtMostKFailureVarsSorted(bdd, vars, idx + 1, k - 1);
    // int high = encodeAtMostKFailureVarsSorted(bdd, vars, idx + 1, k);
    // return bdd.mk(bdd.getVar(vars[idx]), low, high);
    // }

    public static int encodeKFailureVarsSorted(BDD bdd, int[] vars, int k) {
        return bdd.ref(encodeKFailureVarsSorted(bdd, vars, 0, k));
    }

    private static int encodeKFailureVarsSorted(BDD bdd, int[] vars, int idx, int k) {
        if (idx >= vars.length) {
            return k == 0 ? 1 : 0;
        }
        int low = 0, high = encodeKFailureVarsSorted(bdd, vars, idx + 1, k);
        if (k > 0) {
            low = encodeKFailureVarsSorted(bdd, vars, idx + 1, k - 1);
        }
        return bdd.mk(bdd.getVar(vars[idx]), low, high);
    }

    // public static int branchCount(BDD bdd, int predicate) {
    // if (predicate <= 1) return predicate;
    // else return branchCount(bdd, bdd.getLow(predicate)) + branchCount(bdd,
    // bdd.getHigh(predicate));
    // }
    //
    // public static Collection<byte[]> allSat(BDD bdd, int predicate) {
    // byte[] bin = new byte[bdd.numberOfVariables()];
    // Arrays.fill(bin, (byte) -1);
    // Collection<byte[]> collection = new HashSet<>();
    // allSat_rec(bdd, predicate, bin, collection);
    // return collection;
    // }
    //
    // public static void allSat_rec(BDD bdd, int predicate, byte[] bin,
    // Collection<byte[]> collection) {
    // if (predicate == 0) {
    // }
    // else if (predicate == 1) {
    // collection.add(bin.clone());
    // }
    // else {
    // int var = bdd.getVar(predicate);
    // bin[var] = 0;
    // allSat_rec(bdd, bdd.getLow(predicate), bin, collection);
    // bin[var] = 1;
    // allSat_rec(bdd, bdd.getHigh(predicate), bin, collection);
    // bin[var] = -1;
    // }
    // }
}
