package util;

import main.Configuration;

public class NameUtil {
    public static String[] splitHostVrf(String str) {
        String[] hostVrf = {str, "default"};
        if (str.contains("-")) {
            int idx = str.lastIndexOf(Configuration.HOST_VRF_CONNECTOR);
            hostVrf[0] = str.substring(0, idx);
            hostVrf[1] = str.substring(idx + 1);
        }
        return hostVrf;
    }
}
