package util;

import controlplane.network.Router;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import main.Controller;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.stream.Collectors;

public class AnalyzeUtil {
    public static void analyzeFIB() {
        HashMap<Integer, Double> map = new HashMap<>();
        int total = 0;
        for (Router r : Controller.cpExecutor.getRouters().values()) {
            for (SortedMultiList list : r.getFib().getFib().values()) {
                for (SortedMultiListItem item : list.flat()) {
                    int n = BDDUtil.branchCount(Controller.bddManager.getBDD(), item.getListTC());
                    double m = map.getOrDefault(n, 0.0) + 1;
                    map.put(n, m);
                    total++;
                }
            }
        }

        for (Map.Entry<Integer, Double> entry : map.entrySet()) {
            entry.setValue(entry.getValue() / total);
        }

        Vector<Map.Entry<Integer, Double>> vec = map
                .entrySet()
                .stream()
                .sorted(Map.Entry.comparingByKey())
                .collect(Collectors.toCollection(Vector::new));

        try {
            Path file = Controller.storage.output._outputBase.resolve("fib" + Controller.MF + ".txt");
            BufferedWriter bw = new BufferedWriter(new FileWriter(file.toFile()));
            double pre = 0.0;
            for (Map.Entry<Integer, Double> entry : vec) {
                bw.write(entry.getKey() + "\t" + (pre + entry.getValue()) + "\n");
                pre += entry.getValue();
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
