package util;

import multimap.Table;
import controlplane.network.CPExecutor;
import controlplane.network.NDDRouter;
import controlplane.network.Router;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import datamodel.list.SortedMultiList;
import datamodel.list.SortedMultiListItem;
import datamodel.property.NDDProperty;
import datamodel.property.Property;
import datamodel.property.Reachability;
import dataplane.fib.ForwardingRule;
import dataplane.fib.NDDForwardingRule;
import main.Controller;
import main.NDDController;
import main.SRELogger;
import main.storage.Storage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class MemorizeUtil {

    public static void creatDirIfAbsent(File dir) {
        if (!dir.exists()) {
            if (!dir.mkdirs()) {
                SRELogger.log(SRELogger.LEVEL.ERROR, "Cannot create dir " + dir);
                System.exit(1);
            }
        }
    }

    public static void creatFileIfAbsent(File file) throws IOException {
        if (!file.exists()) {
            creatDirIfAbsent(file.getParentFile());
            if (!file.createNewFile()) {
                SRELogger.log(SRELogger.LEVEL.ERROR, "Cannot create file " + file);
                System.exit(1);
            }
        }
    }

    public static void printRIB() {
        Path dir = Controller.storage.output._rib.resolve(Controller.MF + "");
        creatDirIfAbsent(dir.toFile());
        Controller.cpExecutor.getRouters().values().forEach(r -> {
            try {
                Path file = dir.resolve(r.getRouterName() + "_rib" + Controller.ID + ".txt");
                BufferedWriter writer = new BufferedWriter(new FileWriter(file.toFile()));
                writer.write(r.getGlobalRib().toString());
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public static void printNDDRIB() {
        Path dir = NDDController.storage.output._rib.resolve(NDDController.MF + "");
        creatDirIfAbsent(dir.toFile());
        NDDController.cpExecutor.getRouters().values().forEach(r -> {
            try {
                Path file = dir.resolve(r.getRouterName() + "_rib" + NDDController.ID + ".txt");
                BufferedWriter writer = new BufferedWriter(new FileWriter(file.toFile()));
                writer.write(r.getGlobalRib().toString());
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public static void printBGPRIB() {
        Path dir = Controller.storage.output._rib.resolve("bgp").resolve(Controller.MF + "");
        creatDirIfAbsent(dir.toFile());
        Controller.cpExecutor.getRouters().values().forEach(r -> {
            try {
                Path file = dir.resolve(r.getRouterName() + Controller.ID + ".txt");
                BufferedWriter writer = new BufferedWriter(new FileWriter(file.toFile()));
                writer.write(r.getBgpProcess().getRib().toString());
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public static void printFIB() {
        Path dir = Controller.storage.output._fib.resolve(Controller.MF + "");
        creatDirIfAbsent(dir.toFile());
        Controller.cpExecutor.getRouters().values().forEach(r -> {
            try {
                Path file = dir.resolve(r.getRouterName() + "_fib" + Controller.ID + ".txt");
                BufferedWriter writer = new BufferedWriter(new FileWriter(file.toFile()));
                writer.write(r.getFib().toString());
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public static void printFIB(boolean separate) {
        if (separate) printFIB();
        else {
            try {
                String fib = "fib" + Controller.MF + (Controller.ID.equals("") ? "" : "_" + Controller.ID) + ".csv";
                Path file = Controller.storage.output._fib.resolve(fib);
                creatDirIfAbsent(file.getParent().toFile());
                BufferedWriter bw = new BufferedWriter(new FileWriter(file.toFile()));
//                bw.write(String.join(",", ForwardingRule.CSV_HEADER) + "\n");
                for (Router r : Controller.cpExecutor.getRouters().values()) {
                    for (SortedMultiList list : r.getFib().getFib().values()) {
                        for (SortedMultiListItem item : list.flat()) {
                            bw.write(String.join(",", ((ForwardingRule) item).toCsvString()) +"\n");
                        }
                    }
                }
                bw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void printNDDFIB(boolean separate) {
        if (separate) printFIB();
        else {
            try {
                String fib = "fib" + NDDController.MF + (NDDController.ID.equals("") ? "" : "_" + NDDController.ID) + ".csv";
                Path file = NDDController.storage.output._fib.resolve(fib);
                creatDirIfAbsent(file.getParent().toFile());
                BufferedWriter bw = new BufferedWriter(new FileWriter(file.toFile()));
//                bw.write(String.join(",", ForwardingRule.CSV_HEADER) + "\n");
                for (NDDRouter r : NDDController.cpExecutor.getRouters().values()) {
                    for (NDDSortedMultiList list : r.getFib().getFib().values()) {
                        for (NDDSortedMultiListItem item : list.flat()) {
                            bw.write(String.join(",", ((NDDForwardingRule) item).toCsvString()) +"\n");
                        }
                    }
                }
                bw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void printReachabilityForestStats() {
        try {
            String stats = "reachability_forest" + Controller.MF + (Controller.ID.equals("") ? "" : "_" + Controller.ID) + ".csv";
            Path file = Controller.storage.output._outputBase.resolve(stats);
            creatDirIfAbsent(file.getParent().toFile());
            BufferedWriter bw = new BufferedWriter(new FileWriter(file.toFile()));
            bw.write("src,dst,num of paths\n");
            for (Table.Cell<Router, Router, Integer> cell : Controller.dpAnalyzer._reachabilityDB.pfecNums.cellSet()) {
                bw.write(Objects.requireNonNull(cell.getRowKey()).getRouterName()
                        + "," + Objects.requireNonNull(cell.getColumnKey()).getRouterName()
                        + "," + Objects.requireNonNull(cell.getValue())
                        + "\n");
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void printFwdPathNums() {
        try {
            String stats = "fwd_paths" + Controller.MF + (Controller.ID.equals("") ? "" : "_" + Controller.ID) + ".csv";
            Path file = Controller.storage.output._outputBase.resolve(stats);
            creatDirIfAbsent(file.getParent().toFile());
            BufferedWriter bw = new BufferedWriter(new FileWriter(file.toFile()));
            bw.write("src,num of paths\n");
            for (Map.Entry<Router, Integer> entry : Controller.dpAnalyzer._reachabilityDB.fwdPathNums.entrySet()) {
                bw.write(entry.getKey().getRouterName() + "," + entry.getValue() + "\n");
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void printSpecifications(Set<Property> specifications, Property.Type type) {
        if (specifications == null) return;
        int mf = Controller.MF;
        Path dir = Controller.storage.output._spec.resolve(mf + "");
        if (!dir.toFile().exists()) creatDirIfAbsent(dir.toFile());
        try {
            String spec = type.toString() + mf + (Controller.ID.equals("") ? "" : "_" + Controller.ID) + ".csv";
            Path file = dir.resolve(spec);
            BufferedWriter bw = new BufferedWriter(new FileWriter(file.toFile()));
            bw.write(String.join(",", Property.CSV_HEADER) + "\n");
            for (Property specification : specifications) {
                if (specification.getMF() == mf) bw.write(String.join(",", specification.toCsvString()) + "\n");
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void printNDDSpecifications(Set<NDDProperty> specifications, Property.Type type) {
        printNDDSpecifications(specifications, type, false);
    }

    public static void printNDDSpecifications(Set<NDDProperty> specifications, Property.Type type, boolean all) {
        if (specifications == null) return;
        int mf = NDDController.MF;
        Path dir = NDDController.storage.output._spec.resolve(mf + "");
        if (!dir.toFile().exists()) creatDirIfAbsent(dir.toFile());
        try {
            String spec = type.toString() + mf + (NDDController.ID.equals("") ? "" : "_" + NDDController.ID) + ".csv";
            Path file = dir.resolve(spec);
            BufferedWriter bw = new BufferedWriter(new FileWriter(file.toFile()));
            bw.write(String.join(",", NDDProperty.CSV_HEADER) + "\n");
            for (NDDProperty specification : specifications) {
                if (all || specification.getMF() == mf) bw.write(String.join(",", specification.toCsvString()) + "\n");
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void printPrefixOwner() {
        try {
            Path file = Controller.storage.output._outputBase.resolve("prefix.csv");
            List<Prefix> prefixes = Controller.cpExecutor.getPrefixOwners().keys()
                    .stream()
                    .sorted(Prefix::compareTo)
                    .collect(Collectors.toList());

            BufferedWriter bw = new BufferedWriter(new FileWriter(file.toFile()));
            bw.write(String.join(",", new String[] {"ip", "length", "prefix", "owner"}) + "\n");
            for (Prefix prefix : prefixes) {
                Collection<Router> routers = Controller.cpExecutor.getPrefixOwners().get(prefix);
                for (Router router : routers) {
                    bw.write(String.join(",", new String[] {prefix.getIp().toString(), prefix.getPreLength() + "", prefix.toString(), router.getRouterName()}) + "\n");
                }
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void printIpOwner() {
        try {
            Path file = Controller.storage.output._outputBase.resolve("ip.csv");
            BufferedWriter bw = new BufferedWriter(new FileWriter(file.toFile()));
            bw.write(String.join(",", new String[] {"ip", "owner"}) + "\n");
            for (Ip ip : Controller.cpExecutor.getIpOwners().keys()) {
                if (ip != null) {
                    Collection<Router> routers = Controller.cpExecutor.getIpOwners().get(ip);
                    for (Router router : routers) {
                        bw.write(String.join(",", new String[] {ip.toString(), router.getRouterName()}) + "\n");
                    }
                }
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Path inputBase = Paths.get("networks/differential/campus/010316");
        Controller.pushStorage(new Storage(inputBase, null));
        Controller.pushCPExecutor(new CPExecutor());
        Controller.cpExecutor.init();
        printPrefixOwner();
        printIpOwner();
    }
}
