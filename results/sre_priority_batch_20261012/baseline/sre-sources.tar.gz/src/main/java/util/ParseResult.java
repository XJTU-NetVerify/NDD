package util;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

class ParseResult {
    private static String logFilePath = "/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/Results/BDD/bgp_fattree16_1";

    private static void parse() throws IOException {
        String outputPath = logFilePath + "_time";
        FileWriter fileWriter = new FileWriter(outputPath);
        PrintWriter printWriter = new PrintWriter(fileWriter);

        FileInputStream fis = new FileInputStream(logFilePath);
        BufferedReader br = new BufferedReader(new InputStreamReader(fis));
        String line = null;
        int lineCount = 0;
        while ((line = br.readLine()) != null) {
            lineCount++;
            if (lineCount > 12) {
                if (line.contains("total")) {
                    printWriter.println(line.split(":")[1]);
                }
            }
        }
        printWriter.flush();
        br.close();
    }

    public static void main(String[] args) {
        try {
            parse();
        } catch(Exception e) {

        }
    }
}