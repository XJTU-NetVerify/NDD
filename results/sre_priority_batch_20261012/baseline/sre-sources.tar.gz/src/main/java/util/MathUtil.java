/*
 * Atomic Predicates Verifier
 * 
 * Copyright (c) 2013 UNIVERSITY OF TEXAS AUSTIN. All rights reserved. Developed
 * by: HONGKUN YANG and SIMON S. LAM http://www.cs.utexas.edu/users/lam/NRL/
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimers.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimers in the documentation
 * and/or other materials provided with the distribution.
 * 
 * 3. Neither the name of the UNIVERSITY OF TEXAS AUSTIN nor the names of the
 * developers may be used to endorse or promote products derived from this
 * Software without specific prior written permission.
 * 
 * 4. Any report or paper describing results derived from using any part of this
 * Software must cite the following publication of the developers: Hongkun Yang
 * and Simon S. Lam, Real-time Verification of Network Properties using Atomic
 * Predicates, IEEE/ACM Transactions on Networking, April 2016, Volume 24, No.
 * 2, pages 887-900 (first published March 2015, Digital Object Identifier:
 * 10.1109/TNET.2015.2398197).
 * 
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS WITH
 * THE SOFTWARE.
 */

package util;

import bdd.BDDACLWrapper;
import dataplane.acl.Range;

import java.util.ArrayList;
import java.util.LinkedList;

public class MathUtil {

	/*
	 * only used to compute no more than 2^16
	 */
	public static long Power2(int exponent)
	{
		if(exponent <=16)
		{
			switch(exponent){
			case 0: return 1;
			case 1: return 2;
			case 2: return 4;
			case 3: return 8;
			case 4: return 16;
			case 5: return 32;
			case 6: return 64;
			case 7: return 128;
			case 8: return 256;
			case 9: return 512;
			case 10: return 1024;
			case 11: return 2048;
			case 12: return 4096;
			case 13: return 8192;
			case 14: return 16384;
			case 15: return 32768;
			case 16: return 65536;
			default: System.err.println("exponent is too large!");
			break;
			}
		}
		else
		{
			long power = 1;
			for(int i = 0; i < exponent; i ++)
			{
				power = power * 2;
			}
			return power;
		}
		// should not be here
		return 0;
	}

	/*
	 * ex1 < ex2
	 * return 2^ex1 + 2^(ex1+1) + ... + 2^ex2
	 */
	public static long SumPower2(int ex1, int ex2)
	{
		long sum = 0;
		for(int i = ex1; i <= ex2; i ++)
		{
			sum = sum + Power2(i);
		}
		return sum;
	}

	/*
	 * usually bits = 8, or 16
	 */
	public static ArrayList<int[]> DecomposeInterval(Range r, int bits)
	{
		long l = r.getLower();
		long u = r.getUpper();
		ArrayList<int[]> prefix = new ArrayList<>();
		
		while (l <= u)
		{
			l = OnePrefix(l, u, bits, prefix);
		}

		return prefix;
	}

	/**
	 * the input num is at most bits long
	 * find the number of tailing zeros in the binary representation of num
	 * for example, num = 6 = (110)_2, bits = 3, return 1 
	 */
	public static int tailingZeros(long num, int bits)
	{
		if(num == 0) return bits;
		int tmptailing = 0;
		for(int i = 0; i <bits; i ++)
		{
			long tester = Power2(i) - 1;
			long tn = num & tester;
			if(tn == 0)
			{
				tmptailing = i;
			}else
			{
				break;
			}

		}
		return tmptailing;
	}
	
	/**
	 * 
	 * @param IP a string of ip address
	 * @return an array of the binary expression of the ip address. 0th element is the minimal bit
	 * octetbin length is 8
	 */
	public static int[] IPBinRep(String IP)
	{
		String[] octets = IP.split("\\.");
//		System.out.println(octets.length);
		if(octets.length != BDDACLWrapper.getIpBits()/8)
		{
			System.err.println("Not a valid IP address: " + IP);
			return null;
		}
		
		int[] octetsNum = new int[octets.length];
		for(int i = 0; i < octets.length; i ++)
		{
			octetsNum[i] = Integer.parseInt(octets[i]);
		}
		
		int [] ipBin = new int[BDDACLWrapper.getIpBits()];
		
		for(int i = 0; i < octets.length; i ++)
		{
			int [] octetBin = CalBinRep(octetsNum[octets.length - i - 1], 8);
			for(int j = 0; j < octetBin.length; j ++)
			{
				ipBin[j + i * octetBin.length] = octetBin[j];
			}
		}
		return ipBin;
	}

	/**
	 * return the binary representation of num
	 * e.g. num = 10, bits = 4, return an array of {0,1,0,1}
	 */
	public static int[] CalBinRep(long num, int bits)
	{
		if(bits == 0) return new int[0];

		int[] binrep = new int[bits];
		long numtemp = num;
		for(int i = bits; i > 0; i--)
		{
			long abit = numtemp & Power2(i - 1);
			if(abit == 0)
			{
				binrep[i - 1] = 0;
			}else
			{
				binrep[i - 1] = 1;
			}
			numtemp = numtemp - abit;
		}
		return binrep;
	}
	
	/**
	 * 
	 * @param ar an array
	 * @return number of nonzero element in the array
	 */
	public static int NumofNonZeros(int [] ar)
	{
		int sum = 0;
		for(int i = 0; i < ar.length; i ++)
		{
			if(ar[i] != 0)
			{
				sum ++;
			}
		}
		return sum;
	}

	/**
	 * creat one prefix from [l, u]
	 */
	public static long OnePrefix(long l, long u, int bits, ArrayList<int []> prefixs)
	{
		int zeros = tailingZeros(l, bits);
		if(zeros == 0)
		{
			prefixs.add(CalBinRep(l, bits));
			return l + 1;
		}else
		{
			while(l + Power2(zeros) > u + 1)
			{
				zeros --;
			}
			prefixs.add(CalBinRep(l/Power2(zeros), bits - zeros));
			return l + Power2(zeros);
		}
	}
	
	public static int[] ArrayListToArray(ArrayList<Integer> intAryList)
	{
		int[] intAry = new int[intAryList.size()];
		for(int i = 0; i < intAryList.size(); i ++)
		{
			intAry[i] = intAryList.get(i);
		}
		return intAry;
	}

}
