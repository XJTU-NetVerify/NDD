package util;

import main.SRELogger;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeUtil {
    /* Timer part */
    private double total = 0;
    private int n = 0;
    private long start;

    public void begin() {
        start = System.nanoTime();
    }

    public double end() {
        double runtime = (System.nanoTime() - start) / 1e9;
        total += runtime;
        n++;
        return runtime;
    }

    public double end(SRELogger.LEVEL level, String msg) {
        double runtime = (System.nanoTime() - start) / 1e9;
        total += runtime;
        n++;
        if (!msg.equals("")) msg += " ";
        SRELogger.logTimeUse(level, msg + runtime + "s");
        return runtime;
    }

    public void logStatistic(SRELogger.LEVEL level, String msg) {
        if (!msg.equals("")) msg += " ";
        String str = msg + "total: " + total + " number: " + n + " avg: " + total / n;
        SRELogger.logTimeUse(level, str);
    }

    public double getTotal() {
        return total;
    }

    /* Date part */
    public static String getDate() {
        Date date = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return simpleDateFormat.format(date);
    }

    public static String getDate(String format) {
        Date date = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return simpleDateFormat.format(date);
    }
}
