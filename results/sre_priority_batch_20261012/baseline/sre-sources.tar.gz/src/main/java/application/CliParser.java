package application;

import application.config2spec.Config2spec;
import application.netdice.Netdice;
import main.Configuration;
import main.Controller;
import main.storage.Storage;
import org.apache.commons.cli.*;

import java.nio.file.Path;
import java.nio.file.Paths;

public class CliParser {

    Options options;
    CommandLine cli;
    Path inputBase = null;
    Path outputBase = null;

    public CliParser() {
        options = new Options();
        addIOOptions();
        addBDDOptions();
        addExecutionOptions();
        addFailureToleranceOptions();
        addProbabilisticOptions();
    }

    public void parse(String[] args) throws ParseException {
        CommandLineParser parser = new DefaultParser();
        cli = parser.parse(options, args);
        parserIO();
        parserBDD();
        parserExecution();
        parserFailureTolerance();
        parserProbabilistic();
    }

    /* IO options */
    private void addIOOptions() {
        options.addOption("cfg", "config", true, "Configuration path");
        options.addOption("out", true, "Output path");
    }

    /* BDD options */
    private void addBDDOptions() {
        options.addOption("nt", true, "BDD node table size");
        options.addOption("filter", false, "BDDManager option");
        options.addOption("sort", true, "Choose link variable reordering method");
    }

    /* CPExecutor and DPAnalyzer options */
    private void addExecutionOptions() {
        options.addOption("obo", false, "Strategy for generating data plane");
        options.addOption("backward", false, "Build reachability trees backwards");
        options.addOption("id", true, "Controller id");
    }

    /* failure tolerance analysis options */
    private void addFailureToleranceOptions() {
        options.addOption("ft", false, "Run failure tolerance analysis");
        options.addOption("mf", true, "Maximum link failure");
        options.addOption("notrim", false, "Don't trim topology when running failure tolerance analysis");
        options.addOption("valid", true, "Valid routers");
        options.addOption("r", "reach", false, "Mine reachability or not, default true");
        options.addOption("b", "block", false, "Mine block or not, default false");
        options.addOption("w", "waypoint", false, "Mine waypoint or not, default false");
        options.addOption("l", "loadbalancing", false, "Mine loadbalancing or not, default false");
    }

    /* probabilistic analysis options */
    private void addProbabilisticOptions() {
        options.addOption("prob", false, "Run probabilistic analysis");
        options.addOption("type", true, "Property type when running probabilistic analysis");
        options.addOption("failure", true, "Failure Model");
    }

    private void parserIO() {
        if (!cli.hasOption("cfg")) {
            System.out.println("Must specify configuration path");
            System.exit(1);
        }
        else {
            inputBase = Paths.get(cli.getOptionValue("cfg"));
        }
        // get output path
        if (cli.hasOption("out")) {
            outputBase = Paths.get(cli.getOptionValue("out"));
        }
    }

    private void parserBDD() {
        if (cli.hasOption("nt")) {
            Configuration.NT_SIZE = Integer.parseInt(cli.getOptionValue("nt"));
        }
        Configuration.FILTER = cli.hasOption("filter");
        if (cli.hasOption("sort")) {
            Configuration.SORT = true;
            Configuration.SORT_METHOD = Configuration.LinkVarSortMethod.get(Integer.parseInt(cli.getOptionValue("sort")));
        }
    }

    private void parserExecution() {
        Configuration.ALL_IN_ONE = !cli.hasOption("obo");
        Configuration.FORWARD = !cli.hasOption("backward");
        if (options.hasOption("id")) Controller.ID = cli.getOptionValue("id");
    }

    private void parserFailureTolerance() {
        if (cli.hasOption("ft")) {
            int mf = Integer.parseInt(cli.getOptionValue("mf", "1"));
            Config2spec.trim = !cli.hasOption("notrim");
            Config2spec.reach = !cli.hasOption("r");
            Config2spec.block = cli.hasOption("b");
            Config2spec.waypoint = cli.hasOption("w");
            Config2spec.loadbalancing = cli.hasOption("l");
            Controller.pushStorage(new Storage(inputBase, outputBase));
            Config2spec c2s = new Config2spec();
            if (cli.hasOption("valid")) c2s.valid = cli.getOptionValue("valid").split(",");
            c2s.run(mf);
        }
    }

    private void parserProbabilistic() {
        if (cli.hasOption("prob")) {
            Netdice netdice = new Netdice();
            netdice.run(inputBase, cli.getOptionValue("type", "reachability"), cli.getOptionValue("failure", "link"));
        }
    }
}