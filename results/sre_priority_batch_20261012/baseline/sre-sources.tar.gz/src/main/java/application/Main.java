package application;

import org.apache.commons.cli.ParseException;

public class Main {
    public static void main(String[] args) throws ParseException {
        CliParser parser = new CliParser();
        parser.parse(args);
    }
}