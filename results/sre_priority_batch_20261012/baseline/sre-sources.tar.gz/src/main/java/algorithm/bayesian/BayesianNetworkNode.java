package algorithm.bayesian;

public class BayesianNetworkNode {
    RandVar var;
    Factor factor;

    public BayesianNetworkNode(RandVar var, Factor factor) {
        this.var = var;
        this.factor = factor;
    }
}
