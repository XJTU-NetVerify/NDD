package algorithm.bayes;

import java.util.Vector;

public class BucketTree {
    BayesNet bayesNet;
    Vector<Variable> variables;
    Vector<Bucket> buckets;
    Bucket result;

    public BucketTree(BayesNet bayesNet, Vector<Variable> variables) {
        this.bayesNet = bayesNet;
        this.variables = variables;
        this.buckets = new Vector<>(variables.size());
        for (Variable variable : variables) {
            buckets.add(new Bucket(this, variable));
        }
        result = new Bucket(this, null);
        for (Factor factor : bayesNet.factors) {
            insert(0, factor);
        }
    }

    public Factor reduce() {
        for (int i = 0; i < buckets.size(); i++) {
            insert(i, buckets.elementAt(i).reduce());
        }
        return result.combine();
    }

    public void insert(int idx, Factor factor) {
        if (factor != null) {
            while (idx < buckets.size()) {
                if (factor.contains(variables.elementAt(idx))) {
                    buckets.elementAt(idx).insert(factor);
                    return;
                }
                idx++;
            }
            result.insert(factor);
        }
    }
}
