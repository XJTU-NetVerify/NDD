package algorithm.bayes;

import java.math.BigDecimal;
import java.util.Vector;

public class BayesNet {
    String name;
    Vector<Variable> variables;
    Vector<Factor> factors;

    public BayesNet(String name) {
        this.name = name;
        this.variables = new Vector<>();
        this.factors = new Vector<>();
    }

    public void addVariable(Variable var) {
        variables.add(var);
    }

    public void addFactor(Factor factor) {
        factors.add(factor);
    }

    public BigDecimal inference(Condition toInference) {
        Vector<Variable> toEliminate = new Vector<>(variables);
        toEliminate.removeAll(toInference.map.keySet());
        BucketTree bucketTree = new BucketTree(this, toEliminate);
        Factor factor = bucketTree.reduce();
        return factor.evaluate(toInference);
    }
}
