package algorithm.bayes;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Objects;
import java.util.Vector;

public class Condition {
    HashMap<Variable, Integer> map;

    public Condition(Vector<Variable> variables) {
        map = new HashMap<>();
        for (int i = 0; i < variables.size(); i++) {
            map.put(variables.elementAt(i), -1);
        }
    }

    /* for builder */
    public Condition(HashMap<Variable, Integer> map) {
        this.map = map;
    }

    public boolean contains(Variable variable) {
        return map.containsKey(variable);
    }

    public int getVariableValue(Variable variable) {
        return map.get(variable);
    }

    public void setVariableValue(Variable variable, int value) {
        if (!map.containsKey(variable)) {
            return;
        }
        map.put(variable, value);
    }

    public Condition combine(Condition another) {
        HashSet<Variable> hs = new HashSet<>();
        hs.addAll(map.keySet());
        hs.addAll(another.map.keySet());
        Vector<Variable> jointVariables = new Vector<>(hs);
        return combine(jointVariables, another);
    }

    public Condition combine(Vector<Variable> jointVariables, Condition another) {
        Condition combined = new Condition(jointVariables);
        for (Variable variable : jointVariables) {
            if (contains(variable) &&
                another.contains(variable) &&
                getVariableValue(variable) != another.getVariableValue(variable)) {
                return null;
            }
            int value = contains(variable) ? getVariableValue(variable) : another.getVariableValue(variable);
            combined.setVariableValue(variable, value);

        }
        return combined;
    }

    public Condition subtract(Variable variable) {
        Builder builder = new Builder();
        map.forEach((var, val) -> {
            if (var != variable) {
                builder.addVarValPair(var, val);
            }
        });
        return builder.map.isEmpty() ? null : builder.build();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Condition condition = (Condition) o;
        return Objects.equals(map, condition.map);
    }

    @Override
    public int hashCode() {
        return Objects.hash(map);
    }

    public static class Builder {
        HashMap<Variable, Integer> map = new HashMap<>();

        public Condition build() {
            return new Condition(map);
        }

        public Builder addVarValPair(Variable var, int val) {
            map.put(var, val);
            return this;
        }
    }
}
