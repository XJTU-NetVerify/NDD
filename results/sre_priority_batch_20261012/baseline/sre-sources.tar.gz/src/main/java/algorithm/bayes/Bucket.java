package algorithm.bayes;

import java.util.Stack;
import java.util.Vector;

public class Bucket {
    BucketTree owner;
    Variable variable;
    Vector<Factor> factors;
    Factor reduceResult;

    public Bucket(BucketTree owner, Variable variable) {
        this.owner = owner;
        this.variable = variable;
        this.factors = new Vector<>();
    }

    /*
     * step 1. multiple all factors in this bucket
     * step 2. sum out bucket variable
     */
    Factor reduce() {
        if (factors.size() == 0) {
            reduceResult = null;
        }
        else {
            reduceResult = combine().sumOut(variable);
        }
        return reduceResult;
    }

    /*
     * multiple all factors in this bucket
     */
    Factor combine() {
        Stack<Factor> stk = new Stack<>();
        stk.addAll(factors);
        while (stk.size() > 1) {
            Factor f1 = stk.pop();
            Factor f2 = stk.pop();
            stk.push(f1.multiple(f2));
        }
        return stk.pop();
    }

    void insert(Factor factor) {
        factors.add(factor);
    }

}
