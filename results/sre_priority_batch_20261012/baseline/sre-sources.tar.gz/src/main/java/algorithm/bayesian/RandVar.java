package algorithm.bayesian;

import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.Objects;
import java.util.Vector;

public class RandVar implements Comparable<RandVar> {
    String name; // Name of the variable
    Vector<Integer> values; // Values of the variable

    public RandVar(String name, Vector<Integer> values) {
        this.name = name;
        this.values = values;
    }

    public RandVar(String name, int[] values) {
        this.name = name;
        this.values = new Vector<>();
        for (int v : values) {
            this.values.add(v);
        }
    }

    public int numValues() {
        return values.size();
    }

    public String getName() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RandVar randVar = (RandVar) o;
        return Objects.equals(name, randVar.name) && Objects.equals(values, randVar.values);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, values);
    }

    @Override
    public int compareTo(@NotNull RandVar o) {
        return Comparator.comparing(RandVar::getName).compare(this, o);
    }

    @Override
    public String toString() {
        return "RandVar{" +
               "name='" + name + '\'' +
               ", values=" + values +
               '}';
    }
}
