package algorithm.bayesian;

import datamodel.probability.DoubleProbImpl;
import datamodel.probability.Probability;

public class Configuration {
    public static Probability ONE = DoubleProbImpl.ONE;
    public static Probability ZERO = DoubleProbImpl.ZERO;
}
