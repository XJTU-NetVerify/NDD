package algorithm.bayesian;

import datamodel.probability.Probability;

import java.util.Vector;

public class BnNode {
    RandVar var;
    Vector<BnNode> parents;
    Vector<Probability> cpt;

    /**
     * @param var random variable associated with this node
     * @param parents BnNode Vector of parents
     * @param cpt Probability Vector specifying the conditional probability table
     */
    public BnNode(RandVar var, Vector<BnNode> parents, Vector<Probability> cpt) {
        this.var = var;
        this.parents = parents;
        this.cpt = cpt;
    }

    boolean factorCreated = false;

    public void clean() {
        factorCreated = false;
    }

    public void buildNetwork(BayesianNetwork bn) {
        if (factorCreated) {
            return;
        }
        factorCreated = true;
        Vector<RandVar> vars = new Vector<>();
        for (BnNode p : parents) {
            p.buildNetwork(bn);
            vars.add(p.var);
        }
        vars.add(var);
        Factor factor = new Factor(vars, cpt);
        bn.addBnNode(new BayesianNetworkNode(var, factor));
    }

    public RandVar getVar() {
        return var;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BnNode bnNode = (BnNode) o;
        return var.equals(bnNode.var);
    }

    @Override
    public int hashCode() {
        return var.hashCode();
    }
}
