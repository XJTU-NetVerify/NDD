package algorithm.bayes;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Vector;

public class Factor {
    Vector<Variable> variables;
    HashMap<Condition, BigDecimal> values;

    public Factor(Vector<Variable> variables, HashMap<Condition, BigDecimal> values) {
        this.variables = variables;
        this.values = values;
    }

    public Factor(Vector<Variable> variables) {
        this.variables = variables;
        this.values = new HashMap<>();
    }

    public boolean contains(Variable variable) {
        return variables.contains(variable);
    }

    public void setValue(Condition condition, BigDecimal value) {
        values.put(condition, value);
    }

    public Factor multiple(Factor another) {
        HashSet<Variable> hs = new HashSet<>();
        hs.addAll(variables);
        hs.addAll(another.variables);
        Vector<Variable> jointVariables = new Vector<>(hs);
        Factor jointFactor = new Factor(jointVariables);
        values.forEach((c1, v1) -> another.values.forEach((c2, v2) -> {
            Condition condition = c1.combine(c2);
            if (condition != null) {
                BigDecimal value = v1.multiply(v2);
                jointFactor.setValue(condition, value);
            }
        }));
        return jointFactor;
    }

    public Factor sumOut(Variable toSumOut) {
        Vector<Variable> vars = new Vector<>();
        for (Variable variable : variables) {
            if (!variable.equals(toSumOut)) {
                vars.add(variable);
            }
        }
        HashMap<Condition, BigDecimal> vals = new HashMap<>();
        values.forEach((c1, value) -> {
            Condition c2 = c1.subtract(toSumOut);
            if (c2 != null) {
                BigDecimal val = vals.getOrDefault(c2, BigDecimal.ZERO);
                val = val.add(value);
                vals.put(c2, val);
            }
        });
        return new Factor(vars, vals);
    }

    public BigDecimal evaluate(Condition condition) {
        return values.get(condition);
    }
}
