package algorithm.bayesian;

import datamodel.probability.Probability;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Vector;

public class BayesianNetwork {
    Vector<BayesianNetworkNode> nodes = new Vector<>();

    public void addBnNode(BayesianNetworkNode node) {
        nodes.add(node);
    }

    // implementation of variable elimination
    public Probability computeEventProb(Event event) {
        if (event.event.size() == 0) {
            return Configuration.ONE;
        }

        HashSet<Factor> factors = new HashSet<>();
        int nEliminate = 0;
        for (BayesianNetworkNode node : nodes) {
            Factor factor = makeFactor(node.factor, event);
            factors.add(factor);
            if (!event.varInEvent(node.var)) {
                nEliminate++;
            }
        }

        for (int i = 0; i < nEliminate; i++) {
            // map of var to vars in new factor if sum it out
            Multimap<RandVar, RandVar> newFactorVars = HashMultimap.create();
            // map of var to all factors containing it
            Multimap<RandVar, Factor> factorForVars = HashMultimap.create();
            for (Factor factor : factors) {
                for (RandVar var : factor.vars) {
                    newFactorVars.putAll(var, factor.vars);
                    factorForVars.put(var, factor);
                }
            }

            RandVar bestVar = null;
            int bestSize = -1;
            for (Map.Entry<RandVar, Collection<RandVar>> entry : newFactorVars.asMap().entrySet()) {
                if (bestVar == null || entry.getValue().size() < bestSize) {
                    bestVar = entry.getKey();
                    bestSize = entry.getValue().size();
                }
            }

            Collection<Factor> rmFactors = factorForVars.get(bestVar);
            Factor newFactor = sumOut(bestVar, rmFactors);
            factors.removeAll(rmFactors);
            factors.add(newFactor);
        }

        Factor product = null;
        for (Factor f : factors) {
            if (product == null) {
                product = f;
            }
            else {
                product = product.mul(f);
            }
        }
        assert product != null;
        return product.values.get(0);
    }

    /**
     * Sums the variable in var out, meaning that this function will return
     * the product of the factors in factors and will take var out
     *
     * @param var RandVar object that will be summed out
     * @param factors Factors which will have var summed out
     */
    public Factor sumOut(RandVar var, Collection<Factor> factors) {
        // Calculate the product of factors
        Factor product = null;
        for (Factor f : factors) {
            if (product == null) {
                product = f;
            }
            else {
                product = product.mul(f);
            }
        }

        // Get variables for marginal
        Vector<RandVar> marginVars = new Vector<>();
        assert product != null;
        for (RandVar v : product.vars) {
            if (!v.name.equals(var.name)) {
                marginVars.add(v);
            }
        }

        return product.marginal(marginVars);
    }

    public Factor makeFactor(Factor factor, Event event) {
        factor = factor.copy();
        for (Map.Entry<RandVar, Integer> entry : event.event.entrySet()) {
            Factor ret = factor.instantiateVar(entry.getKey(), entry.getValue());
            if (ret != null) factor = ret;
        }
        return factor;
    }
}
