package algorithm.bayesian;

import datamodel.probability.Probability;

import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Vector;
import java.util.function.BiFunction;

/**
 * Represents a Factor. A Factor has one or more random variables associated
 * with an array of values. The array of values is a vectorization of the
 * multi dimensional matrix that represents the factor.
 *
 * e.g.
 * X, Y, Z: domains = {True, False}
 * 1) Factor({X, Y}, {0.2, 0.3, 0.1, 0.4})
 *    P(X=True, Y=True) = 0.2, P(X=False, Y=True) = 0.3
 *    P(X=True, Y=False) = 0.1, P(X=False, Y=False) = 0.4
 * 2) Factor({X, Y, Z}, {0.2, 0.3, 0.1, 0.4, 0.7, 0.1, 0.1, 0.1})
 *    P(X=True, Y=True, Z=True) = 0.2, P(X=False, Y=True, Z=True) = 0.3
 *    P(X=True, Y=False, Z=True) = 0.1, P(X=False, Y=False, Z=True) = 0.4
 *    P(X=True, Y=True, Z=False) = 0.7, P(X=False, Y=True, Z=False) = 0.1
 *    P(X=True, Y=False, Z=False) = 0.1, P(X=False, Y=False, Z=False) = 0.1
 *
 * https://github.com/petermlm/ProbPy
 */
public class Factor {
    Vector<RandVar> vars;
    Vector<Probability> values;

    public Factor(Vector<RandVar> vars, Vector<Probability> values) {
        this.vars = vars;
        this.values = values;
    }

    public Factor(RandVar[] vars, Vector<Probability> values) {
        this.vars = new Vector<>();
        this.vars.addAll(Arrays.asList(vars));
        this.values = values;
    }

    public Factor(Vector<RandVar> vars, Probability[] values) {
        this.vars = vars;
        this.values = new Vector<>();
        this.values.addAll(Arrays.asList(values));
    }

    public Factor(RandVar[] vars, Probability[] values) {
        this.vars = new Vector<>();
        this.vars.addAll(Arrays.asList(vars));
        this.values = new Vector<>();
        this.values.addAll(Arrays.asList(values));
    }

    public Factor mul(Factor another) {
        return factorOp(another, Probability::multiply);
    }

    public Factor div(Factor another) {
        return factorOp(another, Probability::divide);
    }

    public Factor add(Factor another) {
        return factorOp(another, Probability::add);
    }

    public Factor sub(Factor another) {
        return factorOp(another, Probability::subtract);
    }

    public Factor factorOp(Factor another, BiFunction<Probability, Probability, Probability> op) {
        Vector<RandVar> retVars = new Vector<>(vars);
        Vector<Probability> retValues = new Vector<>();

        for (RandVar v1 : another.vars) {
            boolean varInSelf = true;
            for (RandVar v2 : vars) {
                if (v1.equals(v2)) {
                    varInSelf = false;
                    break;
                }
            }
            if (varInSelf) {
                retVars.add(v1);
            }
        }

        // TODO will int overflow?
        int[] mult = new int[another.vars.size()];
        int cMult = 1;

        for (int i = 0; i < mult.length; i++) {
            mult[i] = cMult;
            cMult *= another.vars.get(i).numValues();
        }

        int[] div = new int[another.vars.size()];

        for (int i = 0; i < div.length; i++) {
            int cDiv = 1;
            for (RandVar var : retVars) {
                if (another.vars.get(i).equals(var)) {
                    break;
                }
                cDiv *= var.numValues();
            }
            div[i] = cDiv;
        }

        int[] dim = new int[another.vars.size()];

        for (int i = 0; i < dim.length; i++) {
            dim[i] = another.vars.get(i).numValues();
        }

        int retValueSize = getValueSize(retVars);

        int idx1, idx2;

        for (int i = 0; i < retValueSize; i++) {
            idx1 = i % values.size();
            idx2 = 0;
            for (int j = 0; j < another.vars.size(); j++) {
                idx2 += ((i / div[j]) % dim[j]) * mult[j];
            }
            retValues.add(op.apply(values.get(idx1), another.values.get(idx2)));
        }

        return new Factor(retVars, retValues);
    }

    /**
     * Calculates the marginal of a factor for a list of random variables.
     * For example, if XY_factor is the distribution P(X, Y). Calculating the
     * marginal of X will give P(X).
     */
    protected Factor marginal(Vector<RandVar> toMarginal) {
        Vector<RandVar> retVars = new Vector<>();

        // Get resulting variables
        for (RandVar v1 : vars) {
            boolean varInSelf = false;
            for (RandVar v2 : toMarginal) {
                if (v1.name.equals(v2.name)) {
                    varInSelf = true;
                    break;
                }
            }
            if (varInSelf) {
                retVars.add(v1);
            }
        }

        // Calculate size of resulting factor
        int retValueSize = getValueSize(retVars);

        // Initialize resulting factor
        Vector<Probability> retValues = new Vector<>(retValueSize);
        for (int i = 0; i < retValueSize; i++) {
            retValues.add(Configuration.ZERO);
        }

        // Calculate marginal
        for (int i = 0; i < values.size(); i++) {
            int idx = 0;
            int div = 1;
            int mult = 1;
            int k = 0;

            for (RandVar var : vars) {
                if (k < retVars.size() && var.name.equals(retVars.get(k).name)) {
                    idx += ((i / div) % retVars.get(k).numValues()) * mult;
                    mult *= retVars.get(k).numValues();
                    k += 1;
                }
                div *= var.numValues();
            }
            retValues.set(idx, retValues.get(idx).add(values.get(i)));
        }

        return new Factor(retVars, retValues);
    }

    /**
     * Instantiates variables of a factor. Instantiating variable X with value
     * vx and Y with vy would yield f(X=vx, Y=vy, Z) = f(Z).
     */
    public Factor instantiateVars(Event event) {
        Factor ret = copy();
        for (Map.Entry<RandVar, Integer> entry : event.event.entrySet()) {
            ret = ret.instantiateVar(entry.getKey(), entry.getValue());
        }
        return ret;
    }

    /**
     * Same has instVar, but this method instantiates a single variable and
     * it is the one used in the implementation of instVar.
     */
    public Factor instantiateVar(RandVar toInst, Integer value) {
        Vector<RandVar> retVars = new Vector<>();
        Vector<Probability> retValues = new Vector<>();
        int varIdx = -1;

        // Get the index of "toInst" in this.vars and add other variables into retVars
        for (int i = 0; i < vars.size(); i++) {
            if (toInst.name.equals(vars.get(i).name)) {
                varIdx = i;
                continue;
            }
            retVars.add(vars.get(i));
        }

        // If "toInst" variable not in this factor, return an identical factor to this one
        if (varIdx == -1) {
            retVars = new Vector<>(vars);
            retValues = new Vector<>(values);
        }
        else {
            // Get div factor
            int div = 1;
            for (RandVar var : vars) {
                if (toInst.name.equals(var.name)) {
                    break;
                }
                div *= var.numValues();
            }

            // Check whether "value" is in the values of this.vars[varIdx]
            int valueIdx = -1;
            for (int i = 0; i < vars.get(varIdx).numValues(); i++) {
                if (Objects.equals(vars.get(varIdx).values.get(i), value)) {
                    valueIdx = i;
                    break;
                }
            }

            // If not, return null
            if (valueIdx == -1) {
                return null;
            }

            // Calculate resulting factor
            int numValues = vars.get(varIdx).numValues();
            for (int i = 0; i < values.size(); i++) {
                if (((i / div) % numValues) == valueIdx) {
                    retValues.add(values.get(i));
                }
            }
        }

        return new Factor(retVars, retValues);
    }

    public int getValueSize(Vector<RandVar> vars) {
        int ret = 1;
        for (RandVar var : vars) {
            ret *= var.numValues();
        }
        return ret;
    }

    public Factor copy() {
        return new Factor(new Vector<>(vars), new Vector<>(values));
    }

    @Override
    public String toString() {
        return "Factor{" +
               "vars=" + vars +
               ", values=" + values +
               '}';
    }
}
