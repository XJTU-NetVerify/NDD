package algorithm.bayes;

import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.Objects;
import java.util.Vector;

public class Variable implements Comparable<Variable> {
    String name; // Name of the variable
    Vector<Integer> values; // Values of the variable

    public Variable(String name, Vector<Integer> values) {
        this.name = name;
        this.values = values;
    }

    public int numValues() {
        return values.size();
    }

    public String getName() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Variable variable = (Variable) o;
        return Objects.equals(name, variable.name) &&
               Objects.equals(values, variable.values);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, values);
    }

    @Override
    public int compareTo(@NotNull Variable o) {
        return Comparator.comparing(Variable::getName).compare(this, o);
    }
}
