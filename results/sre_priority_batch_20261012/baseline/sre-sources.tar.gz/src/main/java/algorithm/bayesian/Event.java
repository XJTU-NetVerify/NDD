package algorithm.bayesian;

import java.util.HashMap;

public class Event {
    HashMap<RandVar, Integer> event;

    public Event() {
        event = new HashMap<>();
    }

    public void setValue(RandVar var, Integer value) {
        event.put(var, value);
    }

    public boolean varInEvent(RandVar var) {
        return event.containsKey(var);
    }
}
