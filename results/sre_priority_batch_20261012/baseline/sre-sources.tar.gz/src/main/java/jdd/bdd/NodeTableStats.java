// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   NodeTableStats.java

package jdd.bdd;

import jdd.util.JDDConsole;
import jdd.util.PrintTarget;

public class NodeTableStats
{

    public NodeTableStats(int table_size, int free_nodes_count, int stat_nt_grow, long stat_grow_time, int dead_nodes, int root_nodes, 
            long ht_chain, int stat_lookup_count, int stat_gc_count, long stat_gc_freed, long stat_gc_time, long stat_notify_time)
    {
        this.table_size = table_size;
        this.free_nodes_count = free_nodes_count;
        this.stat_nt_grow = stat_nt_grow;
        this.stat_grow_time = stat_grow_time;
        this.dead_nodes = dead_nodes;
        this.root_nodes = root_nodes;
        this.ht_chain = ht_chain;
        this.stat_lookup_count = stat_lookup_count;
        this.stat_gc_count = stat_gc_count;
        this.stat_gc_freed = stat_gc_freed;
        this.stat_gc_time = stat_gc_time;
        this.stat_notify_time = stat_notify_time;
    }

    public int get_table_size()
    {
        return table_size;
    }

    public int get_free_nodes_count()
    {
        return free_nodes_count;
    }

    public int get_stat_nt_grow()
    {
        return stat_nt_grow;
    }

    public long get_stat_grow_time()
    {
        return stat_grow_time;
    }

    public int get_dead_nodes()
    {
        return dead_nodes;
    }

    public int get_root_nodes()
    {
        return root_nodes;
    }

    public long get_ht_chain()
    {
        return ht_chain;
    }

    public int get_stat_lookup_count()
    {
        return stat_lookup_count;
    }

    public int get_stat_gc_count()
    {
        return stat_gc_count;
    }

    public long get_stat_gc_freed()
    {
        return stat_gc_freed;
    }

    public long get_stat_gc_time()
    {
        return stat_gc_time;
    }

    public long get_stat_notify_time()
    {
        return stat_notify_time;
    }

    public void showStats()
    {
        // JDDConsole.out.printf("NT nodes=%d free=%d #grow=%d grow-time=%d dead=%d root=%d\n", new Object[] {
        //     Integer.valueOf(table_size), Integer.valueOf(free_nodes_count), Integer.valueOf(stat_nt_grow), Long.valueOf(stat_grow_time), Integer.valueOf(dead_nodes), Integer.valueOf(root_nodes)
        // });
        // JDDConsole.out.printf("HT chain=%d access=%d\n", new Object[] {
        //     Long.valueOf(ht_chain), Integer.valueOf(stat_lookup_count)
        // });
        // JDDConsole.out.printf("GC count=%d #freed=%d time=%d signal-time=%d\n", new Object[] {
        //     Integer.valueOf(stat_gc_count), Long.valueOf(stat_gc_freed), Long.valueOf(stat_gc_time), Long.valueOf(stat_notify_time)
        // });

        JDDConsole.out.println("NT nodes="+Integer.valueOf(table_size)+" free="+Integer.valueOf(free_nodes_count)+" #grow="+Integer.valueOf(stat_nt_grow)+" grow-time="+Long.valueOf(stat_grow_time)+" dead="+Integer.valueOf(dead_nodes)+" root="+Integer.valueOf(root_nodes));
        JDDConsole.out.println("HT chain="+Long.valueOf(ht_chain)+" access="+Integer.valueOf(stat_lookup_count));
        JDDConsole.out.println("GC count="+Integer.valueOf(stat_gc_count)+" #freed="+Long.valueOf(stat_gc_freed)+" time="+Long.valueOf(stat_gc_time)+" signal-time="+Long.valueOf(stat_notify_time));
    }

    int table_size;
    int free_nodes_count;
    int stat_nt_grow;
    long stat_grow_time;
    int dead_nodes;
    int root_nodes;
    long ht_chain;
    int stat_lookup_count;
    int stat_gc_count;
    long stat_gc_freed;
    long stat_gc_time;
    long stat_notify_time;
}
