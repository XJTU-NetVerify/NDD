package jdd.bdd;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

import jdd.bdd.debug.BDDDebuger;
import jdd.util.Allocator;
import jdd.util.Array;
import jdd.util.Configuration;
import jdd.util.JDDConsole;
import jdd.util.Options;
import jdd.util.Test;
import jdd.util.math.HashFunctions;
import jdd.util.zip.MemoryInputStream;
import jdd.util.zip.ZipArray;

/**
 * implementation of a node table of elements (var,low,high,ref-count) that
 * supports garbage collections.
 *
 */

// the nodes are unique, which is guranteed by a double linked list
// hash-table-alike structure.
// this structure is very similiar to the double-hashed list in BuDDy.
//
// we divide the node list and the linked-list into to parts (t_nodes, t_list).
// this gives a bad cache performance (CPU cache, not BDD operation caches),
// but it might help to keep the memory peek down a little bit.

public class NodeTable implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1041444991970971613L;

	/** used to mark/unmark BDD nodes */
	public static final int NODE_MARK = 0x80000000, NODE_UNMARK = 0x7FFFFFFF;

	private static final short MAX_REFCOUNT = 32767;
	/** the largest possible ref-count */

	// Monolithic packed arrays used to cap size at ~715M nodes. Use split arrays instead.
	// HotSpot/JDK usually disallows arrays very close to Integer.MAX_VALUE.
	private static final int MAX_JAVA_ARRAY_LENGTH = Integer.MAX_VALUE - 8;
	private static final int MAX_TABLE_SIZE = MAX_JAVA_ARRAY_LENGTH;
	private static final double MEMORY_FUSE_SOFT_USED_RATIO = 0.90;
	private static final double MEMORY_FUSE_HARD_USED_RATIO = 0.96;
	private static final long MEMORY_FUSE_MIN_HEADROOM_BYTES = 512L * 1024 * 1024;
	private static final long MEMORY_FUSE_RESIZE_SAFETY_BYTES = 256L * 1024 * 1024;
	private static final int[] GROWTH_STAGE_DIVISORS = new int[] { 1, 2, 4, 8, 16, 32 };

	/** the "debuggers" connected to this NodeTable. see for example ProfibedBDD2 */
	private Collection debugers;

	public int table_size, stat_nt_grow, dead_nodes;
	protected int nodesminfree /* , bddmaxnodeincrease, minfreenodes */ ;
	private int[] t_var;
	private int[] t_low;
	private int[] t_high;
	private int[] t_next;
	private int[] t_prev;
	private short[] t_ref;
	/** the reference counter */
	private int first_free_node, free_nodes_count;
	private boolean stack_marking_enabled;
	/** if true, we will use the faster version of mark_tree() */

	// GC/grow stuff
	protected int stat_gc_count, stat_lookup_count;
	protected long stat_gc_freed, stat_gc_time, stat_grow_time, stat_notify_time;
	protected int[] work_stack, mark_stack;
	protected int work_stack_tos;
	protected long ht_chain;

	private boolean quickGrow = false;
	private double threshold = 0.1;

	private transient Runnable preGCCallback;

	public void setPreGCCallback(Runnable preGCCallback) {
		this.preGCCallback = preGCCallback;
	}

	private static int checkedTableSize(int size) {
		if (size < 0 || size > MAX_TABLE_SIZE) {
			throw new IllegalStateException(
					"NodeTable size overflow: " + size + " exceeds max table size " + MAX_TABLE_SIZE);
		}
		return size;
	}

	private static int checkedNodeArraySize(int size) {
		return checkedTableSize(size);
	}

	private static int checkedListArraySize(int size) {
		return checkedTableSize(size);
	}

	private long heapMaxBytes() {
		return Runtime.getRuntime().maxMemory();
	}

	private long heapUsedBytes() {
		Runtime rt = Runtime.getRuntime();
		return rt.totalMemory() - rt.freeMemory();
	}

	private long heapHeadroomBytes() {
		long headroom = heapMaxBytes() - heapUsedBytes();
		return Math.max(0L, headroom);
	}

	private boolean isUnderMemoryPressure(double usedRatioThreshold, long minHeadroomBytes) {
		long max = heapMaxBytes();
		if (max <= 0L) {
			return false;
		}
		double usedRatio = (double) heapUsedBytes() / max;
		return usedRatio >= usedRatioThreshold || heapHeadroomBytes() < minHeadroomBytes;
	}

	private static String bytesToMB(long bytes) {
		return (bytes / (1024L * 1024L)) + "MB";
	}

	private String heapSnapshot() {
		long max = heapMaxBytes();
		long used = heapUsedBytes();
		long headroom = heapHeadroomBytes();
		double usedPct = max <= 0L ? 0.0 : (100.0 * used) / max;
		return "heap_used=" + bytesToMB(used) +
				" heap_max=" + bytesToMB(max) +
				" heap_headroom=" + bytesToMB(headroom) +
				" heap_used_pct=" + String.format("%.2f", usedPct);
	}

	private void runMemoryRelief(String stage) {
		if (Options.verbose) {
			JDDConsole.out.println("NodeTable memory relief at stage=" + stage + " " + heapSnapshot());
		}
		if (preGCCallback != null) {
			try {
				preGCCallback.run();
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}
		System.gc();
		System.runFinalization();
		System.gc();
	}

	private boolean canAttemptResize(int candidateSize) {
		if (candidateSize <= table_size) {
			return false;
		}
		int checkedSize = checkedTableSize(candidateSize);
		long largestSingleAllocation = Math.max((long) checkedSize * Integer.BYTES,
				(long) checkedSize * Short.BYTES);
		long requiredHeadroom = largestSingleAllocation + MEMORY_FUSE_RESIZE_SAFETY_BYTES;
		if (isUnderMemoryPressure(MEMORY_FUSE_HARD_USED_RATIO, MEMORY_FUSE_MIN_HEADROOM_BYTES)) {
			return false;
		}
		return heapHeadroomBytes() >= requiredHeadroom;
	}

	private int chooseStagedGrowthSize(int targetSize) {
		if (targetSize <= table_size) {
			return table_size;
		}
		long fullIncrease = (long) targetSize - table_size;
		int lastCandidate = table_size;
		boolean reliefTried = false;

		for (int divisor : GROWTH_STAGE_DIVISORS) {
			long stagedIncrease = Math.max(1L, fullIncrease / divisor);
			int candidate = (int) Math.min((long) table_size + stagedIncrease, (long) targetSize);
			if (candidate <= table_size || candidate == lastCandidate) {
				continue;
			}
			if (canAttemptResize(candidate)) {
				return candidate;
			}
			if (!reliefTried) {
				runMemoryRelief("grow-stage-" + divisor);
				reliefTried = true;
				if (canAttemptResize(candidate)) {
					return candidate;
				}
			}
			lastCandidate = candidate;
		}

		if (canAttemptResize(targetSize)) {
			return targetSize;
		}
		return table_size;
	}

	public NodeTable(int nodesize) {
		debugers = new LinkedList();

		// we dont like nodetables that are too small
		if (nodesize < Configuration.MIN_NODETABLE_SIZE)
			nodesize = Configuration.MIN_NODETABLE_SIZE;
		if (nodesize > MAX_TABLE_SIZE) {
			throw new IllegalArgumentException(
					"Initial node table size " + nodesize + " exceeds supported max " + MAX_TABLE_SIZE);
		}

		// allocate the initial arraus
		table_size = nodesize;
		t_ref = Allocator.allocateShortArray(table_size);
		t_var = Allocator.allocateIntArray(checkedTableSize(table_size));
		t_low = Allocator.allocateIntArray(checkedTableSize(table_size));
		t_high = Allocator.allocateIntArray(checkedTableSize(table_size));
		t_next = Allocator.allocateIntArray(checkedTableSize(table_size));
		t_prev = Allocator.allocateIntArray(checkedTableSize(table_size));

		first_free_node = 2;
		free_nodes_count = nodesize - 2;
		for (int i = 0; i < nodesize; i++) {
			invalidate(i);
			setPrev(i, 0);
			setNext(i, i + 1);
		}

		setNext(nodesize - 1, 0);

		// get 1 and zero:
		setAll(0, -1, 0, 0, MAX_REFCOUNT);
		setAll(1, -1, 1, 1, MAX_REFCOUNT);

		update_grow_parameters();
		stat_nt_grow = 0; // number of times we expand the table
		dead_nodes = 0; // no dead nodes yet

		// hash table stuff
		stat_gc_count = stat_lookup_count = 0;
		stat_gc_freed = stat_gc_time = stat_grow_time = stat_notify_time = 0L;
		ht_chain = 0;

		work_stack = Allocator.allocateIntArray(32); // just some silly number
		mark_stack = Allocator.allocateIntArray(work_stack.length);
		work_stack_tos = 0;

		stack_marking_enabled = false; // disable by default
	}

	// --------------------------------------------------------------------
	public void cleanup() { // to help GC
		stopDebuggers();
		t_ref = null;
		t_var = null;
		t_low = null;
		t_high = null;
		t_next = null;
		t_prev = null;
		work_stack = null;
		mark_stack = null;
	}

	/**
	 * this function MUST be called when a paramater that may change the tree dpeth
	 * (such as the number of variables in a BDD) has changed!
	 */
	protected void tree_depth_changed(int n) {
		// mark_stack is the stack used for recursive tree marking
		int need = n * 4 + 3;
		if (mark_stack.length < need)
			mark_stack = Allocator.allocateIntArray(need * 2); // twice, so we dont need to do it too often....
	}

	// --- [ HT stuff ]
	// ----------------------------------------------------------------
	// compute hash for the triple (i,l,h)
	// this function can change very much between the releases :)
	private final int compute_hash(int i, int l, int h) {
		return (HashFunctions.hash_prime(i, l, h) & 0x7FFFFFFF) % table_size;
	}

	/**
	 * how much can we allow this node-table to increase??
	 *
	 * <p>
	 * TODO: we should also check how much free memory we have!
	 */
	private final int compute_increase_limit(int current_size) {
		// limit disabled?
		if (Configuration.nodetableSmallSize <= 0 || Configuration.nodetableLargeSize <= 0)
			return current_size;

		if (current_size <= Configuration.nodetableSmallSize)
			return Configuration.nodetableGrowMax;
		if (current_size >= Configuration.nodetableLargeSize)
			return Configuration.nodetableGrowMin;

		// avoid division by zero, when badly configured
		if (Configuration.nodetableLargeSize == Configuration.nodetableSmallSize)
			return (Configuration.nodetableGrowMax + Configuration.nodetableGrowMin) / 2;

		// anywhere between the two limits, we use a linear interpolation of them.
		return Configuration.nodetableGrowMax -
				((current_size - Configuration.nodetableSmallSize) *
						(Configuration.nodetableGrowMax - Configuration.nodetableGrowMin)) /
						(Configuration.nodetableLargeSize - Configuration.nodetableSmallSize);
	}

	/**
	 * this function is called when something in the node table is changed (GC or
	 * grow).
	 *
	 * <p>
	 * sub-classes must "implement" this function for, for example, flushing caches
	 * since it signals that something important has been changed and old data might
	 * have
	 * become invalid.
	 */
	protected void post_removal_callbak() {
		/* do nothing */ }

	protected final void signal_removed() {
		long time = System.currentTimeMillis();
		post_removal_callbak();
		stat_notify_time += System.currentTimeMillis() - time;

	}

	/**
	 * do a garbage collection.
	 * 
	 * @return number of freed nodes
	 */
	public int gc() {
		return gc(true);
	}

	/**
	 * this is the internal version of gc(). when called from NodeTable internally,
	 * we might to choose to call signal_removed() not here but at a later point.
	 */
	private int gc(boolean call_callback) {
		// System.out.println("JDD start garbage collection #" + stat_gc_count + ": " + table_size + " nodes");
		long time = System.currentTimeMillis();
		stat_gc_count++;

		if (preGCCallback != null) {
			try {
				preGCCallback.run();
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}

		// 0. mark nodes in use
		mark_nodes_in_use();

		// 1. free or re-hash and unmark
		int old_free = free_nodes_count;
		first_free_node = free_nodes_count = 0;

		// 1.5 go backward to get the list in correct direction. doesnt really matter :(
		for (int i = table_size; i > 2;) {
			i--;
			if (isValid(i) && isNodeMarked(i)) {
				unmark_node(i);
				int pos = compute_hash(getVar(i), getLow(i), getHigh(i));
				connect_list(i, pos);
			} else {
				invalidate(i);
				setNext(i, first_free_node);
				first_free_node = i;
				free_nodes_count++;
			}
		}

		// 2. ok, we have removed things, inform others [caches ?] about it
		if (call_callback)
			signal_removed();

		// 3. update our statistics
		stat_gc_time += System.currentTimeMillis() - time;
		int new_free = free_nodes_count - old_free;
		stat_gc_freed += new_free;

		if (Options.verbose) {
			JDDConsole.out.println("Garbage collection #" + stat_gc_count + ": " + table_size + " nodes, " + new_free
					+ " freed, time " + stat_gc_time + "+" + stat_notify_time);
		}

		// System.out.println("JDD end garbage collection #" + stat_gc_count + ": " + table_size + " nodes, " + new_free
		//				+ " freed, time " + stat_gc_time + "+" + stat_notify_time);

		return new_free;
	}

	/**
	 * this functions marks the nodes in use AND cleans the <tt>prev</tt> link.
	 * we had a version that used t_list as stack and avoided recursive calls
	 * with mark_tree. there are some problems with that but we might switch back to
	 * it for better efficiency
	 */
	private final void mark_nodes_in_use() {
		// insert the stuff we are working on:
		for (int i = 0; i < work_stack_tos; i++)
			mark_tree(work_stack[i]);

		// and referenced nodes.
		// it looks inefficient, but you cant do it much faster than this :(
		for (int i = table_size; i != 0;) {
			i--;
			if (isValid(i) && getRefPlain(i) > 0)
				mark_tree(i);
			setPrev(i, 0);
		}
	}

	/**
	 * grow is called when we need more nodes in the table. it first will try to
	 * make more room by a garbage collection. if that fails, the node table is
	 * resized
	 */
	protected void grow() {
		int got = -1;

		// if we have no dead nodes, we dont bother to collect garbage,
		// but the dead-node counter is bot always accurate
		if (dead_nodes > 0 || table_size > Configuration.nodetableSimpleDeadcountThreshold) {

			got = gc(false);
			dead_nodes = 0;

			// we might have had DEAD NODES, but that doesnt mean that we can always
			// free those nodes (they can be used in some other tree)
			// furthermore, we must of at least minfreenodes% free nodes or we will grow
			if (got >= nodesminfree && free_nodes_count > 1) {
				signal_removed(); // Force all caches to be wiped out!
				return;
			}
		}

		if (isUnderMemoryPressure(MEMORY_FUSE_SOFT_USED_RATIO, MEMORY_FUSE_MIN_HEADROOM_BYTES)) {
			runMemoryRelief("grow-precheck");
		}

		// could not GC, start growing:
		long time = System.currentTimeMillis();

		// 1. grow node table:
		stat_nt_grow++;

		// 1.b) compute the new size.
		// this snippet is not very intelligent. I just don't feel like re-writing it
		// right now
		// int new_size = table_size + Math.min(table_size,
		// compute_increase_limit(table_size) );
		long requestedSize = (long) table_size + compute_increase_limit(nodesminfree);
		int targetSize;
		if (requestedSize > MAX_TABLE_SIZE) {
			// At hard cap, prefer progress with reclaimed nodes over mandatory growth.
			if (free_nodes_count > 1) {
				signal_removed();
				return;
			}
			if (table_size >= MAX_TABLE_SIZE) {
				throw new IllegalStateException(
						"NodeTable reached hard capacity " + MAX_TABLE_SIZE +
						" and cannot grow further (requested " + requestedSize +
						", storage=split-arrays" +
						", table_size=" + table_size +
						", free_nodes_count=" + free_nodes_count +
						", nodesminfree=" + nodesminfree +
						", gc_freed=" + got +
						", stat_nt_grow=" + stat_nt_grow +
						", " + heapSnapshot() + ")");
			}
			targetSize = MAX_TABLE_SIZE;
			if (Options.verbose) {
				JDDConsole.out.println("NodeTable growth capped at max capacity: requested " + requestedSize +
						", using " + targetSize);
			}
		} else {
			targetSize = (int) requestedSize;
		}

		int new_size = chooseStagedGrowthSize(targetSize);
		if (new_size <= table_size) {
			if (free_nodes_count > 1) {
				signal_removed();
				return;
			}
			throw new IllegalStateException(
					"NodeTable memory fuse triggered before resize: unable to reserve headroom for growth"
							+ " (table_size=" + table_size
							+ ", target_size=" + targetSize
							+ ", free_nodes_count=" + free_nodes_count
							+ ", nodesminfree=" + nodesminfree
							+ ", gc_freed=" + got
							+ ", stat_nt_grow=" + stat_nt_grow
							+ ", " + heapSnapshot() + ")");
		}

		if (new_size < targetSize && Options.verbose) {
			JDDConsole.out.println("NodeTable staged growth downgrade: requested=" + targetSize +
					" selected=" + new_size + " " + heapSnapshot());
		}

		// 2. resize tables
		int old_size = table_size;
		try {
			safe_resize(new_size);
		} catch (OutOfMemoryError oom) {
			throw new IllegalStateException(
					"NodeTable memory fuse: resize failed with OOM after staged checks"
							+ " (old_size=" + old_size
							+ ", new_size=" + new_size
							+ ", " + heapSnapshot() + ")",
					oom);
		}
		table_size = new_size;

		// 3. update the new array to become a unique node table
		/*
		 * // this is what we had before (kinda inefficient ha?)
		 * for(int i = old_size; i < new_size; i++) invalidate(i);
		 * clearPrev(0, new_size);
		 * recompute_hash();
		 */

		// 3.a) start clean
		first_free_node = free_nodes_count = 0;

		// 3.b) invalidate the new nodes and insert them into the linked list
		for (int i = new_size; i > old_size;) {
			i--;
			invalidate(i);
			setPrev(i, 0);
			setNext(i, first_free_node);
			first_free_node = i;
			free_nodes_count++;
		}

		// 3.c) clear the rest.
		clearPrev(0, old_size); // XXX: how do we embed this in the loop below??

		// 3.d) now seperate the old and new invalid nodes
		for (int i = old_size; i > 2;) {
			i--;
			if (isValid(i)) {
				int hash = compute_hash(getVar(i), getLow(i), getHigh(i));
				connect_list(i, hash);
			} else {
				setNext(i, first_free_node);
				first_free_node = i;
				free_nodes_count++;
			}
		}

		// 4. update internal variables that need to be upated...
		update_grow_parameters();

		// 5. force all caches to be wiped out!
		signal_removed();

		// 6. and statictics...
		time = System.currentTimeMillis() - time;
		stat_grow_time += time;

		if (Options.verbose) {
			JDDConsole.out.println("Node-table grown #" + stat_nt_grow + ": " + old_size + " -> " + new_size
					+ " nodes, time " + stat_grow_time);
		}
	}

	public static boolean getMKCount = true;
	public static int MKCount = 0;

	public int add(int v, int l, int h) {

		int hash = compute_hash(v, l, h);
		int curr = getPrev(hash);

		// look it up in the cache
		stat_lookup_count++;
		while (curr != 0) {
			if (match_table(curr, v, l, h))
				return curr; // tuple found in the table!
			curr = getNext(curr);
			ht_chain++;

		}

		// see if we have room for it!
		if ((!quickGrow && free_nodes_count < 2) || (quickGrow && free_nodes_count < (table_size * threshold))) { // dont
																													// change
																													// "2"
																													// to
																													// "0"
																													// !
			grow();
			hash = compute_hash(v, l, h); // table_size might have changed (or not if we only did a GC)
		}

		if (first_free_node == 0 || free_nodes_count < 1) {
			throw new IllegalStateException(
					"NodeTable memory fuse: no free nodes available after grow"
							+ " (table_size=" + table_size
							+ ", free_nodes_count=" + free_nodes_count
							+ ", dead_nodes=" + dead_nodes
							+ ", stat_gc_count=" + stat_gc_count
							+ ", stat_nt_grow=" + stat_nt_grow
							+ ", " + heapSnapshot() + ")");
		}

		if (getMKCount)
			MKCount++;

		// takke next free node
		curr = first_free_node;
		first_free_node = getNext(first_free_node);
		free_nodes_count--;

		// adjust and write node
		setAll(curr, v, l, h, (short) -1);

		connect_list(curr, hash);
		return curr;
	}

	// --------------------------------------------------------------------

	/**
	 * for debugging: install a debugger. returns the set of caches.
	 */
	public Collection addDebugger(BDDDebuger d) {
		debugers.add(d);
		Collection v = new LinkedList();

		// at this level, we wont do anything with the returned vector.
		// the sub-classes will do that.

		return v;
	}

	/**
	 * stop the running debuggers, otherwise they will keep collecting data.
	 * called from cleanup()
	 */
	private void stopDebuggers() {
		for (Iterator e = debugers.iterator(); e.hasNext();) {
			BDDDebuger d = (BDDDebuger) e.next();
			d.stop();
		}
	}

	// ---------------------------------------------------------------

	/**
	 * this is called when the table ha grown and we might need to
	 * update some internal parameters
	 */
	protected void update_grow_parameters() {
		nodesminfree = Math.min((table_size * Configuration.minFreeNodesProcent) / 100, Configuration.maxNodeFree - 1);
	}

	// ---- [resizeing algo] ---------------------------------------------------

	/** resize the tables. if not possible, try the compressed method */
	private void safe_resize(int new_size) {
		int oldSize = checkedTableSize(table_size);
		int newSize = checkedTableSize(new_size);

		if (!canAttemptResize(new_size)) {
			runMemoryRelief("safe-resize-precheck");
			if (!canAttemptResize(new_size)) {
				throw new IllegalStateException(
						"NodeTable memory fuse: insufficient headroom before safe_resize"
								+ " (table_size=" + table_size
								+ ", new_size=" + new_size
								+ ", " + heapSnapshot() + ")");
			}
		}

		// currently, ZipArray only handles int[]
		try {
			t_ref = Array.resize(t_ref, oldSize, newSize);
			t_var = Array.resize(t_var, oldSize, newSize);
			t_low = Array.resize(t_low, oldSize, newSize);
			t_high = Array.resize(t_high, oldSize, newSize);
			t_next = Array.resize(t_next, oldSize, newSize);
			t_prev = Array.resize(t_prev, oldSize, newSize);
		} catch (OutOfMemoryError ignored) {

			// if we end up here, then at leats one of the array could not be allocated.
			// find the old arrays and use compressed memory to try allocate them again
			if (Options.verbose) {
				JDDConsole.out.println("NodeTable.safe_resize failed. trying the compressed method...");
			}
			try {
				compressed_resize(new_size);
			} catch (OutOfMemoryError oom) {
				throw new IllegalStateException(
						"NodeTable memory fuse: compressed resize failed"
								+ " (table_size=" + table_size
								+ ", new_size=" + new_size
								+ ", " + heapSnapshot() + ")",
						oom);
			}
		}
	}

	/**
	 * to free space, first compress to a gzip structure, then free vectors and
	 * allocate
	 * larger ones. beware that this methods is extremely slow!
	 */
	private void compressed_resize(int new_size) {
		int checkedSize = checkedTableSize(new_size);
		if (!canAttemptResize(new_size)) {
			runMemoryRelief("compressed-resize-precheck");
			if (!canAttemptResize(new_size)) {
				throw new IllegalStateException(
						"NodeTable memory fuse: insufficient headroom before compressed_resize"
								+ " (table_size=" + table_size
								+ ", new_size=" + new_size
								+ ", " + heapSnapshot() + ")");
			}
		}
		// TODO: fill invalid nodes with ZEROS for better compression
		if (t_var.length != checkedSize) {
			MemoryInputStream mis = ZipArray.compressArray(t_var);
			t_var = null;
			t_var = new int[checkedSize];
			ZipArray.decompressArray(mis, t_var);
			mis.free();
		}

		if (t_low.length != checkedSize) {
			MemoryInputStream mis = ZipArray.compressArray(t_low);
			t_low = null;
			t_low = new int[checkedSize];
			ZipArray.decompressArray(mis, t_low);
			mis.free();
		}

		if (t_high.length != checkedSize) {
			MemoryInputStream mis = ZipArray.compressArray(t_high);
			t_high = null;
			t_high = new int[checkedSize];
			ZipArray.decompressArray(mis, t_high);
			mis.free();
		}

		if (t_next.length != checkedSize) {
			MemoryInputStream mis = ZipArray.compressArray(t_next);
			t_next = null;
			t_next = new int[checkedSize];
			ZipArray.decompressArray(mis, t_next);
			mis.free();
		}

		if (t_prev.length != checkedSize) {
			MemoryInputStream mis = ZipArray.compressArray(t_prev);
			t_prev = null;
			t_prev = new int[checkedSize];
			ZipArray.decompressArray(mis, t_prev);
			mis.free();
		}
	}

	// -------- [ refocunting ] ---------------------------------------------------
	/**
	 * increase the reference-count of this BDD once
	 * 
	 * @return bdd
	 */
	public final int ref(int bdd) {
		short ref = getRefPlain(bdd);
		if (ref == -1)
			ref = 1;
		else if (ref == 0) {
			ref = 1;
			dead_nodes--;
		} else if (ref != MAX_REFCOUNT)
			ref++;
		setRef(bdd, ref);
		return bdd;
	}

	/**
	 * decrease the reference-count of this BDD once.
	 * 
	 * @return bdd
	 */
	public final int deref(int bdd) {
		short ref = getRefPlain(bdd);
		if (ref == 1) {
			ref = (short) 0;
			dead_nodes++;
		} else if (ref != MAX_REFCOUNT && ref > 0) {
			ref--;
		}
		setRef(bdd, ref);
		return bdd;

	}

	/**
	 * set the reference-count of this BDD to max.
	 * after that, the ref-count cant be changed and the node cannot be garbage
	 * collected anymore.
	 * <p>
	 * DO NOT USE, unless you know what you are doing (note: you probably don't).
	 */
	public final void saturate(int bdd) {
		setRef(bdd, MAX_REFCOUNT);
	}

	// ------- [ low-level access ]
	// --------------------------------------------------------------

	// low-level access to the ref-counter
	private final short getRefPlain(int bdd) {
		return t_ref[bdd];
	}

	/** just return the number */
	private final void setRef(final int bdd, final short r) {
		t_ref[bdd] = r;
	}

	/**
	 * get the number of references to this BDD.
	 */
	public final short getRef(int bdd) {
		if (t_ref[bdd] == -1)
			return 0;
		return t_ref[bdd];
	}

	// -----------------------------------------------------------------------------------------
	// low-level access to the node table
	private final void setVar(final int bdd, int v) {
		t_var[bdd] = v;
	}

	private final void setLow(int bdd, int v) {
		t_low[bdd] = v;
	}

	private final void setHigh(int bdd, int v) {
		t_high[bdd] = v;
	}

	public final int getVar(final int bdd) {
		return t_var[bdd];
	}

	public final int getLow(final int bdd) {
		return t_low[bdd];
	}

	public final int getHigh(final int bdd) {
		return t_high[bdd];
	}

	/** return the associated variable. works even when the table is marked */
	protected final int getVarUnmasked(int bdd) {
		return t_var[bdd] & NODE_UNMARK;
	}

	/** returns true if this bdd is a valid bdd */
	public final boolean isValid(int bdd) {
		return t_var[bdd] != -1;
	}

	/** make the node invalid */
	protected final void invalidate(int bdd) {
		t_var[bdd] = -1;
	}

	// set multiple members (including ref) at the same time. not called very often
	protected final void setAll(final int bdd, final int v, final int l, final int h, final short r) {
		t_var[bdd] = v;
		t_low[bdd] = l;
		t_high[bdd] = h;
		t_ref[bdd] = r;
	}

	// set multiple members at the same time. not called very often
	protected final void setAll(final int bdd, final int v, final int l, final int h) {
		t_var[bdd] = v;
		t_low[bdd] = l;
		t_high[bdd] = h;
	}

	/** returns true of the bdd <tt>bdd</tt> is the same as (var,low,high) */
	protected final boolean match_table(final int bdd, final int var, final int low, final int high) {
		return t_var[bdd] == var && t_low[bdd] == low && t_high[bdd] == high;
	}

	// -----------------------------------------------------------------------------------------
	// low-level access to the linked list
	private final void setNext(int bdd, int v) {
		t_next[bdd] = v;
	}

	private final void setPrev(int bdd, int v) {
		t_prev[bdd] = v;
	}

	private final int getNext(final int bdd) {
		return t_next[bdd];
	}

	private final int getPrev(final int bdd) {
		return t_prev[bdd];
	}

	/** a more clever way to set all the prev members up to <tt>upto</tt> to 0 */
	private final void clearPrev(int from, int upto) {
		// TODO: we should unroll this at least once!
		while (from < upto) {
			t_prev[from] = 0;
			from++;
		}
	}

	/** put <tt>a</tt> before <tt>b</tt> in the linked list */
	private final void connect_list(int a, int b) {
		t_next[a] = t_prev[b];
		t_prev[b] = a;
	}

	// ----[ node marking ] ----------------------------

	/**
	 * call this functio to enable the fast variant of the mark_node() function.
	 * if you do that, you mustlet JDD know the maximum depth of all trees by
	 * calling
	 * tree_depth_changed() from your sub-class
	 * 
	 * @see #tree_depth_changed
	 */
	public void enableStackMarking() {
		stack_marking_enabled = true;
	}

	/**
	 * recursively mark nodes, used by some internal functions.
	 * 
	 * @see #mark_node
	 */
	public final void mark_tree(int bdd) {
		if (stack_marking_enabled)
			mark_tree_stack(bdd);
		else
			mark_tree_rec(bdd);
	}

	/** the recursive version f mark_tree */
	private final void mark_tree_rec(int bdd) {
		if (bdd < 2)
			return;
		if (isNodeMarked(bdd))
			return;
		mark_node(bdd);
		mark_tree(getLow(bdd));
		mark_tree_rec(getHigh(bdd));
	}

	/**
	 * non recursive version of mark tree
	 * <p>
	 * to use this function, you MUST know the maximum depth of the tree and tell
	 * it to NodeTable by calling tree_depth_changed()
	 * 
	 * @see #mark_tree_rec
	 * @see #tree_depth_changed
	 * @see #enableStackMarking
	 */
	private final void mark_tree_stack(int bdd) {
		// ok, it works like this:
		// we dont want to do recursive calls in such a tight functions so we do an
		// artifical recursive call by haveing out own stack. the stack is "mark_stack"
		// and it is important to have the right size. this is why the user must call
		// recursive_mark_tree() as soon as the tree depth changes

		// if its terminal, then we are already done
		if (bdd < 2)
			return;

		// insert the first one
		int tos = 0; // top of stack
		mark_stack[tos++] = bdd;
		mark_node(bdd);

		// here we go, recursively mark the nodes in this tree:
		while (tos > 0) {
			int next = mark_stack[--tos];
			int tmp = getLow(next);
			if (tmp > 1 && !isNodeMarked(tmp)) {
				mark_node(tmp);
				mark_stack[tos++] = tmp;
			}

			tmp = getHigh(next);
			if (tmp > 1 && !isNodeMarked(tmp)) {
				mark_node(tmp);
				mark_stack[tos++] = tmp;
			}
		}
	}

	/** recursively unmark nodes, used by some internal functions */
	public final void unmark_tree(int bdd) {
		if (bdd < 2)
			return;
		if (!isNodeMarked(bdd))
			return;
		unmark_node(bdd);
		unmark_tree(getLow(bdd));
		unmark_tree(getHigh(bdd));
	}

	public final void mark_node(int bdd) {
		t_var[bdd] |= NODE_MARK;
	}

	public final void unmark_node(int bdd) {
		t_var[bdd] &= NODE_UNMARK;
	}

	public final boolean isNodeMarked(int bdd) {
		return (t_var[bdd] & NODE_MARK) != 0;
	}

	// ------- [ debug ]
	// -----------------------------------------------------------------------

	/* return the amount of internally allocated memory in bytes */
	public long getMemoryUsage() {
		long ret = 0;

		if (t_var != null)
			ret += t_var.length * 4L;
		if (t_low != null)
			ret += t_low.length * 4L;
		if (t_high != null)
			ret += t_high.length * 4L;
		if (t_next != null)
			ret += t_next.length * 4L;
		if (t_prev != null)
			ret += t_prev.length * 4L;
		if (t_ref != null)
			ret += t_ref.length * 2L;
		if (work_stack != null)
			ret += work_stack.length * 4L;
		if (mark_stack != null)
			ret += mark_stack.length * 4L;

		return ret;
	}

	/**
	 * count the number of ROOT bdd nodes.
	 *
	 */
	public int countRootNodes() {
		int c = 0;
		for (int i = 0; i < table_size; i++)
			if (isValid(i) && (getRef(i) > 0 && getRef(i) != MAX_REFCOUNT))
				c++;
		return c;
	}

	protected void show_tuple(int i) {
		JDDConsole.out.println("" + i + "\t" + getVar(i) + "\t" + getLow(i) + "\t" + getHigh(i) + "\t: " + getRef(i));
	}

	protected void show_table() {
		JDDConsole.out.println("Node-table:");
		for (int i = 0; i < table_size; i++)
			if (isValid(i))
				show_tuple(i);
	}

	protected void show_table_all() {
		JDDConsole.out.println("Node-table (complete):");
		for (int i = 0; i < table_size; i++)
			show_tuple(i);
	}

	// --------------------------------------------------------------------

	void check() {

		// see if the number of free nodes is correct
		int c = 2, b = 0;
		for (int i = 2; i < table_size; i++)
			if (isValid(i))
				c++;
			else
				b++;
		Test.check(c == (table_size - free_nodes_count), "Invalid # of free nodes: #live= " + c + ", table_size="
				+ table_size + ", free_nodes_count=" + free_nodes_count);

		// see if a nodes children point to invalid entries:
		for (int i = 0; i < table_size; i++) {
			if (isValid(i)) {
				if (getLow(i) < 0 || getHigh(i) < 0) {
					show_tuple(i);
					Test.check(false, "Invalied node entry");
				}
				if ((getLow(i) > 1 && !isValid(getLow(i))) || (getHigh(i) > 1 && !isValid(getHigh(i)))) {
					System.err.println();
					show_tuple(i);
					show_tuple(getLow(i));
					show_tuple(getHigh(i));
					Test.check(false);
				}
			}
		}

		if (table_size > 100) {
			// out.println("(omitting slow parts of NodeTable.check(), table too large)");
			return;
		}

		// stupid O(N * N) test to see if there are two of any nodes in the table
		for (int i = 0; i < table_size; i++) {
			if (isValid(i)) {
				for (int j = i + 1; j < table_size; j++) {
					if (getVar(i) == getVar(j) && getLow(i) == getLow(j) && getHigh(i) == getHigh(j)) {
						JDDConsole.out.println("Duplicate entries in NodeTable (" + i + " and " + j + "): ");
						show_tuple(i);
						show_tuple(j);
						System.exit(20);
					}
				}
			}
		}
	}

	// --------------------------------------------------------
	/** show some statistics ... */
	public void showStats() {

		JDDConsole.out.println("NT nodes/free/#grow/grow-time/dead/root: " +
				table_size + "/" + free_nodes_count + "/" + stat_nt_grow + "/" + stat_grow_time +
				"/" + dead_nodes + "/" + countRootNodes());

		JDDConsole.out.println("HT chain/access: "
				+ ht_chain + "/" + stat_lookup_count);

		JDDConsole.out.println("GC #times/#freed/signal-time/gc-time: " +
				stat_gc_count + "/" + stat_gc_freed + "/" + stat_notify_time + "/" + stat_gc_time);
	}

	// --[ recursive node test operators
	// ]------------------------------------------------------
	private String check_say = null;

	/**
	 * check if all nodes are ok. it will test validaty and ref-count of nodes in
	 * the table
	 */
	public void check_all_nodes() {
		for (int i = 0; i < work_stack_tos; i++)
			check_node(work_stack[i]);

		for (int i = 0; i < table_size; i++)
			if (isValid(i) && getRefPlain(i) > 0)
				check_node(i);
	}

	/** check if some node is ok. it actuallt check the whole tree below the node */
	public void check_node(int node, String str) {
		check_say = str;
		check_node(node);
	}

	private void check_node(int node) {
		if (node < 2)
			return;
		if (!isValid(node)) {
			show_tuple(node);
			Test.check(false, "Node " + node + " invalid " + ((check_say != null) ? check_say : ""));
		}

		// XXX: this is gode, but we should mark nodes so we dont check them multiple
		// times if we are doing anything recursive!
		// check_node( getLow(node));
		// check_node( getHigh(node));
	}

	private int count_free_nodes() {
		int ret = 0, root = first_free_node;
		while (root != 0) {
			ret++;
			root = getNext(root);
		}
		return ret;
	}

	public int debug_compute_root_nodes() {
		int c = 0;

		for (int i = 0; i < this.table_size; ++i) {
			if (this.isValid(i) && this.getRef(i) > 0 && this.getRef(i) != 32767) {
				++c;
			}
		}

		return c;
	}

	public NodeTableStats getStats() {
		return new NodeTableStats(this.table_size, this.free_nodes_count, this.stat_nt_grow, this.stat_grow_time,
				this.dead_nodes, this.debug_compute_root_nodes(), this.ht_chain, this.stat_lookup_count,
				this.stat_gc_count, this.stat_gc_freed, this.stat_gc_time, this.stat_notify_time);
	}

	// -------------- [testbed] ----------------------------
	/** testbench. do not call */
	public static void internal_test() {
		Test.start("NodeTable");

		NodeTable nt = new NodeTable(10);
		// nt.show_table(); nt.show_unused();

		// NOT WORKING ANYMORE
		// Test.check(nt.table_size == 10 && nt.free_nodes_tos == 8, "Table ok before
		// grow");
		nt.add(4, 0, 1);
		Test.check(nt.table_size == nt.free_nodes_count + 3, "Table ok after grow"); // bad test, I know
		nt.check();

		// now, this is not a test, its just for profiling huge grows:
		int MAX = 15;
		nt = new NodeTable(MAX);
		int last = 0;
		for (int i = 2; i < MAX; i++)
			last = nt.add(i, last, last);
		nt.check();
		nt.grow();
		nt.check();
		nt.grow();
		nt.check();
		nt.grow();
		nt.check();

		// test the hash-table stuff
		nt = new NodeTable(10);
		// save by work_stack
		int a = nt.add(4, 0, 1);
		nt.work_stack[0] = a;
		nt.work_stack_tos++;

		// save by ref
		int b = nt.add(4, 1, 0);
		nt.ref(b);

		// dont save:
		int c = nt.add(3, 0, 1);
		Test.checkEquality(nt.count_free_nodes(), nt.free_nodes_count, "free node count correct (1)");

		nt.gc();
		Test.check(nt.isValid(a), "saved by work_stack");
		Test.check(nt.isValid(b), "saved by ref");
		Test.check(!nt.isValid(c), "should have been removed");
		Test.checkEquality(nt.count_free_nodes(), nt.free_nodes_count, "free node count correct (2)");

		nt.grow();
		Test.check(nt.isValid(a), "saved by work_stack");
		Test.check(nt.isValid(b), "saved by ref");
		Test.check(!nt.isValid(c), "should have been removed");
		Test.checkEquality(nt.count_free_nodes(), nt.free_nodes_count, "free node count correct (3)");

		Test.end();
	}

}
