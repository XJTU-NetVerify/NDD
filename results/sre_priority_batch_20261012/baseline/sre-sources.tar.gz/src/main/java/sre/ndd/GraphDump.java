package sre.ndd;

import com.google.gson.Gson;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Optional post-timing diagnostic graph export; cubes preserve Boolean meaning. */
public final class GraphDump {
    public static void write(int root, String path) {
        Map<String,Object> result = new LinkedHashMap<>();
        int[] widths = new int[NDD.getFieldNum()+1];
        for (int i=0;i<widths.length;++i) widths[i]=NDD.fieldWidth(i);
        result.put("widths",widths); result.put("root",root);
        Map<Integer,Object> nodes = new LinkedHashMap<>();
        ArrayDeque<Integer> pending = new ArrayDeque<>(); pending.add(root);
        while(!pending.isEmpty()) {
            int id=pending.remove(); if(id<=1 || nodes.containsKey(id)) continue;
            int field=NDD.getField(id), count=NDD.getEdgeCount(id);
            List<Object> edges=new ArrayList<>();
            for(int i=0;i<count;++i) {
                int child=NDD.getEdgeTarget(id,i), label=NDD.getEdgeLabel(id,i);
                Map<String,Object> edge=new LinkedHashMap<>();edge.put("target",child);
                edge.put("labelToken",label);
                edge.put("cubes",NDD.labelCubes(field,label,widths[field]));
                edges.add(edge); pending.add(child);
            }
            Map<String,Object> node=new LinkedHashMap<>();node.put("field",field);node.put("edges",edges);
            nodes.put(id,node);
        }
        result.put("nodes",nodes);
        try { Files.write(Paths.get(path), new Gson().toJson(result).getBytes(StandardCharsets.UTF_8)); }
        catch(java.io.IOException failure) { throw new IllegalStateException(failure); }
        System.out.println("diagnostic_graph_nodes:"+nodes.size());
    }
}
