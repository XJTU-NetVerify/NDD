package sre.ndd;

import main.NDDController;
import controlplane.network.NDDRouter;
import controlplane.route.NDDRoute;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Checks complete Boolean route/FIB conditions after the timed SRE phases.
 * Each canonical DAG receives a 64-bit structural hash; the sorted collection
 * of route descriptors and hashes is then SHA-256 digested. */
public final class SemanticCheck {
    public static void print() {
        long start = System.nanoTime(); NDD.clearFingerprints();
        ArrayList<String> rows = new ArrayList<>();
        for (NDDRouter router : NDDController.cpExecutor.getRouters().values()) {
            for (NDDSortedMultiList list : router.getGlobalRib().getRib().values())
                for (NDDSortedMultiListItem item : list.flat()) {
                    NDDRoute r = (NDDRoute)item;
                    String wanted = System.getProperty("sre.ndd.debugRootHash");
                    if (wanted != null && wanted.equals(Long.toUnsignedString(NDD.fingerprint(r.getArriveTC()), 16))) {
                        GraphDump.write(r.getArriveTC(), System.getProperty("sre.ndd.debugGraphFile"));
                        System.clearProperty("sre.ndd.debugRootHash");
                    }
                    rows.add("rib|" + router.getRouterName() + "|" + r.getPrefix() + "|" + r.getProtocol()
                            + "|" + r.getNextHop() + "|" + r.getOutPort() + "|" + r.getMetric()
                            + "|" + Long.toUnsignedString(NDD.fingerprint(r.getArriveTC()), 16)
                            + "|" + Long.toUnsignedString(NDD.fingerprint(r.getListTC()), 16));
                }
            for (Map.Entry<?, NDDSortedMultiList> e : router.getFib().getFib().entrySet())
                for (NDDSortedMultiListItem item : e.getValue().flat())
                    rows.add("fib|" + router.getRouterName() + "|" + e.getKey()
                            + "|" + Long.toUnsignedString(NDD.fingerprint(item.getArriveTC()), 16)
                            + "|" + Long.toUnsignedString(NDD.fingerprint(item.getListTC()), 16));
        }
        Collections.sort(rows);
        String dump = System.getProperty("sre.ndd.checksumFile");
        if (dump != null) try {
            java.nio.file.Files.write(java.nio.file.Paths.get(dump), rows, StandardCharsets.UTF_8);
        } catch (java.io.IOException failure) { throw new IllegalStateException(failure); }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            for (String row : rows) digest.update((row + "\n").getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : digest.digest()) hex.append(String.format("%02x", b & 255));
            System.out.println("semantic_condition_rows:" + rows.size());
            System.out.println("semantic_condition_sha256:" + hex);
        } catch (Exception failure) { throw new IllegalStateException(failure); }
        NDD.clearFingerprints();
        System.out.println("verification_seconds:" + (System.nanoTime() - start) / 1e9);
    }
}
