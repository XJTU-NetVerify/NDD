import java.lang.instrument.Instrumentation;
import java.lang.reflect.Field;
import java.nio.file.*;
import java.util.*;

/** Post-timing audit of actual adapter key hashes. No application mutations. */
public final class HashAuditAgent {
    public static void premain(String ignored, Instrumentation instrumentation) {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                Field ids = Class.forName("sre.ndd.NDD").getDeclaredField("ids"); ids.setAccessible(true);
                Map<?, ?> map = (Map<?, ?>) ids.get(null);
                Map<Integer, Integer> histogram = new HashMap<>();
                for (Object key : map.keySet()) histogram.merge(key.hashCode(), 1, Integer::sum);
                int max = histogram.values().stream().mapToInt(Integer::intValue).max().orElse(0);
                long pairs = 0; for (int count : histogram.values()) pairs += (long)count * (count - 1) / 2;
                String json = "{\"keys\":" + map.size() + ",\"distinct_hashes\":" + histogram.size()
                    + ",\"max_equal_hash_keys\":" + max + ",\"colliding_pairs\":" + pairs + "}\n";
                Files.writeString(Paths.get(System.getProperty("sre.ndd.auditFile")), json);
                System.out.println("hash_audit_keys:" + map.size());
                System.out.println("hash_audit_distinct:" + histogram.size());
                System.out.println("hash_audit_max_bucket:" + max);
            } catch (Throwable failure) { failure.printStackTrace(); }
        }, "adapter-hash-audit"));
    }
}
