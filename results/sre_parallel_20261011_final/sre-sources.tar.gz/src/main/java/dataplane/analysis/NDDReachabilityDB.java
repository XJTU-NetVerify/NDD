package dataplane.analysis;

import sre.ndd.NDD;
import application.config2spec.NDDConfig2spec;
import bdd.NDDTuple;
import controlplane.network.NDDPort;
import controlplane.network.NDDRouter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.Vector;
import java.util.stream.Collectors;
import main.Configuration;
import multimap.HashBasedTable;
import multimap.HashMultimap;
import multimap.Multimap;
import multimap.Table;
import util.NDDUtil;

public class NDDReachabilityDB implements AutoCloseable {
    public Table<NDDRouter, NDDRouter, HashSet<NDDReachabilityNode>> reachabilityForest;
    public Table<NDDRouter, NDDRouter, Integer> allPairReachability;
    public Table<NDDRouter, NDDRouter, Integer> pfecNums;
    public HashMap<NDDRouter, Integer> fwdPathNums;
    public Multimap<NDDPort, NDDReachabilityNode> in;
    public Multimap<NDDPort, NDDReachabilityNode> out;
    private int loopPrunes;
    private boolean closed;

    public NDDReachabilityDB() {
        reachabilityForest = HashBasedTable.create();
        // allPairReachability = HashBasedTable.create();
        pfecNums = HashBasedTable.create();
        fwdPathNums = new HashMap<>();
        in = HashMultimap.create();
        out = HashMultimap.create();
    }

    private void insertNode(NDDRouter src, NDDRouter dst, NDDReachabilityNode node) {
        if (reachabilityForest.contains(src, dst)) {
            HashSet<NDDReachabilityNode> set = reachabilityForest.get(src, dst);
            set.add(node);
            reachabilityForest.put(src, dst, set);
            // allPairReachability.put(src, dst, NDD.orTo(allPairReachability.get(src, dst),
            // node.tuple.getNDD()));
            int pfecN = pfecNums.get(src, dst);
            pfecNums.put(src, dst, pfecN + 1);
        } else {
            HashSet<NDDReachabilityNode> set = new HashSet<>();
            set.add(node);
            reachabilityForest.put(src, dst, set);
            // allPairReachability.put(src, dst, NDD.ref(node.tuple.getNDD()));
            pfecNums.put(src, dst, 1);
        }
    }

    public Table<NDDRouter, NDDRouter, Integer> getAllPairReachability() {
        if (allPairReachability == null) {
            allPairReachability = HashBasedTable.create();
            for (Table.Cell<NDDRouter, NDDRouter, HashSet<NDDReachabilityNode>> cell : reachabilityForest.cellSet()) {
                int stp = NDDUtil.orInBatch(
                        Objects.requireNonNull(cell.getValue())
                                .stream()
                                .map(node -> node.getTuple().getNDD())
                                .collect(Collectors.toSet()));
                allPairReachability.put(
                        Objects.requireNonNull(cell.getRowKey()),
                        Objects.requireNonNull(cell.getColumnKey()),
                        stp);
            }
        }
        return allPairReachability;
    }

    public void buildReachabilityTree(NDDRouter root) {
        // System.out.println("source: "+root.getRouterName());
        if (Configuration.FORWARD)
            buildReachabilityTree(root, NDDTuple.FULL);
        else
            buildReachabilityTree(root, new NDDTuple(root.getPrefixBDD(), NDD.getTrue()));
        // System.out.println();
    }

    public void buildReachabilityTree(NDDRouter root, NDDTuple tuple) {
        NDDReachabilityNode node = new NDDReachabilityNode(root, tuple, new Vector<>());
        node.setSource(root);
        if (Configuration.FORWARD)
            traverseForward(root, node);
        else
            traverseBackward(root, node);
    }

    private void traverseForward(NDDRouter root, NDDReachabilityNode curNode) {
        boolean terminate = true;
        for (NDDPort port : curNode.router.getPorts().values()) {
            NDDReachabilityNode nxtNode = forward(root, curNode, port);
            // if (nxtNode != null) System.out.println(nxtNode.router.getRouterName());
            if (nxtNode != null) {
                terminate = false;
                traverseForward(root, nxtNode);
            }
        }
        if (terminate)
            fwdPathNums.put(root, fwdPathNums.getOrDefault(root, 0) + 1);
    }

    private void traverseBackward(NDDRouter root, NDDReachabilityNode curNode) {
        boolean terminate = true;
        for (NDDPort port : curNode.router.getPorts().values()) {
            NDDReachabilityNode nxtNode = backward(root, curNode, port);
            if (nxtNode != null) {
                terminate = false;
                traverseBackward(root, nxtNode);
            }
        }
        if (terminate)
            fwdPathNums.put(root, fwdPathNums.getOrDefault(root, 0) + 1);
    }

    public void buildReachabilityTreeLazy(NDDRouter root) {
        buildReachabilityTreeLazy(root, NDDTuple.FULL);
    }

    public void buildReachabilityTreeLazy(NDDRouter root, NDDTuple tuple) {
        NDDReachabilityNode node = new NDDReachabilityNode(root, tuple, new Vector<>());
        node.setSource(root);
        traverseLazy(root, node, tuple);
    }

    HashSet<NDDRouter> hs = new HashSet<>();

    private void traverseLazy(NDDRouter root, NDDReachabilityNode curNode, NDDTuple tuple) {
        if (!hs.contains(curNode.router)) {
            NDDDPAnalyzer.computeFwdBDD(curNode.router, tuple.getFirst());
            NDDDPAnalyzer.computeAclBDD(curNode.router);
            hs.add(curNode.router);
        }
        for (NDDPort port : curNode.router.getPorts().values()) {
            NDDReachabilityNode nxtNode;
            if (Configuration.FORWARD)
                nxtNode = forward(root, curNode, port);
            else
                nxtNode = backward(root, curNode, port);
            if (nxtNode != null)
                traverseLazy(root, nxtNode, tuple);
        }
    }

    private NDDReachabilityNode forward(NDDRouter root, NDDReachabilityNode curNode, NDDPort outPort) {
        if (outPort.isEdge()) {
            NDDTuple finalTuple = NDDTuple.intersect(curNode.tuple, outPort.getPortFwdNDD(),
                    outPort.getPortAclOutNDD());
            if (!finalTuple.isEmpty()) {
                NDDRouter finalRouter = outPort.getRouter();
                Vector<NDDRouter> finalPath = new Vector<>(curNode.path);
                finalPath.add(finalRouter);
                NDDReachabilityNode finalNode = new NDDReachabilityNode(finalRouter, outPort, finalTuple, finalPath);
                finalNode.setSource(root);
                insertNode(root, outPort.getRouter(), finalNode);
                out.put(outPort, finalNode);
            } else {
                finalTuple.releaseNddOwnership();
            }
            return null;
        } else if (outPort.isBlackhole()) {
            return null;
        } else {
            NDDPort nxtPort = outPort.getLinkedPort();
            if (nxtPort == null)
                return null;

            NDDTuple newTuple = NDDTuple.intersect(curNode.tuple, outPort.getPortFwdNDD(), NDD.getTrue());
            newTuple = NDDTuple.intersect(newTuple, NDD.getTrue(), outPort.getPortAclOutNDD()); // ACLout
            newTuple = NDDTuple.intersect(newTuple, NDD.getTrue(), nxtPort.getPortAclInNDD()); // ACLin
            if (newTuple.isEmpty())
            {
                newTuple.releaseNddOwnership();
                return null;
            }

            NDDRouter nxtRouter = nxtPort.getRouter();

            Vector<NDDRouter> newPath = new Vector<>(curNode.path);
            newPath.add(curNode.router);

            NDDReachabilityNode nxtNode = new NDDReachabilityNode(nxtRouter, newTuple, newPath);
            nxtNode.setSource(root);

            if (nxtNode.isLoopDetected)
            {
                loopPrunes++;
                nxtNode.releaseNddOwnership();
                return null;
            }

            out.put(outPort, nxtNode);
            in.put(nxtPort, nxtNode);

            return nxtNode;
        }
    }

    @Deprecated
    private NDDReachabilityNode backward(NDDRouter root, NDDReachabilityNode curNode, NDDPort inPort) {
        NDDPort prePort = inPort.getLinkedPort();
        if (prePort == null)
            return null;

        NDDRouter preRouter = prePort.getRouter();

        Vector<NDDRouter> newPath = new Vector<>(curNode.path);
        newPath.add(curNode.router);

        NDDTuple newTuple = NDDTuple.intersect(curNode.tuple, prePort.getPortFwdNDD(), NDD.getTrue());
        newTuple = NDDTuple.intersect(newTuple, NDD.getTrue(), prePort.getPortAclOutNDD()); // ACLout
        newTuple = NDDTuple.intersect(newTuple, NDD.getTrue(), inPort.getPortAclInNDD()); // ACLin
        if (newTuple.isEmpty()) {
            fwdPathNums.put(root, fwdPathNums.getOrDefault(root, 0) + 1);
            return null;
        }

        NDDReachabilityNode nxtNode = new NDDReachabilityNode(preRouter, newTuple, newPath);

        if (nxtNode.isLoopDetected) {
            fwdPathNums.put(root, fwdPathNums.getOrDefault(root, 0) + 1);
            return null;
        }

        in.put(inPort, nxtNode);
        out.put(prePort, nxtNode);

        insertNode(preRouter, root, nxtNode);

        return nxtNode;
    }

    public int getNumOfPFEC() {
        return pfecNums.values().stream().reduce(0, Integer::sum);
    }

    public int getNumOfFwdPath() {
        return fwdPathNums.values().stream().reduce(0, Integer::sum);
    }

    public int getLoopPrunes() {
        return loopPrunes;
    }

    public int getStoredNodeCount() {
        Set<NDDReachabilityNode> nodes = java.util.Collections.newSetFromMap(
                new java.util.IdentityHashMap<>());
        nodes.addAll(in.values());
        nodes.addAll(out.values());
        reachabilityForest.values().forEach(nodes::addAll);
        return nodes.size();
    }

    /** Replaces complete source rows and transfers node ownership from candidate. */
    public void replaceSourcesFrom(NDDReachabilityDB candidate,
            Collection<NDDRouter> sources) {
        Set<NDDRouter> selected = new HashSet<>(sources);
        Set<NDDReachabilityNode> retired = java.util.Collections.newSetFromMap(
                new java.util.IdentityHashMap<>());
        for (NDDRouter source : selected) {
            reachabilityForest.row(source).values().forEach(retired::addAll);
        }
        for (NDDReachabilityNode node : in.values()) {
            if (selected.contains(node.getSource())) retired.add(node);
        }
        for (NDDReachabilityNode node : out.values()) {
            if (selected.contains(node.getSource())) retired.add(node);
        }
        in.values().removeAll(retired);
        out.values().removeAll(retired);
        for (NDDRouter source : selected) {
            reachabilityForest.row(source).clear();
            pfecNums.row(source).clear();
            fwdPathNums.remove(source);
        }
        invalidateAllPairReachability();
        retired.forEach(NDDReachabilityNode::releaseNddOwnership);

        for (NDDRouter source : selected) {
            Map<NDDRouter, HashSet<NDDReachabilityNode>> forestRow =
                    new LinkedHashMap<>(candidate.reachabilityForest.row(source));
            candidate.reachabilityForest.row(source).clear();
            forestRow.forEach((destination, nodes) ->
                    reachabilityForest.put(source, destination, nodes));

            Map<NDDRouter, Integer> countRow = new LinkedHashMap<>(
                    candidate.pfecNums.row(source));
            candidate.pfecNums.row(source).clear();
            countRow.forEach((destination, count) ->
                    pfecNums.put(source, destination, count));
            Integer paths = candidate.fwdPathNums.remove(source);
            if (paths != null) fwdPathNums.put(source, paths);
        }
        for (Map.Entry<NDDPort, NDDReachabilityNode> entry
                : new ArrayList<>(candidate.in.entries())) {
            if (!selected.contains(entry.getValue().getSource())) continue;
            in.put(entry.getKey(), entry.getValue());
            candidate.in.remove(entry.getKey(), entry.getValue());
        }
        for (Map.Entry<NDDPort, NDDReachabilityNode> entry
                : new ArrayList<>(candidate.out.entries())) {
            if (!selected.contains(entry.getValue().getSource())) continue;
            out.put(entry.getKey(), entry.getValue());
            candidate.out.remove(entry.getKey(), entry.getValue());
        }
        candidate.invalidateAllPairReachability();
    }

    private void invalidateAllPairReachability() {
        if (allPairReachability == null) return;
        allPairReachability.values().forEach(NDD::deref);
        allPairReachability = null;
    }

    @Override
    public void close() {
        if (closed) return;
        Set<NDDReachabilityNode> nodes = java.util.Collections.newSetFromMap(
                new java.util.IdentityHashMap<>());
        if (in != null) nodes.addAll(in.values());
        if (out != null) nodes.addAll(out.values());
        if (reachabilityForest != null) {
            reachabilityForest.values().forEach(nodes::addAll);
        }
        nodes.forEach(NDDReachabilityNode::releaseNddOwnership);
        if (allPairReachability != null) {
            allPairReachability.values().forEach(NDD::deref);
        }
        closed = true;
    }

    public void clear() {
        close();
        reachabilityForest = null;
        allPairReachability = null;
        pfecNums = null;
        fwdPathNums = null;
        in = null;
        out = null;
    }

    public void reset() {
        close();
        reachabilityForest = HashBasedTable.create();
        allPairReachability = HashBasedTable.create();
        pfecNums = HashBasedTable.create();
        fwdPathNums = new HashMap<>();
        in = HashMultimap.create();
        out = HashMultimap.create();
        loopPrunes = 0;
        closed = false;
    }

    public void printReachability() {
        System.out.println("print reach");
        getAllPairReachability();
        try {
            // string path =
            // "/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/exp/fattree/bgp/"+NDDConfig2spec.dataset+"/OutNDD/test/src_reach";
            String path = "/home/augists/Cheney/SRE-Benchmark/variants/ndd/networks/exp/fattree/bgp/" + NDDConfig2spec.dataset
                    + "/OutBddVector/test/src_reach";
            FileWriter fw = new FileWriter(path, false);
            PrintWriter pw = new PrintWriter(fw);
            pw.println("check reachability");
            for (NDDRouter src : allPairReachability.rowKeySet()) {
                pw.println("row");
                for (NDDRouter dst : allPairReachability.columnKeySet()) {
                    pw.println("col");
                    Integer packets = allPairReachability.get(src, dst);
                    if (packets != null) {
                        pw.println("========= check 1 =========");
                        pw.println(src.getRouterName() + " " + dst.getRouterName() + " " + NDD.satCount(packets));
                        pw.flush();
                    }
                }
            }
            pw.close();
        } catch (IOException e) {
            // TODO: handle exception
        }
    }
}
