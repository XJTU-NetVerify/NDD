package controlplane.route;

import java.util.Comparator;
import java.util.Objects;

import sre.ndd.NDD;
import org.jetbrains.annotations.NotNull;

import controlplane.network.NDDPort;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import controlplane.route.builder.NDDOspfRouteBuilder;

public class NDDOspfRoute extends NDDDynamicRoute {
    int _AD;
    long _metric;

    public NDDOspfRoute(
            Prefix prefix,
            Ip nextHop,
            NDDPort outPort,
            int arriveTC,
            int listTC,
            int innerIdx,
            int outerIdx,
            NDDSortedMultiList list,
            Path<String> path,
            boolean dirty,
            int AD,
            long metric
    ) {
        super(prefix, nextHop, outPort, arriveTC, listTC, innerIdx, outerIdx, list, path, dirty);
        _AD = AD;
        _metric = metric;
    }

    @Override
    public RoutingProtocol getProtocol() {
        return RoutingProtocol.OSPF;
    }

    @Override
    public int getAD() {
        return _AD;
    }

    @Override
    public Long getMetric() {
        return _metric;
    }

    public void setMetric(long metric) {
        _metric = metric;
    }

    /** Owned copy for installation into a different RIB layer. */
    public NDDOspfRoute detachedCopy() {
        Path<String> path = new Path<>();
        path.addAll(_path);
        return new NDDOspfRouteBuilder()
                .setPrefix(_prefix)
                .setNextHop(_nextHop)
                .setOutPort(_outPort)
                .setPath(path)
                .setAD(_AD)
                .setMetric(_metric)
                .setArriveTC(NDD.ref(_arriveTC))
                .setListTC(NDD.ref(_listTC))
                .build();
    }

    @Override
    public int compareTo(@NotNull NDDSortedMultiListItem o) {
        if (o instanceof NDDOspfRoute) {
            return Comparator
                    .comparing(NDDOspfRoute::getMetric, Comparator.reverseOrder())
                    .compare(this, (NDDOspfRoute) o);
        }
        else {
            return super.compareTo(o);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        NDDOspfRoute ospfRoute = (NDDOspfRoute) o;
        return _AD == ospfRoute._AD &&
                _metric == ospfRoute._metric;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), _AD, _metric);
    }

    @Override
    public String toString() {
        return _prefix.toString()
                + "\t" + _outPort
                + "\t" + _nextHop
                + "\t" + _path
                + "\t" + _arriveTC
                + "\t" + _listTC
                + "\tOSPF";
    }
}
