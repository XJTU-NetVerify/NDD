package controlplane.rib;

import sre.ndd.NDD;
import multimap.HashBasedTable;
import multimap.HashMultimap;
import multimap.ImmutableList;
import multimap.Table;
import multimap.Multimap;

import org.jetbrains.annotations.NotNull;
import controlplane.network.NDDPort;
import controlplane.network.Port;
import controlplane.process.NDDProcess;
import controlplane.process.Process;
import controlplane.route.NDDRoute;
import controlplane.route.NDDOspfRoute;
import controlplane.route.Route;
import datamodel.ipv4.Ip;
import datamodel.ipv4.Prefix;
import datamodel.list.*;
import dataplane.fib.Fib;
import dataplane.fib.ForwardingRule;
import dataplane.fib.NDDFib;
import dataplane.fib.NDDForwardingRule;
import main.Controller;
import main.NDDController;

import multimap.javax.annotation.Nonnull;
import multimap.javax.annotation.Nullable;
import java.util.*;

public class NDDRib implements SortedMultiListOwner {
    /**
     * From batfish FibImpl: Helps perform recursive route resolution and maintain
     * the route chain
     */
    private static final class NDDResolutionTreeNode {
        private final @Nonnull NDDRoute _route;
        private final @Nullable Ip _finalNextHopIp;

        private final @Nonnull List<NDDResolutionTreeNode> _children;

        /** Use static factories for sanity */
        private NDDResolutionTreeNode(@NotNull NDDRoute route, @Nullable Ip finalNextHopIp,
                @NotNull List<NDDResolutionTreeNode> children) {
            _route = route;
            _finalNextHopIp = finalNextHopIp;
            _children = children;
        }

        static NDDResolutionTreeNode withParent(NDDRoute route, @Nullable NDDResolutionTreeNode parent,
                @Nullable Ip finalNextHopIp) {
            NDDResolutionTreeNode child = new NDDResolutionTreeNode(route, finalNextHopIp, new LinkedList<>());
            if (parent != null) {
                parent.addChild(child);
            }
            return child;
        }

        static NDDResolutionTreeNode root(@Nonnull NDDRoute route) {
            return new NDDResolutionTreeNode(route, null, new LinkedList<>());
        }

        @Nonnull
        public NDDRoute getRoute() {
            return _route;
        }

        @Nullable
        public Ip getFinalNextHopIp() {
            return _finalNextHopIp;
        }

        @Nonnull
        public List<NDDResolutionTreeNode> getChildren() {
            return _children;
        }

        private void addChild(NDDResolutionTreeNode child) {
            _children.add(child);
        }
    }

    private static final int MAX_DEPTH = 10;

    NDDProcess process;
    Map<Prefix, NDDSortedMultiList> rib;
    Multimap<Integer, Prefix> networks;

    public NDDRib() {
        rib = new TreeMap<>();
        networks = HashMultimap.create();
    }

    public NDDRib(NDDProcess process) {
        this();
        this.process = process;
    }

    public void insert(NDDRoute route) {
        Prefix prefix = route.getPrefix();
        NDDSortedMultiList list;
        if (rib.containsKey(prefix)) {
            list = rib.get(prefix);
        } else {
            list = new NDDSortedMultiList(this);
            networks.put(prefix.getPreLength(), prefix);
        }
        list.insert(route);
        rib.put(prefix, list);
    }

    public void insert(Prefix prefix, NDDSortedMultiList routes) {
        rib.put(prefix, routes);
        networks.put(prefix.getPreLength(), prefix);
    }

    /** Detach one prefix without changing its route objects. */
    public NDDSortedMultiList removePrefix(Prefix prefix) {
        NDDSortedMultiList removed = rib.remove(prefix);
        if (removed != null) networks.remove(prefix.getPreLength(), prefix);
        return removed;
    }

    /** Attach a detached prefix list. */
    public void attachPrefix(Prefix prefix, NDDSortedMultiList routes) {
        if (rib.containsKey(prefix)) {
            throw new IllegalStateException("prefix already attached: " + prefix);
        }
        insert(prefix, routes);
    }

    public void install(NDDRib globalRib, boolean ecmp) {
        HashSet<Prefix> prefixes = new HashSet<>();
        rib.forEach((prefix, routes) -> {
            NDDSortedMultiList detached = new NDDSortedMultiList();
            routes.flat().forEach(item -> detached.insert(item instanceof NDDOspfRoute
                    ? ((NDDOspfRoute) item).detachedCopy() : item));
            if (!globalRib.getRib().containsKey(prefix)) {
                globalRib.insert(prefix, detached);
            } else {
                prefixes.add(prefix);
                detached.flat().forEach(route -> globalRib.insert((NDDRoute) route));
            }
        });
        prefixes.forEach(prefix -> {
            NDDSortedMultiList list = globalRib.getRib().get(prefix);
            NDDController.bddManager.getBDDTCWrapper().calTC(list, ecmp);
        });
    }

    public void install(NDDFib fib) {
        for (Prefix prefix : rib.keySet()) {
            NDDSortedMultiList routes = rib.get(prefix);
            NDDSortedMultiList fwdRules;
            if (routes.flat().stream().allMatch(item -> ((NDDRoute) item).getOutPort() != null)) {
                fwdRules = routes.stream()
                        .map(list -> list
                                .stream()
                                .map(item -> (NDDRoute) item)
                                .map(NDDForwardingRule::new)
                                .collect(ArrayList<NDDSortedMultiListItem>::new, ArrayList<NDDSortedMultiListItem>::add,
                                        ArrayList<NDDSortedMultiListItem>::addAll))
                        .collect(NDDSortedMultiList::new, NDDSortedMultiList::add, NDDSortedMultiList::addAll);
            } else {
                fwdRules = new NDDSortedMultiList();
                for (NDDSortedMultiListItem item : routes.flat()) {
                    NDDRoute route = (NDDRoute) item;
                    if (route.getOutPort() == null) {
                        resolveRoute(route).forEach(fwdRules::insert);
                    } else {
                        fwdRules.insert(new NDDForwardingRule(route));
                    }
                }
                NDDController.bddManager.getBDDTCWrapper().calTC(fwdRules, fib.getRouter().ecmp());
                fwdRules.cleanDead();
            }
            fib.insert(prefix, fwdRules);
        }
    }

    public int[] cleanDeadRoute() {
        int total = 0;
        int remain = 0;
        Iterator<Map.Entry<Prefix, NDDSortedMultiList>> itr = rib.entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry<Prefix, NDDSortedMultiList> entry = itr.next();
            int[] statistic = entry.getValue().cleanDead();
            total += statistic[0];
            remain += statistic[1];
            if (entry.getValue().isEmpty())
                itr.remove();
        }
        return new int[] { total, remain };
    }

    public int[] getStats() {
        int total = 0;
        int valid = 0;
        for (NDDSortedMultiList list : rib.values()) {
            int[] tmp = list.getStats();
            total += tmp[0];
            valid += tmp[1];
        }
        return new int[] { total, valid };
    }

    /**
     * Helper function for computing "igp cost to next hop" for ebgp routes.
     * Longest prefix match. For a specific prefix length, a next hop ip can match
     * at most one prefix.
     */
    public Table<Long, NDDPort, Integer> query(Ip ip) {
        // (metric, out port) -> tc
        Table<Long, NDDPort, Integer> tbl = HashBasedTable.create();
        int prefixLength = 32;
        int alMatched = NDD.getFalse();
        int nAlMatched = NDD.getFalse();
        for (Map.Entry<Prefix, NDDSortedMultiList> entry : rib.entrySet()) {
            if (entry.getKey().getPreLength() != prefixLength) {
                prefixLength = entry.getKey().getPreLength();
                nAlMatched = NDD.ref(NDD.not(alMatched));
            }
            if (entry.getKey().ipMatch(ip)) {
                for (NDDSortedMultiListItem item : entry.getValue().flat()) {
                    NDDRoute route = (NDDRoute) item;
                    int delta = NDD.ref(NDD.and(route.getListTC(), nAlMatched));
                    int tc = NDD.getFalse();
                    if (tbl.contains(route.getMetric(), route.getOutPort())) {
                        tc = tbl.get(route.getMetric(), route.getOutPort());
                    }
                    tc = NDD.orTo(tc, delta);
                    tbl.put(route.getMetric(), route.getOutPort(), tc);
                    alMatched = NDD.orTo(alMatched, route.getListTC());
                }
            }
        }
        return tbl;
    }

    /**
     * Attempt to resolve a RIB route down to an interface route.
     *
     * @param route {@link Route} with a next hop IP to be resolved.
     * @return A map (interface name -&gt; last hop IP -&gt; last taken route) for
     */
    public Set<NDDForwardingRule> resolveRoute(NDDRoute route) {
        NDDResolutionTreeNode resolutionRoot = NDDResolutionTreeNode.root(route);
        buildResolutionTree(
                route,
                Ip.AUTO,
                new HashSet<>(),
                0,
                resolutionRoot);
        Set<NDDForwardingRule> collector = new HashSet<>();
        collect(resolutionRoot, new Stack<>(), collector);
        return collector;
    }

    public void collect(NDDResolutionTreeNode node, Stack<NDDRoute> stack, Set<NDDForwardingRule> collector) {
        if (node.getChildren().isEmpty() && node.getFinalNextHopIp() != null) {
            collector.add(new NDDForwardingRule(node._finalNextHopIp, ImmutableList.copyOf(stack)));
            return;
        }
        stack.push(node._route);
        for (NDDResolutionTreeNode child : node.getChildren()) {
            collect(child, stack, collector);
        }
        stack.pop();
    }

    public void buildResolutionTree(NDDRoute route,
            Ip mostRecentNextHopIp,
            Set<Prefix> seenNetworks,
            int depth,
            NDDResolutionTreeNode treeNode) {
        Prefix network = route.getPrefix();
        if (seenNetworks.contains(network) || depth > MAX_DEPTH) {
            // Don't enter a resolution loop
            return;
        }
        Set<Prefix> newSeenNetworks = new HashSet<>(seenNetworks);
        newSeenNetworks.add(network);

        NDDPort outPort = route.getOutPort();
        Ip nextHop = route.getNextHop();
        // Finally we have reached an interface route.
        if (outPort != null) {
            // Discard
            if (outPort.isBlackhole()) {
                NDDResolutionTreeNode.withParent(route, treeNode, Ip.AUTO);
            } else {
                // nextHop equals Ip.AUTO means this is a connected route.
                // otherwise, ospf route.
                NDDResolutionTreeNode.withParent(route, treeNode,
                        nextHop.equals(Ip.AUTO) ? mostRecentNextHopIp : nextHop);
            }
        } else {
            // todo
            NDDSortedMultiList matched = null;
            for (int preLen = 32; preLen >= 0 && matched == null; preLen--) {
                matched = query(nextHop, preLen);
            }
            if (matched != null) {
                // We have at least one valid longest-prefix match
                for (NDDSortedMultiListItem matchedRoute : matched.flat()) {
                    buildResolutionTree(
                            (NDDRoute) matchedRoute,
                            nextHop,
                            newSeenNetworks,
                            depth + 1,
                            NDDResolutionTreeNode.withParent((NDDRoute) matchedRoute, treeNode, null));
                }
            }
        }
    }

    public NDDSortedMultiList query(Ip ip, int prefixLength) {
        for (Prefix prefix : networks.get(prefixLength)) {
            if (prefix.ipMatch(ip))
                return rib.get(prefix);
        }
        return null;
    }

    public Map<Prefix, NDDSortedMultiList> getRib() {
        return rib;
    }

    public NDDProcess getProcess() {
        return process;
    }

    public void clear() {
        rib = null;
    }

    public void reset() {
        rib = new TreeMap<>();
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        rib.values().forEach(list -> builder.append(list.toString()).append("\n\n"));
        return builder.toString();
    }
}
