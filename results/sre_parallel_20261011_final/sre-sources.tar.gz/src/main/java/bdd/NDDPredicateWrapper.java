package bdd;

import sre.ndd.NDD;
import controlplane.network.PortName;
import datamodel.ipv4.Header;
import datamodel.ipv4.Prefix;
import datamodel.list.NDDSortedMultiList;
import datamodel.list.NDDSortedMultiListItem;
import dataplane.fib.NDDForwardingRule;
import java.util.*;

public class NDDPredicateWrapper {
    NDDManager manager;

    public NDDPredicateWrapper(NDDManager manager) {
        this.manager = manager;
    }

    public HashMap<PortName, Integer> getPortPredicates(NDDSortedMultiList rules, boolean ecmp, int fwd) {
        if (!ecmp) {
            return getPortPredicates(rules, fwd);
        }
        HashMap<PortName, Integer> portPredicates = new HashMap<>();

        int alreadyForwarded = NDD.getFalse();
        for (ArrayList<NDDSortedMultiListItem> list : rules) {
            int inner = NDD.getFalse();
            int notAlreadyForwarded = manager.filter(NDD.ref(NDD.not(alreadyForwarded)));

            if (NDD.isFalse(notAlreadyForwarded))
                break;

            for (NDDSortedMultiListItem item : list) {
                NDDForwardingRule rule = (NDDForwardingRule) item;
                PortName pName = rule.getOutPort();
                Prefix prefix = rule.getPrefix();
                int dstPrefix = manager.nddACLWrapper.encodeDstIPPrefix(prefix.getIp().asLong(), prefix.getPreLength());
                int care = NDD.ref(NDD.and(fwd, dstPrefix));
                if (!NDD.isFalse(care)) {
                    int tc = rule.getListTC();
                    int ruleBDD = NDD.ref(NDD.and(care, tc));

                    int toAdd = NDD.ref(NDD.and(ruleBDD, notAlreadyForwarded));
                    inner = NDD.orTo(inner, ruleBDD);

                    if (portPredicates.containsKey(pName)) {
                        portPredicates.put(pName, manager.orDerefBoth(toAdd, portPredicates.get(pName)));
                    } else {
                        portPredicates.put(pName, toAdd);
                    }
                }
                NDD.deref(care);
            }

            NDD.deref(notAlreadyForwarded);
            alreadyForwarded = manager.orDerefBoth(alreadyForwarded, inner);
        }
        NDD.deref(alreadyForwarded);

//        for (Map.Entry<PortName, NDD> predicate : portPredicates.entrySet()) {
//            System.out.println(predicate.getKey().getFullName());
//            NDD.printDot("/home/augists/Cheney/SRE-Benchmark/variants/ndd/NDD", predicate.getValue());
//            break;
//            // System.out.println(predicate.getKey().getFullName() + " " +
//            // NDD.satCount(predicate.getValue()));
//        }

        return portPredicates;
    }

    private HashMap<PortName, Integer> getPortPredicates(NDDSortedMultiList rules, int fwd) {
        HashMap<PortName, Integer> portPredicates = new HashMap<>();

        int alreadyForwarded = NDD.getFalse();
        for (NDDSortedMultiListItem item : rules.flat()) {
            int notAlreadyForwarded = manager.filter(NDD.ref(NDD.not(alreadyForwarded)));

            if (NDD.isFalse(notAlreadyForwarded))
                break;

            NDDForwardingRule rule = (NDDForwardingRule) item;
            PortName pName = rule.getOutPort();
            Prefix prefix = rule.getPrefix();
            int dstPrefix = manager.nddACLWrapper.encodeDstIPPrefix(prefix.getIp().asLong(), prefix.getPreLength());
            int care = NDD.ref(NDD.and(dstPrefix, fwd));
            if (!NDD.isFalse(care)) {
                int tc = rule.getListTC();
                int ruleBDD = NDD.ref(NDD.and(care, tc));

                int toAdd = NDD.andTo(notAlreadyForwarded, ruleBDD);
                alreadyForwarded = NDD.orTo(alreadyForwarded, ruleBDD);

                if (portPredicates.containsKey(pName)) {
                    portPredicates.put(pName, manager.orDerefBoth(toAdd, portPredicates.get(pName)));
                } else {
                    portPredicates.put(pName, toAdd);
                }
            }
            NDD.deref(care);
        }
        NDD.deref(alreadyForwarded);

        return portPredicates;
    }

    Map<Integer, Map<Header, Integer>> headerTCMemo = new HashMap<>();
    int memoHit = 0;

    public Map<Header, Integer> splitHeaderTC(int predicate) {
        if (!headerTCMemo.containsKey(predicate)) {
            Map<HeaderLabels, Integer> symbolic = splitByHeader(predicate, new HashMap<>());
            Map<Header, Integer> concrete = new HashMap<>();
            for (Map.Entry<HeaderLabels, Integer> entry : symbolic.entrySet()) {
                Collection<Header> headers = manager.nddACLWrapper.predVector2Header(entry.getKey().labels);
                for (Header header : headers) {
                    Integer previous = concrete.get(header);
                    if (previous == null) {
                        concrete.put(header, entry.getValue());
                    } else {
                        concrete.put(header, NDD.ref(NDD.or(previous, entry.getValue())));
                    }
                }
            }
            headerTCMemo.put(predicate, concrete);
        } else {
            memoHit++;
        }
        return headerTCMemo.get(predicate);
    }

    /**
     * Factor an NDD into header-label vectors and Link-only NDDs. This works for both declaration
     * orders: Header nodes update the vector, while Link nodes are rebuilt around every vector
     * returned by their children.
     */
    private Map<HeaderLabels, Integer> splitByHeader(int predicate,
            Map<Integer, Map<HeaderLabels, Integer>> memo) {
        Map<HeaderLabels, Integer> cached = memo.get(predicate);
        if (cached != null) return cached;

        Map<HeaderLabels, Integer> result = new HashMap<>();
        if (NDD.isFalse(predicate)) {
            memo.put(predicate, result);
            return result;
        }
        if (NDD.isTrue(predicate)) {
            int[] labels = new int[NDDACLWrapper.Field.num];
            Arrays.fill(labels, 1);
            result.put(new HeaderLabels(labels), NDD.getTrue());
            memo.put(predicate, result);
            return result;
        }

        int field = NDD.getField(predicate);
        NDDACLWrapper.Field headerField = NDDACLWrapper.Field.fromPhysicalField(field);
        int edgeCount = NDD.getEdgeCount(predicate);
        if (headerField != null) {
            for (int edge = 0; edge < edgeCount; edge++) {
                int label = NDD.getEdgeLabel(predicate, edge);
                Map<HeaderLabels, Integer> child = splitByHeader(NDD.getEdgeTarget(predicate, edge), memo);
                for (Map.Entry<HeaderLabels, Integer> entry : child.entrySet()) {
                    int[] labels = entry.getKey().labels.clone();
                    labels[headerField.logicalIndex] = label;
                    mergeOwned(result, new HeaderLabels(labels), NDD.ref(entry.getValue()));
                }
            }
        } else {
            for (int edge = 0; edge < edgeCount; edge++) {
                int label = NDD.getEdgeLabel(predicate, edge);
                Map<HeaderLabels, Integer> child = splitByHeader(NDD.getEdgeTarget(predicate, edge), memo);
                for (Map.Entry<HeaderLabels, Integer> entry : child.entrySet()) {
                    Map<Integer, Integer> branchEdges = new HashMap<>();
                    branchEdges.put(entry.getValue(), label);
                    int branch = NDD.ref(NDD.addAtField(field, branchEdges));
                    mergeOwned(result, entry.getKey(), branch);
                }
            }
        }
        memo.put(predicate, result);
        return result;
    }

    private static void mergeOwned(Map<HeaderLabels, Integer> result, HeaderLabels labels, int condition) {
        Integer previous = result.get(labels);
        if (previous == null) {
            result.put(labels, condition);
            return;
        }
        int merged = NDD.ref(NDD.or(previous, condition));
        NDD.deref(previous);
        NDD.deref(condition);
        result.put(labels, merged);
    }

    private static final class HeaderLabels {
        final int[] labels;

        HeaderLabels(int[] labels) {
            this.labels = labels;
        }

        @Override
        public boolean equals(Object other) {
            return other instanceof HeaderLabels && Arrays.equals(labels, ((HeaderLabels) other).labels);
        }

        @Override
        public int hashCode() {
            return Arrays.hashCode(labels);
        }
    }

    //
    // /**
    // * get prefix-specific failure max
    // * prefix vars first
    // */
    // public Map<Header, Integer> getHeaderFailureMax(int predicate) {
    // Map<Header, Integer> ret = new HashMap<>();
    // Map<Header, Integer> tmp = splitHeaderTC(predicate);
    // tmp.forEach((prefix, tc) -> ret.put(prefix,
    // manager.bddTCWrapper.getTCFailureMax(tc)));
    // return ret;
    // }
}
