# SRE

SRE 是一个面向网络配置验证的 Symbolic Router Execution 基准平台。本仓库基于
SIGCOMM 2022 论文 *Symbolic Router Execution* 的实验代码，当前用于研究 NDD
（Network Decision Diagram）的多后端与混合后端设计。

本仓库只保留最新版的 SoA NDD 实现。研究重点不再是历史 NDD 实现之间的对比，而是
在相同 SRE 工作负载、相同域划分和相同变量顺序下，对比 BDD、补边 BDD（BCDD）和
普通 set-family ZDD 标签后端。

## NDD 后端

NDD 的宏观节点使用 Structure of Arrays 存储，边标签可按域选择以下逻辑域一致的后端：

- `BDD`：标准二叉决策图。
- `COMPLEMENTED_BDD`：使用补边的 BDD（简称 BCDD）。
- `ZDD`：普通 set-family ZDD；仓库不包含 finite-domain ZDD。

当前 SRE 驱动把域分为 Header 和 Link 两类。Header 包含五元组字段；Link 表示网络链路
状态。ZDD Link 域采用 `1=failure`，使低故障数场景对应稀疏集合；BDD/BCDD Link 域采用
`1=up`。这种极性差异只改变标签表示，不改变实验所表达的链路状态。

内置实验组如下：

| 组别 | Header 后端 | Link 后端 | Link 极性 | 参数 |
|:---:|---|---|---|---|
| A | BDD | BDD | `1=up` | `backend=a` 或 `backend=all-bdd` |
| B | BDD | ZDD | `1=failure` | `backend=b` 或 `backend=mixed` |
| D | BCDD | ZDD | `1=failure` | `backend=d` |
| E | BDD | BCDD | `1=up` | `backend=e` |
| F | BCDD | BCDD | `1=up` | `backend=f` |

默认配置是 A 组、Header-Link 域顺序和 `plan=0`。

## 仓库结构

```text
.
├── src/main/java/          # SRE 驱动与最新版多后端 NDD
├── src/test/java/          # NDD/BCDD 回归测试
├── networks/               # 网络配置与拓扑数据集
├── run.sh                  # 单次实验入口
├── run_backend_matrix.sh   # 后端矩阵重复实验
└── results/                # 本地结果（不提交到 Git）
```

## 环境要求

- Linux（运行脚本通过 `/proc` 采样 JVM 峰值 RSS）
- Java 11 或更高版本
- Maven 3.x 或 4.x
- Bash

内存需求取决于数据集、MF 和后端。建议显式设置 JVM 堆上限，并保证系统仍有足够空间
用于 JVM native memory、页缓存和其他进程。当前 BCDD 容量参数针对 fattree08/fattree12
的实验规模做了预分配优化。

## 构建与测试

```bash
# 构建并运行回归测试
mvn test

# 构建可执行 JAR
mvn package
```

NDD 源码已经内置在本仓库中，不需要安装旧版 `org.ants:ndd` JAR。

## 运行单组实验

```bash
# 用法：./run.sh <dataset> <mf> [heap_mb]

# 默认：A 组、Header-Link、plan=0、12 GB heap
./run.sh bgp_fattree08 3

# A 组，全 BDD
NDD_ARGS='backend=a order=header-link plan=1' \
  ./run.sh bgp_fattree08 3 12288

# B 组，Header-BDD / Link-ZDD
NDD_ARGS='backend=b order=header-link plan=1' \
  ./run.sh bgp_fattree08 3 12288

# D 组，Header-BCDD / Link-ZDD
NDD_ARGS='backend=d order=header-link plan=1' \
  ./run.sh bgp_fattree12 2 14336
```

可选参数：

- `backend=a|b|d|e|f`：选择上表中的实验组。
- `order=header-link|link-header`：选择 NDD 物理域顺序。`header-link` 是正常实验顺序；
  `link-header` 仅用于研究域顺序影响的对照实验。
- `plan=0|1|2`：SRE 的节点表容量方案。同一组对比必须使用相同 plan；当前后端容量优化
  主要在 `plan=1` 下生效。
- `filter`、`notrim`：沿用 SRE 的过滤与裁剪开关。

设置 `SKIP_BUILD=1` 可以复用已有编译结果，适合连续实验：

```bash
SKIP_BUILD=1 NDD_ARGS='backend=e order=header-link plan=1' \
  ./run.sh bgp_fattree08 3 12288
```

## 运行后端矩阵

```bash
# 用法：./run_backend_matrix.sh <dataset> <mf> [repetitions] [heap_mb] [profiles]

# A/B/D/E/F 各运行 3 次
./run_backend_matrix.sh bgp_fattree08 3 3 12288 'a b d e f'

# 只比较包含 BCDD Link 的 E/F 组，各运行 5 次
./run_backend_matrix.sh bgp_fattree12 2 5 14336 'e f'
```

矩阵脚本固定使用 Header-Link 与 `plan=1`，并在所有重复实验前只构建一次。

## 输出与可比性

每次运行会生成：

- `results/<dataset>_mf<mf>_<timestamp>.txt`：运行环境、参数和汇总。
- `results/<dataset>_mf<mf>_<timestamp>_ndd.log`：完整程序输出。

主要指标包括：

| 指标 | 含义 |
|---|---|
| `init` / `src` / `spf` / `mine` / `exit` | 各阶段耗时（秒） |
| `total` | 端到端总耗时（秒） |
| `memory` | 两次显式 GC 后的 Java heap 净增量 |
| `peak_rss_kb` | 由运行脚本从 `/proc` 采样的进程峰值 RSS |
| `ndd_nodes_created` / `ndd_nodes_alive` | 宏观 NDD 节点累计创建数与存活数 |
| `label_nodes_alive_*` | 各标签后端的存活节点数 |
| `label_nodes_created_*` | 各标签后端的累计创建节点数 |
| `bcdd_*` | BCDD 表容量、GC、扩容和 apply cache 指标 |
| `link_variable_order_hash` | Link 变量顺序指纹，用于确认对比组变量顺序一致 |
| `ndd_field_layout` | 域顺序、位宽和后端布局 |

做后端对比时，应固定数据集、MF、域顺序、`plan`、heap、Link 变量排序策略、JDK、主机负载
和代码版本。首先核对 BGP 路由数、域布局和变量顺序指纹一致，再比较耗时、RSS 与节点数。
建议每组至少运行三次，报告中位数，同时保留单次结果以观察 GC 和扩容造成的离散程度。

## 数据集

实验数据位于 `networks/`。当前后端研究主要使用：

- `bgp_fattree08`：80 个路由器、320 条链路。
- `bgp_fattree12`：180 个路由器、1080 条链路。

程序运行产生的 `OutBDD/`、`OutNDD/`、`out/` 和 `results/` 不纳入版本控制。

## 当前 Java NDD 与并行 native NDD

`parallel-ndd` 分支将 Config2Spec F 组迁移到当前 NDD 库，并通过
`-Dsre.ndd.engine=java|native` 选择 Java 或 C/JNI 引擎。native 支持
`-Dsre.ndd.workers=1|6`；本次比较保留 Header-Link 顺序、原始 trim 和
LSB 优先的 BCDD 变量顺序。构建、引用适配与复现脚本见
[并行 NDD 使用说明](experiments/parallel-ndd/README.md)。
